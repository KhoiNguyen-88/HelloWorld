/*<BASDKey>
 ***********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2017. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 ***********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:$
 * $Namespace_:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 ***********************************************************************************************************************
</BASDKey>*/


#include "TestCd_rba_Msc.h"

#include "rba_Msc.h"
#include "rba_Msc_Prv.h"

// file content shall only be compiled if MSC is configured
#ifdef RBA_MSC_CFG_MSC_IS_CONFIGURED
#include "rba_Msc_Cfg_Prv.h"
#include "Mcu.h"
#include "rba_Gtm.h"

#include "rba_Msc_Cfg_SchM.h"

TestCd_rba_Msc_stTest_ten       TestCd_rba_Msc_stTest_en    = TestCd_rba_Msc_Init_e;    // initialize in 1st cycle
TestCd_rba_Msc_stIsrTest_ten    TestCd_rba_Msc_stIsrTest_en = TestCd_rba_Msc_IsrIdle_e;
TestCd_rba_Msc_stItfTest_ten    TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;

TestCd_rba_Msc_xItfTest_tst     TestCd_rba_Msc_xItfTest_st;

// constants needed by ITF
// -> since these constants are not used in the code it is necessary to make them volatile and add a dummy read
// -> otherwise the constants may be removed by the compiler/linker (first observed with Tasking compiler/linker)
#if (RBA_MSC_CFG_DEV_ERR_DET == STD_ON)
const volatile boolean TestCd_rba_Msc_isDetReportEnabled_cb = TRUE;
#else
const volatile boolean TestCd_rba_Msc_isDetReportEnabled_cb = FALSE;
#endif

#if (RBA_MSC_CFG_ASYNC_MODE == STD_ON)
const volatile boolean TestCd_rba_Msc_isAsyncModeEnabled_cb = TRUE;
#else
const volatile boolean TestCd_rba_Msc_isAsyncModeEnabled_cb = FALSE;
#endif


boolean TestCd_rba_Msc_stMux_b;
boolean TestCd_rba_Msc_stSig_b;

uint32  TestCd_rba_Msc_cntPutYourBreakPointHere_u32;

uint32  TestCd_rba_Msc_cntCmd1Notif_u32 = 0uL;
uint32  TestCd_rba_Msc_cntCmd2Notif_u32 = 0uL;
uint32  TestCd_rba_Msc_cntCmd3Notif_u32 = 0uL;
uint32  TestCd_rba_Msc_cntCmd4Notif_u32 = 0uL;
#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5
uint32  TestCd_rba_Msc_cntCmd5Notif_u32 = 0uL;
#endif
#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd6
uint32  TestCd_rba_Msc_cntCmd6Notif_u32 = 0uL;
#endif
#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd7
uint32  TestCd_rba_Msc_cntCmd7Notif_u32 = 0uL;
#endif
#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8
uint32  TestCd_rba_Msc_cntCmd8Notif_u32 = 0uL;
#endif
#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd9
uint32  TestCd_rba_Msc_cntCmd9Notif_u32 = 0uL;
#endif
#ifdef rba_MscConf_rba_Msc_Seq_TestCd_rba_Msc_Seq0
uint32  TestCd_rba_Msc_cntSeq0Notif_u32 = 0uL;
#endif
uint32  TestCd_rba_Msc_tiBackgroundProc_u32;
uint32  TestCd_rba_Msc_tiWaistTimeProc_u32;
uint32  TestCd_rba_Msc_tiDeltaBg10ms_u32;
uint32  TestCd_rba_Msc_tiWaistTimeUs_u32;
uint32  TestCd_rba_Msc_cntBackgroundProc_u32;
uint32  TestCd_rba_Msc_nrBackgroundProc_u32 = 2345uL;
// To check uninterrupatble transmission of seuqence
uint32  TestCd_rba_Msc_SeqCmpl = 0u;

#if (MCU_RB_MACHINE_DEV == MCU_RB_JDP_UC1_DEV1_ALL)
uint8   Testcd_rba_Msc_TestSignal_ID_u8 = rba_MscConf_rba_Msc_Sig_DioSignal_01;
#else
uint8   Testcd_rba_Msc_TestSignal_ID_u8 = rba_MscConf_rba_Msc_Sig_CJ950_1_100hz;
#endif

uint32  TestCd_rba_Msc_cntToggleAsyncSync_u32;

uint32  TestCd_rba_Msc_cntSwtToSyncState_aau32[RBA_MSC_CFG_NR_HWUNIT_MAX][5u];

boolean TestCd_rba_Msc_stUseBgTask_b;


void TestCd_rba_Msc_Init(void)
{
    //------------------------------------------------------------------------------------------------------------------
    // test cases for ITF
    //------------------------------------------------------------------------------------------------------------------

    // dummy read of ITF constants is necessary to prevent removal of the constants by compiler/linker optimization
    // -> this also requires the constants (and constants) to be qualified as volatile
    // -> introduced for Tasking compiler/linker
    (void)TestCd_rba_Msc_isDetReportEnabled_cb;
    (void)TestCd_rba_Msc_isAsyncModeEnabled_cb;

    //------------------------------------------------------------------------------------------------------------------
    // test steps for rba_Msc_Init() and rba_Msc_PostPort_Init()
    // -> this process must by called between rba_Msc_Init() and rba_Msc_PostPort_Init()

    // rba_Msc_Init(): check normal operation, check if after initialization the internal state is set accordingly
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfInit_e)
    {
        boolean stSig_b;

        // check initialized state
        // -> driver must be initialized but downstream must not be enabled yet and interrupt mode is not yet set
        if (   (rba_Msc_Prv_stInitialized_b)
            && (!rba_Msc_Prv_stDsEnabled_b)
#if (RBA_MSC_CFG_ASYNC_MODE == STD_ON)
            && (!rba_Msc_Prv_stInterruptMode_b)
#endif
           )
        {
            TestCd_rba_Msc_xItfTest_st.stRet = E_OK;
        }
        else
        {
            TestCd_rba_Msc_xItfTest_st.stRet = E_NOT_OK;
        }

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;

        // check if signal and multiplexer APIs can be called here without problems
        //--------------------------------------------------------------------------------------------------------------
        // run into breakpoint to be able to set next sub-step of test step
        TestCd_rba_Msc_PutYourBreakPointHere();

        TestCd_rba_Msc_xItfTest_st.stRet = E_OK;

        // get current multiplexer setting
        TestCd_rba_Msc_xItfTest_st.stRet |= rba_Msc_GetMux(Testcd_rba_Msc_TestSignal_ID_u8,
                                                           &TestCd_rba_Msc_stMux_b);

        // set multiplexer to internal
        TestCd_rba_Msc_xItfTest_st.stRet |= rba_Msc_SetMux(Testcd_rba_Msc_TestSignal_ID_u8, RBA_MSC_MUX_INT);

        // get current signal setting
        TestCd_rba_Msc_xItfTest_st.stRet |= rba_Msc_GetSigVal(Testcd_rba_Msc_TestSignal_ID_u8,
                                                              &TestCd_rba_Msc_stSig_b);

        // invert current signal setting
        if (TestCd_rba_Msc_stSig_b == FALSE)
        {
            stSig_b = TRUE;
        }
        else
        {
            stSig_b = FALSE;
        }

        // set inverted signal
        TestCd_rba_Msc_xItfTest_st.stRet |= rba_Msc_SetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, stSig_b);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;

        // check if signal and multiplexer setting is still as expected after initialization is complete
        //--------------------------------------------------------------------------------------------------------------
        // run into breakpoint to be able to set next sub-step of test step
        // -> test step is continued in cyclic 10ms task
        TestCd_rba_Msc_PutYourBreakPointHere();
    }
}


void TestCd_rba_Msc_10ms(void)
{
    // test cases for manual test

    if (TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_Init_e)
    {
        (void)rba_Msc_SetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, 1u);
        (void)rba_Msc_SetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, 0x33u);    // read ID

        (void)rba_Msc_SetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd2, 2u);
        (void)rba_Msc_SetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd2, 0xD3u);

        (void)rba_Msc_SetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd3, 3u);
        (void)rba_Msc_SetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd3, 0x1510u);

        (void)rba_Msc_SetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd4, 4u);
        (void)rba_Msc_SetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd4, 0x1E10u);

#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5
        (void)rba_Msc_SetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5, 1u);
        (void)rba_Msc_SetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5, 0x33u);    // read ID
#endif

#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd6
        (void)rba_Msc_SetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd6, 2u);
        (void)rba_Msc_SetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd6, 0xD3u);
#endif

#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd7
        (void)rba_Msc_SetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd7, 3u);
        (void)rba_Msc_SetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd7, 0x1510u);
#endif

#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8
        (void)rba_Msc_SetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8, 4u);
        (void)rba_Msc_SetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8, 0x1E10u);
#endif

        TestCd_rba_Msc_stTest_en = TestCd_rba_Msc_Idle_e;
    }

    if (TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_InitCj950_e)
    {
        rba_Msc_xCmdResult_ten xCmdResult_en;

        // initialization of CJ950_01

        // use TestCd_rba_Msc_Cmd1 to initialize CJ950_01
        (void)rba_Msc_SetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, 0u);
        (void)rba_Msc_SetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, 0x1E6Du);  // CONREG4 = 0xF3 (divident 32)
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1);

        // wait until the command is sent
        do
        {
            (void)rba_Msc_GetCmdResult(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, &xCmdResult_en);
        }
        while(xCmdResult_en == rba_Msc_CmdPending_e);

        (void)rba_Msc_SetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, 0x000Bu);  // WR_START enable power stages
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1);

        // wait until the command is sent
        do
        {
            (void)rba_Msc_GetCmdResult(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, &xCmdResult_en);
        }
        while(xCmdResult_en == rba_Msc_CmdPending_e);

        // restore TestCd_rba_Msc_Cmd1
        (void)rba_Msc_SetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, 1u);
        (void)rba_Msc_SetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, 0x33u);    // read ID

#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5
        // initialization of CJ950_02

        // use TestCd_rba_Msc_Cmd5 to initialize CJ950_02
        (void)rba_Msc_SetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5, 0u);
        (void)rba_Msc_SetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5, 0x1E6Du);  // CONREG4 = 0xF3 (divident 32)
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5);

        // wait until the command is sent
        do
        {
            (void)rba_Msc_GetCmdResult(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5, &xCmdResult_en);
        }
        while(xCmdResult_en == rba_Msc_CmdPending_e);

        (void)rba_Msc_SetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5, 0x000Bu);  // WR_START enable power stages
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5);

        // wait until the command is sent
        do
        {
            (void)rba_Msc_GetCmdResult(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5, &xCmdResult_en);
        }
        while(xCmdResult_en == rba_Msc_CmdPending_e);

        // restore TestCd_rba_Msc_Cmd5
        (void)rba_Msc_SetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5, 1u);
        (void)rba_Msc_SetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5, 0x33u);    // read ID
#endif

        TestCd_rba_Msc_stTest_en = TestCd_rba_Msc_Idle_e;
    }

    if (   (TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_ChkTrfSng_e)
        || (TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_ChkTrfContns_e))
    {
        // send commands of CJ950_01

        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1);

        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd2);

        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd3);

        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd4);

        // send commands of CJ950_02

#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5);
#endif

#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd6
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd6);
#endif

#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd7
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd7);
#endif

#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8);
#endif

        if (TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_ChkTrfSng_e)
        {
            TestCd_rba_Msc_stTest_en = TestCd_rba_Msc_Idle_e;
        }
    }

    if (TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_ChkMuxToggleCj950100Hz_e)
    {
        boolean stMux_b;

        (void)rba_Msc_GetMux(Testcd_rba_Msc_TestSignal_ID_u8, &stMux_b);

        if (stMux_b == RBA_MSC_MUX_EXT)
        {
            stMux_b = RBA_MSC_MUX_INT;
        }
        else
        {
            stMux_b = RBA_MSC_MUX_EXT;
        }

        (void)rba_Msc_SetMux(Testcd_rba_Msc_TestSignal_ID_u8, stMux_b);

        TestCd_rba_Msc_stTest_en = TestCd_rba_Msc_Idle_e;
    }

    if (TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_ChkMuxSetIntCj950100Hz_e)
    {
        (void)rba_Msc_SetMux(Testcd_rba_Msc_TestSignal_ID_u8, RBA_MSC_MUX_INT);

        TestCd_rba_Msc_stTest_en = TestCd_rba_Msc_Idle_e;
    }

    if (TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_ChkSigToggleCj950100Hz_e)
    {
        boolean stSig_b;

        (void)rba_Msc_GetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, &stSig_b);

        if (stSig_b == FALSE)
        {
            stSig_b = TRUE;
        }
        else
        {
            stSig_b = FALSE;
        }

        (void)rba_Msc_SetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, stSig_b);

        TestCd_rba_Msc_stTest_en = TestCd_rba_Msc_Idle_e;
    }

    if (TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_ChkSigSetTrueCj950100Hz_e)
    {
        (void)rba_Msc_SetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, TRUE);

        TestCd_rba_Msc_stTest_en = TestCd_rba_Msc_Idle_e;
    }

    if (TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_ChkSigSetFalseCj950100Hz_e)
    {
        (void)rba_Msc_SetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, FALSE);

        TestCd_rba_Msc_stTest_en = TestCd_rba_Msc_Idle_e;
    }

#ifdef rba_MscConf_rba_Msc_Sig_A_P_AVS_CHL0_NORM
    if (TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_ChkMuxToggleNorm_e)
    {
        boolean stMux_b;

        (void)rba_Msc_GetMux(rba_MscConf_rba_Msc_Sig_A_P_AVS_CHL0_NORM, &stMux_b);

        if (stMux_b == RBA_MSC_MUX_EXT)
        {
            stMux_b = RBA_MSC_MUX_INT;
        }
        else
        {
            stMux_b = RBA_MSC_MUX_EXT;
        }

        (void)rba_Msc_SetMux(rba_MscConf_rba_Msc_Sig_A_P_AVS_CHL0_NORM, stMux_b);

        TestCd_rba_Msc_stTest_en = TestCd_rba_Msc_Idle_e;
    }
#endif

#ifdef rba_MscConf_rba_Msc_Sig_A_P_AVS_CHL0_SPEC
    if (TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_ChkMuxToggleSpec_e)
    {
        boolean stMux_b;

        (void)rba_Msc_GetMux(rba_MscConf_rba_Msc_Sig_A_P_AVS_CHL0_SPEC, &stMux_b);

        if (stMux_b == RBA_MSC_MUX_EXT)
        {
            stMux_b = RBA_MSC_MUX_INT;
        }
        else
        {
            stMux_b = RBA_MSC_MUX_EXT;
        }

        (void)rba_Msc_SetMux(rba_MscConf_rba_Msc_Sig_A_P_AVS_CHL0_SPEC, stMux_b);

        TestCd_rba_Msc_stTest_en = TestCd_rba_Msc_Idle_e;
    }
#endif

    if (TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_ShDwn_e)
    {
#if (RBA_MSC_CFG_ASYNC_MODE == STD_ON)
        rba_Msc_ShDwn();
        TestCd_rba_Msc_stTest_en = TestCd_rba_Msc_Idle_e;
#endif
    }

    if (TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_SwtToIntrpt_e)
    {
#if (RBA_MSC_CFG_ASYNC_MODE == STD_ON)
        rba_Msc_End_Init();
        TestCd_rba_Msc_stTest_en = TestCd_rba_Msc_Idle_e;
#endif
    }

    if (TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_SwtToSync_e)
    {
#if (RBA_MSC_CFG_ASYNC_MODE == STD_ON)
        // lock is required to be able to run this test during drive
        // -> API may only be called with disabled interrupts
        SchM_Enter_rba_Msc_Driver();

        rba_Msc_SwtToSync();

        SchM_Exit_rba_Msc_Driver();

        TestCd_rba_Msc_stTest_en = TestCd_rba_Msc_Idle_e;
#endif
    }

    if (TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_ToggleAsyncSync_e)
    {
#if (RBA_MSC_CFG_ASYNC_MODE == STD_ON)
        if (TestCd_rba_Msc_cntToggleAsyncSync_u32 == 4uL)
        {
            SchM_Enter_rba_Msc_Driver();

            rba_Msc_End_Init();

            SchM_Exit_rba_Msc_Driver();
        }

        if (TestCd_rba_Msc_cntToggleAsyncSync_u32 > 7uL)
        {
            uint32 idxHwUnit_u32;

            // lock is required to be able to run this test during drive
            // -> API may only be called with disabled interrupts
            // -> it also must be ensured that no rba_Msc handler ISR is running anymore therefore this test will only
            //    work if this test code runs on the same core as the rba_Msc handler ISRs
            SchM_Enter_rba_Msc_Driver();

            // record current state of each HW unit
            for (idxHwUnit_u32 = 0uL; idxHwUnit_u32 < RBA_MSC_CFG_NR_HWUNIT_MAX; idxHwUnit_u32++)
            {
                // get current handler state
                rba_Msc_Prv_stHndlr_ten stHndlr_en = rba_Msc_Prv_xHwUnit_ast[idxHwUnit_u32].stHndlr_ven;

                TestCd_rba_Msc_cntSwtToSyncState_aau32[idxHwUnit_u32][stHndlr_en]++;
            }

            rba_Msc_SwtToSync();

            SchM_Exit_rba_Msc_Driver();

            TestCd_rba_Msc_cntToggleAsyncSync_u32 = 0uL;
        }

        TestCd_rba_Msc_cntToggleAsyncSync_u32++;
#endif
    }
#ifdef rba_MscConf_rba_Msc_Seq_TestCd_rba_Msc_Seq0
    if(TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_TransmitSeq_e)
    {
        (void)rba_Msc_TransmitSeq(rba_MscConf_rba_Msc_Seq_TestCd_rba_Msc_Seq0);

        rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd9);
        do
        {
            (void)rba_Msc_GetSeqResult(rba_MscConf_rba_Msc_Seq_TestCd_rba_Msc_Seq0, &TestCd_rba_Msc_xItfTest_st.stSeq_en);
        }while(TestCd_rba_Msc_xItfTest_st.stSeq_en == rba_Msc_SeqPending_e);

        TestCd_rba_Msc_stTest_en = TestCd_rba_Msc_Idle_e;
    }
#endif

    if(TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_MoInitCheck_e)
    {
        if((rba_Msc_MoInitCheck(NULL_PTR) == E_NOT_OK) && (rba_Msc_MoInitCheck(rba_Msc_Prv_PbCfg_en) == E_OK))
        {
            TestCd_rba_Msc_stTest_en = TestCd_rba_Msc_Passed_e;
        }
        else
        {
            TestCd_rba_Msc_stTest_en = TestCd_rba_Msc_Failed_e;
        }
    }

#ifdef RBA_GTM_TOM_TESTCD_RBA_MSC_GTM_CONF
    // these test cases require suitable OS ISR configuration and GTM TOM configuration
    if (TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_StrtGtmIsr_e)
    {
        // enable interrupt
        (void)rba_Gtm_SetTomReg(rba_Gtm_Tom_TestCd_rba_Msc_Gtm, RBA_GTM_TOM_CH_IRQ_EN, 1uL);

        // start GTM cell
        (void)rba_Gtm_SetTomEndisStat(rba_Gtm_Tom_TestCd_rba_Msc_Gtm, 2u);

        TestCd_rba_Msc_stTest_en = TestCd_rba_Msc_Idle_e;
    }

    if (TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_StopGtmIsr_e)
    {
        // disable interrupt
        (void)rba_Gtm_SetTomReg(rba_Gtm_Tom_TestCd_rba_Msc_Gtm, RBA_GTM_TOM_CH_IRQ_EN, 0uL);

        TestCd_rba_Msc_stTest_en = TestCd_rba_Msc_Idle_e;
    }
#endif

#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd_L9779_Dia1
    if (TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_SingleRead_e)
    {
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd_L9779_Unlock);
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd_L9779_WR_CONFIG4);
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd_L9779_Lock);
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd_L9779_RD_DATA5);
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd_L9779_Dia1);
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd_L9779_Dia2);
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd_L9779_Dia3);
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd_L9779_Dia4);
    }
#endif


    //------------------------------------------------------------------------------------------------------------------
    // test cases for ITF
    //------------------------------------------------------------------------------------------------------------------

    //------------------------------------------------------------------------------------------------------------------
    // test steps for rba_Msc_Init()

    // rba_Msc_Init(): check normal operation, check if after initialization the internal state is set accordingly
    // -> at this stage also rba_Msc_PostPort_Init() and rba_Msc_End_Init() are called
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfInit_e)
    {
        // check initialized state
        // -> driver must be fully initialized
        if (   (rba_Msc_Prv_stInitialized_b)
            && (rba_Msc_Prv_stDsEnabled_b)
#if (RBA_MSC_CFG_ASYNC_MODE == STD_ON)
            && (rba_Msc_Prv_stInterruptMode_b)
#endif
           )
        {
            TestCd_rba_Msc_xItfTest_st.stRet = E_OK;
        }
        else
        {
            TestCd_rba_Msc_xItfTest_st.stRet = E_NOT_OK;
        }

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;

        // check if signal and multiplexer are still set in the expected way
        //--------------------------------------------------------------------------------------------------------------
        // run into breakpoint to be able to set next sub-step of test step
        TestCd_rba_Msc_PutYourBreakPointHere();

        {
            boolean stMux_b;
            boolean stSig_b;

            // get current multiplexer setting
            (void)rba_Msc_GetMux(Testcd_rba_Msc_TestSignal_ID_u8, &stMux_b);

            // get current signal setting
            (void)rba_Msc_GetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, &stSig_b);

            // check values
            if ((stMux_b == RBA_MSC_MUX_INT) && (stSig_b != TestCd_rba_Msc_stSig_b))
            {
                TestCd_rba_Msc_xItfTest_st.stRet = E_OK;
            }
            else
            {
                TestCd_rba_Msc_xItfTest_st.stRet = E_NOT_OK;
            }
        }

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;

        // restore signal and multiplexer settings while checking for DETs and correct return value
        //--------------------------------------------------------------------------------------------------------------
        // run into breakpoint to be able to set next sub-step of test step
        TestCd_rba_Msc_PutYourBreakPointHere();

        TestCd_rba_Msc_xItfTest_st.stRet = E_OK;

        // restore signal setting
        TestCd_rba_Msc_xItfTest_st.stRet |= rba_Msc_SetSigVal(Testcd_rba_Msc_TestSignal_ID_u8,
                                                              TestCd_rba_Msc_stSig_b);

        // restore multiplexer setting
        TestCd_rba_Msc_xItfTest_st.stRet |= rba_Msc_SetMux(Testcd_rba_Msc_TestSignal_ID_u8,
                                                           TestCd_rba_Msc_stMux_b);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_Init(): check DET RBA_MSC_E_ALREADY_INITIALIZED
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfInit_Init_e)
    {
        // set config set variable to 1st config set and call init
        // -> this will trigger a DET
        /* MR12 RULE 10.5 VIOLATION: Casting 0 to rba_Msc_ConfigType is always valid. */
        rba_Msc_ConfigType xCfg_en = (rba_Msc_ConfigType)0;

        rba_Msc_Init(&xCfg_en);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_Init(): check DET RBA_MSC_E_PARAM_IS_NULL
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfInit_NullPtr_e)
    {
        // patch the initialization state to FALSE
        rba_Msc_Prv_stInitialized_b = FALSE;

        // try to call rba_Msc_Init() with a NULL_PTR as post build pointer
        rba_Msc_Init(NULL_PTR);

        // change the initialization state back to TRUE
        rba_Msc_Prv_stInitialized_b = TRUE;

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_Init(): check DET RBA_MSC_E_PARAM_PB_CFG_IDX
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfInit_InvldPbPtr_e)
    {
        // set post build pointer to number of post builds which is an invalid value
        rba_Msc_ConfigType xPbCfg_en = rba_Msc_Cfg_nrPbCfg_e;

        // patch the initialization state to FALSE
        rba_Msc_Prv_stInitialized_b = FALSE;

        // try to call rba_Msc_Init() with an invalid post build pointer
        rba_Msc_Init(&xPbCfg_en);

        // change the initialization state back to TRUE
        rba_Msc_Prv_stInitialized_b = TRUE;

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_PostPort_Init(): check DET RBA_MSC_E_ALREADY_INITIALIZED
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfInitPostPort_Init_e)
    {
        // try to call rba_Msc_PostPort_Init() again
        rba_Msc_PostPort_Init();

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_PostPort_Init(): check DET RBA_MSC_E_UNINIT
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfInitPostPort_UnInit_e)
    {
        // patch the initialization states to FALSE
        rba_Msc_Prv_stInitialized_b = FALSE;
        rba_Msc_Prv_stDsEnabled_b   = FALSE;

        // try to call rba_Msc_PostPort_Init()
        rba_Msc_PostPort_Init();

        // change the initialization states back to TRUE
        rba_Msc_Prv_stInitialized_b = TRUE;
        rba_Msc_Prv_stDsEnabled_b   = TRUE;

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_End_Init(): check DET RBA_MSC_E_ALREADY_INITIALIZED
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfInitEndInit_Init_e)
    {
#if (RBA_MSC_CFG_ASYNC_MODE == STD_ON)
        // try to call rba_Msc_End_Init() again
        rba_Msc_End_Init();

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
#else
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfTestNotTestable_e;
#endif
    }

    // rba_Msc_End_Init(): check DET RBA_MSC_E_UNINIT
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfInitEndInit_UnInit_e)
    {
#if (RBA_MSC_CFG_ASYNC_MODE == STD_ON)
        // patch the downstream enabled state and interrupt mode to FALSE
        rba_Msc_Prv_stDsEnabled_b     = FALSE;
        rba_Msc_Prv_stInterruptMode_b = FALSE;

        // try to call rba_Msc_End_Init()
        rba_Msc_End_Init();

        // change the downstream enabled state and interrupt mode back to TRUE
        rba_Msc_Prv_stDsEnabled_b     = TRUE;
        rba_Msc_Prv_stInterruptMode_b = TRUE;

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
#else
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfTestNotTestable_e;
#endif
    }

    //------------------------------------------------------------------------------------------------------------------
    // test steps for rba_Msc_GetCmdResult()

    // rba_Msc_GetCmdResult(): check normal operation
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetCmdRes_e)
    {
        // transmit the command
        // -> return value of rba_Msc_Transmit() is not checked
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1);

        // call rba_Msc_GetCmdResult() and check its return value
        // -> command is expected to be still pending since it is just sent above (rba_Msc_CmdPending_e)
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetCmdResult(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1,
                                                                &TestCd_rba_Msc_xItfTest_st.stCmd_en);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_GetCmdResult(): check DET RBA_MSC_E_PARAM_IS_NULL
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetCmdRes_NullPtr_e)
    {
        // try to get command result for a valid command index but do not pass a valid result pointer
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetCmdResult(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1,
                                                                NULL_PTR);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_GetCmdResult(): check DET RBA_MSC_E_UNINIT
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetCmdRes_UnInit_e)
    {
        // patch the initialization state to FALSE
        rba_Msc_Prv_stInitialized_b = FALSE;

        // try to get command result
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetCmdResult(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1,
                                                                &TestCd_rba_Msc_xItfTest_st.stCmd_en);

        // change the initialization state back to TRUE
        rba_Msc_Prv_stInitialized_b = TRUE;

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_GetCmdResult(): check DET RBA_MSC_E_PARAM_CMD_IDX
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetCmdRes_InvldCmd_e)
    {
        // try to get command result for an invalid command index
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetCmdResult(RBA_MSC_CFG_NR_CMD_MAX,
                                                                &TestCd_rba_Msc_xItfTest_st.stCmd_en);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    //------------------------------------------------------------------------------------------------------------------
    // test steps for rba_Msc_SetNrUsFrm()

    // rba_Msc_SetNrUsFrm(): check normal operation
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfSetNrUsFrm_e)
    {
        uint32 nrUsFrmBackup_u32;

#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8
        // get current number of upstream frames to restore it later
        (void)rba_Msc_GetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8, &nrUsFrmBackup_u32);

        // set test number of upstream frames for the given command index
        // -> this is the actual test call
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_SetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8, 2u);

        // get the number of upstream frames to verify if the set operation above worked properly
        (void)rba_Msc_GetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8, &TestCd_rba_Msc_xItfTest_st.nrUsFrm_u32);

        // restore original number of upstream frames
        (void)rba_Msc_SetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8, nrUsFrmBackup_u32);
#else
        // get current number of upstream frames to restore it later
        (void)rba_Msc_GetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, &nrUsFrmBackup_u32);

        // set test number of upstream frames for the given command index
        // -> this is the actual test call
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_SetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, 2u);

        // get the number of upstream frames to verify if the set operation above worked properly
        (void)rba_Msc_GetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, &TestCd_rba_Msc_xItfTest_st.nrUsFrm_u32);

        // restore original number of upstream frames
        (void)rba_Msc_SetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, nrUsFrmBackup_u32);
#endif

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_SetNrUsFrm(): check DET RBA_MSC_E_UNINIT
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfSetNrUsFrm_UnInit_e)
    {
        // patch the initialization state to FALSE
        rba_Msc_Prv_stInitialized_b = FALSE;

        // try to set number of upstream frames for a valid command index
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_SetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, 0u);

        // change the initialization state back to TRUE
        rba_Msc_Prv_stInitialized_b = TRUE;

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_SetNrUsFrm(): check DET RBA_MSC_E_PARAM_CMD_IDX
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfSetNrUsFrm_InvldCmd_e)
    {
        // try to set number of upstream frames for an invalid command index
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_SetNrUsFrm(RBA_MSC_CFG_NR_CMD_MAX, 0u);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_SetNrUsFrm(): check DET RBA_MSC_E_PARAM_NR_US_FRM
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfSetNrUsFrm_UsMax_e)
    {
        // try to set number of upstream frames for a valid command index but use an invalid number of upstream frames
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_SetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1,
                                                              TESTCD_RBA_MSC_INVALID_US_NUM);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    //------------------------------------------------------------------------------------------------------------------
    // test steps for rba_Msc_GetNrUsFrm()

    // rba_Msc_GetNrUsFrm(): normal operation
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetNrUsFrm_e)
    {
        // set a valid command index used for the test
        // -> used in the test script to validate the return value
        TestCd_rba_Msc_xItfTest_st.idxCmd_uo = rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1;

        // get the number of upstream frames set for the given command
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetNrUsFrm(TestCd_rba_Msc_xItfTest_st.idxCmd_uo,
                                                               &TestCd_rba_Msc_xItfTest_st.nrUsFrm_u32);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_GetNrUsFrm(): check DET RBA_MSC_E_UNINIT
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetNrUsFrm_UnInit_e)
    {
        // patch the initialization state to FALSE
        rba_Msc_Prv_stInitialized_b = FALSE;

        // try to get number of upstream frames for a valid command index
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1,
                                                              &TestCd_rba_Msc_xItfTest_st.nrUsFrm_u32);

        // change the initialization state back to TRUE
        rba_Msc_Prv_stInitialized_b = TRUE;

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_GetNrUsFrm(): check DET RBA_MSC_E_PARAM_IS_NULL
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetNrUsFrm_NullPtr_e)
    {
        // try to get number of upstream frames for a valid command index but do not pass a valid result pointer
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetNrUsFrm(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1,
                                                                NULL_PTR);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_GetNrUsFrm(): check DET RBA_MSC_E_PARAM_CMD_IDX
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetNrUsFrm_InvldCmd_e)
    {
        // try to get number of upstream frames for an invalid command index
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetNrUsFrm(RBA_MSC_CFG_NR_CMD_MAX,
                                                              &TestCd_rba_Msc_xItfTest_st.nrUsFrm_u32);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    //------------------------------------------------------------------------------------------------------------------
    // test steps for rba_Msc_SetCmdVal()

    // rba_Msc_SetCmdVal(): check normal operation
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfSetCmdVal_e)
    {
        rba_Msc_xCmdVal_tuo xCmdValBackup_uo;

        // get current command value to restore it later
        (void)rba_Msc_GetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, &xCmdValBackup_uo);

        // set test command value for the given command index
        // -> this is the actual test call
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_SetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, 0x2A5Au);

        // get the command value to verify if the set operation above worked properly
        (void)rba_Msc_GetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, &TestCd_rba_Msc_xItfTest_st.xCmdVal_uo);

        // restore original command value
        (void)rba_Msc_SetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, xCmdValBackup_uo);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_SetCmdVal(): check DET RBA_MSC_E_UNINIT
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfSetCmdVal_UnInit_e)
    {
        // patch the initialization state to FALSE
        rba_Msc_Prv_stInitialized_b = FALSE;

        // try to set the command value for a valid command index
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_SetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, 0u);

        // change the initialization state back to TRUE
        rba_Msc_Prv_stInitialized_b = TRUE;

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_SetCmdVal(): check DET RBA_MSC_E_PARAM_CMD_IDX
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfSetCmdVal_InvldCmd_e)
    {
        // try to get the command value for an invalid command index
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_SetCmdVal(RBA_MSC_CFG_NR_CMD_MAX, 0u);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    //------------------------------------------------------------------------------------------------------------------
    // test steps for rba_Msc_GetCmdVal()

    // rba_Msc_GetCmdVal(): check normal operation
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetCmdVal_e)
    {
        rba_Msc_xCmdVal_tuo xCmdValBackup_uo;

        // get current command value to restore it later
        (void)rba_Msc_GetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, &xCmdValBackup_uo);

        // set test command value
        // -> the test command value will be verified by the ITF script
        (void)rba_Msc_SetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, 0x15A5);

        // get the command value for the given command index
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1,
                                                             &TestCd_rba_Msc_xItfTest_st.xCmdVal_uo);

        // restore original command value
        (void)rba_Msc_SetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, xCmdValBackup_uo);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_GetCmdVal(): check DET RBA_MSC_E_UNINIT
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetCmdVal_UnInit_e)
    {
        // patch the initialization state to FALSE
        rba_Msc_Prv_stInitialized_b = FALSE;

        // try to get command value
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1,
                                                             &TestCd_rba_Msc_xItfTest_st.xCmdVal_uo);

        // change the initialization state back to TRUE
        rba_Msc_Prv_stInitialized_b = TRUE;

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_GetCmdVal(): check DET RBA_MSC_E_PARAM_IS_NULL
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetCmdVal_NullPtr_e)
    {
        // try to get command value for a valid command index but do not pass a valid result pointer
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetCmdVal(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1,
                                                             NULL_PTR);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_GetCmdVal(): check DET RBA_MSC_E_PARAM_CMD_IDX
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetCmdVal_InvldCmd_e)
    {
        // try to get the command value for an invalid command index
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetCmdVal(RBA_MSC_CFG_NR_CMD_MAX,
                                                             &TestCd_rba_Msc_xItfTest_st.xCmdVal_uo);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    //------------------------------------------------------------------------------------------------------------------
    // test steps for rba_Msc_SetSigVal()

    // rba_Msc_SetSigVal(): check normal operation with set value TRUE
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfSetSigVal_T_e)
    {
        boolean stSigBackup_b;

        // backup current signal setting to be able to restore it later
        // -> test preparation, therefore return value is not checked
        (void)rba_Msc_GetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, &stSigBackup_b);

        // set test value TRUE
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_SetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, TRUE);

        // read back the signal value for the signal index under test
        // -> validate if setting works properly
        (void)rba_Msc_GetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, &TestCd_rba_Msc_xItfTest_st.stSig_b);

        // restore signal value
        (void)rba_Msc_SetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, stSigBackup_b);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_SetSigVal(): check normal operation with set value FALSE
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfSetSigVal_F_e)
    {
        boolean stSigBackup_b;

        // backup current signal setting to be able to restore it later
        // -> test preparation, therefore return value is not checked
        (void)rba_Msc_GetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, &stSigBackup_b);

        // set test value FALSE
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_SetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, FALSE);

        // read back the signal value for the signal index under test
        // -> validate if setting works properly
        (void)rba_Msc_GetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, &TestCd_rba_Msc_xItfTest_st.stSig_b);

        // restore signal value
        (void)rba_Msc_SetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, stSigBackup_b);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_SetSigVal(): check DET RBA_MSC_E_UNINIT
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfSetSigVal_UnInit_e)
    {
        // patch the initialization state to FALSE
        rba_Msc_Prv_stInitialized_b = FALSE;

        // try to set the signal value for a valid signal index
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_SetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, FALSE);

        // change the initialization state back to TRUE
        rba_Msc_Prv_stInitialized_b = TRUE;

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_SetSigVal(): check DET RBA_MSC_E_PARAM_SIG_IDX
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfSetSigVal_InvldSig_e)
    {
        // try to set the signal value for an invalid signal index
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_SetSigVal(RBA_MSC_CFG_NR_SIG_MAX, FALSE);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    //------------------------------------------------------------------------------------------------------------------
    // test steps for rba_Msc_GetSigVal()

    // rba_Msc_GetSigVal(): check normal operation with set value TRUE
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetSigVal_T_e)
    {
        boolean stSigBackup_b;

        // backup current signal setting to be able to restore it later
        // -> test preparation, therefore return value is not checked
        (void)rba_Msc_GetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, &stSigBackup_b);

        // set test value TRUE
        // -> test preparation, therefore return value is not checked
        (void)rba_Msc_SetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, TRUE);

        // get the signal value for the signal index under test
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetSigVal(Testcd_rba_Msc_TestSignal_ID_u8,
                                                             &TestCd_rba_Msc_xItfTest_st.stSig_b);

        // restore signal value
        (void)rba_Msc_SetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, stSigBackup_b);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_GetSigVal(): check normal operation with set value FALSE
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetSigVal_F_e)
    {
        boolean stSigBackup_b;

        // backup current signal setting to be able to restore it later
        // -> test preparation, therefore return value is not checked
        (void)rba_Msc_GetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, &stSigBackup_b);

        // set test value FALSE
        // -> test preparation, therefore return value is not checked
        (void)rba_Msc_SetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, FALSE);

        // get the signal value for the signal index under test
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetSigVal(Testcd_rba_Msc_TestSignal_ID_u8,
                                                             &TestCd_rba_Msc_xItfTest_st.stSig_b);

        // restore signal value
        (void)rba_Msc_SetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, stSigBackup_b);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_GetSigVal(): check DET RBA_MSC_E_UNINIT
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetSigVal_UnInit_e)
    {
        // patch the initialization state to FALSE
        rba_Msc_Prv_stInitialized_b = FALSE;

        // try to get the signal value for a valid signal index
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetSigVal(Testcd_rba_Msc_TestSignal_ID_u8,
                                                             &TestCd_rba_Msc_xItfTest_st.stSig_b);

        // change the initialization state back to TRUE
        rba_Msc_Prv_stInitialized_b = TRUE;

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_GetSigVal(): check DET RBA_MSC_E_PARAM_SIG_IDX
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetSigVal_InvldSig_e)
    {
        // try to get the signal value for an invalid signal index
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetSigVal(RBA_MSC_CFG_NR_SIG_MAX,
                                                             &TestCd_rba_Msc_xItfTest_st.stSig_b);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_GetSigVal(): check DET RBA_MSC_E_PARAM_IS_NULL
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetSigVal_NullPtr_e)
    {
        // try to get the signal value for a valid signal index but do not pass a valid result pointer
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetSigVal(Testcd_rba_Msc_TestSignal_ID_u8, NULL_PTR);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    //------------------------------------------------------------------------------------------------------------------
    // test steps for rba_Msc_Transmit()

    // rba_Msc_Transmit(): check normal operation (interrupt/queue mode)
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfTransmit_e)
    {
        // transmit a valid command
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd4);

        // read command state, expect rba_Msc_CmdPending_e
        // -> return value of rba_Msc_GetCmdResult() is not evaluated by this test case
        (void)rba_Msc_GetCmdResult(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd4, &TestCd_rba_Msc_xItfTest_st.stCmd_en);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_Transmit(): check normal operation (interrupt/queue mode) with Timeout error
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfTransmit_TimeoutError_e)
    {
#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8
        uint8 BackUsBuf_u8;

        BackUsBuf_u8 = rba_Msc_Prv_xCmd_ast[rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8].nrUsFrm_u8;

        // set a value which causing a Timeout Error
        rba_Msc_Prv_xCmd_ast[rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8].nrUsFrm_u8 = 6u;

        // transmit a command causing a Timeout Error
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8);

        // wait until the command is sent
        do
        {
            (void)rba_Msc_GetCmdResult(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8, &TestCd_rba_Msc_xItfTest_st.stCmd_en);
        }
        while(TestCd_rba_Msc_xItfTest_st.stCmd_en == rba_Msc_CmdPending_e);

        // read command state, expect rba_Msc_CmdFailed_e
        // -> return value of rba_Msc_GetCmdResult() is not evaluated by this test case
        (void)rba_Msc_GetCmdResult(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8, &TestCd_rba_Msc_xItfTest_st.stCmd_en);

        rba_Msc_Prv_xCmd_ast[rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8].nrUsFrm_u8 = BackUsBuf_u8;

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
#endif
    }

    // rba_Msc_Transmit(): check normal operation (polling mode)
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfTransmit_TimeoutError_PollingMode_e)
    {
#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8
        uint8 BackUsBuf_u8;

#if (RBA_MSC_CFG_ASYNC_MODE == STD_ON)
        // switch to polling mode
        rba_Msc_ShDwn();
#endif

        BackUsBuf_u8 = rba_Msc_Prv_xCmd_ast[rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8].nrUsFrm_u8;

        // set a value which causing a Timeout Error
        rba_Msc_Prv_xCmd_ast[rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8].nrUsFrm_u8 = 6u;

        // transmit a command causing a Timeout Error
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8);

        // read command state, expect rba_Msc_CmdFailed_e
        // -> return value of rba_Msc_GetCmdResult() is not evaluated by this test case
        (void)rba_Msc_GetCmdResult(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8, &TestCd_rba_Msc_xItfTest_st.stCmd_en);

        rba_Msc_Prv_xCmd_ast[rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8].nrUsFrm_u8 = BackUsBuf_u8;

#if (RBA_MSC_CFG_ASYNC_MODE == STD_ON)
        // switch back to interrupt mode
        rba_Msc_End_Init();
#endif

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
#endif
    }

    // rba_Msc_Transmit(): check normal operation (polling mode)
        if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfTransmit_PollingMode_e)
        {
    #if (RBA_MSC_CFG_ASYNC_MODE == STD_ON)
            // switch to polling mode
            rba_Msc_ShDwn();
    #endif

            // transmit a valid command
            TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1);

            // read command state, expect rba_Msc_CmdOk_e
            // -> return value of rba_Msc_GetCmdResult() is not evaluated by this test case
            (void)rba_Msc_GetCmdResult(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, &TestCd_rba_Msc_xItfTest_st.stCmd_en);

    #if (RBA_MSC_CFG_ASYNC_MODE == STD_ON)
            // switch back to interrupt mode
            rba_Msc_End_Init();
    #endif

            // reset TestCd state
            TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
        }



    // rba_Msc_Transmit(): check DET RBA_MSC_E_UNINIT
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfTransmit_UnInit_e)
    {
        // patch the initialization state to FALSE
        rba_Msc_Prv_stDsEnabled_b = FALSE;

        // try to transmit a valid command
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1);

        // change the initialization state back to TRUE
        rba_Msc_Prv_stDsEnabled_b = TRUE;

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_Transmit(): check DET RBA_MSC_E_PARAM_CMD_IDX
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfTransmit_InvldCmd_e)
    {
        // try to transmit an invalid command
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_Transmit(RBA_MSC_CFG_NR_CMD_MAX);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_Transmit(): check DET RBA_MSC_E_CMD_PENDING
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfTransmit_CmdPending_e)
    {
        // transmit a valid command
        // -> transmit it twice back to back, the second call will get a command pending error
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd4);
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd4);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    //------------------------------------------------------------------------------------------------------------------
    //------------------------------------------------------------------------------------------------------------------
    // test steps for rba_Msc_GetUsBuf()

    // rba_Msc_GetUsBuf(): normal operation
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetUsBuf_e)
    {
        // set a valid command index used for the test
        // -> used in the test script to validate the return value
        TestCd_rba_Msc_xItfTest_st.idxCmd_uo = rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1;

        // get the upstream buffer with valid parameters
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetUsBuf(TestCd_rba_Msc_xItfTest_st.idxCmd_uo,
                                                            &TestCd_rba_Msc_xItfTest_st.xUsBuf_pu8);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_GetUsBuf(): check DET RBA_MSC_E_PARAM_IS_NULL
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetUsBuf_NullPtr_e)
    {
        // try to get the upstream buffer for a valid command index but do not pass a valid result pointer
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetUsBuf(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, NULL_PTR);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_GetUsBuf(): check DET RBA_MSC_E_UNINIT
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetUsBuf_UnInit_e)
    {
        // patch the initialization state to FALSE
        rba_Msc_Prv_stInitialized_b = FALSE;

        // try to get the upstream buffer with valid parameters
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetUsBuf(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1,
                                                            &TestCd_rba_Msc_xItfTest_st.xUsBuf_pu8);

        // change the initialization state back to TRUE
        rba_Msc_Prv_stInitialized_b = TRUE;

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_GetUsBuf(): check DET RBA_MSC_E_PARAM_CMD_IDX
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetUsBuf_InvldCmd_e)
    {
        // try to get the upstream buffer for an in valid command index
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetUsBuf(RBA_MSC_CFG_NR_CMD_MAX,
                                                            &TestCd_rba_Msc_xItfTest_st.xUsBuf_pu8);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    //------------------------------------------------------------------------------------------------------------------
    // test step to check callback feature

    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfCallBack_e)
    {
        rba_Msc_xCmdResult_ten xCmdResult_en;

        // transmit command with configured callback function
        // -> the callback function is invoked upon transmission of the corresponding command
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1);

        // wait for command to complete to ensure that callback is called
        do
        {
            (void)rba_Msc_GetCmdResult(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1, &xCmdResult_en);
        }
        while(xCmdResult_en == rba_Msc_CmdPending_e);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }


    //------------------------------------------------------------------------------------------------------------------
    // test case for rba_Msc_GetMux()

    // rba_Msc_GetMux(): normal operation
    // -> capture current setting
    // -> set to internal
    // -> check if internal is read by rba_Msc_GetMux
    // -> set to external
    // -> check if external is read by rba_Msc_GetMux
    // -> restore setting
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetMux_e)
    {
        Std_ReturnType  stRet = E_OK;

        boolean stMuxRestore_b;
        boolean stMuxTest_b;

        // get current multiplexer setting for later restore
        (void)rba_Msc_GetMux(Testcd_rba_Msc_TestSignal_ID_u8, &stMuxRestore_b);

        // set multiplexer to internal
        (void)rba_Msc_SetMux(Testcd_rba_Msc_TestSignal_ID_u8, RBA_MSC_MUX_INT);

        // now the actual test starts
        if (rba_Msc_GetMux(Testcd_rba_Msc_TestSignal_ID_u8, &stMuxTest_b) == E_OK)
        {
            if (stMuxTest_b != RBA_MSC_MUX_INT)
            {
                stRet = E_NOT_OK;
            }
        }
        else
        {
            stRet = E_NOT_OK;
        }

        // set multiplexer to external
        (void)rba_Msc_SetMux(Testcd_rba_Msc_TestSignal_ID_u8, RBA_MSC_MUX_EXT);

        // now the actual test starts
        if (rba_Msc_GetMux(Testcd_rba_Msc_TestSignal_ID_u8, &stMuxTest_b) == E_OK)
        {
            if (stMuxTest_b != RBA_MSC_MUX_EXT)
            {
                stRet = E_NOT_OK;
            }
        }
        else
        {
            stRet = E_NOT_OK;
        }

        // restore multiplexer setting
        (void)rba_Msc_SetMux(Testcd_rba_Msc_TestSignal_ID_u8, RBA_MSC_MUX_EXT);

        // set test result for evaluation by ITF
        TestCd_rba_Msc_xItfTest_st.stRet = stRet;

        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_GetMux(): DET check RBA_MSC_E_UNINIT
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetMux_UnInit_e)
    {
        boolean stMuxTest_b;

        // patch the initialization state to FALSE
        rba_Msc_Prv_stInitialized_b = FALSE;

        // try to get multiplexer setting of a valid signal
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetMux(Testcd_rba_Msc_TestSignal_ID_u8, &stMuxTest_b);

        // change the initialization state back to TRUE
        rba_Msc_Prv_stInitialized_b = TRUE;

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_GetMux(): DET check RBA_MSC_E_PARAM_SIG_IDX
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetMux_InvldSig_e)
    {
        boolean stMuxTest_b;

        // try to get multiplexer setting of an invalid signal
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetMux(RBA_MSC_CFG_NR_SIG_MAX, &stMuxTest_b);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_GetMux(): DET check RBA_MSC_E_UNINIT
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfGetMux_NullPtr_e)
    {
        // try to get multiplexer setting of a valid signal but with NULL_PTR as return parameter
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_GetMux(Testcd_rba_Msc_TestSignal_ID_u8, NULL_PTR);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    //------------------------------------------------------------------------------------------------------------------
    // test case for rba_Msc_SetMux()

    // rba_Msc_SetMux(): normal operation
    // -> capture current setting
    // -> set to internal by rba_Msc_SetMux
    // -> check if internal is read by rba_Msc_GetMux
    // -> set to external by rba_Msc_SetMux
    // -> check if external is read by rba_Msc_GetMux
    // -> restore setting
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfSetMux_e)
    {
        Std_ReturnType  stRet = E_OK;

        boolean stMuxRestore_b;
        boolean stMuxTest_b;

        // get current multiplexer setting for later restore
        (void)rba_Msc_GetMux(Testcd_rba_Msc_TestSignal_ID_u8, &stMuxRestore_b);

        // now the actual test starts
        // -> set to internal
        if (rba_Msc_SetMux(Testcd_rba_Msc_TestSignal_ID_u8, RBA_MSC_MUX_INT) == E_OK)
        {
            (void)rba_Msc_GetMux(Testcd_rba_Msc_TestSignal_ID_u8, &stMuxTest_b);

            if (stMuxTest_b != RBA_MSC_MUX_INT)
            {
                stRet = E_NOT_OK;
            }
        }
        else
        {
            stRet = E_NOT_OK;
        }

        // now the actual test starts
        // -> set to external
        if (rba_Msc_SetMux(Testcd_rba_Msc_TestSignal_ID_u8, RBA_MSC_MUX_EXT) == E_OK)
        {
            (void)rba_Msc_GetMux(Testcd_rba_Msc_TestSignal_ID_u8, &stMuxTest_b);

            if (stMuxTest_b != RBA_MSC_MUX_EXT)
            {
                stRet = E_NOT_OK;
            }
        }
        else
        {
            stRet = E_NOT_OK;
        }

        // restore multiplexer setting
        (void)rba_Msc_SetMux(Testcd_rba_Msc_TestSignal_ID_u8, RBA_MSC_MUX_EXT);

        // set test result for evaluation by ITF
        TestCd_rba_Msc_xItfTest_st.stRet = stRet;

        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_SetMux(): check DET RBA_MSC_E_UNINIT
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfSetMux_UnInit_e)
    {
        // patch the initialization state to FALSE
        rba_Msc_Prv_stInitialized_b = FALSE;

        // try to set the multiplexer for a valid signal index
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_SetMux(Testcd_rba_Msc_TestSignal_ID_u8, RBA_MSC_MUX_EXT);

        // change the initialization state back to TRUE
        rba_Msc_Prv_stInitialized_b = TRUE;

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    // rba_Msc_SetMux(): check DET RBA_MSC_E_PARAM_CMD_IDX
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfSetMux_InvldSig_e)
    {
        // try to set the multiplexer for an invalid signal index
        TestCd_rba_Msc_xItfTest_st.stRet = rba_Msc_SetMux(RBA_MSC_CFG_NR_SIG_MAX, RBA_MSC_MUX_EXT);

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
    }

    //------------------------------------------------------------------------------------------------------------------
    // test steps for rba_Msc_ShDwn()

    // rba_Msc_ShDwn(): check normal operation
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfShDwn_e)
    {
#if (RBA_MSC_CFG_ASYNC_MODE == STD_ON)
        // transmit a valid command
        // -> make sure that shut down below has something to do
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd4);

        // call shut down
        // -> this is the API under test here
        rba_Msc_ShDwn();

        // check interrupt state
        if (rba_Msc_Prv_stInterruptMode_b)
        {
            TestCd_rba_Msc_xItfTest_st.stRet = E_NOT_OK;
        }
        else
        {
            TestCd_rba_Msc_xItfTest_st.stRet = E_OK;
        }

        // return to interrupt mode
        rba_Msc_End_Init();

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
#else
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfTestNotTestable_e;
#endif
    }

    // rba_Msc_ShDwn(): check DET RBA_MSC_E_UNINIT
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfShDwn_UnInit_e)
    {
#if (RBA_MSC_CFG_ASYNC_MODE == STD_ON)
        // patch the initialization state to FALSE
        rba_Msc_Prv_stDsEnabled_b = FALSE;

        // try to call shut down
        rba_Msc_ShDwn();

        // change the initialization state back to TRUE
        rba_Msc_Prv_stDsEnabled_b = TRUE;

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
#else
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfTestNotTestable_e;
#endif
    }

    //------------------------------------------------------------------------------------------------------------------
    // test steps for rba_Msc_SwtToSync()

    // rba_Msc_SwtToSync(): check normal operation
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfSwtToSync_e)
    {
#if (RBA_MSC_CFG_ASYNC_MODE == STD_ON)
        // initialize test result to passed
        Std_ReturnType  stRet = E_OK;

        // transmit a valid command
        // -> make sure that shut down below has something to do
        (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd4);

        // use lock because the API under test may only be called with disabled interrupts
        // -> it is also required that this test driver runs on the same core as the rba_Msc ISRs
        SchM_Enter_rba_Msc_Driver();

        // check interrupt state, must be asynchronous at this point
        if (!rba_Msc_Prv_stInterruptMode_b)
        {
            // state is not asynchronous, test failed
            stRet = E_NOT_OK;
        }

        // call switch to synchronous transmission API
        // -> this is the API under test here
        rba_Msc_SwtToSync();

        // check interrupt state, must be synchronous at this point
        if (rba_Msc_Prv_stInterruptMode_b)
        {
            // state is not synchronous, test failed
            stRet = E_NOT_OK;
        }

        // return to asynchronous mode (formerly known as interrupt mode)
        rba_Msc_End_Init();

        SchM_Exit_rba_Msc_Driver();

        // store test result
        TestCd_rba_Msc_xItfTest_st.stRet = stRet;

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
#else
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfTestNotTestable_e;
#endif
    }

    // rba_Msc_SwtToSync(): check DET RBA_MSC_E_UNINIT
    if (TestCd_rba_Msc_stItfTest_en == TestCd_rba_Msc_ItfSwtToSync_UnInit_e)
    {
#if (RBA_MSC_CFG_ASYNC_MODE == STD_ON)
        // use lock because the API under test may only be called with disabled interrupts
        SchM_Enter_rba_Msc_Driver();

        // patch the initialization state to FALSE
        rba_Msc_Prv_stDsEnabled_b = FALSE;

        // try to API to switch to synchronous transmission mode
        rba_Msc_SwtToSync();

        // change the initialization state back to TRUE
        rba_Msc_Prv_stDsEnabled_b = TRUE;

        SchM_Exit_rba_Msc_Driver();

        // reset TestCd state
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfIdle_e;
#else
        TestCd_rba_Msc_stItfTest_en = TestCd_rba_Msc_ItfTestNotTestable_e;
#endif
    }
}


// function used to set breakpoint from ITF script
// -> it is essential that this function is never inlined to be able to set the breakpoint properly
void __attribute__ ((noinline)) TestCd_rba_Msc_PutYourBreakPointHere(void)
{
    // nothing to do here
    // -> ITF will set a breakpoint to this function to stop processing
    // -> use counter to make sure that the function is not removed by compiler optimization
    TestCd_rba_Msc_cntPutYourBreakPointHere_u32++;
}


void TestCd_rba_Msc_WaistTime_Proc(void)
{
    uint32 tiStart_u32 = Mcu_Rb_GetSysTicks();

    // store system timer
    // -> this allows to verify that TestCd_rba_Msc_Background_Proc and TestCd_rba_Msc_WaistTime_Proc are not in sync
    TestCd_rba_Msc_tiWaistTimeProc_u32 = tiStart_u32;

    // calculate difference between the timestamps of TestCd_rba_Msc_Background_Proc and TestCd_rba_Msc_WaistTime_Proc
    TestCd_rba_Msc_tiDeltaBg10ms_u32 = TestCd_rba_Msc_tiWaistTimeProc_u32 - TestCd_rba_Msc_tiBackgroundProc_u32;

    // waist some time to simulate a long 10ms task
    while ((Mcu_Rb_GetSysTicks() - tiStart_u32) < MCU_RB_US_TO_TICKS(TestCd_rba_Msc_tiWaistTimeUs_u32))
    {
        // waist some CPU cycles to prevent continuous polling of system timer
        Mcu_Rb_WaitNop(128);
    }
}


void TestCd_rba_Msc_Background_Proc(void)
{
    // create a low prio task independent of any other task
    // -> this task should float compared to the real 10ms task
    // -> the real 10ms task will eventually break this task anywhere
    // -> a counter is used instead of system timer to prevent the unintended re-sync at the end of a long interruption

    TestCd_rba_Msc_cntBackgroundProc_u32++;

    if (TestCd_rba_Msc_cntBackgroundProc_u32 > TestCd_rba_Msc_nrBackgroundProc_u32)
    {
        // reset activation counter
        TestCd_rba_Msc_cntBackgroundProc_u32 = 0uL;

        // store system timer
        // -> this allows to verify that TestCd_rba_Msc_Background_Proc and TestCd_rba_Msc_WaistTime_Proc are not in sync
        TestCd_rba_Msc_tiBackgroundProc_u32 = Mcu_Rb_GetSysTicks();

        TestCd_rba_Msc_10ms();
    }
}

#if (RBA_MSC_CFG_ASYNC_MODE == STD_ON)
#if (MCU_RB_MACHINE_FAM == MCU_RB_IFX_UC1)
static TestCd_rba_Msc_DmaPendingTest_tst TestCd_rba_Msc_DmaPendingTest_st =
{
    1u,             /*idxHwUnit_u32*/
    0,              /*tiIsrLockIntrs_u32*/
    0,              /*tiIsrLockIntrs2_u32*/
    0,              /*tiIsrLockIntrs2Delay_u32*/
    200u,           /*tiIsrLockIntrsWaistTime_u32*/
    30u,            /*tiIsrLockIntrs2WaistTime_u32*/
    (1u << 12u),    /*ctHitReset_u32*/
    0,              /*tiCurrentCounter_u32*/
    0,              /*tiCnOffset_u32*/
    140u,           /*tiDeltaGtm2Isr_u32*/
    0,              /*ctHit_u32*/
    0x0000FFFFuL    /*cntTomChSR0_u32;*/
};
#endif

// test function triggered by GTM to get asynchronous transmissions compared to normal tasks
// -> ISR needs to be enabled by TestCd_rba_Msc_stTest_en == TestCd_rba_Msc_StrtGtmIsr_e
// -> runtime of this function is critical because it is called on a high priority and hence must be lower
//    than 1ms otherwise there will be OS task overflows
void TestCd_rba_Msc_GtmIsr(void)
{
#ifdef RBA_GTM_TOM_TESTCD_RBA_MSC_GTM_CONF
    uint32 regIrqNotify_u32;

    // get the notification register corresponding to the GTM resource
    if (rba_Gtm_GetTomReg(rba_Gtm_Tom_TestCd_rba_Msc_Gtm, RBA_GTM_TOM_CH_IRQ_NOTIFY, &regIrqNotify_u32) != E_NOT_OK)
    {
        // GTM resource is configured in the current PB variant

        // check if the notification bit is actually set
        // -> this is done to be shareable with neighboring interrupts
        if ((regIrqNotify_u32 & 1uL) != 0uL)
        {
            if (TestCd_rba_Msc_stIsrTest_en == TestCd_rba_Msc_IsrChkTrfContns_e)
            {
                // send command of CJ950_01
                // -> use command with 1 upstream frame because of runtime issues in test setup
                (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd1);

#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5
                // send commands of CJ950_02
                // -> use command with 1 upstream frame because of runtime issues in test setup
                (void)rba_Msc_Transmit(rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5);
#endif
            }

#if (MCU_RB_MACHINE_FAM == MCU_RB_IFX_UC1)
            if (TestCd_rba_Msc_stIsrTest_en == TestCd_rba_Msc_DmaPendingState1_e)
            {

                // use fast clock
                (void)rba_Gtm_SetTomReg(rba_Gtm_Tom_TestCd_rba_Msc_Gtm, RBA_GTM_TOM_CH_SR0,  TestCd_rba_Msc_DmaPendingTest_st.cntTomChSR0_u32);
                (void)rba_Gtm_SetTomReg(rba_Gtm_Tom_TestCd_rba_Msc_Gtm, RBA_GTM_TOM_CH_CTRL, 0x00000000uL);



                if (rba_Msc_Prv_xHwUnit_ast[TestCd_rba_Msc_DmaPendingTest_st.idxHwUnit_u32].stHndlr_ven == rba_Msc_HndlrEvalUs_e)
                {

                    // waist some time to stimulate a situation
                    // where DMA *and* timeout interrupt are pending at the same time
                    {
                        uint32 tiStart_u32 = Mcu_Rb_GetSysTicks();

                        // store system timer
                        TestCd_rba_Msc_DmaPendingTest_st.tiIsrLockIntrs_u32 = tiStart_u32;

                        // waist some time to interrupt the MSC Handler to delay the service of the DMA interrupt
                        while ((Mcu_Rb_GetSysTicks() - tiStart_u32) < MCU_RB_US_TO_TICKS(TestCd_rba_Msc_DmaPendingTest_st.tiIsrLockIntrsWaistTime_u32))
                        {
                            // waist some CPU cycles to prevent continuous polling of system timer
                            Mcu_Rb_WaitNop(128);
                        }
                    }


                    if (((SRC.MSC[rba_Msc_Prv_xHwUnitCfg_pcst[TestCd_rba_Msc_DmaPendingTest_st.idxHwUnit_u32].idxPhyHwUnit_u8].SR0 & (1uL << RBA_REG_SRC_SRR_POS)) != 0uL) &&
                      ((SRC.DMACH[rba_Msc_Prv_xHwUnit_ast[TestCd_rba_Msc_DmaPendingTest_st.idxHwUnit_u32].idxDmaCh_u8] & (1uL << RBA_REG_SRC_SRR_POS)) != 0uL))
                    {
                        uint32 tiCurrentCounter_u32;

                        TestCd_rba_Msc_DmaPendingTest_st.ctHit_u32++;

                        // program for ISR call after MSC handler ISR
                        (void)rba_Gtm_GetTomReg(rba_Gtm_Tom_TestCd_rba_Msc_Gtm, RBA_GTM_TOM_CH_CN0, &tiCurrentCounter_u32);

                        TestCd_rba_Msc_DmaPendingTest_st.tiCnOffset_u32 = (TestCd_rba_Msc_DmaPendingTest_st.ctHit_u32 >> 5) + TestCd_rba_Msc_DmaPendingTest_st.tiDeltaGtm2Isr_u32;
                        TestCd_rba_Msc_DmaPendingTest_st.tiCurrentCounter_u32 = tiCurrentCounter_u32;

                        (void)rba_Gtm_SetTomReg(rba_Gtm_Tom_TestCd_rba_Msc_Gtm, RBA_GTM_TOM_CH_CM0, (TestCd_rba_Msc_DmaPendingTest_st.tiCnOffset_u32 + tiCurrentCounter_u32));

                        if (TestCd_rba_Msc_DmaPendingTest_st.ctHit_u32 > TestCd_rba_Msc_DmaPendingTest_st.ctHitReset_u32)
                        {
                            TestCd_rba_Msc_DmaPendingTest_st.ctHit_u32 = 0uL;
                        }

                        TestCd_rba_Msc_stIsrTest_en = TestCd_rba_Msc_DmaPendingState2_e;
                    }
                }
            }
            else if (TestCd_rba_Msc_stIsrTest_en == TestCd_rba_Msc_DmaPendingState2_e)
            {
                uint32 tiStart_u32 = Mcu_Rb_GetSysTicks();

                // store system timer
                TestCd_rba_Msc_DmaPendingTest_st.tiIsrLockIntrs2_u32 = tiStart_u32;

                TestCd_rba_Msc_DmaPendingTest_st.tiIsrLockIntrs2Delay_u32 = tiStart_u32 - TestCd_rba_Msc_DmaPendingTest_st.tiIsrLockIntrs_u32;

                while ((Mcu_Rb_GetSysTicks() - tiStart_u32) < MCU_RB_US_TO_TICKS(TestCd_rba_Msc_DmaPendingTest_st.tiIsrLockIntrs2WaistTime_u32))
                {
                    // waist some CPU cycles to prevent continuous polling of system timer
                    Mcu_Rb_WaitNop(128);
                }

                TestCd_rba_Msc_stIsrTest_en = TestCd_rba_Msc_DmaPendingState1_e;
            }
            else
            {
                (void)0;
            }
#endif

            // acknowledge ISR
            (void)rba_Gtm_SetTomReg(rba_Gtm_Tom_TestCd_rba_Msc_Gtm, RBA_GTM_TOM_CH_IRQ_NOTIFY, 1uL);
        }
    }
#endif
}
#endif

void TestCd_rba_Msc_Cmd1_Notif(void)
{
    TestCd_rba_Msc_cntCmd1Notif_u32++;
}

void TestCd_rba_Msc_Cmd2_Notif(void)
{
    TestCd_rba_Msc_cntCmd2Notif_u32++;
}

void TestCd_rba_Msc_Cmd3_Notif(void)
{
    TestCd_rba_Msc_cntCmd3Notif_u32++;
}

void TestCd_rba_Msc_Cmd4_Notif(void)
{
    TestCd_rba_Msc_cntCmd4Notif_u32++;
}

#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5
void TestCd_rba_Msc_Cmd5_Notif(void)
{
    TestCd_rba_Msc_cntCmd5Notif_u32++;
}
#endif

#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd6
void TestCd_rba_Msc_Cmd6_Notif(void)
{
    TestCd_rba_Msc_cntCmd6Notif_u32++;
}
#endif

#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd7
void TestCd_rba_Msc_Cmd7_Notif(void)
{
    TestCd_rba_Msc_cntCmd7Notif_u32++;
}
#endif

#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8
void TestCd_rba_Msc_Cmd8_Notif(void)
{
    TestCd_rba_Msc_cntCmd8Notif_u32++;
}
#endif

// To check if a sequence is transmimitted without interruption
// In test case TestCd_rba_Msc_TransmitSeq_e a high priority command rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd9
// is called after a low priority sequence rba_MscConf_rba_Msc_Seq_TestCd_rba_Msc_Seq0
// Notification of sequence has to be called first - check TestCd_rba_Msc_SeqCmpl
#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd9
void TestCd_rba_Msc_Cmd9_Notif(void)
{
    if(TestCd_rba_Msc_SeqCmpl == 1)
    {
        TestCd_rba_Msc_SeqCmpl = 2; // Sequence notification called first - Test passed
    }
    else
    {
        TestCd_rba_Msc_SeqCmpl = 255; // Command notification called before sequence notification - test failed
    }
    TestCd_rba_Msc_cntCmd9Notif_u32++;
}
#endif

#ifdef rba_MscConf_rba_Msc_Seq_TestCd_rba_Msc_Seq0
void TestCd_rba_Msc_Seq0_Notif(void)
{
    TestCd_rba_Msc_cntSeq0Notif_u32++;
    TestCd_rba_Msc_SeqCmpl = 1;
}
#endif

#endif /* RBA_MSC_CFG_MSC_IS_CONFIGURED */

/*<BASDKey>
 ***********************************************************************************************************************
 * $History___:$
 ***********************************************************************************************************************
</BASDKey>*/
