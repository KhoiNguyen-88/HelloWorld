/*<BASDKey>
 ***********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 ***********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:$
 * $Namespace_:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 ***********************************************************************************************************************
</BASDKey>*/

#ifndef TESTCD_RBA_MSC_H
#define TESTCD_RBA_MSC_H

#include "Std_Types.h"

#include "rba_Msc.h"

#define TESTCD_RBA_MSC_INVALID_US_NUM   0xFFu

typedef struct
{
    boolean                 stSig_b;
    uint8 *                 xUsBuf_pu8;
    rba_Msc_idxCmd_tuo      idxCmd_uo;
    Std_ReturnType          stRet;
    rba_Msc_idxSig_tuo      idxSig_uo;
    rba_Msc_xCmdVal_tuo     xCmdVal_uo;
    rba_Msc_xCmdResult_ten  stCmd_en;
    uint32                  nrUsFrm_u32;
    rba_Msc_xSeqResult_ten  stSeq_en;
} TestCd_rba_Msc_xItfTest_tst;

typedef enum
{
    TestCd_rba_Msc_Idle_e,
    TestCd_rba_Msc_Passed_e,
    TestCd_rba_Msc_Failed_e,
    TestCd_rba_Msc_Init_e,
    TestCd_rba_Msc_InitCj950_e,
    TestCd_rba_Msc_ChkTrfSng_e,
    TestCd_rba_Msc_ChkTrfContns_e,
    TestCd_rba_Msc_ChkMuxToggleCj950100Hz_e,
    TestCd_rba_Msc_ChkMuxSetIntCj950100Hz_e,
    TestCd_rba_Msc_ChkSigToggleCj950100Hz_e,
    TestCd_rba_Msc_ChkSigSetTrueCj950100Hz_e,
    TestCd_rba_Msc_ChkSigSetFalseCj950100Hz_e,
    TestCd_rba_Msc_ChkMuxToggleNorm_e,
    TestCd_rba_Msc_ChkMuxToggleSpec_e,
    TestCd_rba_Msc_ShDwn_e,
    TestCd_rba_Msc_SwtToIntrpt_e,
    TestCd_rba_Msc_SwtToSync_e,
    TestCd_rba_Msc_ToggleAsyncSync_e,
    TestCd_rba_Msc_StrtGtmIsr_e,
    TestCd_rba_Msc_StopGtmIsr_e,
    TestCd_rba_Msc_SingleRead_e,
    TestCd_rba_Msc_TransmitSeq_e,
    TestCd_rba_Msc_MoInitCheck_e
} TestCd_rba_Msc_stTest_ten;

typedef enum
{
    TestCd_rba_Msc_IsrIdle_e,
    TestCd_rba_Msc_IsrChkTrfContns_e,
    TestCd_rba_Msc_DmaPendingState1_e,
    TestCd_rba_Msc_DmaPendingState2_e
} TestCd_rba_Msc_stIsrTest_ten;

// test cases for ITF
typedef enum
{
    TestCd_rba_Msc_ItfIdle_e,
    TestCd_rba_Msc_ItfTestNotTestable_e,

    TestCd_rba_Msc_ItfInit_e,
    TestCd_rba_Msc_ItfInit_Init_e,
    TestCd_rba_Msc_ItfInit_NullPtr_e,
    TestCd_rba_Msc_ItfInit_InvldPbPtr_e,
    TestCd_rba_Msc_ItfInitPostPort_Init_e,
    TestCd_rba_Msc_ItfInitPostPort_UnInit_e,
    TestCd_rba_Msc_ItfInitEndInit_Init_e,
    TestCd_rba_Msc_ItfInitEndInit_UnInit_e,

    TestCd_rba_Msc_ItfGetCmdRes_e,
    TestCd_rba_Msc_ItfGetCmdRes_NullPtr_e,
    TestCd_rba_Msc_ItfGetCmdRes_UnInit_e,
    TestCd_rba_Msc_ItfGetCmdRes_InvldCmd_e,

    TestCd_rba_Msc_ItfSetNrUsFrm_e,
    TestCd_rba_Msc_ItfSetNrUsFrm_UnInit_e,
    TestCd_rba_Msc_ItfSetNrUsFrm_InvldCmd_e,
    TestCd_rba_Msc_ItfSetNrUsFrm_UsMax_e,

    TestCd_rba_Msc_ItfGetNrUsFrm_e,
    TestCd_rba_Msc_ItfGetNrUsFrm_UnInit_e,
    TestCd_rba_Msc_ItfGetNrUsFrm_NullPtr_e,
    TestCd_rba_Msc_ItfGetNrUsFrm_InvldCmd_e,

    TestCd_rba_Msc_ItfSetCmdVal_e,
    TestCd_rba_Msc_ItfSetCmdVal_UnInit_e,
    TestCd_rba_Msc_ItfSetCmdVal_InvldCmd_e,

    TestCd_rba_Msc_ItfGetCmdVal_e,
    TestCd_rba_Msc_ItfGetCmdVal_UnInit_e,
    TestCd_rba_Msc_ItfGetCmdVal_NullPtr_e,
    TestCd_rba_Msc_ItfGetCmdVal_InvldCmd_e,

    TestCd_rba_Msc_ItfSetSigVal_T_e,
    TestCd_rba_Msc_ItfSetSigVal_F_e,
    TestCd_rba_Msc_ItfSetSigVal_UnInit_e,
    TestCd_rba_Msc_ItfSetSigVal_InvldSig_e,

    TestCd_rba_Msc_ItfGetSigVal_T_e,
    TestCd_rba_Msc_ItfGetSigVal_F_e,
    TestCd_rba_Msc_ItfGetSigVal_UnInit_e,
    TestCd_rba_Msc_ItfGetSigVal_InvldSig_e,
    TestCd_rba_Msc_ItfGetSigVal_NullPtr_e,

    TestCd_rba_Msc_ItfGetUsBuf_e,
    TestCd_rba_Msc_ItfGetUsBuf_NullPtr_e,
    TestCd_rba_Msc_ItfGetUsBuf_UnInit_e,
    TestCd_rba_Msc_ItfGetUsBuf_InvldCmd_e,

    TestCd_rba_Msc_ItfTransmit_e,
    TestCd_rba_Msc_ItfTransmit_TimeoutError_e,
    TestCd_rba_Msc_ItfTransmit_TimeoutError_PollingMode_e,
    TestCd_rba_Msc_ItfTransmit_PollingMode_e,
    TestCd_rba_Msc_ItfTransmit_UnInit_e,
    TestCd_rba_Msc_ItfTransmit_InvldCmd_e,
    TestCd_rba_Msc_ItfTransmit_CmdPending_e,

    TestCd_rba_Msc_ItfCallBack_e,

    TestCd_rba_Msc_ItfGetMux_e,
    TestCd_rba_Msc_ItfGetMux_UnInit_e,
    TestCd_rba_Msc_ItfGetMux_InvldSig_e,
    TestCd_rba_Msc_ItfGetMux_NullPtr_e,

    TestCd_rba_Msc_ItfSetMux_e,
    TestCd_rba_Msc_ItfSetMux_UnInit_e,
    TestCd_rba_Msc_ItfSetMux_InvldSig_e,

    TestCd_rba_Msc_ItfShDwn_e,
    TestCd_rba_Msc_ItfShDwn_UnInit_e,

    TestCd_rba_Msc_ItfSwtToSync_e,
    TestCd_rba_Msc_ItfSwtToSync_UnInit_e
} TestCd_rba_Msc_stItfTest_ten;


typedef struct
{
    uint32 idxHwUnit_u32;
    uint32 tiIsrLockIntrs_u32;
    uint32 tiIsrLockIntrs2_u32;
    uint32 tiIsrLockIntrs2Delay_u32;
    uint32 tiIsrLockIntrsWaistTime_u32;
    uint32 tiIsrLockIntrs2WaistTime_u32;
    uint32 ctHitReset_u32;
    uint32 tiCurrentCounter_u32;
    uint32 tiCnOffset_u32;

    uint32 tiDeltaGtm2Isr_u32;
    uint32 ctHit_u32;
    uint32 cntTomChSR0_u32;

} TestCd_rba_Msc_DmaPendingTest_tst;



extern TestCd_rba_Msc_stTest_ten    TestCd_rba_Msc_stTest_en;
extern TestCd_rba_Msc_stIsrTest_ten TestCd_rba_Msc_stIsrTest_en;
extern TestCd_rba_Msc_stItfTest_ten TestCd_rba_Msc_stItfTest_en;

extern TestCd_rba_Msc_xItfTest_tst  TestCd_rba_Msc_xItfTest_st;
extern rba_Msc_xCmdResult_ten       TestCd_rba_Msc_CmdRes_u8;
extern uint32                       TestCd_rba_Msc_nrUsFrm_u32;
extern uint16                       TestCd_rba_Msc_CmdVal_u16[RBA_MSC_CFG_NR_CMD_MAX];
extern uint8 *                      TestCd_rba_Msc_UsBuf_pu8;
extern const volatile boolean       TestCd_rba_Msc_isDetReportEnabled_cb;
extern const volatile boolean       TestCd_rba_Msc_isAsyncModeEnabled_cb;

extern boolean TestCd_rba_Msc_stMux_b;
extern boolean TestCd_rba_Msc_stSig_b;

extern uint32 TestCd_rba_Msc_cntPutYourBreakPointHere_u32;

extern uint32 TestCd_rba_Msc_cntCmd1Notif_u32;
extern uint32 TestCd_rba_Msc_cntCmd2Notif_u32;
extern uint32 TestCd_rba_Msc_cntCmd3Notif_u32;
extern uint32 TestCd_rba_Msc_cntCmd4Notif_u32;
#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd5
extern uint32 TestCd_rba_Msc_cntCmd5Notif_u32;
#endif
#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd6
extern uint32 TestCd_rba_Msc_cntCmd6Notif_u32;
#endif
#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd7
extern uint32 TestCd_rba_Msc_cntCmd7Notif_u32;
#endif
#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd8
extern uint32 TestCd_rba_Msc_cntCmd8Notif_u32;
#endif
#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd9
extern uint32 TestCd_rba_Msc_cntCmd9Notif_u32;
#endif
#ifdef rba_MscConf_rba_Msc_Seq_TestCd_rba_Msc_Seq0
extern uint32 TestCd_rba_Msc_cntSeq0Notif_u32;
#endif


extern uint32 TestCd_rba_Msc_tiBackgroundProc_u32;
extern uint32 TestCd_rba_Msc_tiWaistTimeProc_u32;
extern uint32 TestCd_rba_Msc_tiDeltaBg10ms_u32;
extern uint32 TestCd_rba_Msc_tiWaistTimeUs_u32;
extern uint32 TestCd_rba_Msc_cntBackgroundProc_u32;
extern uint32 TestCd_rba_Msc_nrBackgroundProc_u32;

extern uint32 TestCd_rba_Msc_cntToggleAsyncSync_u32;

extern uint32 TestCd_rba_Msc_cntSwtToSyncState_aau32[RBA_MSC_CFG_NR_HWUNIT_MAX][5u];

extern boolean TestCd_rba_Msc_stUseBgTask_b;

extern void TestCd_rba_Msc_Init(void);
extern void TestCd_rba_Msc_10ms(void);
extern void __attribute__ ((noinline)) TestCd_rba_Msc_PutYourBreakPointHere(void);

extern void TestCd_rba_Msc_Background_Proc(void);
extern void TestCd_rba_Msc_WaistTime_Proc(void);

extern void TestCd_rba_Msc_GtmIsr(void);

#ifdef rba_MscConf_rba_Msc_Cmd_TestCd_rba_Msc_Cmd9
extern void TestCd_rba_Msc_Cmd9_Notif(void);
#endif


#endif

/*<BASDKey>
 ***********************************************************************************************************************
 * $History___:$
 ***********************************************************************************************************************
</BASDKey>*/

/*<BASDKey>
 ***********************************************************************************************************************
 * End of header file: $Name______:$
 ***********************************************************************************************************************
</BASDKey>*/
