#<BASDKey>
#***********************************************************************************************************************
#
# COPYRIGHT RESERVED, Robert Bosch GmbH, 2014. All rights reserved.
# The reproduction, distribution and utilization of this document as well as the communication of its contents to
# others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
# All rights reserved in the event of the grant of a patent, utility model or design.
#
#***********************************************************************************************************************
# Administrative Information (automatically filled in)
# $Domain____:$
# $Namespace_:$
# $Class_____:$
# $Name______:$
# $Variant___:$
# $Revision__:$
#***********************************************************************************************************************
#</BASDKey>

package rba_Msc_Callback;

#-----------------------------------------------------------------------------------------------------------------------

=head1 Test specification for rba_Msc_Callback

This is the test specification as XML description

<TestConfiguration>
  <TC_Id>rba_Msc_AR40.2.0.0_Itf_Callback</TC_Id>
  <TC_BL></TC_BL>
  <TC_Spec></TC_Spec>
  <TC_EnvCond></TC_EnvCond>
  <TC_ExpRes></TC_ExpRes>
  <TestStep></TestStep>
  <TestMethod></TestMethod>
  <TestPrep></TestPrep>
  <TestType>automated</TestType>
  <Environment></Environment>
  <ResConsumption></ResConsumption>
  <CoveredReq_Id>
BSW_SWS_MCAL_Msc_RBA-445
  </CoveredReq_Id>
  <CoveredReq_Doc>BSW_SWS_MCAL_Msc_RBA</CoveredReq_Doc>
</TestConfiguration>

=cut

#-----------------------------------------------------------------------------------------------------------------------

use STEPS_general;
use STEPS_NET;
use STEPS_NET_Reports;
use STEPS_BSWITF;
use STEPS_BSWITF_BSW;
use STEPS_BSWITF_ECU;
use STEPS_BSWITF_Debugger;

use strict;
use warnings;

use rba_Msc_TestLib;

# global variables
my $TestResult_s;    # test result of the test case (result of all test steps)
my $ude_s = undef;   # handle for accessing UDE functionality


#-----------------------------------------------------------------------------------------------------------------------
sub TC_set_parameters
{
  # set initial parameters for the test cases
  $TestResult_s = RESULT_PASSED;
  $ude_s        = new UdeControl();
  return (1);
}


#-----------------------------------------------------------------------------------------------------------------------
sub TC_initialization
{
  BSWITF_Init();
  return (1);
}


#-----------------------------------------------------------------------------------------------------------------------
sub TC_stimulation_and_measurement
{
  # variables containing describing text
  my $testStep_s;
  my $testStepDesc_s;
  my $testStepPrecond_s;
  my $testStepExpectedBehav_s;
  my $testStepResult_s;
  my $strTestCd_s;
  my $cntCallback_s;

  # variables containing test step result values
  my $testStepReturnValue_s;

  #---------------------------------------------------------------------------------------------------------------------
  # check if callbacks get called
  #---------------------------------------------------------------------------------------------------------------------
  $testStep_s              = "rba_Msc_Callback_NormalOperation";
  $testStepDesc_s          = "Check if callbacks get called after transmission of a command";
  $testStepPrecond_s       = "MSC driver is initialized";
  $testStepExpectedBehav_s = "TestCd_rba_Msc_cntCmd1Notif_u32 has to be incremented";

  printTestStepInfo($testStep_s, $testStepDesc_s, $testStepPrecond_s, $testStepExpectedBehav_s);

  # prepare test step execution
  $strTestCd_s      = "TestCd_rba_Msc_ItfCallBack_e";
  $testStepResult_s = RESULT_PASSED;

  # read current callback counter value
  $cntCallback_s = $ude_s->readVar("TestCd_rba_Msc_cntCmd1Notif_u32");

  # execute test step
  execTestStep($ude_s, $strTestCd_s);

  # check if counter has changed
  # -> if not the callback did not get called
  if ($ude_s->readVar("TestCd_rba_Msc_cntCmd1Notif_u32") == $cntCallback_s)
  {
    $testStepResult_s = RESULT_FAILED;
  }

  # result documentation
  $TestResult_s = documentTestStepResult($testStepResult_s, $TestResult_s);

  # clean up test step
  # -> nothing to do

  return (1);
}


#-----------------------------------------------------------------------------------------------------------------------
sub TC_evaluation
{
  evalTestCaseResult($ude_s, $TestResult_s);
  return (1);
}


#-----------------------------------------------------------------------------------------------------------------------
sub TC_finalization
{
  # exit the test environment

  # clear the handle to enable following test cases to have access to the ude
  undef($ude_s);

  BSWITF_Exit();
  return (1);
}


#-----------------------------------------------------------------------------------------------------------------------
1;
#-----------------------------------------------------------------------------------------------------------------------

#<BASDKey>
#***********************************************************************************************************************
# $History___:$
#***********************************************************************************************************************
#</BASDKey>
