#<BASDKey>
#***********************************************************************************************************************
#
# COPYRIGHT RESERVED, Robert Bosch GmbH, 2014. All rights reserved.
# The reproduction, distribution and utilization of this document as well as the communication of its contents to
# others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
# All rights reserved in the event of the grant of a patent, utility model or design.
#
#***********************************************************************************************************************
# Administrative Information (automatically filled in)
# $Domain____:$
# $Namespace_:$
# $Class_____:$
# $Name______:$
# $Variant___:$
# $Revision__:$
#***********************************************************************************************************************
#</BASDKey>

package rba_Msc_TestLib;

########################################################################################################################

use warnings;
use strict;
use UdeControl;

use STEPS_general;
use STEPS_NET;
use STEPS_NET_Reports;
use STEPS_BSWITF;
use STEPS_BSWITF_BSW;
use STEPS_BSWITF_ECU;
use STEPS_BSWITF_Debugger;

use base qw(Exporter);
use vars qw(@EXPORT);

########################################################################################################################

# taken from Std_Types.h
use constant E_OK     => 0;    # no error occurred
use constant E_NOT_OK => 1;    # an error occurred

# taken from Platform_Types.h
use constant TRUE  => 1;
use constant FALSE => 0;

use constant RESULT_FAILED       => 0;
use constant RESULT_PASSED       => 1;
use constant RESULT_NOT_TESTABLE => 2;

########################################################################################################################
# the following constants need to be consistent to the #defines in rba_Msc.h

# vendor and module identification
use constant RBA_MSC_VENDOR_ID                    => 6;
use constant RBA_MSC_MODULE_ID                    => 254;
use constant RBA_MSC_INSTANCE_ID                  => 40;

# AUTOSAR version information
use constant RBA_MSC_AR_RELEASE_MAJOR_VERSION     => 4;
use constant RBA_MSC_AR_RELEASE_MINOR_VERSION     => 0;
use constant RBA_MSC_AR_RELEASE_REVISION_VERSION  => 2;

# module version information
use constant RBA_MSC_SW_MAJOR_VERSION             => 2;
use constant RBA_MSC_SW_MINOR_VERSION             => 0;
use constant RBA_MSC_SW_PATCH_VERSION             => 0;

# service IDs for public APIs
use constant RBA_MSC_SERVICE_ID_INIT              => 1;
use constant RBA_MSC_SERVICE_ID_POST_PORT_INIT    => 2;
use constant RBA_MSC_SERVICE_ID_END_INIT          => 3;
use constant RBA_MSC_SERVICE_ID_TRANSMIT          => 4;
use constant RBA_MSC_SERVICE_ID_GET_CMD_RESULT    => 5;
use constant RBA_MSC_SERVICE_ID_GET_CMD_VAL       => 6;
use constant RBA_MSC_SERVICE_ID_SET_CMD_VAL       => 7;
use constant RBA_MSC_SERVICE_ID_GET_MUX           => 8;
use constant RBA_MSC_SERVICE_ID_SET_MUX           => 9;
use constant RBA_MSC_SERVICE_ID_GET_SIG_VAL       => 10;
use constant RBA_MSC_SERVICE_ID_SET_SIG_VAL       => 11;
use constant RBA_MSC_SERVICE_ID_GET_NR_US_FRM     => 12;
use constant RBA_MSC_SERVICE_ID_SET_NR_US_FRM     => 13;
use constant RBA_MSC_SERVICE_ID_GET_US_BUF        => 14;
use constant RBA_MSC_SERVICE_ID_SHDWN             => 15;
use constant RBA_MSC_SERVICE_ID_SWTTOSYNC         => 16;

# service IDs for private APIs
use constant RBA_MSC_SERVICE_ID_PRV_HNDLR         => 50;
use constant RBA_MSC_SERVICE_ID_PRV_REMOVE_CMD    => 51;

# error codes reported to DET
use constant RBA_MSC_E_UNINIT                     => 1;
use constant RBA_MSC_E_ALREADY_INITIALIZED        => 2;
use constant RBA_MSC_E_PARAM_IS_NULL              => 3;
use constant RBA_MSC_E_PARAM_PB_CFG_IDX           => 4;
use constant RBA_MSC_E_PARAM_CMD_IDX              => 5;
use constant RBA_MSC_E_PARAM_SIG_IDX              => 6;
use constant RBA_MSC_E_PARAM_MUX_MODE             => 7;
use constant RBA_MSC_E_PARAM_SIG_VAL              => 8;
use constant RBA_MSC_E_PARAM_MUX_VAL              => 9;
use constant RBA_MSC_E_PARAM_NR_US_FRM            => 10;
use constant RBA_MSC_E_CMD_PENDING                => 11;
use constant RBA_MSC_E_DMA_INVALID                => 12;
use constant RBA_MSC_E_HNDLR_IS_IDLE              => 13;
use constant RBA_MSC_E_HNDLR_INVALID_STATE        => 14;
use constant RBA_MSC_E_HNDLR_INVALID_CFG          => 15;

########################################################################################################################

@EXPORT = qw(
  E_OK
  E_NOT_OK

  TRUE
  FALSE

  RESULT_FAILED
  RESULT_PASSED
  RESULT_NOT_TESTABLE

  RBA_MSC_VENDOR_ID
  RBA_MSC_MODULE_ID
  RBA_MSC_INSTANCE_ID

  RBA_MSC_AR_RELEASE_MAJOR_VERSION
  RBA_MSC_AR_RELEASE_MINOR_VERSION
  RBA_MSC_AR_RELEASE_REVISION_VERSION

  RBA_MSC_SW_MAJOR_VERSION
  RBA_MSC_SW_MINOR_VERSION
  RBA_MSC_SW_PATCH_VERSION

  RBA_MSC_SERVICE_ID_INIT
  RBA_MSC_SERVICE_ID_POST_PORT_INIT
  RBA_MSC_SERVICE_ID_END_INIT
  RBA_MSC_SERVICE_ID_TRANSMIT
  RBA_MSC_SERVICE_ID_GET_CMD_RESULT
  RBA_MSC_SERVICE_ID_GET_CMD_VAL
  RBA_MSC_SERVICE_ID_SET_CMD_VAL
  RBA_MSC_SERVICE_ID_GET_MUX
  RBA_MSC_SERVICE_ID_SET_MUX
  RBA_MSC_SERVICE_ID_GET_SIG_VAL
  RBA_MSC_SERVICE_ID_SET_SIG_VAL
  RBA_MSC_SERVICE_ID_GET_NR_US_FRM
  RBA_MSC_SERVICE_ID_SET_NR_US_FRM
  RBA_MSC_SERVICE_ID_GET_US_BUF
  RBA_MSC_SERVICE_ID_SHDWN
  RBA_MSC_SERVICE_ID_SWTTOSYNC

  RBA_MSC_SERVICE_ID_PRV_HNDLR
  RBA_MSC_SERVICE_ID_PRV_REMOVE_CMD

  RBA_MSC_E_UNINIT
  RBA_MSC_E_ALREADY_INITIALIZED
  RBA_MSC_E_PARAM_IS_NULL
  RBA_MSC_E_PARAM_PB_CFG_IDX
  RBA_MSC_E_PARAM_CMD_IDX
  RBA_MSC_E_PARAM_SIG_IDX
  RBA_MSC_E_PARAM_MUX_MODE
  RBA_MSC_E_PARAM_SIG_VAL
  RBA_MSC_E_PARAM_MUX_VAL
  RBA_MSC_E_PARAM_NR_US_FRM
  RBA_MSC_E_CMD_PENDING
  RBA_MSC_E_DMA_INVALID
  RBA_MSC_E_HNDLR_IS_IDLE
  RBA_MSC_E_HNDLR_INVALID_STATE
  RBA_MSC_E_HNDLR_INVALID_CFG

  getDetStatus
  getTestStep
  setTestStep
  execTestStep
  execTestStepEvalDetReportErrorBreakPoint
  isBreakPointReached
  evalDet
  evalRetVal
  printTestStepInfo
  printPassedReason
  printFailedReason
  printNotTestableReason
  printTestStepResult
  documentTestStepResult
  evalTestCaseResult
);


#-----------------------------------------------------------------------------------------------------------------------
# get DET status
# -> also write DET status to log
#-----------------------------------------------------------------------------------------------------------------------
sub getDetStatus
{
  my $ude_s = shift;

  my $detReportEnabled_s = $ude_s->readVar("TestCd_rba_Msc_isDetReportEnabled_cb");

  S_w2log(3, ("#" x 80) . "\n", "black");
  if ($detReportEnabled_s)
  {
    S_w2log(3, "Test running with DET enabled.\n", "blue");
  }
  else
  {
    S_w2log(3, "Test running with DET disabled.\n", "blue");
  }
  S_w2log(3, ("#" x 80) . "\n", "black");
  S_w2log(3, "\n", "black");

  return ($detReportEnabled_s);
}


#-----------------------------------------------------------------------------------------------------------------------
# get test step
#-----------------------------------------------------------------------------------------------------------------------
sub getTestStep
{
  my $ude_s = shift;

  return ($ude_s->readEnum("TestCd_rba_Msc_stItfTest_en"));
}


#-----------------------------------------------------------------------------------------------------------------------
# set test step in ITF structure
#-----------------------------------------------------------------------------------------------------------------------
sub setTestStep
{
  my $ude_s         = shift;
  my $strTestCase_s = shift;

  # set the test case
  $ude_s->setEnum("TestCd_rba_Msc_stItfTest_en", $strTestCase_s)
}


#-----------------------------------------------------------------------------------------------------------------------
# execute test step
#-----------------------------------------------------------------------------------------------------------------------
sub execTestStep
{
  my $ude_s         = shift;
  my $strTestStep_s = shift;

  my $timeoutCnt_s = 0;

  # start test execution
  S_w2log(3, "Execute test step $strTestStep_s\n", "black");
  setTestStep($ude_s, $strTestStep_s);

  # wait until test case has been finished
  while (getTestStep($ude_s) eq $strTestStep_s)
  {
    select(undef, undef, undef, 0.1);    # sleep 100ms
    $timeoutCnt_s++;
    if ($timeoutCnt_s > 100)             # 10s expired
    {
      $ude_s->udeDie("##ERROR execution of test step: timeout");
    }
  }
}


#-----------------------------------------------------------------------------------------------------------------------
# execute test step and evaluate if DET report occurs
#-----------------------------------------------------------------------------------------------------------------------
sub execTestStepEvalDetReportErrorBreakPoint
{
  my $ude_s         = shift;
  my $strTestStep_s = shift;
  my $moduleId_s    = shift;
  my $instanceId_s  = shift;
  my $serviceId_s   = shift;
  my $errorId_s     = shift;

  my $cntBreakPoint_s = 0;
  my $cntTimeout_s    = 500;    # set timeout to appr. 50 seconds

  my $xDetReportError_s = "Det_ReportError";

  # set breakpoint to Det_ReportError
  if (0)
  {
    # workaround for Green Hills compiler
    # -> locals are not valid at the start of the function
    # -> there are initial register moves, after these moves the locals are valid, hence add 8 to the functions address

    # get address of Det_ReportError
    $xDetReportError_s = $ude_s->getAddr($xDetReportError_s);

    # strip leading 0X
    # -> hex() does not like the capital X in the leading 0X of the hex value
    $xDetReportError_s =~ s/^0X//i;

    # convert heximal to decimal and add offset of 8
    $xDetReportError_s = hex($xDetReportError_s) + 8;
  }
  $ude_s->addBreakpoint($xDetReportError_s);

  S_w2log(3, "Execute test step $strTestStep_s with DET check\n", "black");

  # start test execution in TestCd by triggering the test step
  setTestStep($ude_s, $strTestStep_s);

  # wait until test step has been finished
  # -> die in case the test step is not finished in time
  while (getTestStep($ude_s) eq $strTestStep_s)
  {
    # check if breakpoint is reached
    if (!($ude_s->targetProgramIsRunning()))
    {
      if ($ude_s->pcIsInsideFunction("Det_ReportError"))
      {
        S_w2log(3, "Found Det_ReportError breakpoint\n", "black");

        my $moduleIdAct_s = $ude_s->readLocalVar("ModuleId");

        # breakpoint is reached
        # -> check if the expected DET report call is found
        if ($moduleIdAct_s == $moduleId_s)
        {
          S_w2log(3, "Found DET with correct module ID: $moduleId_s\n", "black");

          # check also the instance ID if specified
          if (defined($instanceId_s))
          {
            my $instanceIdAct_s = $ude_s->readLocalVar("InstanceId");

            if ($instanceIdAct_s == $instanceId_s)
            {
              S_w2log(3, "Found DET with correct instance ID: $instanceId_s\n", "black");

              # check also the service/API ID if specified
              if (defined($serviceId_s))
              {
                my $serviceIdAct_s = $ude_s->readLocalVar("ApiId");

                if ($serviceIdAct_s == $serviceId_s)
                {
                  S_w2log(3, "Found DET with correct service ID: $serviceId_s\n", "black");

                  # check also the error ID if specified
                  if (defined($errorId_s))
                  {
                    my $errorIdAct_s = $ude_s->readLocalVar("ErrorId");

                    # DetReportError called with expected parameters (including error ID)
                    if ($errorIdAct_s == $errorId_s)
                    {
                      S_w2log(3, "Found DET with correct error ID: $errorId_s\n", "black");

                      $cntBreakPoint_s++;
                    }
                    else
                    {
                      S_w2log(3, "Found DET with unexpected error ID: $errorIdAct_s\n", "black");
                    }
                  }
                  else
                  {
                    # DetReportError called with expected parameters (no error ID specified)
                    $cntBreakPoint_s++;
                  }
                }
                else
                {
                  S_w2log(3, "Found DET with unexpected service ID: $serviceIdAct_s\n", "black");
                }
              }
              else
              {
                # DetReportError called with expected parameters (no service ID specified)
                $cntBreakPoint_s++;
              }
            }
            else
            {
              S_w2log(3, "Found DET with unexpected instance ID: $instanceIdAct_s\n", "black");
            }
          }
          else
          {
            # DetReportError called with expected parameters (no instance ID specified)
            $cntBreakPoint_s++;
          }
        }
        else
        {
          S_w2log(3, "Found DET with unexpected module ID: $moduleIdAct_s\n", "black");
        }
      }

      $ude_s->go();
    }

    # sleep 100ms
    select(undef, undef, undef, 0.1);

    # timeout handling
    $cntTimeout_s--;
    if ($cntTimeout_s < 0)
    {
      $ude_s->udeDie("##ERROR execution of test step $strTestStep_s: timeout");
    }
  }

  $ude_s->removeBreakpoint($xDetReportError_s);

  # run target in case target has stopped on Det_ReportError breakpoint before it is removed above
  if ((!$ude_s->targetProgramIsRunning()) && $ude_s->pcIsInsideFunction("Det_ReportError"))
  {
    $ude_s->go();
  }

  return ($cntBreakPoint_s);
}


#-----------------------------------------------------------------------------------------------------------------------
# wait until a breakpoint is reached (or a timeout expired)
#-----------------------------------------------------------------------------------------------------------------------
sub isBreakPointReached
{
  my $ude_s     = shift;
  my $strFunc_s = shift;

  # set timeout to 10s
  my $cntTimeOut_s = 10;

  # wait until breakpoint halt is reached
  while ($cntTimeOut_s > 0)
  {
    # check if target is running
    if ($ude_s->targetProgramIsRunning())
    {
      # target is running
      # -> wait a second
      sleep(1);

      $cntTimeOut_s--;
    }
    else
    {
      if (defined($strFunc_s))
      {
        if ($ude_s->pcIsInsideFunction($strFunc_s))
        {
          # return 1 to signal that the breakpoint is reached in the specified function
          return (1);
        }

        # leave while loop, because a breakpoint has been found but in the wrong function
        $cntTimeOut_s = 0;
      }
      else
      {
        # return 1 to signal that the breakpoint is reached
        # -> no specific functions is specified
        return (1);
      }
    }
  }

  # return 0 to signal that the breakpoint is NOT reached
  return (0);
}


#-----------------------------------------------------------------------------------------------------------------------
# check if DET occurred as expected, if not update test result and print failed reason
#-----------------------------------------------------------------------------------------------------------------------
sub evalDet
{
  my $ude_s            = shift;
  my $testStepResult_s = shift;
  my $cntBreakPoint_s  = shift;

  # check if test step result is RESULT_PASSED
  # -> if not there is nothing to do
  if ($testStepResult_s == RESULT_PASSED)
  {
    # check if the expected DET report call was not found
    if ($cntBreakPoint_s == 0)
    {
      $testStepResult_s = RESULT_FAILED;
      printFailedReason("Det_ReportError was not called in the function with the expected parameters.");
    }
  }

  return ($testStepResult_s);
}


#-----------------------------------------------------------------------------------------------------------------------
# check return value stored by test driver
#-----------------------------------------------------------------------------------------------------------------------
sub evalRetVal
{
  my $ude_s            = shift;
  my $testStepResult_s = shift;
  my $strElement_s     = shift;
  my $xExpVal_s        = shift;

  # check if test step result is RESULT_PASSED
  # -> if not there is nothing to do
  if ($testStepResult_s == RESULT_PASSED)
  {
    # read the return value stored by the test driver
    my $xActVal_s = $ude_s->readStructComponentValue($ude_s->getStructObject("TestCd_rba_Msc_xItfTest_st"),
                                                     $strElement_s);

    # check if the expected return value was not found
    if ($xActVal_s ne "$xExpVal_s")
    {
      $testStepResult_s = RESULT_FAILED;
      printFailedReason("The return value found in TestCd_rba_Msc_xItfTest_st.$strElement_s ($xActVal_s) " .
                        "is not the expected value ($xExpVal_s).");
    }
  }

  return ($testStepResult_s);
}


#-----------------------------------------------------------------------------------------------------------------------
# print test step info
#-----------------------------------------------------------------------------------------------------------------------
sub printTestStepInfo
{
  my $testStep_s              = shift;
  my $testStepDesc_s          = shift;
  my $testStepPrecond_s       = shift;
  my $testStepExpectedBehav_s = shift;

  S_w2log(3, ("#" x 80) . "\n", "black");
  S_w2log(3, "<B><U>--- " . $testStep_s . " ---</U></B>\n", "black");
  S_w2log(3, "\n",                                          "black");
  S_w2log(3, "<U>Test step description:</U>\n",             "black");
  S_w2log(3, $testStepDesc_s . "\n",                        "black");
  S_w2log(3, "\n",                                          "black");
  S_w2log(3, "<U>Test step preconditions:</U>\n",           "black");
  S_w2log(3, $testStepPrecond_s . "\n",                     "black");
  S_w2log(3, "\n",                                          "black");
  S_w2log(3, "<U>Test step expected behaviour:</U>\n",      "black");
  S_w2log(3, $testStepExpectedBehav_s . "\n",               "black");
  S_w2log(3, "\n",                                          "black");
  S_w2log(3, "<U>Test step result:</U>\n",                  "black");
}


#-----------------------------------------------------------------------------------------------------------------------
# print passed reason but only if the test step result is actually passed
#-----------------------------------------------------------------------------------------------------------------------
sub printPassedReason
{
  my $testStepResult_s = shift;
  my $passedReason_s   = shift;

  if ($testStepResult_s == RESULT_PASSED)
  {
    S_w2log(3, $passedReason_s . "\n", "black");
  }
}


#-----------------------------------------------------------------------------------------------------------------------
# print failed reason, use colour red to highlight it
#-----------------------------------------------------------------------------------------------------------------------
sub printFailedReason
{
  my $failedReason_s = shift;

  S_w2log(3, $failedReason_s . "\n", "red");
}


#-----------------------------------------------------------------------------------------------------------------------
# print not testable reason, use colour mediumblue to highlight it a little bit
#-----------------------------------------------------------------------------------------------------------------------
sub printNotTestableReason
{
  my $notTestableReason_s = shift;

  S_w2log(3, $notTestableReason_s . "\n", "mediumblue");
}


#-----------------------------------------------------------------------------------------------------------------------
# print test step result
#-----------------------------------------------------------------------------------------------------------------------
sub printTestStepResult
{
  my $testStepResult_s = shift;

  my $text_s;
  my $color_s;

  if ($testStepResult_s == RESULT_FAILED)
  {
    $text_s  = "FAILED";
    $color_s = "red";
  }
  elsif ($testStepResult_s == RESULT_PASSED)
  {
    $text_s  = "PASSED";
    $color_s = "green";
  }
  elsif ($testStepResult_s == RESULT_NOT_TESTABLE)
  {
    $text_s  = "NOT TESTABLE";
    $color_s = "mediumblue";
  }
  else
  {
    $text_s  = "PARAMETER ERROR";
    $color_s = "cyan";
  }

  S_w2log(3, "\n",               "black");
  S_w2log(3, "<B>$text_s</B>\n", $color_s);
  S_w2log(3, ("#" x 80) . "\n",  "black");
  S_w2log(3, "\n",               "black");
  S_w2log(3, "\n",               "black");
}


#-----------------------------------------------------------------------------------------------------------------------
# document the test step result of a normal test step and update the test case result (return value)
#-----------------------------------------------------------------------------------------------------------------------
sub documentTestStepResult
{
  my $testStepResult_s = shift;
  my $testCaseResult_s = shift;

  printTestStepResult($testStepResult_s);

  if ($testStepResult_s == RESULT_FAILED)
  {
    # update test case result in case the test step failed
    $testCaseResult_s = RESULT_FAILED;
  }

  return ($testCaseResult_s);
}


#-----------------------------------------------------------------------------------------------------------------------
# evaluate test case result
# -> write test case result to log
# -> set verdict
#-----------------------------------------------------------------------------------------------------------------------
sub evalTestCaseResult
{
  my $ude_s        = shift;
  my $TestResult_s = shift;

  my $strResult_s;
  my $strColor_s;
  my $strVerdict_s;

  S_w2log(3, "<B>Test case result:</B>\n", "black");
  S_w2log(3, "\n",                         "black");

  if (RESULT_PASSED == $TestResult_s)
  {
    $strResult_s  = "PASSED";
    $strColor_s   = "green";
    $strVerdict_s = "VERDICT_PASS";
  }
  elsif (RESULT_FAILED == $TestResult_s)
  {
    $strResult_s  = "FAILED";
    $strColor_s   = "red";
    $strVerdict_s = "VERDICT_FAIL";
  }
  elsif (RESULT_NOT_TESTABLE == $TestResult_s)
  {
    $strResult_s  = "not testable";
    $strColor_s   = "blue";
    $strVerdict_s = "VERDICT_NONE";
  }
  else
  {
    $ude_s->udeDie("##ERROR invalid test result value: $TestResult_s");
  }

  S_w2log(3, "<B>$strResult_s</B>\n", $strColor_s);
  S_w2log(3, "\n",                    "black");

  S_set_verdict($strVerdict_s);
}


########################################################################################################################
1;
########################################################################################################################

#<BASDKey>
#***********************************************************************************************************************
# $History___:$
#***********************************************************************************************************************
#</BASDKey>
