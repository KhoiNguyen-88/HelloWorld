#// ----------------------------------------------------------------------------
#// COPYRIGHT RESERVED, 2012, Robert Bosch GmbH. All rights reserved.  The
#/ reproduction, distribution and utilization of this document as well as the
#// communication of its contents to others without explicit authorization is
#// prohibited.  Offenders will be held liable for the payment of damages.  All
#// rights reserved in the event of the grant of a patent, utility model or
#// design.
#// ----------------------------------------------------------------------------
#//! \file
#//! \brief
#//!
#//! $Source: T $
#//! $Author:  $
#//! $Revision:  $
#//! $Date: ST $
#//!
#//! User documentation: doc Folder
#// ----------------------------------------------------------------------------
#// History:
#// ---------------------------------------------------------------------------
#######################################################################

#######################################################################

package Dio_ReadPort;

#######################################################################

=head1 Test-Specification for rba_IoDiagPs_Init

This is the test-specification as xml-describtion

<TestConfiguration>
 <TC_Id><BASDKey>$Filename__:$$Class_____:$$Variant___:$$Revision__:$</BASDKey></TC_Id>
 <TC_BL></TC_BL>
 <TC_Spec></TC_Spec>
 <TC_EnvCond></TC_EnvCond>
 <TC_ExpRes></TC_ExpRes>
 <TestStep></TestStep>
 <TestMethod></TestMethod>
 <TestPrep></TestPrep>
 <TestType>automated</TestType>
 <Environment></Environment>
 <ResConsumption></ResConsumption>
 <CoveredReq_Id>
 </CoveredReq_Id>
 <CoveredReq_Doc>BSW_SWS_AR4_0_R2_DIODriver_TC_PPC</CoveredReq_Doc>
</TestConfiguration>

=cut

#######################################################################

use STEPS_general;
use STEPS_NET;
use STEPS_NET_Reports;
use STEPS_BSWITF;
use STEPS_BSWITF_BSW;
use STEPS_BSWITF_ECU;
use STEPS_BSWITF_Debugger;

use strict;
use warnings;
use Dio_TestLib; # library for own tests

# global variables
my $TestResult_s; # test result of the test case (result overall test steps)
my $ude_s = undef; # handle for accessing ude functionality

# constants
use constant SERVICE_ID => 0x02;


sub TC_set_parameters {
  # Here we can set initial parameters for the testcase_s
  $TestResult_s = RESULT_PASSED;
  $ude_s = new UdeControl();

  return 1;
}

sub TC_initialization {
  BSWITF_Init();    ### Initialisation of the BSWITF
  return 1;
}

sub TC_stimulation_and_measurement {


    # variables containing describing text
    my $testStep_s;
    my $testStepDesc_s;
    my $testStepExpectedBehav_s;
    my $testStepResult_s;

    # variables containing values relevant for appraising the test step result
    my $BreakPointReached_s = 0;

     # Start of test steps
    ############################################################################


        my $testcdStruct_s = $ude_s->getStructObject( "TestCd_Dio_st" );
        my $testcase_s     = $ude_s->getStructComponent( $testcdStruct_s, "stTestcase_en" );
        my $configSetTest_s   = $ude_s->getStructComponent( $testcdStruct_s, "pPBConfigTest_pst" );

        my $itf_num_port = $ude_s->readVar("TestCd_Dio_ITF_num_portnames_u8");
        my $itf_port_name = $ude_s->readVar("TestCd_Dio_ITF_PortName_u8");

        my $Machine_Fam_var = $ude_s->readVar("Dio_Machine_Fam_u8");
        my $Machine_Fam_IFX = $ude_s->readVar("Dio_ITF_IFX_u8");
        my $Machine_Fam_JDP = $ude_s->readVar("Dio_ITF_JDP_u8");

        # used test case of TestCd
        my $TestCaseSelected_s = "TESTCD_DIO_READPORT";

        ############################################################################

            my $detReportEnabled_s = checkDetStatus($ude_s);

            if($detReportEnabled_s == 1)
            {
                $testStepExpectedBehav_s .= "\n- Call for Det_ReportError in the function is activated.";
            }
            else
            {
                $detReportEnabled_s = 0;
                $testStepExpectedBehav_s .= "\n- No call of Det_ReportError in the function.";
            }
            printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

            if( $detReportEnabled_s)
            {
                ### Prepare test step execution
                $testStepResult_s = RESULT_PASSED;

                # test step 1
                $testStep_s              = "Dio_ReadPort Test Step 1";
                $testStepDesc_s          = "Call the Dio_ReadPort function with invalid Port name";
                $testStepExpectedBehav_s = "Raise the Det_ReportError DIO_E_PARAM_INVALID_PORT_ID";
                printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

                $ude_s->setStructComponentValue( $testcdStruct_s, "Dio_PortType_u8", $itf_num_port );

                ### Execute test step
                $BreakPointReached_s = execTestCaseEvalDetReportErrorBreakPoint( $ude_s, $TestCaseSelected_s, SERVICE_ID, 0x14 );

                ### Evaluate test step result
                if($BreakPointReached_s != 1)
                {
                    $testStepResult_s = RESULT_FAILED;
                    printFailedReason("Det_ReportError DIO_E_PARAM_INVALID_PORT_ID was not called in the function.");
                }

                ### Result documentation
                if( RESULT_FAILED eq $testStepResult_s )
                {
                    $TestResult_s = RESULT_FAILED;
                }
                printTestStepResult($testStepResult_s);
                #---------------------------------------------------------------------------

               }
            else
            {
                execTestCase( $ude_s, $TestCaseSelected_s );

                if( $ude_s->readEnumObject( $testcase_s )  eq  "TESTCD_DIO_TEST_NOTTESTABLE_E" )
                {
                    $testStepResult_s = RESULT_NOT_TESTABLE;
                    printNotTestableReason(" DIO_DEV_ERROR_DETECT is not activated.");

                    if( RESULT_NOT_TESTABLE eq $testStepResult_s )
                    {
                        $TestResult_s = RESULT_NOT_TESTABLE;
                    }
                    printTestStepResult($testStepResult_s);
                }
            }
            #---------------------------------------------------------------------------

            $testStep_s              = "Dio_ReadPort Test Step 2";
            $testStepDesc_s          = "Call the Dio_ReadPort function with valid port name and get the value of the port from the port input register";
            $testStepExpectedBehav_s = "The return value of the API should be equal to the value obtained from the port input register";
            printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

            $ude_s->setStructComponentValue( $testcdStruct_s, "Dio_PortType_u8", $itf_port_name);

            execTestCase( $ude_s, $TestCaseSelected_s );

            $testStepResult_s = RESULT_FAILED;

            {
                my $StartTime_s = time;
                my $ret         = $ude_s->readVar( "TestCd_Dio_readport_retval_u16" );

                while ((time - $StartTime_s) < 5)
                {
                    my $regVar;

                    if($Machine_Fam_var == $Machine_Fam_IFX)
                    {
                        $regVar = $ude_s->readReg( "P00_IN" );
                    }
                    elsif($Machine_Fam_var == $Machine_Fam_JDP)
                    {
                        $regVar = $ude_s->readReg( "SIUL2_PGPDI3" );
                    }

                    if($ret == $regVar)
                    {
                        $testStepResult_s = RESULT_PASSED;
                        last;
                    }
                }
            }

            ### Result documentation
            printTestStepResult($testStepResult_s);

            $TestResult_s = $testStepResult_s;

    #---------------------------------------------------------------------------
    return 1;
}

sub TC_evaluation
{
    evaluation_TestResult( $ude_s, $TestResult_s );
    return 1;
}

sub TC_finalization {
### exit the test environment

  # clear the handle to enable following test cases to have access to the ude
  undef($ude_s);

  BSWITF_Exit();
  return 1;
}

1;
