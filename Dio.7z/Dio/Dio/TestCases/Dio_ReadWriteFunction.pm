#// ----------------------------------------------------------------------------
#// COPYRIGHT RESERVED, 2012, Robert Bosch GmbH. All rights reserved.  The
#/ reproduction, distribution and utilization of this document as well as the
#// communication of its contents to others without explicit authorization is
#// prohibited.  Offenders will be held liable for the payment of damages.  All
#// rights reserved in the event of the grant of a patent, utility model or
#// design.
#// ----------------------------------------------------------------------------
#//! \file
#//! \brief
#//!
#//! $Source: T $
#//! $Author:  $
#//! $Revision:  $
#//! $Date: ST $
#//!
#//! User documentation: doc Folder
#// ----------------------------------------------------------------------------
#// History:
#// ---------------------------------------------------------------------------
#######################################################################

#######################################################################

package Dio_ReadWriteFunction;

#######################################################################

=head1 Test-Specification for Dio_Test_Temp

This is the test-specification as xml-describtion

<TestConfiguration>
 <TC_Id><BASDKey>$Filename__:$$Class_____:$$Variant___:$$Revision__:$</BASDKey></TC_Id>
 <TC_BL></TC_BL>
 <TC_Spec></TC_Spec>
 <TC_EnvCond></TC_EnvCond>
 <TC_ExpRes></TC_ExpRes>
 <TestStep></TestStep>
 <TestMethod></TestMethod>
 <TestPrep></TestPrep>
 <TestType>automated</TestType>
 <Environment></Environment>
 <ResConsumption></ResConsumption>
 <CoveredReq_Id>
	BSW_SWS_AR4_0_R2_DIODriver-7911,
	BSW_SWS_AR4_0_R2_DIODriver-7912,
	BSW_SWS_AR4_0_R2_DIODriver-7938,
	BSW_SWS_AR4_0_R2_DIODriver-7939,
	BSW_SWS_AR4_0_R2_DIODriver-7940,
	BSW_SWS_AR4_0_R2_DIODriver-7941,
	BSW_SWS_AR4_0_R2_DIODriver-7943,
	BSW_SWS_AR4_0_R2_DIODriver-7953,
	BSW_SWS_AR4_0_R2_DIODriver-7954,
	BSW_SWS_AR4_0_R2_DIODriver-7956,
	BSW_SWS_AR4_0_R2_DIODriver-7962,
	BSW_SWS_AR4_0_R2_DIODriver-7966,
	BSW_SWS_AR4_0_R2_DIODriver-8004,
	BSW_SWS_AR4_0_R2_DIODriver-8009,
	BSW_SWS_AR4_0_R2_DIODriver-8171,
	BSW_SWS_AR4_0_R2_DIODriver-8205,
	BSW_SWS_AR4_0_R2_DIODriver-8206,
	BSW_SWS_AR4_0_R2_DIODriver-8209,
	BSW_SWS_AR4_0_R2_DIODriver-8246,
	BSW_SWS_AR4_0_R2_DIODriver-8247,
	BSW_SWS_AR4_0_R2_DIODriver-8248,
	BSW_SWS_AR4_0_R2_DIODriver-8491
 </CoveredReq_Id>
 <CoveredReq_Doc>BSW_SWS_AR4_0_R2_DIODriver_TC_PPC</CoveredReq_Doc>
</TestConfiguration>

=cut

#######################################################################

use STEPS_general;
use STEPS_NET;
use STEPS_NET_Reports;
use STEPS_BSWITF;
use STEPS_BSWITF_BSW;
use STEPS_BSWITF_ECU;
use STEPS_BSWITF_Debugger;

use Dio_TestLib; # library for own tests

#===============================================================================
# global variables
my $TestResult_s; # test result of the test case (result overall test steps)
my $ude_s = undef; # handle for accessing ude functionality

my $ret;
my $ret_cmp;

# constants
 use constant SERVICE_ID_READ => 0x00;
 use constant SERVICE_ID_WRITE => 0x01;

sub TC_set_parameters {
  # Here we can set initial parameters for the testcase_s

  $TestResult_s = RESULT_PASSED;
  $ude_s = new UdeControl();
  return 1;
}

sub TC_initialization {
  BSWITF_Init();    ### Initialisation of the BSWITF
  return 1;
}

sub TC_stimulation_and_measurement
{

    # variables containing describing text
    my $testStep_s;
    my $testStepDesc_s;
    my $testStepExpectedBehav_s;
    my $testStepResult_s;
    my $TestCaseSelected_s;

    # variables containing values relevant for appraising the test step result
    my $BreakPointReached_s;
    my $testStepReturnValue_s;

    my $testcdStruct_s = $ude_s->getStructObject( "TestCd_Dio_st" );
    my $testcase_s     = $ude_s->getStructComponent( $testcdStruct_s, "stTestcase_en" );
    my $itf_num_signals = $ude_s->readVar("TestCd_Dio_ITF_num_signals_u8");
	my $itf_input = $ude_s->readVar("TestCd_Dio_ITF_input_u8");
	my $itf_output = $ude_s->readVar("TestCd_Dio_ITF_output_u8");


	# used test case of TestCd
		my $detReportEnabled_s = checkDetStatus($ude_s);
		
		if($detReportEnabled_s == 1)
		{
			$testStepExpectedBehav_s .= "\n- Call for Det_ReportError in the function is activated.";
		}
		else
		{
			$detReportEnabled_s = 0;
			$testStepExpectedBehav_s .= "\n- No call of Det_ReportError in the function.";
		}
		printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);
			
		if($detReportEnabled_s)
		{
			### Prepare test step execution
			$testStepResult_s = RESULT_PASSED;

			############################################## test step 1 ############################################################
            $testStep_s              = "Dio Test Step 1";
			$testStepDesc_s          = "Call the Dio_readchannel function with invalid channel";
			$testStepExpectedBehav_s = "Raise the Det_ReportError DIO_E_PARAM_INVALID_CHANNEL_ID";
			printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

			$ude_s->setStructComponentValue( $testcdStruct_s, "Dio_PinType_u16", $itf_num_signals );
			
			### Execute test step
			$TestCaseSelected_s = "TESTCD_DIO_READCHANNEL";
			$BreakPointReached_s = execTestCaseEvalDetReportErrorBreakPoint( $ude_s, $TestCaseSelected_s, SERVICE_ID_READ, 0x0A );
			
			### Evaluate test step result
			if($BreakPointReached_s != 1 )
			{
				$testStepResult_s = RESULT_FAILED;
				printFailedReason("Det_ReportError DIO_E_PARAM_INVALID_CHANNEL_ID was not called in the function.");
			}

			### Result documentation
			if( RESULT_FAILED eq $testStepResult_s )
			{
				$TestResult_s = RESULT_FAILED;
			}
			printTestStepResult($testStepResult_s);

			############################################## test step 2 ############################################################
            $testStep_s              = "Dio Test Step 2";
			$testStepDesc_s          = "Call the Dio_writechannel function with invalid channel";
			$testStepExpectedBehav_s = "Raise the Det_ReportError DIO_E_PARAM_INVALID_CHANNEL_ID";
			printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

			$TestCaseSelected_s = "TESTCD_DIO_WRITECHANNEL";
			$BreakPointReached_s = execTestCaseEvalDetReportErrorBreakPoint( $ude_s, $TestCaseSelected_s, SERVICE_ID_WRITE, 0x0A );
			if($BreakPointReached_s != 1 )
			{
				$testStepResult_s = RESULT_FAILED;
				printFailedReason("Det_ReportError DIO_E_PARAM_INVALID_CHANNEL_ID was not called in the function.");
			}

			if( RESULT_FAILED eq $testStepResult_s )
			{
				$TestResult_s = RESULT_FAILED;
			}
			printTestStepResult($testStepResult_s);

			############################################## test step 3 ############################################################
            $testStep_s              = "Dio Test Step 3";
			$testStepDesc_s          = "Call the Dio_writechannel and Dio_readchannel function with invalid channel";
			$testStepExpectedBehav_s = "Write function shall not process and read function shall return with the value '0'.";
			printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

			$ude_s->setStructComponentValue( $testcdStruct_s, "Dio_LevelType_u8", 1 );

			$TestCaseSelected_s = "TESTCD_DIO_WRITECHANNEL";
			execTestCase( $ude_s, $TestCaseSelected_s );

			$TestCaseSelected_s = "TESTCD_DIO_READCHANNEL";
			execTestCase( $ude_s, $TestCaseSelected_s );

			$ret = $ude_s->readVar("TestCd_Dio_retval_u8");

			if($ret)
			{
				$testStepResult_s = RESULT_FAILED;
				printFailedReason("Dio module's write function should NOT process the write command and the read function should return with the value '0' instead of '$ret'.");
			}

			if( RESULT_FAILED eq $testStepResult_s )
			{
				$TestResult_s = RESULT_FAILED;
			}
			printTestStepResult($testStepResult_s);
		}
    #---------------------------------------------------------------------------

    ############################################################################

			############################################## test step 4 ############################################################
            $testStep_s              = "Dio Test Step 4";
			$testStepDesc_s          = "Call the Dio_writechannel function and make the output channel as high, then read the level of that output channel back by using the Dio_Readchannel function.";
			$testStepExpectedBehav_s = "-  physical level of the selected output channel will be 1.";
			printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

			### Prepare test step execution
			$testStepResult_s = RESULT_PASSED;

			$ude_s->setStructComponentValue( $testcdStruct_s, "Dio_PinType_u16", $itf_output );
			$ude_s->setStructComponentValue( $testcdStruct_s, "Dio_LevelType_u8", 1 );


			$TestCaseSelected_s = "TESTCD_DIO_WRITECHANNEL";
			execTestCase( $ude_s, $TestCaseSelected_s );

			$TestCaseSelected_s = "TESTCD_DIO_READCHANNEL";
			execTestCase( $ude_s, $TestCaseSelected_s );

			$ret = $ude_s->readVar("TestCd_Dio_retval_u8");

			if ($ret != 1)
			{
				$testStepResult_s = RESULT_FAILED;
				printFailedReason("Incorrect level of output channel, expected value: 1, test valve: $ret ");
			}

			### Result documentation

			if( RESULT_FAILED eq $testStepResult_s )
			{
				$TestResult_s = RESULT_FAILED;
			}
			printTestStepResult($testStepResult_s);

			############################################## test step 5 ############################################################
				$testStep_s              = "Dio Test Step 5";
				$testStepDesc_s          = "Call the Dio_writechannel function and make the output channel as low, then read the level of that output channel back by using the Dio_Readchannel function.";
				$testStepExpectedBehav_s = "-  physical level of the selected output channel will be 0.";
				printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

			### Prepare test step execution
			$testStepResult_s = RESULT_PASSED;

			$ude_s->setStructComponentValue( $testcdStruct_s, "Dio_PinType_u16", $itf_output );
			$ude_s->setStructComponentValue( $testcdStruct_s, "Dio_LevelType_u8", 0 );


		   $TestCaseSelected_s = "TESTCD_DIO_WRITECHANNEL";
		   execTestCase( $ude_s, $TestCaseSelected_s );

		   $TestCaseSelected_s = "TESTCD_DIO_READCHANNEL";
		   execTestCase( $ude_s, $TestCaseSelected_s );

		   $ret = $ude_s->readVar("TestCd_Dio_retval_u8");

		   if ($ret != 0)
			  {
				$testStepResult_s = RESULT_FAILED;
				printFailedReason("Incorrect level of output channel, expected value: 0, test valve: $ret ");
			  }

			### Result documentation

			if( RESULT_FAILED eq $testStepResult_s )
			{
				$TestResult_s = RESULT_FAILED;
			}
			printTestStepResult($testStepResult_s);

			############################################## test step 6 ############################################################
					$testStep_s              = "Dio Test Step 6";
					$testStepDesc_s          = "Call the Dio_readchannel function and read the physical level of an input channel, then call the Dio_writechannel function and make that input channel as high, finally read the level of that input channel back by using the Dio_Readchannel function.";
					$testStepExpectedBehav_s = "-  physical level of the selected input channel will remain the same.";
					printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

			### Prepare test step execution
			$testStepResult_s = RESULT_PASSED;

			$ude_s->setStructComponentValue( $testcdStruct_s, "Dio_PinType_u16", $itf_input );
			$ude_s->setStructComponentValue( $testcdStruct_s, "Dio_LevelType_u8", 1 );

			$TestCaseSelected_s = "TESTCD_DIO_READCHANNEL";
			execTestCase( $ude_s, $TestCaseSelected_s );

			$ret = $ude_s->readVar("TestCd_Dio_retval_u8");

			$TestCaseSelected_s = "TESTCD_DIO_WRITECHANNEL";
			execTestCase( $ude_s, $TestCaseSelected_s );

			$TestCaseSelected_s = "TESTCD_DIO_READCHANNEL";
			execTestCase( $ude_s, $TestCaseSelected_s );

			$ret_cmp = $ude_s->readVar("TestCd_Dio_retval_u8");

		   if ($ret != $ret_cmp)
			  {
				$testStepResult_s = RESULT_FAILED;
				printFailedReason(" Physical level of the selected input channel has changed from: $ret to $ret_cmp. ");
			  }

			### Result documentation

			if( RESULT_FAILED eq $testStepResult_s )
			{
				$TestResult_s = RESULT_FAILED;
			}
			printTestStepResult($testStepResult_s);

			############################################## test step 7 ############################################################
					$testStep_s              = "Dio Test Step 7";
					$testStepDesc_s          = "Call the Dio_readchannel function and read the physical level of an input channel, then call the Dio_writechannel function and make that input channel as low, finally read the level of that input channel back by using the Dio_Readchannel function.";
					$testStepExpectedBehav_s = "-  physical level of the selected input channel will remain the same. ";
					printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

			### Prepare test step execution
			$testStepResult_s = RESULT_PASSED;

			$ude_s->setStructComponentValue( $testcdStruct_s, "Dio_PinType_u16", $itf_input );
			$ude_s->setStructComponentValue( $testcdStruct_s, "Dio_LevelType_u8", 0 );

			$TestCaseSelected_s = "TESTCD_DIO_READCHANNEL";
			execTestCase( $ude_s, $TestCaseSelected_s );

			$ret = $ude_s->readVar("TestCd_Dio_retval_u8");

			$TestCaseSelected_s = "TESTCD_DIO_WRITECHANNEL";
			execTestCase( $ude_s, $TestCaseSelected_s );

			$TestCaseSelected_s = "TESTCD_DIO_READCHANNEL";
			execTestCase( $ude_s, $TestCaseSelected_s );

			$ret_cmp = $ude_s->readVar("TestCd_Dio_retval_u8");

			if ($ret != $ret_cmp)
			  {
				$testStepResult_s = RESULT_FAILED;
				printFailedReason(" Physical level of the selected input channel has changed from: $ret to $ret_cmp. ");
			  }

			### Result documentation

			if( RESULT_FAILED eq $testStepResult_s )
			{
				$TestResult_s = RESULT_FAILED;
			}
			printTestStepResult($testStepResult_s);

    #---------------------------------------------------------------------------

    return 1;
}



sub TC_evaluation
{
    evaluation_TestResult( $ude_s, $TestResult_s );
    return 1;
}

sub TC_finalization {
### exit the test environment

  # clear the handle to enable following test cases to have access to the ude
  undef($ude_s);

  BSWITF_Exit();
  return 1;
}

1;
