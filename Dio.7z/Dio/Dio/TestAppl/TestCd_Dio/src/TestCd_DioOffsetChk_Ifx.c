/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, 2010 Robert Bosch GmbH. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:$
 * $Namespace_:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 **********************************************************************************************************************
</BASDKey>*/

#include "TestCd_Dio.h"
#include "Mcu.h"

#if (MCU_RB_MACHINE_FAM == MCU_RB_IFX_UC1)

#include "Dio.h"
#include "Dio_Prv.h"
#include "rba_Reg.h"
#include RBA_REG_PORT_H

// This is the perl script which is used to generate the code below
//my $out;
//
//for(my $Port=0; $Port<100; $Port++)
//{
//    my $port = sprintf('%02s', $Port);
//$out .= <<EOT;
//#if defined RBA_REG_P${port}_OUT_P0_POS || defined RBA_REG_P${port}_OUT_P1_POS || defined RBA_REG_P${port}_OUT_P2_POS|| defined RBA_REG_P${port}_OUT_P3_POS || defined RBA_REG_P${port}_OUT_P4_POS || defined RBA_REG_P${port}_OUT_P5_POS || defined RBA_REG_P${port}_OUT_P6_POS || defined RBA_REG_P${port}_OUT_P7_POS || defined RBA_REG_P${port}_OUT_P8_POS || defined RBA_REG_P${port}_OUT_P9_POS || defined RBA_REG_P${port}_OUT_P10_POS || defined RBA_REG_P${port}_OUT_P11_POS || defined RBA_REG_P${port}_OUT_P12_POS || defined RBA_REG_P${port}_OUT_P13_POS || defined RBA_REG_P${port}_OUT_P14_POS || defined RBA_REG_P${port}_OUT_P15_POS
//    TestCdDioChkPort(P${port});
//#endif
//
//EOT
//}
//
//print $out;

#define TestCdDioChkPort(Port)                                                    \
    if(                                                                           \
            (((uint32)(&(Port).OUT) - (uint32)(&(Port))) == DIO_RB_OUT_OFFSET) && \
            (((uint32)(&(Port).OMR) - (uint32)(&(Port))) == DIO_RB_OMR_OFFSET) && \
            (((uint32)(&(Port).IN)  - (uint32)(&(Port))) == DIO_RB_IN_OFFSET)     \
    )                                                                             \
    {                                                                             \
        /* Everything OK */                                                       \
    }                                                                             \
    else                                                                          \
    {                                                                             \
        TESTCD_DIO_HALT("Dio offset has changed");                                \
    }                                                                             \

void TestCd_DioOffsetChk_Ifx(void)
{
/* MR12 RULE 11.4, 11.6 VIOLATION: other possibility for cast to uint32 in TestCdDioChkPort is not possible */
#if defined RBA_REG_P00_OUT_P0_POS || defined RBA_REG_P00_OUT_P1_POS || defined RBA_REG_P00_OUT_P2_POS|| defined RBA_REG_P00_OUT_P3_POS || defined RBA_REG_P00_OUT_P4_POS || defined RBA_REG_P00_OUT_P5_POS || defined RBA_REG_P00_OUT_P6_POS || defined RBA_REG_P00_OUT_P7_POS || defined RBA_REG_P00_OUT_P8_POS || defined RBA_REG_P00_OUT_P9_POS || defined RBA_REG_P00_OUT_P10_POS || defined RBA_REG_P00_OUT_P11_POS || defined RBA_REG_P00_OUT_P12_POS || defined RBA_REG_P00_OUT_P13_POS || defined RBA_REG_P00_OUT_P14_POS || defined RBA_REG_P00_OUT_P15_POS
    TestCdDioChkPort(P00);
#endif
#if defined RBA_REG_P01_OUT_P0_POS || defined RBA_REG_P01_OUT_P1_POS || defined RBA_REG_P01_OUT_P2_POS|| defined RBA_REG_P01_OUT_P3_POS || defined RBA_REG_P01_OUT_P4_POS || defined RBA_REG_P01_OUT_P5_POS || defined RBA_REG_P01_OUT_P6_POS || defined RBA_REG_P01_OUT_P7_POS || defined RBA_REG_P01_OUT_P8_POS || defined RBA_REG_P01_OUT_P9_POS || defined RBA_REG_P01_OUT_P10_POS || defined RBA_REG_P01_OUT_P11_POS || defined RBA_REG_P01_OUT_P12_POS || defined RBA_REG_P01_OUT_P13_POS || defined RBA_REG_P01_OUT_P14_POS || defined RBA_REG_P01_OUT_P15_POS
    TestCdDioChkPort(P01);
#endif
#if defined RBA_REG_P02_OUT_P0_POS || defined RBA_REG_P02_OUT_P1_POS || defined RBA_REG_P02_OUT_P2_POS|| defined RBA_REG_P02_OUT_P3_POS || defined RBA_REG_P02_OUT_P4_POS || defined RBA_REG_P02_OUT_P5_POS || defined RBA_REG_P02_OUT_P6_POS || defined RBA_REG_P02_OUT_P7_POS || defined RBA_REG_P02_OUT_P8_POS || defined RBA_REG_P02_OUT_P9_POS || defined RBA_REG_P02_OUT_P10_POS || defined RBA_REG_P02_OUT_P11_POS || defined RBA_REG_P02_OUT_P12_POS || defined RBA_REG_P02_OUT_P13_POS || defined RBA_REG_P02_OUT_P14_POS || defined RBA_REG_P02_OUT_P15_POS
    TestCdDioChkPort(P02);
#endif
#if defined RBA_REG_P03_OUT_P0_POS || defined RBA_REG_P03_OUT_P1_POS || defined RBA_REG_P03_OUT_P2_POS|| defined RBA_REG_P03_OUT_P3_POS || defined RBA_REG_P03_OUT_P4_POS || defined RBA_REG_P03_OUT_P5_POS || defined RBA_REG_P03_OUT_P6_POS || defined RBA_REG_P03_OUT_P7_POS || defined RBA_REG_P03_OUT_P8_POS || defined RBA_REG_P03_OUT_P9_POS || defined RBA_REG_P03_OUT_P10_POS || defined RBA_REG_P03_OUT_P11_POS || defined RBA_REG_P03_OUT_P12_POS || defined RBA_REG_P03_OUT_P13_POS || defined RBA_REG_P03_OUT_P14_POS || defined RBA_REG_P03_OUT_P15_POS
    TestCdDioChkPort(P03);
#endif
#if defined RBA_REG_P04_OUT_P0_POS || defined RBA_REG_P04_OUT_P1_POS || defined RBA_REG_P04_OUT_P2_POS|| defined RBA_REG_P04_OUT_P3_POS || defined RBA_REG_P04_OUT_P4_POS || defined RBA_REG_P04_OUT_P5_POS || defined RBA_REG_P04_OUT_P6_POS || defined RBA_REG_P04_OUT_P7_POS || defined RBA_REG_P04_OUT_P8_POS || defined RBA_REG_P04_OUT_P9_POS || defined RBA_REG_P04_OUT_P10_POS || defined RBA_REG_P04_OUT_P11_POS || defined RBA_REG_P04_OUT_P12_POS || defined RBA_REG_P04_OUT_P13_POS || defined RBA_REG_P04_OUT_P14_POS || defined RBA_REG_P04_OUT_P15_POS
    TestCdDioChkPort(P04);
#endif
#if defined RBA_REG_P05_OUT_P0_POS || defined RBA_REG_P05_OUT_P1_POS || defined RBA_REG_P05_OUT_P2_POS|| defined RBA_REG_P05_OUT_P3_POS || defined RBA_REG_P05_OUT_P4_POS || defined RBA_REG_P05_OUT_P5_POS || defined RBA_REG_P05_OUT_P6_POS || defined RBA_REG_P05_OUT_P7_POS || defined RBA_REG_P05_OUT_P8_POS || defined RBA_REG_P05_OUT_P9_POS || defined RBA_REG_P05_OUT_P10_POS || defined RBA_REG_P05_OUT_P11_POS || defined RBA_REG_P05_OUT_P12_POS || defined RBA_REG_P05_OUT_P13_POS || defined RBA_REG_P05_OUT_P14_POS || defined RBA_REG_P05_OUT_P15_POS
    TestCdDioChkPort(P05);
#endif
#if defined RBA_REG_P06_OUT_P0_POS || defined RBA_REG_P06_OUT_P1_POS || defined RBA_REG_P06_OUT_P2_POS|| defined RBA_REG_P06_OUT_P3_POS || defined RBA_REG_P06_OUT_P4_POS || defined RBA_REG_P06_OUT_P5_POS || defined RBA_REG_P06_OUT_P6_POS || defined RBA_REG_P06_OUT_P7_POS || defined RBA_REG_P06_OUT_P8_POS || defined RBA_REG_P06_OUT_P9_POS || defined RBA_REG_P06_OUT_P10_POS || defined RBA_REG_P06_OUT_P11_POS || defined RBA_REG_P06_OUT_P12_POS || defined RBA_REG_P06_OUT_P13_POS || defined RBA_REG_P06_OUT_P14_POS || defined RBA_REG_P06_OUT_P15_POS
    TestCdDioChkPort(P06);
#endif
#if defined RBA_REG_P07_OUT_P0_POS || defined RBA_REG_P07_OUT_P1_POS || defined RBA_REG_P07_OUT_P2_POS|| defined RBA_REG_P07_OUT_P3_POS || defined RBA_REG_P07_OUT_P4_POS || defined RBA_REG_P07_OUT_P5_POS || defined RBA_REG_P07_OUT_P6_POS || defined RBA_REG_P07_OUT_P7_POS || defined RBA_REG_P07_OUT_P8_POS || defined RBA_REG_P07_OUT_P9_POS || defined RBA_REG_P07_OUT_P10_POS || defined RBA_REG_P07_OUT_P11_POS || defined RBA_REG_P07_OUT_P12_POS || defined RBA_REG_P07_OUT_P13_POS || defined RBA_REG_P07_OUT_P14_POS || defined RBA_REG_P07_OUT_P15_POS
    TestCdDioChkPort(P07);
#endif
#if defined RBA_REG_P08_OUT_P0_POS || defined RBA_REG_P08_OUT_P1_POS || defined RBA_REG_P08_OUT_P2_POS|| defined RBA_REG_P08_OUT_P3_POS || defined RBA_REG_P08_OUT_P4_POS || defined RBA_REG_P08_OUT_P5_POS || defined RBA_REG_P08_OUT_P6_POS || defined RBA_REG_P08_OUT_P7_POS || defined RBA_REG_P08_OUT_P8_POS || defined RBA_REG_P08_OUT_P9_POS || defined RBA_REG_P08_OUT_P10_POS || defined RBA_REG_P08_OUT_P11_POS || defined RBA_REG_P08_OUT_P12_POS || defined RBA_REG_P08_OUT_P13_POS || defined RBA_REG_P08_OUT_P14_POS || defined RBA_REG_P08_OUT_P15_POS
    TestCdDioChkPort(P08);
#endif
#if defined RBA_REG_P09_OUT_P0_POS || defined RBA_REG_P09_OUT_P1_POS || defined RBA_REG_P09_OUT_P2_POS|| defined RBA_REG_P09_OUT_P3_POS || defined RBA_REG_P09_OUT_P4_POS || defined RBA_REG_P09_OUT_P5_POS || defined RBA_REG_P09_OUT_P6_POS || defined RBA_REG_P09_OUT_P7_POS || defined RBA_REG_P09_OUT_P8_POS || defined RBA_REG_P09_OUT_P9_POS || defined RBA_REG_P09_OUT_P10_POS || defined RBA_REG_P09_OUT_P11_POS || defined RBA_REG_P09_OUT_P12_POS || defined RBA_REG_P09_OUT_P13_POS || defined RBA_REG_P09_OUT_P14_POS || defined RBA_REG_P09_OUT_P15_POS
    TestCdDioChkPort(P09);
#endif
#if defined RBA_REG_P10_OUT_P0_POS || defined RBA_REG_P10_OUT_P1_POS || defined RBA_REG_P10_OUT_P2_POS|| defined RBA_REG_P10_OUT_P3_POS || defined RBA_REG_P10_OUT_P4_POS || defined RBA_REG_P10_OUT_P5_POS || defined RBA_REG_P10_OUT_P6_POS || defined RBA_REG_P10_OUT_P7_POS || defined RBA_REG_P10_OUT_P8_POS || defined RBA_REG_P10_OUT_P9_POS || defined RBA_REG_P10_OUT_P10_POS || defined RBA_REG_P10_OUT_P11_POS || defined RBA_REG_P10_OUT_P12_POS || defined RBA_REG_P10_OUT_P13_POS || defined RBA_REG_P10_OUT_P14_POS || defined RBA_REG_P10_OUT_P15_POS
    TestCdDioChkPort(P10);
#endif
#if defined RBA_REG_P11_OUT_P0_POS || defined RBA_REG_P11_OUT_P1_POS || defined RBA_REG_P11_OUT_P2_POS|| defined RBA_REG_P11_OUT_P3_POS || defined RBA_REG_P11_OUT_P4_POS || defined RBA_REG_P11_OUT_P5_POS || defined RBA_REG_P11_OUT_P6_POS || defined RBA_REG_P11_OUT_P7_POS || defined RBA_REG_P11_OUT_P8_POS || defined RBA_REG_P11_OUT_P9_POS || defined RBA_REG_P11_OUT_P10_POS || defined RBA_REG_P11_OUT_P11_POS || defined RBA_REG_P11_OUT_P12_POS || defined RBA_REG_P11_OUT_P13_POS || defined RBA_REG_P11_OUT_P14_POS || defined RBA_REG_P11_OUT_P15_POS
    TestCdDioChkPort(P11);
#endif
#if defined RBA_REG_P12_OUT_P0_POS || defined RBA_REG_P12_OUT_P1_POS || defined RBA_REG_P12_OUT_P2_POS|| defined RBA_REG_P12_OUT_P3_POS || defined RBA_REG_P12_OUT_P4_POS || defined RBA_REG_P12_OUT_P5_POS || defined RBA_REG_P12_OUT_P6_POS || defined RBA_REG_P12_OUT_P7_POS || defined RBA_REG_P12_OUT_P8_POS || defined RBA_REG_P12_OUT_P9_POS || defined RBA_REG_P12_OUT_P10_POS || defined RBA_REG_P12_OUT_P11_POS || defined RBA_REG_P12_OUT_P12_POS || defined RBA_REG_P12_OUT_P13_POS || defined RBA_REG_P12_OUT_P14_POS || defined RBA_REG_P12_OUT_P15_POS
    TestCdDioChkPort(P12);
#endif
#if defined RBA_REG_P13_OUT_P0_POS || defined RBA_REG_P13_OUT_P1_POS || defined RBA_REG_P13_OUT_P2_POS|| defined RBA_REG_P13_OUT_P3_POS || defined RBA_REG_P13_OUT_P4_POS || defined RBA_REG_P13_OUT_P5_POS || defined RBA_REG_P13_OUT_P6_POS || defined RBA_REG_P13_OUT_P7_POS || defined RBA_REG_P13_OUT_P8_POS || defined RBA_REG_P13_OUT_P9_POS || defined RBA_REG_P13_OUT_P10_POS || defined RBA_REG_P13_OUT_P11_POS || defined RBA_REG_P13_OUT_P12_POS || defined RBA_REG_P13_OUT_P13_POS || defined RBA_REG_P13_OUT_P14_POS || defined RBA_REG_P13_OUT_P15_POS
    TestCdDioChkPort(P13);
#endif
#if defined RBA_REG_P14_OUT_P0_POS || defined RBA_REG_P14_OUT_P1_POS || defined RBA_REG_P14_OUT_P2_POS|| defined RBA_REG_P14_OUT_P3_POS || defined RBA_REG_P14_OUT_P4_POS || defined RBA_REG_P14_OUT_P5_POS || defined RBA_REG_P14_OUT_P6_POS || defined RBA_REG_P14_OUT_P7_POS || defined RBA_REG_P14_OUT_P8_POS || defined RBA_REG_P14_OUT_P9_POS || defined RBA_REG_P14_OUT_P10_POS || defined RBA_REG_P14_OUT_P11_POS || defined RBA_REG_P14_OUT_P12_POS || defined RBA_REG_P14_OUT_P13_POS || defined RBA_REG_P14_OUT_P14_POS || defined RBA_REG_P14_OUT_P15_POS
    TestCdDioChkPort(P14);
#endif
#if defined RBA_REG_P15_OUT_P0_POS || defined RBA_REG_P15_OUT_P1_POS || defined RBA_REG_P15_OUT_P2_POS|| defined RBA_REG_P15_OUT_P3_POS || defined RBA_REG_P15_OUT_P4_POS || defined RBA_REG_P15_OUT_P5_POS || defined RBA_REG_P15_OUT_P6_POS || defined RBA_REG_P15_OUT_P7_POS || defined RBA_REG_P15_OUT_P8_POS || defined RBA_REG_P15_OUT_P9_POS || defined RBA_REG_P15_OUT_P10_POS || defined RBA_REG_P15_OUT_P11_POS || defined RBA_REG_P15_OUT_P12_POS || defined RBA_REG_P15_OUT_P13_POS || defined RBA_REG_P15_OUT_P14_POS || defined RBA_REG_P15_OUT_P15_POS
    TestCdDioChkPort(P15);
#endif
#if defined RBA_REG_P16_OUT_P0_POS || defined RBA_REG_P16_OUT_P1_POS || defined RBA_REG_P16_OUT_P2_POS|| defined RBA_REG_P16_OUT_P3_POS || defined RBA_REG_P16_OUT_P4_POS || defined RBA_REG_P16_OUT_P5_POS || defined RBA_REG_P16_OUT_P6_POS || defined RBA_REG_P16_OUT_P7_POS || defined RBA_REG_P16_OUT_P8_POS || defined RBA_REG_P16_OUT_P9_POS || defined RBA_REG_P16_OUT_P10_POS || defined RBA_REG_P16_OUT_P11_POS || defined RBA_REG_P16_OUT_P12_POS || defined RBA_REG_P16_OUT_P13_POS || defined RBA_REG_P16_OUT_P14_POS || defined RBA_REG_P16_OUT_P15_POS
    TestCdDioChkPort(P16);
#endif
#if defined RBA_REG_P17_OUT_P0_POS || defined RBA_REG_P17_OUT_P1_POS || defined RBA_REG_P17_OUT_P2_POS|| defined RBA_REG_P17_OUT_P3_POS || defined RBA_REG_P17_OUT_P4_POS || defined RBA_REG_P17_OUT_P5_POS || defined RBA_REG_P17_OUT_P6_POS || defined RBA_REG_P17_OUT_P7_POS || defined RBA_REG_P17_OUT_P8_POS || defined RBA_REG_P17_OUT_P9_POS || defined RBA_REG_P17_OUT_P10_POS || defined RBA_REG_P17_OUT_P11_POS || defined RBA_REG_P17_OUT_P12_POS || defined RBA_REG_P17_OUT_P13_POS || defined RBA_REG_P17_OUT_P14_POS || defined RBA_REG_P17_OUT_P15_POS
    TestCdDioChkPort(P17);
#endif
#if defined RBA_REG_P18_OUT_P0_POS || defined RBA_REG_P18_OUT_P1_POS || defined RBA_REG_P18_OUT_P2_POS|| defined RBA_REG_P18_OUT_P3_POS || defined RBA_REG_P18_OUT_P4_POS || defined RBA_REG_P18_OUT_P5_POS || defined RBA_REG_P18_OUT_P6_POS || defined RBA_REG_P18_OUT_P7_POS || defined RBA_REG_P18_OUT_P8_POS || defined RBA_REG_P18_OUT_P9_POS || defined RBA_REG_P18_OUT_P10_POS || defined RBA_REG_P18_OUT_P11_POS || defined RBA_REG_P18_OUT_P12_POS || defined RBA_REG_P18_OUT_P13_POS || defined RBA_REG_P18_OUT_P14_POS || defined RBA_REG_P18_OUT_P15_POS
    TestCdDioChkPort(P18);
#endif
#if defined RBA_REG_P19_OUT_P0_POS || defined RBA_REG_P19_OUT_P1_POS || defined RBA_REG_P19_OUT_P2_POS|| defined RBA_REG_P19_OUT_P3_POS || defined RBA_REG_P19_OUT_P4_POS || defined RBA_REG_P19_OUT_P5_POS || defined RBA_REG_P19_OUT_P6_POS || defined RBA_REG_P19_OUT_P7_POS || defined RBA_REG_P19_OUT_P8_POS || defined RBA_REG_P19_OUT_P9_POS || defined RBA_REG_P19_OUT_P10_POS || defined RBA_REG_P19_OUT_P11_POS || defined RBA_REG_P19_OUT_P12_POS || defined RBA_REG_P19_OUT_P13_POS || defined RBA_REG_P19_OUT_P14_POS || defined RBA_REG_P19_OUT_P15_POS
    TestCdDioChkPort(P19);
#endif
#if defined RBA_REG_P20_OUT_P0_POS || defined RBA_REG_P20_OUT_P1_POS || defined RBA_REG_P20_OUT_P2_POS|| defined RBA_REG_P20_OUT_P3_POS || defined RBA_REG_P20_OUT_P4_POS || defined RBA_REG_P20_OUT_P5_POS || defined RBA_REG_P20_OUT_P6_POS || defined RBA_REG_P20_OUT_P7_POS || defined RBA_REG_P20_OUT_P8_POS || defined RBA_REG_P20_OUT_P9_POS || defined RBA_REG_P20_OUT_P10_POS || defined RBA_REG_P20_OUT_P11_POS || defined RBA_REG_P20_OUT_P12_POS || defined RBA_REG_P20_OUT_P13_POS || defined RBA_REG_P20_OUT_P14_POS || defined RBA_REG_P20_OUT_P15_POS
    TestCdDioChkPort(P20);
#endif
#if defined RBA_REG_P21_OUT_P0_POS || defined RBA_REG_P21_OUT_P1_POS || defined RBA_REG_P21_OUT_P2_POS|| defined RBA_REG_P21_OUT_P3_POS || defined RBA_REG_P21_OUT_P4_POS || defined RBA_REG_P21_OUT_P5_POS || defined RBA_REG_P21_OUT_P6_POS || defined RBA_REG_P21_OUT_P7_POS || defined RBA_REG_P21_OUT_P8_POS || defined RBA_REG_P21_OUT_P9_POS || defined RBA_REG_P21_OUT_P10_POS || defined RBA_REG_P21_OUT_P11_POS || defined RBA_REG_P21_OUT_P12_POS || defined RBA_REG_P21_OUT_P13_POS || defined RBA_REG_P21_OUT_P14_POS || defined RBA_REG_P21_OUT_P15_POS
    TestCdDioChkPort(P21);
#endif
#if defined RBA_REG_P22_OUT_P0_POS || defined RBA_REG_P22_OUT_P1_POS || defined RBA_REG_P22_OUT_P2_POS|| defined RBA_REG_P22_OUT_P3_POS || defined RBA_REG_P22_OUT_P4_POS || defined RBA_REG_P22_OUT_P5_POS || defined RBA_REG_P22_OUT_P6_POS || defined RBA_REG_P22_OUT_P7_POS || defined RBA_REG_P22_OUT_P8_POS || defined RBA_REG_P22_OUT_P9_POS || defined RBA_REG_P22_OUT_P10_POS || defined RBA_REG_P22_OUT_P11_POS || defined RBA_REG_P22_OUT_P12_POS || defined RBA_REG_P22_OUT_P13_POS || defined RBA_REG_P22_OUT_P14_POS || defined RBA_REG_P22_OUT_P15_POS
    TestCdDioChkPort(P22);
#endif
#if defined RBA_REG_P23_OUT_P0_POS || defined RBA_REG_P23_OUT_P1_POS || defined RBA_REG_P23_OUT_P2_POS|| defined RBA_REG_P23_OUT_P3_POS || defined RBA_REG_P23_OUT_P4_POS || defined RBA_REG_P23_OUT_P5_POS || defined RBA_REG_P23_OUT_P6_POS || defined RBA_REG_P23_OUT_P7_POS || defined RBA_REG_P23_OUT_P8_POS || defined RBA_REG_P23_OUT_P9_POS || defined RBA_REG_P23_OUT_P10_POS || defined RBA_REG_P23_OUT_P11_POS || defined RBA_REG_P23_OUT_P12_POS || defined RBA_REG_P23_OUT_P13_POS || defined RBA_REG_P23_OUT_P14_POS || defined RBA_REG_P23_OUT_P15_POS
    TestCdDioChkPort(P23);
#endif
#if defined RBA_REG_P24_OUT_P0_POS || defined RBA_REG_P24_OUT_P1_POS || defined RBA_REG_P24_OUT_P2_POS|| defined RBA_REG_P24_OUT_P3_POS || defined RBA_REG_P24_OUT_P4_POS || defined RBA_REG_P24_OUT_P5_POS || defined RBA_REG_P24_OUT_P6_POS || defined RBA_REG_P24_OUT_P7_POS || defined RBA_REG_P24_OUT_P8_POS || defined RBA_REG_P24_OUT_P9_POS || defined RBA_REG_P24_OUT_P10_POS || defined RBA_REG_P24_OUT_P11_POS || defined RBA_REG_P24_OUT_P12_POS || defined RBA_REG_P24_OUT_P13_POS || defined RBA_REG_P24_OUT_P14_POS || defined RBA_REG_P24_OUT_P15_POS
    TestCdDioChkPort(P24);
#endif
#if defined RBA_REG_P25_OUT_P0_POS || defined RBA_REG_P25_OUT_P1_POS || defined RBA_REG_P25_OUT_P2_POS|| defined RBA_REG_P25_OUT_P3_POS || defined RBA_REG_P25_OUT_P4_POS || defined RBA_REG_P25_OUT_P5_POS || defined RBA_REG_P25_OUT_P6_POS || defined RBA_REG_P25_OUT_P7_POS || defined RBA_REG_P25_OUT_P8_POS || defined RBA_REG_P25_OUT_P9_POS || defined RBA_REG_P25_OUT_P10_POS || defined RBA_REG_P25_OUT_P11_POS || defined RBA_REG_P25_OUT_P12_POS || defined RBA_REG_P25_OUT_P13_POS || defined RBA_REG_P25_OUT_P14_POS || defined RBA_REG_P25_OUT_P15_POS
    TestCdDioChkPort(P25);
#endif
#if defined RBA_REG_P26_OUT_P0_POS || defined RBA_REG_P26_OUT_P1_POS || defined RBA_REG_P26_OUT_P2_POS|| defined RBA_REG_P26_OUT_P3_POS || defined RBA_REG_P26_OUT_P4_POS || defined RBA_REG_P26_OUT_P5_POS || defined RBA_REG_P26_OUT_P6_POS || defined RBA_REG_P26_OUT_P7_POS || defined RBA_REG_P26_OUT_P8_POS || defined RBA_REG_P26_OUT_P9_POS || defined RBA_REG_P26_OUT_P10_POS || defined RBA_REG_P26_OUT_P11_POS || defined RBA_REG_P26_OUT_P12_POS || defined RBA_REG_P26_OUT_P13_POS || defined RBA_REG_P26_OUT_P14_POS || defined RBA_REG_P26_OUT_P15_POS
    TestCdDioChkPort(P26);
#endif
#if defined RBA_REG_P27_OUT_P0_POS || defined RBA_REG_P27_OUT_P1_POS || defined RBA_REG_P27_OUT_P2_POS|| defined RBA_REG_P27_OUT_P3_POS || defined RBA_REG_P27_OUT_P4_POS || defined RBA_REG_P27_OUT_P5_POS || defined RBA_REG_P27_OUT_P6_POS || defined RBA_REG_P27_OUT_P7_POS || defined RBA_REG_P27_OUT_P8_POS || defined RBA_REG_P27_OUT_P9_POS || defined RBA_REG_P27_OUT_P10_POS || defined RBA_REG_P27_OUT_P11_POS || defined RBA_REG_P27_OUT_P12_POS || defined RBA_REG_P27_OUT_P13_POS || defined RBA_REG_P27_OUT_P14_POS || defined RBA_REG_P27_OUT_P15_POS
    TestCdDioChkPort(P27);
#endif
#if defined RBA_REG_P28_OUT_P0_POS || defined RBA_REG_P28_OUT_P1_POS || defined RBA_REG_P28_OUT_P2_POS|| defined RBA_REG_P28_OUT_P3_POS || defined RBA_REG_P28_OUT_P4_POS || defined RBA_REG_P28_OUT_P5_POS || defined RBA_REG_P28_OUT_P6_POS || defined RBA_REG_P28_OUT_P7_POS || defined RBA_REG_P28_OUT_P8_POS || defined RBA_REG_P28_OUT_P9_POS || defined RBA_REG_P28_OUT_P10_POS || defined RBA_REG_P28_OUT_P11_POS || defined RBA_REG_P28_OUT_P12_POS || defined RBA_REG_P28_OUT_P13_POS || defined RBA_REG_P28_OUT_P14_POS || defined RBA_REG_P28_OUT_P15_POS
    TestCdDioChkPort(P28);
#endif
#if defined RBA_REG_P29_OUT_P0_POS || defined RBA_REG_P29_OUT_P1_POS || defined RBA_REG_P29_OUT_P2_POS|| defined RBA_REG_P29_OUT_P3_POS || defined RBA_REG_P29_OUT_P4_POS || defined RBA_REG_P29_OUT_P5_POS || defined RBA_REG_P29_OUT_P6_POS || defined RBA_REG_P29_OUT_P7_POS || defined RBA_REG_P29_OUT_P8_POS || defined RBA_REG_P29_OUT_P9_POS || defined RBA_REG_P29_OUT_P10_POS || defined RBA_REG_P29_OUT_P11_POS || defined RBA_REG_P29_OUT_P12_POS || defined RBA_REG_P29_OUT_P13_POS || defined RBA_REG_P29_OUT_P14_POS || defined RBA_REG_P29_OUT_P15_POS
    TestCdDioChkPort(P29);
#endif
#if defined RBA_REG_P30_OUT_P0_POS || defined RBA_REG_P30_OUT_P1_POS || defined RBA_REG_P30_OUT_P2_POS|| defined RBA_REG_P30_OUT_P3_POS || defined RBA_REG_P30_OUT_P4_POS || defined RBA_REG_P30_OUT_P5_POS || defined RBA_REG_P30_OUT_P6_POS || defined RBA_REG_P30_OUT_P7_POS || defined RBA_REG_P30_OUT_P8_POS || defined RBA_REG_P30_OUT_P9_POS || defined RBA_REG_P30_OUT_P10_POS || defined RBA_REG_P30_OUT_P11_POS || defined RBA_REG_P30_OUT_P12_POS || defined RBA_REG_P30_OUT_P13_POS || defined RBA_REG_P30_OUT_P14_POS || defined RBA_REG_P30_OUT_P15_POS
    TestCdDioChkPort(P30);
#endif
#if defined RBA_REG_P31_OUT_P0_POS || defined RBA_REG_P31_OUT_P1_POS || defined RBA_REG_P31_OUT_P2_POS|| defined RBA_REG_P31_OUT_P3_POS || defined RBA_REG_P31_OUT_P4_POS || defined RBA_REG_P31_OUT_P5_POS || defined RBA_REG_P31_OUT_P6_POS || defined RBA_REG_P31_OUT_P7_POS || defined RBA_REG_P31_OUT_P8_POS || defined RBA_REG_P31_OUT_P9_POS || defined RBA_REG_P31_OUT_P10_POS || defined RBA_REG_P31_OUT_P11_POS || defined RBA_REG_P31_OUT_P12_POS || defined RBA_REG_P31_OUT_P13_POS || defined RBA_REG_P31_OUT_P14_POS || defined RBA_REG_P31_OUT_P15_POS
    TestCdDioChkPort(P31);
#endif
#if defined RBA_REG_P32_OUT_P0_POS || defined RBA_REG_P32_OUT_P1_POS || defined RBA_REG_P32_OUT_P2_POS|| defined RBA_REG_P32_OUT_P3_POS || defined RBA_REG_P32_OUT_P4_POS || defined RBA_REG_P32_OUT_P5_POS || defined RBA_REG_P32_OUT_P6_POS || defined RBA_REG_P32_OUT_P7_POS || defined RBA_REG_P32_OUT_P8_POS || defined RBA_REG_P32_OUT_P9_POS || defined RBA_REG_P32_OUT_P10_POS || defined RBA_REG_P32_OUT_P11_POS || defined RBA_REG_P32_OUT_P12_POS || defined RBA_REG_P32_OUT_P13_POS || defined RBA_REG_P32_OUT_P14_POS || defined RBA_REG_P32_OUT_P15_POS
    TestCdDioChkPort(P32);
#endif
#if defined RBA_REG_P33_OUT_P0_POS || defined RBA_REG_P33_OUT_P1_POS || defined RBA_REG_P33_OUT_P2_POS|| defined RBA_REG_P33_OUT_P3_POS || defined RBA_REG_P33_OUT_P4_POS || defined RBA_REG_P33_OUT_P5_POS || defined RBA_REG_P33_OUT_P6_POS || defined RBA_REG_P33_OUT_P7_POS || defined RBA_REG_P33_OUT_P8_POS || defined RBA_REG_P33_OUT_P9_POS || defined RBA_REG_P33_OUT_P10_POS || defined RBA_REG_P33_OUT_P11_POS || defined RBA_REG_P33_OUT_P12_POS || defined RBA_REG_P33_OUT_P13_POS || defined RBA_REG_P33_OUT_P14_POS || defined RBA_REG_P33_OUT_P15_POS
    TestCdDioChkPort(P33);
#endif
#if defined RBA_REG_P34_OUT_P0_POS || defined RBA_REG_P34_OUT_P1_POS || defined RBA_REG_P34_OUT_P2_POS|| defined RBA_REG_P34_OUT_P3_POS || defined RBA_REG_P34_OUT_P4_POS || defined RBA_REG_P34_OUT_P5_POS || defined RBA_REG_P34_OUT_P6_POS || defined RBA_REG_P34_OUT_P7_POS || defined RBA_REG_P34_OUT_P8_POS || defined RBA_REG_P34_OUT_P9_POS || defined RBA_REG_P34_OUT_P10_POS || defined RBA_REG_P34_OUT_P11_POS || defined RBA_REG_P34_OUT_P12_POS || defined RBA_REG_P34_OUT_P13_POS || defined RBA_REG_P34_OUT_P14_POS || defined RBA_REG_P34_OUT_P15_POS
    TestCdDioChkPort(P34);
#endif
#if defined RBA_REG_P35_OUT_P0_POS || defined RBA_REG_P35_OUT_P1_POS || defined RBA_REG_P35_OUT_P2_POS|| defined RBA_REG_P35_OUT_P3_POS || defined RBA_REG_P35_OUT_P4_POS || defined RBA_REG_P35_OUT_P5_POS || defined RBA_REG_P35_OUT_P6_POS || defined RBA_REG_P35_OUT_P7_POS || defined RBA_REG_P35_OUT_P8_POS || defined RBA_REG_P35_OUT_P9_POS || defined RBA_REG_P35_OUT_P10_POS || defined RBA_REG_P35_OUT_P11_POS || defined RBA_REG_P35_OUT_P12_POS || defined RBA_REG_P35_OUT_P13_POS || defined RBA_REG_P35_OUT_P14_POS || defined RBA_REG_P35_OUT_P15_POS
    TestCdDioChkPort(P35);
#endif
#if defined RBA_REG_P36_OUT_P0_POS || defined RBA_REG_P36_OUT_P1_POS || defined RBA_REG_P36_OUT_P2_POS|| defined RBA_REG_P36_OUT_P3_POS || defined RBA_REG_P36_OUT_P4_POS || defined RBA_REG_P36_OUT_P5_POS || defined RBA_REG_P36_OUT_P6_POS || defined RBA_REG_P36_OUT_P7_POS || defined RBA_REG_P36_OUT_P8_POS || defined RBA_REG_P36_OUT_P9_POS || defined RBA_REG_P36_OUT_P10_POS || defined RBA_REG_P36_OUT_P11_POS || defined RBA_REG_P36_OUT_P12_POS || defined RBA_REG_P36_OUT_P13_POS || defined RBA_REG_P36_OUT_P14_POS || defined RBA_REG_P36_OUT_P15_POS
    TestCdDioChkPort(P36);
#endif
#if defined RBA_REG_P37_OUT_P0_POS || defined RBA_REG_P37_OUT_P1_POS || defined RBA_REG_P37_OUT_P2_POS|| defined RBA_REG_P37_OUT_P3_POS || defined RBA_REG_P37_OUT_P4_POS || defined RBA_REG_P37_OUT_P5_POS || defined RBA_REG_P37_OUT_P6_POS || defined RBA_REG_P37_OUT_P7_POS || defined RBA_REG_P37_OUT_P8_POS || defined RBA_REG_P37_OUT_P9_POS || defined RBA_REG_P37_OUT_P10_POS || defined RBA_REG_P37_OUT_P11_POS || defined RBA_REG_P37_OUT_P12_POS || defined RBA_REG_P37_OUT_P13_POS || defined RBA_REG_P37_OUT_P14_POS || defined RBA_REG_P37_OUT_P15_POS
    TestCdDioChkPort(P37);
#endif
#if defined RBA_REG_P38_OUT_P0_POS || defined RBA_REG_P38_OUT_P1_POS || defined RBA_REG_P38_OUT_P2_POS|| defined RBA_REG_P38_OUT_P3_POS || defined RBA_REG_P38_OUT_P4_POS || defined RBA_REG_P38_OUT_P5_POS || defined RBA_REG_P38_OUT_P6_POS || defined RBA_REG_P38_OUT_P7_POS || defined RBA_REG_P38_OUT_P8_POS || defined RBA_REG_P38_OUT_P9_POS || defined RBA_REG_P38_OUT_P10_POS || defined RBA_REG_P38_OUT_P11_POS || defined RBA_REG_P38_OUT_P12_POS || defined RBA_REG_P38_OUT_P13_POS || defined RBA_REG_P38_OUT_P14_POS || defined RBA_REG_P38_OUT_P15_POS
    TestCdDioChkPort(P38);
#endif
#if defined RBA_REG_P39_OUT_P0_POS || defined RBA_REG_P39_OUT_P1_POS || defined RBA_REG_P39_OUT_P2_POS|| defined RBA_REG_P39_OUT_P3_POS || defined RBA_REG_P39_OUT_P4_POS || defined RBA_REG_P39_OUT_P5_POS || defined RBA_REG_P39_OUT_P6_POS || defined RBA_REG_P39_OUT_P7_POS || defined RBA_REG_P39_OUT_P8_POS || defined RBA_REG_P39_OUT_P9_POS || defined RBA_REG_P39_OUT_P10_POS || defined RBA_REG_P39_OUT_P11_POS || defined RBA_REG_P39_OUT_P12_POS || defined RBA_REG_P39_OUT_P13_POS || defined RBA_REG_P39_OUT_P14_POS || defined RBA_REG_P39_OUT_P15_POS
    TestCdDioChkPort(P39);
#endif
#if defined RBA_REG_P40_OUT_P0_POS || defined RBA_REG_P40_OUT_P1_POS || defined RBA_REG_P40_OUT_P2_POS|| defined RBA_REG_P40_OUT_P3_POS || defined RBA_REG_P40_OUT_P4_POS || defined RBA_REG_P40_OUT_P5_POS || defined RBA_REG_P40_OUT_P6_POS || defined RBA_REG_P40_OUT_P7_POS || defined RBA_REG_P40_OUT_P8_POS || defined RBA_REG_P40_OUT_P9_POS || defined RBA_REG_P40_OUT_P10_POS || defined RBA_REG_P40_OUT_P11_POS || defined RBA_REG_P40_OUT_P12_POS || defined RBA_REG_P40_OUT_P13_POS || defined RBA_REG_P40_OUT_P14_POS || defined RBA_REG_P40_OUT_P15_POS
    TestCdDioChkPort(P40);
#endif
#if defined RBA_REG_P41_OUT_P0_POS || defined RBA_REG_P41_OUT_P1_POS || defined RBA_REG_P41_OUT_P2_POS|| defined RBA_REG_P41_OUT_P3_POS || defined RBA_REG_P41_OUT_P4_POS || defined RBA_REG_P41_OUT_P5_POS || defined RBA_REG_P41_OUT_P6_POS || defined RBA_REG_P41_OUT_P7_POS || defined RBA_REG_P41_OUT_P8_POS || defined RBA_REG_P41_OUT_P9_POS || defined RBA_REG_P41_OUT_P10_POS || defined RBA_REG_P41_OUT_P11_POS || defined RBA_REG_P41_OUT_P12_POS || defined RBA_REG_P41_OUT_P13_POS || defined RBA_REG_P41_OUT_P14_POS || defined RBA_REG_P41_OUT_P15_POS
    TestCdDioChkPort(P41);
#endif
#if defined RBA_REG_P42_OUT_P0_POS || defined RBA_REG_P42_OUT_P1_POS || defined RBA_REG_P42_OUT_P2_POS|| defined RBA_REG_P42_OUT_P3_POS || defined RBA_REG_P42_OUT_P4_POS || defined RBA_REG_P42_OUT_P5_POS || defined RBA_REG_P42_OUT_P6_POS || defined RBA_REG_P42_OUT_P7_POS || defined RBA_REG_P42_OUT_P8_POS || defined RBA_REG_P42_OUT_P9_POS || defined RBA_REG_P42_OUT_P10_POS || defined RBA_REG_P42_OUT_P11_POS || defined RBA_REG_P42_OUT_P12_POS || defined RBA_REG_P42_OUT_P13_POS || defined RBA_REG_P42_OUT_P14_POS || defined RBA_REG_P42_OUT_P15_POS
    TestCdDioChkPort(P42);
#endif
#if defined RBA_REG_P43_OUT_P0_POS || defined RBA_REG_P43_OUT_P1_POS || defined RBA_REG_P43_OUT_P2_POS|| defined RBA_REG_P43_OUT_P3_POS || defined RBA_REG_P43_OUT_P4_POS || defined RBA_REG_P43_OUT_P5_POS || defined RBA_REG_P43_OUT_P6_POS || defined RBA_REG_P43_OUT_P7_POS || defined RBA_REG_P43_OUT_P8_POS || defined RBA_REG_P43_OUT_P9_POS || defined RBA_REG_P43_OUT_P10_POS || defined RBA_REG_P43_OUT_P11_POS || defined RBA_REG_P43_OUT_P12_POS || defined RBA_REG_P43_OUT_P13_POS || defined RBA_REG_P43_OUT_P14_POS || defined RBA_REG_P43_OUT_P15_POS
    TestCdDioChkPort(P43);
#endif
#if defined RBA_REG_P44_OUT_P0_POS || defined RBA_REG_P44_OUT_P1_POS || defined RBA_REG_P44_OUT_P2_POS|| defined RBA_REG_P44_OUT_P3_POS || defined RBA_REG_P44_OUT_P4_POS || defined RBA_REG_P44_OUT_P5_POS || defined RBA_REG_P44_OUT_P6_POS || defined RBA_REG_P44_OUT_P7_POS || defined RBA_REG_P44_OUT_P8_POS || defined RBA_REG_P44_OUT_P9_POS || defined RBA_REG_P44_OUT_P10_POS || defined RBA_REG_P44_OUT_P11_POS || defined RBA_REG_P44_OUT_P12_POS || defined RBA_REG_P44_OUT_P13_POS || defined RBA_REG_P44_OUT_P14_POS || defined RBA_REG_P44_OUT_P15_POS
    TestCdDioChkPort(P44);
#endif
#if defined RBA_REG_P45_OUT_P0_POS || defined RBA_REG_P45_OUT_P1_POS || defined RBA_REG_P45_OUT_P2_POS|| defined RBA_REG_P45_OUT_P3_POS || defined RBA_REG_P45_OUT_P4_POS || defined RBA_REG_P45_OUT_P5_POS || defined RBA_REG_P45_OUT_P6_POS || defined RBA_REG_P45_OUT_P7_POS || defined RBA_REG_P45_OUT_P8_POS || defined RBA_REG_P45_OUT_P9_POS || defined RBA_REG_P45_OUT_P10_POS || defined RBA_REG_P45_OUT_P11_POS || defined RBA_REG_P45_OUT_P12_POS || defined RBA_REG_P45_OUT_P13_POS || defined RBA_REG_P45_OUT_P14_POS || defined RBA_REG_P45_OUT_P15_POS
    TestCdDioChkPort(P45);
#endif
#if defined RBA_REG_P46_OUT_P0_POS || defined RBA_REG_P46_OUT_P1_POS || defined RBA_REG_P46_OUT_P2_POS|| defined RBA_REG_P46_OUT_P3_POS || defined RBA_REG_P46_OUT_P4_POS || defined RBA_REG_P46_OUT_P5_POS || defined RBA_REG_P46_OUT_P6_POS || defined RBA_REG_P46_OUT_P7_POS || defined RBA_REG_P46_OUT_P8_POS || defined RBA_REG_P46_OUT_P9_POS || defined RBA_REG_P46_OUT_P10_POS || defined RBA_REG_P46_OUT_P11_POS || defined RBA_REG_P46_OUT_P12_POS || defined RBA_REG_P46_OUT_P13_POS || defined RBA_REG_P46_OUT_P14_POS || defined RBA_REG_P46_OUT_P15_POS
    TestCdDioChkPort(P46);
#endif
#if defined RBA_REG_P47_OUT_P0_POS || defined RBA_REG_P47_OUT_P1_POS || defined RBA_REG_P47_OUT_P2_POS|| defined RBA_REG_P47_OUT_P3_POS || defined RBA_REG_P47_OUT_P4_POS || defined RBA_REG_P47_OUT_P5_POS || defined RBA_REG_P47_OUT_P6_POS || defined RBA_REG_P47_OUT_P7_POS || defined RBA_REG_P47_OUT_P8_POS || defined RBA_REG_P47_OUT_P9_POS || defined RBA_REG_P47_OUT_P10_POS || defined RBA_REG_P47_OUT_P11_POS || defined RBA_REG_P47_OUT_P12_POS || defined RBA_REG_P47_OUT_P13_POS || defined RBA_REG_P47_OUT_P14_POS || defined RBA_REG_P47_OUT_P15_POS
    TestCdDioChkPort(P47);
#endif
#if defined RBA_REG_P48_OUT_P0_POS || defined RBA_REG_P48_OUT_P1_POS || defined RBA_REG_P48_OUT_P2_POS|| defined RBA_REG_P48_OUT_P3_POS || defined RBA_REG_P48_OUT_P4_POS || defined RBA_REG_P48_OUT_P5_POS || defined RBA_REG_P48_OUT_P6_POS || defined RBA_REG_P48_OUT_P7_POS || defined RBA_REG_P48_OUT_P8_POS || defined RBA_REG_P48_OUT_P9_POS || defined RBA_REG_P48_OUT_P10_POS || defined RBA_REG_P48_OUT_P11_POS || defined RBA_REG_P48_OUT_P12_POS || defined RBA_REG_P48_OUT_P13_POS || defined RBA_REG_P48_OUT_P14_POS || defined RBA_REG_P48_OUT_P15_POS
    TestCdDioChkPort(P48);
#endif
#if defined RBA_REG_P49_OUT_P0_POS || defined RBA_REG_P49_OUT_P1_POS || defined RBA_REG_P49_OUT_P2_POS|| defined RBA_REG_P49_OUT_P3_POS || defined RBA_REG_P49_OUT_P4_POS || defined RBA_REG_P49_OUT_P5_POS || defined RBA_REG_P49_OUT_P6_POS || defined RBA_REG_P49_OUT_P7_POS || defined RBA_REG_P49_OUT_P8_POS || defined RBA_REG_P49_OUT_P9_POS || defined RBA_REG_P49_OUT_P10_POS || defined RBA_REG_P49_OUT_P11_POS || defined RBA_REG_P49_OUT_P12_POS || defined RBA_REG_P49_OUT_P13_POS || defined RBA_REG_P49_OUT_P14_POS || defined RBA_REG_P49_OUT_P15_POS
    TestCdDioChkPort(P49);
#endif
#if defined RBA_REG_P50_OUT_P0_POS || defined RBA_REG_P50_OUT_P1_POS || defined RBA_REG_P50_OUT_P2_POS|| defined RBA_REG_P50_OUT_P3_POS || defined RBA_REG_P50_OUT_P4_POS || defined RBA_REG_P50_OUT_P5_POS || defined RBA_REG_P50_OUT_P6_POS || defined RBA_REG_P50_OUT_P7_POS || defined RBA_REG_P50_OUT_P8_POS || defined RBA_REG_P50_OUT_P9_POS || defined RBA_REG_P50_OUT_P10_POS || defined RBA_REG_P50_OUT_P11_POS || defined RBA_REG_P50_OUT_P12_POS || defined RBA_REG_P50_OUT_P13_POS || defined RBA_REG_P50_OUT_P14_POS || defined RBA_REG_P50_OUT_P15_POS
    TestCdDioChkPort(P50);
#endif
#if defined RBA_REG_P51_OUT_P0_POS || defined RBA_REG_P51_OUT_P1_POS || defined RBA_REG_P51_OUT_P2_POS|| defined RBA_REG_P51_OUT_P3_POS || defined RBA_REG_P51_OUT_P4_POS || defined RBA_REG_P51_OUT_P5_POS || defined RBA_REG_P51_OUT_P6_POS || defined RBA_REG_P51_OUT_P7_POS || defined RBA_REG_P51_OUT_P8_POS || defined RBA_REG_P51_OUT_P9_POS || defined RBA_REG_P51_OUT_P10_POS || defined RBA_REG_P51_OUT_P11_POS || defined RBA_REG_P51_OUT_P12_POS || defined RBA_REG_P51_OUT_P13_POS || defined RBA_REG_P51_OUT_P14_POS || defined RBA_REG_P51_OUT_P15_POS
    TestCdDioChkPort(P51);
#endif
#if defined RBA_REG_P52_OUT_P0_POS || defined RBA_REG_P52_OUT_P1_POS || defined RBA_REG_P52_OUT_P2_POS|| defined RBA_REG_P52_OUT_P3_POS || defined RBA_REG_P52_OUT_P4_POS || defined RBA_REG_P52_OUT_P5_POS || defined RBA_REG_P52_OUT_P6_POS || defined RBA_REG_P52_OUT_P7_POS || defined RBA_REG_P52_OUT_P8_POS || defined RBA_REG_P52_OUT_P9_POS || defined RBA_REG_P52_OUT_P10_POS || defined RBA_REG_P52_OUT_P11_POS || defined RBA_REG_P52_OUT_P12_POS || defined RBA_REG_P52_OUT_P13_POS || defined RBA_REG_P52_OUT_P14_POS || defined RBA_REG_P52_OUT_P15_POS
    TestCdDioChkPort(P52);
#endif
#if defined RBA_REG_P53_OUT_P0_POS || defined RBA_REG_P53_OUT_P1_POS || defined RBA_REG_P53_OUT_P2_POS|| defined RBA_REG_P53_OUT_P3_POS || defined RBA_REG_P53_OUT_P4_POS || defined RBA_REG_P53_OUT_P5_POS || defined RBA_REG_P53_OUT_P6_POS || defined RBA_REG_P53_OUT_P7_POS || defined RBA_REG_P53_OUT_P8_POS || defined RBA_REG_P53_OUT_P9_POS || defined RBA_REG_P53_OUT_P10_POS || defined RBA_REG_P53_OUT_P11_POS || defined RBA_REG_P53_OUT_P12_POS || defined RBA_REG_P53_OUT_P13_POS || defined RBA_REG_P53_OUT_P14_POS || defined RBA_REG_P53_OUT_P15_POS
    TestCdDioChkPort(P53);
#endif
#if defined RBA_REG_P54_OUT_P0_POS || defined RBA_REG_P54_OUT_P1_POS || defined RBA_REG_P54_OUT_P2_POS|| defined RBA_REG_P54_OUT_P3_POS || defined RBA_REG_P54_OUT_P4_POS || defined RBA_REG_P54_OUT_P5_POS || defined RBA_REG_P54_OUT_P6_POS || defined RBA_REG_P54_OUT_P7_POS || defined RBA_REG_P54_OUT_P8_POS || defined RBA_REG_P54_OUT_P9_POS || defined RBA_REG_P54_OUT_P10_POS || defined RBA_REG_P54_OUT_P11_POS || defined RBA_REG_P54_OUT_P12_POS || defined RBA_REG_P54_OUT_P13_POS || defined RBA_REG_P54_OUT_P14_POS || defined RBA_REG_P54_OUT_P15_POS
    TestCdDioChkPort(P54);
#endif
#if defined RBA_REG_P55_OUT_P0_POS || defined RBA_REG_P55_OUT_P1_POS || defined RBA_REG_P55_OUT_P2_POS|| defined RBA_REG_P55_OUT_P3_POS || defined RBA_REG_P55_OUT_P4_POS || defined RBA_REG_P55_OUT_P5_POS || defined RBA_REG_P55_OUT_P6_POS || defined RBA_REG_P55_OUT_P7_POS || defined RBA_REG_P55_OUT_P8_POS || defined RBA_REG_P55_OUT_P9_POS || defined RBA_REG_P55_OUT_P10_POS || defined RBA_REG_P55_OUT_P11_POS || defined RBA_REG_P55_OUT_P12_POS || defined RBA_REG_P55_OUT_P13_POS || defined RBA_REG_P55_OUT_P14_POS || defined RBA_REG_P55_OUT_P15_POS
    TestCdDioChkPort(P55);
#endif
#if defined RBA_REG_P56_OUT_P0_POS || defined RBA_REG_P56_OUT_P1_POS || defined RBA_REG_P56_OUT_P2_POS|| defined RBA_REG_P56_OUT_P3_POS || defined RBA_REG_P56_OUT_P4_POS || defined RBA_REG_P56_OUT_P5_POS || defined RBA_REG_P56_OUT_P6_POS || defined RBA_REG_P56_OUT_P7_POS || defined RBA_REG_P56_OUT_P8_POS || defined RBA_REG_P56_OUT_P9_POS || defined RBA_REG_P56_OUT_P10_POS || defined RBA_REG_P56_OUT_P11_POS || defined RBA_REG_P56_OUT_P12_POS || defined RBA_REG_P56_OUT_P13_POS || defined RBA_REG_P56_OUT_P14_POS || defined RBA_REG_P56_OUT_P15_POS
    TestCdDioChkPort(P56);
#endif
#if defined RBA_REG_P57_OUT_P0_POS || defined RBA_REG_P57_OUT_P1_POS || defined RBA_REG_P57_OUT_P2_POS|| defined RBA_REG_P57_OUT_P3_POS || defined RBA_REG_P57_OUT_P4_POS || defined RBA_REG_P57_OUT_P5_POS || defined RBA_REG_P57_OUT_P6_POS || defined RBA_REG_P57_OUT_P7_POS || defined RBA_REG_P57_OUT_P8_POS || defined RBA_REG_P57_OUT_P9_POS || defined RBA_REG_P57_OUT_P10_POS || defined RBA_REG_P57_OUT_P11_POS || defined RBA_REG_P57_OUT_P12_POS || defined RBA_REG_P57_OUT_P13_POS || defined RBA_REG_P57_OUT_P14_POS || defined RBA_REG_P57_OUT_P15_POS
    TestCdDioChkPort(P57);
#endif
#if defined RBA_REG_P58_OUT_P0_POS || defined RBA_REG_P58_OUT_P1_POS || defined RBA_REG_P58_OUT_P2_POS|| defined RBA_REG_P58_OUT_P3_POS || defined RBA_REG_P58_OUT_P4_POS || defined RBA_REG_P58_OUT_P5_POS || defined RBA_REG_P58_OUT_P6_POS || defined RBA_REG_P58_OUT_P7_POS || defined RBA_REG_P58_OUT_P8_POS || defined RBA_REG_P58_OUT_P9_POS || defined RBA_REG_P58_OUT_P10_POS || defined RBA_REG_P58_OUT_P11_POS || defined RBA_REG_P58_OUT_P12_POS || defined RBA_REG_P58_OUT_P13_POS || defined RBA_REG_P58_OUT_P14_POS || defined RBA_REG_P58_OUT_P15_POS
    TestCdDioChkPort(P58);
#endif
#if defined RBA_REG_P59_OUT_P0_POS || defined RBA_REG_P59_OUT_P1_POS || defined RBA_REG_P59_OUT_P2_POS|| defined RBA_REG_P59_OUT_P3_POS || defined RBA_REG_P59_OUT_P4_POS || defined RBA_REG_P59_OUT_P5_POS || defined RBA_REG_P59_OUT_P6_POS || defined RBA_REG_P59_OUT_P7_POS || defined RBA_REG_P59_OUT_P8_POS || defined RBA_REG_P59_OUT_P9_POS || defined RBA_REG_P59_OUT_P10_POS || defined RBA_REG_P59_OUT_P11_POS || defined RBA_REG_P59_OUT_P12_POS || defined RBA_REG_P59_OUT_P13_POS || defined RBA_REG_P59_OUT_P14_POS || defined RBA_REG_P59_OUT_P15_POS
    TestCdDioChkPort(P59);
#endif
#if defined RBA_REG_P60_OUT_P0_POS || defined RBA_REG_P60_OUT_P1_POS || defined RBA_REG_P60_OUT_P2_POS|| defined RBA_REG_P60_OUT_P3_POS || defined RBA_REG_P60_OUT_P4_POS || defined RBA_REG_P60_OUT_P5_POS || defined RBA_REG_P60_OUT_P6_POS || defined RBA_REG_P60_OUT_P7_POS || defined RBA_REG_P60_OUT_P8_POS || defined RBA_REG_P60_OUT_P9_POS || defined RBA_REG_P60_OUT_P10_POS || defined RBA_REG_P60_OUT_P11_POS || defined RBA_REG_P60_OUT_P12_POS || defined RBA_REG_P60_OUT_P13_POS || defined RBA_REG_P60_OUT_P14_POS || defined RBA_REG_P60_OUT_P15_POS
    TestCdDioChkPort(P60);
#endif
#if defined RBA_REG_P61_OUT_P0_POS || defined RBA_REG_P61_OUT_P1_POS || defined RBA_REG_P61_OUT_P2_POS|| defined RBA_REG_P61_OUT_P3_POS || defined RBA_REG_P61_OUT_P4_POS || defined RBA_REG_P61_OUT_P5_POS || defined RBA_REG_P61_OUT_P6_POS || defined RBA_REG_P61_OUT_P7_POS || defined RBA_REG_P61_OUT_P8_POS || defined RBA_REG_P61_OUT_P9_POS || defined RBA_REG_P61_OUT_P10_POS || defined RBA_REG_P61_OUT_P11_POS || defined RBA_REG_P61_OUT_P12_POS || defined RBA_REG_P61_OUT_P13_POS || defined RBA_REG_P61_OUT_P14_POS || defined RBA_REG_P61_OUT_P15_POS
    TestCdDioChkPort(P61);
#endif
#if defined RBA_REG_P62_OUT_P0_POS || defined RBA_REG_P62_OUT_P1_POS || defined RBA_REG_P62_OUT_P2_POS|| defined RBA_REG_P62_OUT_P3_POS || defined RBA_REG_P62_OUT_P4_POS || defined RBA_REG_P62_OUT_P5_POS || defined RBA_REG_P62_OUT_P6_POS || defined RBA_REG_P62_OUT_P7_POS || defined RBA_REG_P62_OUT_P8_POS || defined RBA_REG_P62_OUT_P9_POS || defined RBA_REG_P62_OUT_P10_POS || defined RBA_REG_P62_OUT_P11_POS || defined RBA_REG_P62_OUT_P12_POS || defined RBA_REG_P62_OUT_P13_POS || defined RBA_REG_P62_OUT_P14_POS || defined RBA_REG_P62_OUT_P15_POS
    TestCdDioChkPort(P62);
#endif
#if defined RBA_REG_P63_OUT_P0_POS || defined RBA_REG_P63_OUT_P1_POS || defined RBA_REG_P63_OUT_P2_POS|| defined RBA_REG_P63_OUT_P3_POS || defined RBA_REG_P63_OUT_P4_POS || defined RBA_REG_P63_OUT_P5_POS || defined RBA_REG_P63_OUT_P6_POS || defined RBA_REG_P63_OUT_P7_POS || defined RBA_REG_P63_OUT_P8_POS || defined RBA_REG_P63_OUT_P9_POS || defined RBA_REG_P63_OUT_P10_POS || defined RBA_REG_P63_OUT_P11_POS || defined RBA_REG_P63_OUT_P12_POS || defined RBA_REG_P63_OUT_P13_POS || defined RBA_REG_P63_OUT_P14_POS || defined RBA_REG_P63_OUT_P15_POS
    TestCdDioChkPort(P63);
#endif
#if defined RBA_REG_P64_OUT_P0_POS || defined RBA_REG_P64_OUT_P1_POS || defined RBA_REG_P64_OUT_P2_POS|| defined RBA_REG_P64_OUT_P3_POS || defined RBA_REG_P64_OUT_P4_POS || defined RBA_REG_P64_OUT_P5_POS || defined RBA_REG_P64_OUT_P6_POS || defined RBA_REG_P64_OUT_P7_POS || defined RBA_REG_P64_OUT_P8_POS || defined RBA_REG_P64_OUT_P9_POS || defined RBA_REG_P64_OUT_P10_POS || defined RBA_REG_P64_OUT_P11_POS || defined RBA_REG_P64_OUT_P12_POS || defined RBA_REG_P64_OUT_P13_POS || defined RBA_REG_P64_OUT_P14_POS || defined RBA_REG_P64_OUT_P15_POS
    TestCdDioChkPort(P64);
#endif
#if defined RBA_REG_P65_OUT_P0_POS || defined RBA_REG_P65_OUT_P1_POS || defined RBA_REG_P65_OUT_P2_POS|| defined RBA_REG_P65_OUT_P3_POS || defined RBA_REG_P65_OUT_P4_POS || defined RBA_REG_P65_OUT_P5_POS || defined RBA_REG_P65_OUT_P6_POS || defined RBA_REG_P65_OUT_P7_POS || defined RBA_REG_P65_OUT_P8_POS || defined RBA_REG_P65_OUT_P9_POS || defined RBA_REG_P65_OUT_P10_POS || defined RBA_REG_P65_OUT_P11_POS || defined RBA_REG_P65_OUT_P12_POS || defined RBA_REG_P65_OUT_P13_POS || defined RBA_REG_P65_OUT_P14_POS || defined RBA_REG_P65_OUT_P15_POS
    TestCdDioChkPort(P65);
#endif
#if defined RBA_REG_P66_OUT_P0_POS || defined RBA_REG_P66_OUT_P1_POS || defined RBA_REG_P66_OUT_P2_POS|| defined RBA_REG_P66_OUT_P3_POS || defined RBA_REG_P66_OUT_P4_POS || defined RBA_REG_P66_OUT_P5_POS || defined RBA_REG_P66_OUT_P6_POS || defined RBA_REG_P66_OUT_P7_POS || defined RBA_REG_P66_OUT_P8_POS || defined RBA_REG_P66_OUT_P9_POS || defined RBA_REG_P66_OUT_P10_POS || defined RBA_REG_P66_OUT_P11_POS || defined RBA_REG_P66_OUT_P12_POS || defined RBA_REG_P66_OUT_P13_POS || defined RBA_REG_P66_OUT_P14_POS || defined RBA_REG_P66_OUT_P15_POS
    TestCdDioChkPort(P66);
#endif
#if defined RBA_REG_P67_OUT_P0_POS || defined RBA_REG_P67_OUT_P1_POS || defined RBA_REG_P67_OUT_P2_POS|| defined RBA_REG_P67_OUT_P3_POS || defined RBA_REG_P67_OUT_P4_POS || defined RBA_REG_P67_OUT_P5_POS || defined RBA_REG_P67_OUT_P6_POS || defined RBA_REG_P67_OUT_P7_POS || defined RBA_REG_P67_OUT_P8_POS || defined RBA_REG_P67_OUT_P9_POS || defined RBA_REG_P67_OUT_P10_POS || defined RBA_REG_P67_OUT_P11_POS || defined RBA_REG_P67_OUT_P12_POS || defined RBA_REG_P67_OUT_P13_POS || defined RBA_REG_P67_OUT_P14_POS || defined RBA_REG_P67_OUT_P15_POS
    TestCdDioChkPort(P67);
#endif
#if defined RBA_REG_P68_OUT_P0_POS || defined RBA_REG_P68_OUT_P1_POS || defined RBA_REG_P68_OUT_P2_POS|| defined RBA_REG_P68_OUT_P3_POS || defined RBA_REG_P68_OUT_P4_POS || defined RBA_REG_P68_OUT_P5_POS || defined RBA_REG_P68_OUT_P6_POS || defined RBA_REG_P68_OUT_P7_POS || defined RBA_REG_P68_OUT_P8_POS || defined RBA_REG_P68_OUT_P9_POS || defined RBA_REG_P68_OUT_P10_POS || defined RBA_REG_P68_OUT_P11_POS || defined RBA_REG_P68_OUT_P12_POS || defined RBA_REG_P68_OUT_P13_POS || defined RBA_REG_P68_OUT_P14_POS || defined RBA_REG_P68_OUT_P15_POS
    TestCdDioChkPort(P68);
#endif
#if defined RBA_REG_P69_OUT_P0_POS || defined RBA_REG_P69_OUT_P1_POS || defined RBA_REG_P69_OUT_P2_POS|| defined RBA_REG_P69_OUT_P3_POS || defined RBA_REG_P69_OUT_P4_POS || defined RBA_REG_P69_OUT_P5_POS || defined RBA_REG_P69_OUT_P6_POS || defined RBA_REG_P69_OUT_P7_POS || defined RBA_REG_P69_OUT_P8_POS || defined RBA_REG_P69_OUT_P9_POS || defined RBA_REG_P69_OUT_P10_POS || defined RBA_REG_P69_OUT_P11_POS || defined RBA_REG_P69_OUT_P12_POS || defined RBA_REG_P69_OUT_P13_POS || defined RBA_REG_P69_OUT_P14_POS || defined RBA_REG_P69_OUT_P15_POS
    TestCdDioChkPort(P69);
#endif
#if defined RBA_REG_P70_OUT_P0_POS || defined RBA_REG_P70_OUT_P1_POS || defined RBA_REG_P70_OUT_P2_POS|| defined RBA_REG_P70_OUT_P3_POS || defined RBA_REG_P70_OUT_P4_POS || defined RBA_REG_P70_OUT_P5_POS || defined RBA_REG_P70_OUT_P6_POS || defined RBA_REG_P70_OUT_P7_POS || defined RBA_REG_P70_OUT_P8_POS || defined RBA_REG_P70_OUT_P9_POS || defined RBA_REG_P70_OUT_P10_POS || defined RBA_REG_P70_OUT_P11_POS || defined RBA_REG_P70_OUT_P12_POS || defined RBA_REG_P70_OUT_P13_POS || defined RBA_REG_P70_OUT_P14_POS || defined RBA_REG_P70_OUT_P15_POS
    TestCdDioChkPort(P70);
#endif
#if defined RBA_REG_P71_OUT_P0_POS || defined RBA_REG_P71_OUT_P1_POS || defined RBA_REG_P71_OUT_P2_POS|| defined RBA_REG_P71_OUT_P3_POS || defined RBA_REG_P71_OUT_P4_POS || defined RBA_REG_P71_OUT_P5_POS || defined RBA_REG_P71_OUT_P6_POS || defined RBA_REG_P71_OUT_P7_POS || defined RBA_REG_P71_OUT_P8_POS || defined RBA_REG_P71_OUT_P9_POS || defined RBA_REG_P71_OUT_P10_POS || defined RBA_REG_P71_OUT_P11_POS || defined RBA_REG_P71_OUT_P12_POS || defined RBA_REG_P71_OUT_P13_POS || defined RBA_REG_P71_OUT_P14_POS || defined RBA_REG_P71_OUT_P15_POS
    TestCdDioChkPort(P71);
#endif
#if defined RBA_REG_P72_OUT_P0_POS || defined RBA_REG_P72_OUT_P1_POS || defined RBA_REG_P72_OUT_P2_POS|| defined RBA_REG_P72_OUT_P3_POS || defined RBA_REG_P72_OUT_P4_POS || defined RBA_REG_P72_OUT_P5_POS || defined RBA_REG_P72_OUT_P6_POS || defined RBA_REG_P72_OUT_P7_POS || defined RBA_REG_P72_OUT_P8_POS || defined RBA_REG_P72_OUT_P9_POS || defined RBA_REG_P72_OUT_P10_POS || defined RBA_REG_P72_OUT_P11_POS || defined RBA_REG_P72_OUT_P12_POS || defined RBA_REG_P72_OUT_P13_POS || defined RBA_REG_P72_OUT_P14_POS || defined RBA_REG_P72_OUT_P15_POS
    TestCdDioChkPort(P72);
#endif
#if defined RBA_REG_P73_OUT_P0_POS || defined RBA_REG_P73_OUT_P1_POS || defined RBA_REG_P73_OUT_P2_POS|| defined RBA_REG_P73_OUT_P3_POS || defined RBA_REG_P73_OUT_P4_POS || defined RBA_REG_P73_OUT_P5_POS || defined RBA_REG_P73_OUT_P6_POS || defined RBA_REG_P73_OUT_P7_POS || defined RBA_REG_P73_OUT_P8_POS || defined RBA_REG_P73_OUT_P9_POS || defined RBA_REG_P73_OUT_P10_POS || defined RBA_REG_P73_OUT_P11_POS || defined RBA_REG_P73_OUT_P12_POS || defined RBA_REG_P73_OUT_P13_POS || defined RBA_REG_P73_OUT_P14_POS || defined RBA_REG_P73_OUT_P15_POS
    TestCdDioChkPort(P73);
#endif
#if defined RBA_REG_P74_OUT_P0_POS || defined RBA_REG_P74_OUT_P1_POS || defined RBA_REG_P74_OUT_P2_POS|| defined RBA_REG_P74_OUT_P3_POS || defined RBA_REG_P74_OUT_P4_POS || defined RBA_REG_P74_OUT_P5_POS || defined RBA_REG_P74_OUT_P6_POS || defined RBA_REG_P74_OUT_P7_POS || defined RBA_REG_P74_OUT_P8_POS || defined RBA_REG_P74_OUT_P9_POS || defined RBA_REG_P74_OUT_P10_POS || defined RBA_REG_P74_OUT_P11_POS || defined RBA_REG_P74_OUT_P12_POS || defined RBA_REG_P74_OUT_P13_POS || defined RBA_REG_P74_OUT_P14_POS || defined RBA_REG_P74_OUT_P15_POS
    TestCdDioChkPort(P74);
#endif
#if defined RBA_REG_P75_OUT_P0_POS || defined RBA_REG_P75_OUT_P1_POS || defined RBA_REG_P75_OUT_P2_POS|| defined RBA_REG_P75_OUT_P3_POS || defined RBA_REG_P75_OUT_P4_POS || defined RBA_REG_P75_OUT_P5_POS || defined RBA_REG_P75_OUT_P6_POS || defined RBA_REG_P75_OUT_P7_POS || defined RBA_REG_P75_OUT_P8_POS || defined RBA_REG_P75_OUT_P9_POS || defined RBA_REG_P75_OUT_P10_POS || defined RBA_REG_P75_OUT_P11_POS || defined RBA_REG_P75_OUT_P12_POS || defined RBA_REG_P75_OUT_P13_POS || defined RBA_REG_P75_OUT_P14_POS || defined RBA_REG_P75_OUT_P15_POS
    TestCdDioChkPort(P75);
#endif
#if defined RBA_REG_P76_OUT_P0_POS || defined RBA_REG_P76_OUT_P1_POS || defined RBA_REG_P76_OUT_P2_POS|| defined RBA_REG_P76_OUT_P3_POS || defined RBA_REG_P76_OUT_P4_POS || defined RBA_REG_P76_OUT_P5_POS || defined RBA_REG_P76_OUT_P6_POS || defined RBA_REG_P76_OUT_P7_POS || defined RBA_REG_P76_OUT_P8_POS || defined RBA_REG_P76_OUT_P9_POS || defined RBA_REG_P76_OUT_P10_POS || defined RBA_REG_P76_OUT_P11_POS || defined RBA_REG_P76_OUT_P12_POS || defined RBA_REG_P76_OUT_P13_POS || defined RBA_REG_P76_OUT_P14_POS || defined RBA_REG_P76_OUT_P15_POS
    TestCdDioChkPort(P76);
#endif
#if defined RBA_REG_P77_OUT_P0_POS || defined RBA_REG_P77_OUT_P1_POS || defined RBA_REG_P77_OUT_P2_POS|| defined RBA_REG_P77_OUT_P3_POS || defined RBA_REG_P77_OUT_P4_POS || defined RBA_REG_P77_OUT_P5_POS || defined RBA_REG_P77_OUT_P6_POS || defined RBA_REG_P77_OUT_P7_POS || defined RBA_REG_P77_OUT_P8_POS || defined RBA_REG_P77_OUT_P9_POS || defined RBA_REG_P77_OUT_P10_POS || defined RBA_REG_P77_OUT_P11_POS || defined RBA_REG_P77_OUT_P12_POS || defined RBA_REG_P77_OUT_P13_POS || defined RBA_REG_P77_OUT_P14_POS || defined RBA_REG_P77_OUT_P15_POS
    TestCdDioChkPort(P77);
#endif
#if defined RBA_REG_P78_OUT_P0_POS || defined RBA_REG_P78_OUT_P1_POS || defined RBA_REG_P78_OUT_P2_POS|| defined RBA_REG_P78_OUT_P3_POS || defined RBA_REG_P78_OUT_P4_POS || defined RBA_REG_P78_OUT_P5_POS || defined RBA_REG_P78_OUT_P6_POS || defined RBA_REG_P78_OUT_P7_POS || defined RBA_REG_P78_OUT_P8_POS || defined RBA_REG_P78_OUT_P9_POS || defined RBA_REG_P78_OUT_P10_POS || defined RBA_REG_P78_OUT_P11_POS || defined RBA_REG_P78_OUT_P12_POS || defined RBA_REG_P78_OUT_P13_POS || defined RBA_REG_P78_OUT_P14_POS || defined RBA_REG_P78_OUT_P15_POS
    TestCdDioChkPort(P78);
#endif
#if defined RBA_REG_P79_OUT_P0_POS || defined RBA_REG_P79_OUT_P1_POS || defined RBA_REG_P79_OUT_P2_POS|| defined RBA_REG_P79_OUT_P3_POS || defined RBA_REG_P79_OUT_P4_POS || defined RBA_REG_P79_OUT_P5_POS || defined RBA_REG_P79_OUT_P6_POS || defined RBA_REG_P79_OUT_P7_POS || defined RBA_REG_P79_OUT_P8_POS || defined RBA_REG_P79_OUT_P9_POS || defined RBA_REG_P79_OUT_P10_POS || defined RBA_REG_P79_OUT_P11_POS || defined RBA_REG_P79_OUT_P12_POS || defined RBA_REG_P79_OUT_P13_POS || defined RBA_REG_P79_OUT_P14_POS || defined RBA_REG_P79_OUT_P15_POS
    TestCdDioChkPort(P79);
#endif
#if defined RBA_REG_P80_OUT_P0_POS || defined RBA_REG_P80_OUT_P1_POS || defined RBA_REG_P80_OUT_P2_POS|| defined RBA_REG_P80_OUT_P3_POS || defined RBA_REG_P80_OUT_P4_POS || defined RBA_REG_P80_OUT_P5_POS || defined RBA_REG_P80_OUT_P6_POS || defined RBA_REG_P80_OUT_P7_POS || defined RBA_REG_P80_OUT_P8_POS || defined RBA_REG_P80_OUT_P9_POS || defined RBA_REG_P80_OUT_P10_POS || defined RBA_REG_P80_OUT_P11_POS || defined RBA_REG_P80_OUT_P12_POS || defined RBA_REG_P80_OUT_P13_POS || defined RBA_REG_P80_OUT_P14_POS || defined RBA_REG_P80_OUT_P15_POS
    TestCdDioChkPort(P80);
#endif
#if defined RBA_REG_P81_OUT_P0_POS || defined RBA_REG_P81_OUT_P1_POS || defined RBA_REG_P81_OUT_P2_POS|| defined RBA_REG_P81_OUT_P3_POS || defined RBA_REG_P81_OUT_P4_POS || defined RBA_REG_P81_OUT_P5_POS || defined RBA_REG_P81_OUT_P6_POS || defined RBA_REG_P81_OUT_P7_POS || defined RBA_REG_P81_OUT_P8_POS || defined RBA_REG_P81_OUT_P9_POS || defined RBA_REG_P81_OUT_P10_POS || defined RBA_REG_P81_OUT_P11_POS || defined RBA_REG_P81_OUT_P12_POS || defined RBA_REG_P81_OUT_P13_POS || defined RBA_REG_P81_OUT_P14_POS || defined RBA_REG_P81_OUT_P15_POS
    TestCdDioChkPort(P81);
#endif
#if defined RBA_REG_P82_OUT_P0_POS || defined RBA_REG_P82_OUT_P1_POS || defined RBA_REG_P82_OUT_P2_POS|| defined RBA_REG_P82_OUT_P3_POS || defined RBA_REG_P82_OUT_P4_POS || defined RBA_REG_P82_OUT_P5_POS || defined RBA_REG_P82_OUT_P6_POS || defined RBA_REG_P82_OUT_P7_POS || defined RBA_REG_P82_OUT_P8_POS || defined RBA_REG_P82_OUT_P9_POS || defined RBA_REG_P82_OUT_P10_POS || defined RBA_REG_P82_OUT_P11_POS || defined RBA_REG_P82_OUT_P12_POS || defined RBA_REG_P82_OUT_P13_POS || defined RBA_REG_P82_OUT_P14_POS || defined RBA_REG_P82_OUT_P15_POS
    TestCdDioChkPort(P82);
#endif
#if defined RBA_REG_P83_OUT_P0_POS || defined RBA_REG_P83_OUT_P1_POS || defined RBA_REG_P83_OUT_P2_POS|| defined RBA_REG_P83_OUT_P3_POS || defined RBA_REG_P83_OUT_P4_POS || defined RBA_REG_P83_OUT_P5_POS || defined RBA_REG_P83_OUT_P6_POS || defined RBA_REG_P83_OUT_P7_POS || defined RBA_REG_P83_OUT_P8_POS || defined RBA_REG_P83_OUT_P9_POS || defined RBA_REG_P83_OUT_P10_POS || defined RBA_REG_P83_OUT_P11_POS || defined RBA_REG_P83_OUT_P12_POS || defined RBA_REG_P83_OUT_P13_POS || defined RBA_REG_P83_OUT_P14_POS || defined RBA_REG_P83_OUT_P15_POS
    TestCdDioChkPort(P83);
#endif
#if defined RBA_REG_P84_OUT_P0_POS || defined RBA_REG_P84_OUT_P1_POS || defined RBA_REG_P84_OUT_P2_POS|| defined RBA_REG_P84_OUT_P3_POS || defined RBA_REG_P84_OUT_P4_POS || defined RBA_REG_P84_OUT_P5_POS || defined RBA_REG_P84_OUT_P6_POS || defined RBA_REG_P84_OUT_P7_POS || defined RBA_REG_P84_OUT_P8_POS || defined RBA_REG_P84_OUT_P9_POS || defined RBA_REG_P84_OUT_P10_POS || defined RBA_REG_P84_OUT_P11_POS || defined RBA_REG_P84_OUT_P12_POS || defined RBA_REG_P84_OUT_P13_POS || defined RBA_REG_P84_OUT_P14_POS || defined RBA_REG_P84_OUT_P15_POS
    TestCdDioChkPort(P84);
#endif
#if defined RBA_REG_P85_OUT_P0_POS || defined RBA_REG_P85_OUT_P1_POS || defined RBA_REG_P85_OUT_P2_POS|| defined RBA_REG_P85_OUT_P3_POS || defined RBA_REG_P85_OUT_P4_POS || defined RBA_REG_P85_OUT_P5_POS || defined RBA_REG_P85_OUT_P6_POS || defined RBA_REG_P85_OUT_P7_POS || defined RBA_REG_P85_OUT_P8_POS || defined RBA_REG_P85_OUT_P9_POS || defined RBA_REG_P85_OUT_P10_POS || defined RBA_REG_P85_OUT_P11_POS || defined RBA_REG_P85_OUT_P12_POS || defined RBA_REG_P85_OUT_P13_POS || defined RBA_REG_P85_OUT_P14_POS || defined RBA_REG_P85_OUT_P15_POS
    TestCdDioChkPort(P85);
#endif
#if defined RBA_REG_P86_OUT_P0_POS || defined RBA_REG_P86_OUT_P1_POS || defined RBA_REG_P86_OUT_P2_POS|| defined RBA_REG_P86_OUT_P3_POS || defined RBA_REG_P86_OUT_P4_POS || defined RBA_REG_P86_OUT_P5_POS || defined RBA_REG_P86_OUT_P6_POS || defined RBA_REG_P86_OUT_P7_POS || defined RBA_REG_P86_OUT_P8_POS || defined RBA_REG_P86_OUT_P9_POS || defined RBA_REG_P86_OUT_P10_POS || defined RBA_REG_P86_OUT_P11_POS || defined RBA_REG_P86_OUT_P12_POS || defined RBA_REG_P86_OUT_P13_POS || defined RBA_REG_P86_OUT_P14_POS || defined RBA_REG_P86_OUT_P15_POS
    TestCdDioChkPort(P86);
#endif
#if defined RBA_REG_P87_OUT_P0_POS || defined RBA_REG_P87_OUT_P1_POS || defined RBA_REG_P87_OUT_P2_POS|| defined RBA_REG_P87_OUT_P3_POS || defined RBA_REG_P87_OUT_P4_POS || defined RBA_REG_P87_OUT_P5_POS || defined RBA_REG_P87_OUT_P6_POS || defined RBA_REG_P87_OUT_P7_POS || defined RBA_REG_P87_OUT_P8_POS || defined RBA_REG_P87_OUT_P9_POS || defined RBA_REG_P87_OUT_P10_POS || defined RBA_REG_P87_OUT_P11_POS || defined RBA_REG_P87_OUT_P12_POS || defined RBA_REG_P87_OUT_P13_POS || defined RBA_REG_P87_OUT_P14_POS || defined RBA_REG_P87_OUT_P15_POS
    TestCdDioChkPort(P87);
#endif
#if defined RBA_REG_P88_OUT_P0_POS || defined RBA_REG_P88_OUT_P1_POS || defined RBA_REG_P88_OUT_P2_POS|| defined RBA_REG_P88_OUT_P3_POS || defined RBA_REG_P88_OUT_P4_POS || defined RBA_REG_P88_OUT_P5_POS || defined RBA_REG_P88_OUT_P6_POS || defined RBA_REG_P88_OUT_P7_POS || defined RBA_REG_P88_OUT_P8_POS || defined RBA_REG_P88_OUT_P9_POS || defined RBA_REG_P88_OUT_P10_POS || defined RBA_REG_P88_OUT_P11_POS || defined RBA_REG_P88_OUT_P12_POS || defined RBA_REG_P88_OUT_P13_POS || defined RBA_REG_P88_OUT_P14_POS || defined RBA_REG_P88_OUT_P15_POS
    TestCdDioChkPort(P88);
#endif
#if defined RBA_REG_P89_OUT_P0_POS || defined RBA_REG_P89_OUT_P1_POS || defined RBA_REG_P89_OUT_P2_POS|| defined RBA_REG_P89_OUT_P3_POS || defined RBA_REG_P89_OUT_P4_POS || defined RBA_REG_P89_OUT_P5_POS || defined RBA_REG_P89_OUT_P6_POS || defined RBA_REG_P89_OUT_P7_POS || defined RBA_REG_P89_OUT_P8_POS || defined RBA_REG_P89_OUT_P9_POS || defined RBA_REG_P89_OUT_P10_POS || defined RBA_REG_P89_OUT_P11_POS || defined RBA_REG_P89_OUT_P12_POS || defined RBA_REG_P89_OUT_P13_POS || defined RBA_REG_P89_OUT_P14_POS || defined RBA_REG_P89_OUT_P15_POS
    TestCdDioChkPort(P89);
#endif
#if defined RBA_REG_P90_OUT_P0_POS || defined RBA_REG_P90_OUT_P1_POS || defined RBA_REG_P90_OUT_P2_POS|| defined RBA_REG_P90_OUT_P3_POS || defined RBA_REG_P90_OUT_P4_POS || defined RBA_REG_P90_OUT_P5_POS || defined RBA_REG_P90_OUT_P6_POS || defined RBA_REG_P90_OUT_P7_POS || defined RBA_REG_P90_OUT_P8_POS || defined RBA_REG_P90_OUT_P9_POS || defined RBA_REG_P90_OUT_P10_POS || defined RBA_REG_P90_OUT_P11_POS || defined RBA_REG_P90_OUT_P12_POS || defined RBA_REG_P90_OUT_P13_POS || defined RBA_REG_P90_OUT_P14_POS || defined RBA_REG_P90_OUT_P15_POS
    TestCdDioChkPort(P90);
#endif
#if defined RBA_REG_P91_OUT_P0_POS || defined RBA_REG_P91_OUT_P1_POS || defined RBA_REG_P91_OUT_P2_POS|| defined RBA_REG_P91_OUT_P3_POS || defined RBA_REG_P91_OUT_P4_POS || defined RBA_REG_P91_OUT_P5_POS || defined RBA_REG_P91_OUT_P6_POS || defined RBA_REG_P91_OUT_P7_POS || defined RBA_REG_P91_OUT_P8_POS || defined RBA_REG_P91_OUT_P9_POS || defined RBA_REG_P91_OUT_P10_POS || defined RBA_REG_P91_OUT_P11_POS || defined RBA_REG_P91_OUT_P12_POS || defined RBA_REG_P91_OUT_P13_POS || defined RBA_REG_P91_OUT_P14_POS || defined RBA_REG_P91_OUT_P15_POS
    TestCdDioChkPort(P91);
#endif
#if defined RBA_REG_P92_OUT_P0_POS || defined RBA_REG_P92_OUT_P1_POS || defined RBA_REG_P92_OUT_P2_POS|| defined RBA_REG_P92_OUT_P3_POS || defined RBA_REG_P92_OUT_P4_POS || defined RBA_REG_P92_OUT_P5_POS || defined RBA_REG_P92_OUT_P6_POS || defined RBA_REG_P92_OUT_P7_POS || defined RBA_REG_P92_OUT_P8_POS || defined RBA_REG_P92_OUT_P9_POS || defined RBA_REG_P92_OUT_P10_POS || defined RBA_REG_P92_OUT_P11_POS || defined RBA_REG_P92_OUT_P12_POS || defined RBA_REG_P92_OUT_P13_POS || defined RBA_REG_P92_OUT_P14_POS || defined RBA_REG_P92_OUT_P15_POS
    TestCdDioChkPort(P92);
#endif
#if defined RBA_REG_P93_OUT_P0_POS || defined RBA_REG_P93_OUT_P1_POS || defined RBA_REG_P93_OUT_P2_POS|| defined RBA_REG_P93_OUT_P3_POS || defined RBA_REG_P93_OUT_P4_POS || defined RBA_REG_P93_OUT_P5_POS || defined RBA_REG_P93_OUT_P6_POS || defined RBA_REG_P93_OUT_P7_POS || defined RBA_REG_P93_OUT_P8_POS || defined RBA_REG_P93_OUT_P9_POS || defined RBA_REG_P93_OUT_P10_POS || defined RBA_REG_P93_OUT_P11_POS || defined RBA_REG_P93_OUT_P12_POS || defined RBA_REG_P93_OUT_P13_POS || defined RBA_REG_P93_OUT_P14_POS || defined RBA_REG_P93_OUT_P15_POS
    TestCdDioChkPort(P93);
#endif
#if defined RBA_REG_P94_OUT_P0_POS || defined RBA_REG_P94_OUT_P1_POS || defined RBA_REG_P94_OUT_P2_POS|| defined RBA_REG_P94_OUT_P3_POS || defined RBA_REG_P94_OUT_P4_POS || defined RBA_REG_P94_OUT_P5_POS || defined RBA_REG_P94_OUT_P6_POS || defined RBA_REG_P94_OUT_P7_POS || defined RBA_REG_P94_OUT_P8_POS || defined RBA_REG_P94_OUT_P9_POS || defined RBA_REG_P94_OUT_P10_POS || defined RBA_REG_P94_OUT_P11_POS || defined RBA_REG_P94_OUT_P12_POS || defined RBA_REG_P94_OUT_P13_POS || defined RBA_REG_P94_OUT_P14_POS || defined RBA_REG_P94_OUT_P15_POS
    TestCdDioChkPort(P94);
#endif
#if defined RBA_REG_P95_OUT_P0_POS || defined RBA_REG_P95_OUT_P1_POS || defined RBA_REG_P95_OUT_P2_POS|| defined RBA_REG_P95_OUT_P3_POS || defined RBA_REG_P95_OUT_P4_POS || defined RBA_REG_P95_OUT_P5_POS || defined RBA_REG_P95_OUT_P6_POS || defined RBA_REG_P95_OUT_P7_POS || defined RBA_REG_P95_OUT_P8_POS || defined RBA_REG_P95_OUT_P9_POS || defined RBA_REG_P95_OUT_P10_POS || defined RBA_REG_P95_OUT_P11_POS || defined RBA_REG_P95_OUT_P12_POS || defined RBA_REG_P95_OUT_P13_POS || defined RBA_REG_P95_OUT_P14_POS || defined RBA_REG_P95_OUT_P15_POS
    TestCdDioChkPort(P95);
#endif
#if defined RBA_REG_P96_OUT_P0_POS || defined RBA_REG_P96_OUT_P1_POS || defined RBA_REG_P96_OUT_P2_POS|| defined RBA_REG_P96_OUT_P3_POS || defined RBA_REG_P96_OUT_P4_POS || defined RBA_REG_P96_OUT_P5_POS || defined RBA_REG_P96_OUT_P6_POS || defined RBA_REG_P96_OUT_P7_POS || defined RBA_REG_P96_OUT_P8_POS || defined RBA_REG_P96_OUT_P9_POS || defined RBA_REG_P96_OUT_P10_POS || defined RBA_REG_P96_OUT_P11_POS || defined RBA_REG_P96_OUT_P12_POS || defined RBA_REG_P96_OUT_P13_POS || defined RBA_REG_P96_OUT_P14_POS || defined RBA_REG_P96_OUT_P15_POS
    TestCdDioChkPort(P96);
#endif
#if defined RBA_REG_P97_OUT_P0_POS || defined RBA_REG_P97_OUT_P1_POS || defined RBA_REG_P97_OUT_P2_POS|| defined RBA_REG_P97_OUT_P3_POS || defined RBA_REG_P97_OUT_P4_POS || defined RBA_REG_P97_OUT_P5_POS || defined RBA_REG_P97_OUT_P6_POS || defined RBA_REG_P97_OUT_P7_POS || defined RBA_REG_P97_OUT_P8_POS || defined RBA_REG_P97_OUT_P9_POS || defined RBA_REG_P97_OUT_P10_POS || defined RBA_REG_P97_OUT_P11_POS || defined RBA_REG_P97_OUT_P12_POS || defined RBA_REG_P97_OUT_P13_POS || defined RBA_REG_P97_OUT_P14_POS || defined RBA_REG_P97_OUT_P15_POS
    TestCdDioChkPort(P97);
#endif
#if defined RBA_REG_P98_OUT_P0_POS || defined RBA_REG_P98_OUT_P1_POS || defined RBA_REG_P98_OUT_P2_POS|| defined RBA_REG_P98_OUT_P3_POS || defined RBA_REG_P98_OUT_P4_POS || defined RBA_REG_P98_OUT_P5_POS || defined RBA_REG_P98_OUT_P6_POS || defined RBA_REG_P98_OUT_P7_POS || defined RBA_REG_P98_OUT_P8_POS || defined RBA_REG_P98_OUT_P9_POS || defined RBA_REG_P98_OUT_P10_POS || defined RBA_REG_P98_OUT_P11_POS || defined RBA_REG_P98_OUT_P12_POS || defined RBA_REG_P98_OUT_P13_POS || defined RBA_REG_P98_OUT_P14_POS || defined RBA_REG_P98_OUT_P15_POS
    TestCdDioChkPort(P98);
#endif
#if defined RBA_REG_P99_OUT_P0_POS || defined RBA_REG_P99_OUT_P1_POS || defined RBA_REG_P99_OUT_P2_POS|| defined RBA_REG_P99_OUT_P3_POS || defined RBA_REG_P99_OUT_P4_POS || defined RBA_REG_P99_OUT_P5_POS || defined RBA_REG_P99_OUT_P6_POS || defined RBA_REG_P99_OUT_P7_POS || defined RBA_REG_P99_OUT_P8_POS || defined RBA_REG_P99_OUT_P9_POS || defined RBA_REG_P99_OUT_P10_POS || defined RBA_REG_P99_OUT_P11_POS || defined RBA_REG_P99_OUT_P12_POS || defined RBA_REG_P99_OUT_P13_POS || defined RBA_REG_P99_OUT_P14_POS || defined RBA_REG_P99_OUT_P15_POS
    TestCdDioChkPort(P99);
#endif
}
#endif /* MCU_RB_MACHINE_FAM == MCU_RB_IFX_UC1 */

