/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, 2010 Robert Bosch GmbH. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:$
 * $Namespace_:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 **********************************************************************************************************************
</BASDKey>*/

#include "TestCd_Dio_ITF.h"
#include "Mcu.h"

TestCd_Dio_tst TestCd_Dio_st;
Dio_LevelType TestCd_Dio_retval_u8;
Dio_PortLevelType TestCd_Dio_readport_retval_u16;
volatile uint8 Dio_Machine_Fam_u8 = MCU_RB_MACHINE_FAM;
volatile uint8 Dio_ITF_IFX_u8 = MCU_RB_IFX_UC1;
volatile uint8 Dio_ITF_JDP_u8 = MCU_RB_JDP_UC1;
volatile uint8 TestCd_Dio_ITF_num_signals_u8 = DIO_NUMBER_OF_SIGNALS;
volatile uint8 TestCd_Dio_ITF_num_portnames_u8 = DIO_NUMBER_OF_PORTNAMES;
volatile uint8 TestCd_Dio_ITF_num_pinpos_u8 = DIO_NUMBER_OF_PINPOS;
volatile uint8 TestCd_Dio_ITF_input_u8 = DioConf_DioChannel_ITF_DIO_Input;
volatile uint8 TestCd_Dio_ITF_output_u8 = DioConf_DioChannel_ITF_DIO_Output;
volatile uint8 TestCd_Dio_PinPos_ITF_input_u8 = DioConf_DioRbPinPos_ITF_DIO_Input;
volatile uint8 TestCd_Dio_ITF_PortName_u8 = DioConf_DioRbPortName_ITF_Port;

void TestCd_Dio_Itf_10ms(void)
{
    // Dummy reads (and volatile declaration) are needed to prevent Tasking compiler form removing unused variables
    (void)Dio_Machine_Fam_u8;
    (void)Dio_ITF_IFX_u8;
    (void)Dio_ITF_JDP_u8;
    (void)TestCd_Dio_ITF_num_signals_u8;
    (void)TestCd_Dio_ITF_num_portnames_u8;
    (void)TestCd_Dio_ITF_num_pinpos_u8;
    (void)TestCd_Dio_ITF_input_u8;
    (void)TestCd_Dio_ITF_output_u8;
    (void)TestCd_Dio_PinPos_ITF_input_u8;
    (void)TestCd_Dio_ITF_PortName_u8;

    switch( TestCd_Dio_st.stTestcase_en )
        {

            case TESTCD_DIO_CHECK_DET_ENABLE:
            {
                TestCd_Dio_st.isDetReportEnabled_b = FALSE;
                    #if( DIO_DEV_ERROR_DETECT == STD_ON )
                TestCd_Dio_st.isDetReportEnabled_b = TRUE;
                    #endif
                TestCd_Dio_st.stTestcase_en = TESTCD_DIO_TEST_PASSED;
            }
            break;

            case TESTCD_DIO_INIT_NULL:
            {
                #if( DIO_DEV_ERROR_DETECT == STD_ON )
                    Dio_Init(TestCd_Dio_st.pPBConfigTest_pst);
                    TestCd_Dio_st.stTestcase_en = TESTCD_DIO_TEST_DONE;
                #else
                    TestCd_Dio_st.stTestcase_en = TESTCD_DIO_TEST_NOTTESTABLE_E;
                #endif
            }
            break;

            case TESTCD_DIO_GET_VERSION_INFO:
            {
				#if ( DIO_VERSION_INFO_API == STD_ON )
                    Dio_GetVersionInfo( &(TestCd_Dio_st.stVersionInfo_st) );
                    TestCd_Dio_st.retVal_b      = TRUE;
                    TestCd_Dio_st.stTestcase_en = TESTCD_DIO_TEST_PASSED;
				#else
                    TestCd_Dio_st.stTestcase_en = TESTCD_DIO_TEST_NOTTESTABLE_E;
                #endif
            }
			break;


			case TESTCD_DIO_GET_VERSION_INFO_NULL:
			{
				#if ( DIO_VERSION_INFO_API == STD_ON )
					Dio_GetVersionInfo((void*)0);
					TestCd_Dio_st.stTestcase_en = TESTCD_DIO_TEST_PASSED;
                #else
					TestCd_Dio_st.stTestcase_en = TESTCD_DIO_TEST_NOTTESTABLE_E;
                #endif
			}
			break;

            case TESTCD_DIO_WRITECHANNEL:
            {
                Dio_WriteChannel(TestCd_Dio_st.Dio_PinType_u16, TestCd_Dio_st.Dio_LevelType_u8);
                TestCd_Dio_st.stTestcase_en = TESTCD_DIO_TEST_PASSED;

            }
			break;

            case TESTCD_DIO_READCHANNEL:
            {
                TestCd_Dio_retval_u8 = Dio_ReadChannel(TestCd_Dio_st.Dio_PinType_u16);
                TestCd_Dio_st.stTestcase_en = TESTCD_DIO_TEST_PASSED;

            }
			break;

			case TESTCD_DIO_READPORT:
            {
                TestCd_Dio_readport_retval_u16 = Dio_ReadPort(TestCd_Dio_st.Dio_PortType_u8);
                TestCd_Dio_st.stTestcase_en = TESTCD_DIO_TEST_PASSED;

            }
            break;

			case TESTCD_DIO_RB_GETPINPOS:
            {
                (void)Dio_Rb_GetPinPos(TestCd_Dio_st.Dio_PinPosId_u8 , &TestCd_Dio_st.Dio_PinPos_u8);
                TestCd_Dio_st.stTestcase_en = TESTCD_DIO_TEST_PASSED;

            }
            break;

			case TESTCD_DIO_IDLE:
			{
				// nothing to do
			}
			break;

			case TESTCD_DIO_TEST_DONE:
			{
				// nothing to do
			}
			break;


			case TESTCD_DIO_TEST_PASSED:
			{
				// nothing to do
			}
			break;


			case TESTCD_DIO_TEST_FAILED:
			{
				// nothing to do
			}
			break;


			case TESTCD_DIO_TEST_NOTTESTABLE_E:
			{
				// nothing to do
			}
			break;

            case TESTCD_DIO_UNDEFINED:
            {
                // nothing to do
            }
			break;

			default:
			{
			    TestCd_Dio_st.stTestcase_en = TESTCD_DIO_UNDEFINED;
			}
			break;
        }

}
