/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, 2010 Robert Bosch GmbH. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:$
 * $Namespace_:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 **********************************************************************************************************************
</BASDKey>*/

#include "TestCd_Dio.h"
#include "Mcu.h"
#include "Dio.h"
#include "rba_BswSrv.h"

void TestCd_Dio(void)
{
    uint8 PinPos_u8;

#if (MCU_RB_MACHINE_FAM == MCU_RB_IFX_UC1)
    TestCd_DioOffsetChk_Ifx();
#endif

    (void)Dio_ReadPort(DioConf_DioRbPortName_Port0_0);
    (void)Dio_Rb_GetPinPos(DioConf_DioRbPinPos_Dio_Rb_GetPinPos, &PinPos_u8);
#if ((STD_TYPES_AR_RELEASE_MAJOR_VERSION == 4) && (STD_TYPES_AR_RELEASE_MINOR_VERSION == 0))
	
    /* MR12 RULE 13.5 VIOLATION: Dio_Rb_MoInitCheck has no side effects */
    if ((((Dio_Rb_MoInitCheck(&DioConfig_4Cyl) == E_OK    ) && (Dio_Rb_MoInitCheck(&DioConfig_6Cyl) == E_NOT_OK))  ||
         ((Dio_Rb_MoInitCheck(&DioConfig_4Cyl) == E_NOT_OK) && (Dio_Rb_MoInitCheck(&DioConfig_6Cyl) == E_OK    ))) &&
          (Dio_Rb_MoInitCheck(NULL_PTR)        == E_NOT_OK)
    )
    {
        // Everything OK
    }
    else
    {
        // Post Build Pointer check failed !!!
        RBA_BSWSRV_DEBUG_HALT();
    }
#endif	
}
