/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, 2010 Robert Bosch GmbH. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:$
 * $Namespace_:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 **********************************************************************************************************************
</BASDKey>*/

#ifndef TESTCD_DIO_ITF_H
#define TESTCD_DIO_ITF_H
#include "rba_BswSrv.h"
#include "Dio.h"

typedef enum
{
	TESTCD_DIO_IDLE=0,
	TESTCD_DIO_CHECK_DET_ENABLE,
	TESTCD_DIO_INIT_NULL,
    TESTCD_DIO_GET_VERSION_INFO,
	TESTCD_DIO_GET_VERSION_INFO_NULL,
    TESTCD_DIO_WRITECHANNEL,
    TESTCD_DIO_READCHANNEL,
    TESTCD_DIO_READPORT,
    TESTCD_DIO_RB_GETPINPOS,
	TESTCD_DIO_TEST_DONE,
	TESTCD_DIO_TEST_PASSED,
	TESTCD_DIO_TEST_FAILED,
	TESTCD_DIO_TEST_NOTTESTABLE_E,
    TESTCD_DIO_UNDEFINED

} testcd_Dio_Case_te;


typedef struct
{
    uint32 numbOfCalls_u32;
    testcd_Dio_Case_te stTestcase_en;
    boolean retVal_b;
    boolean isDetReportEnabled_b;
    Std_VersionInfoType stVersionInfo_st;
    Dio_ChannelType Dio_PinType_u16;
    Dio_LevelType Dio_LevelType_u8;
    Dio_PortType Dio_PortType_u8;
    uint8 Dio_PinPosId_u8;
    uint8 Dio_PinPos_u8;
	Dio_ConfigType * pPBConfigTest_pst;


} TestCd_Dio_tst;

/* Extern declarations for variables accessed through ITF */
extern TestCd_Dio_tst TestCd_Dio_st;
extern Dio_LevelType TestCd_Dio_retval_u8;
extern Dio_PortLevelType TestCd_Dio_readport_retval_u16;
extern volatile uint8 Dio_Machine_Fam_u8;
extern volatile uint8 Dio_ITF_IFX_u8;
extern volatile uint8 Dio_ITF_JDP_u8;
extern volatile uint8 TestCd_Dio_ITF_num_signals_u8;
extern volatile uint8 TestCd_Dio_ITF_num_portnames_u8;
extern volatile uint8 TestCd_Dio_ITF_num_pinpos_u8;
extern volatile uint8 TestCd_Dio_ITF_input_u8;
extern volatile uint8 TestCd_Dio_ITF_output_u8;
extern volatile uint8 TestCd_Dio_PinPos_ITF_input_u8;
extern volatile uint8 TestCd_Dio_ITF_PortName_u8;

#define TESTCD_DIO_HALT(x)  RBA_BSWSRV_DEBUG_HALT()

void TestCd_Dio_Itf_10ms(void);

#endif /* TESTCD_DIO_H_ */
