/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, 2010 Robert Bosch GmbH. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:$
 * $Namespace_:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 **********************************************************************************************************************
</BASDKey>*/

#ifndef TESTCD_DIO_H
#define TESTCD_DIO_H

#include "rba_BswSrv.h"

#define TESTCD_DIO_HALT(x)  RBA_BSWSRV_DEBUG_HALT()

void TestCd_Dio(void);
void TestCd_DioOffsetChk_Ifx(void);

#endif /* TESTCD_DIO_H_ */
