#<BASDKey>
#**********************************************************************************************************************
#
# COPYRIGHT RESERVED, 2010 Robert Bosch GmbH. All rights reserved.
# The reproduction, distribution and utilization of this document as well as the communication of its contents to
# others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
# All rights reserved in the event of the grant of a patent, utility model or design.
#
#**********************************************************************************************************************
# Administrative Information (automatically filled in)
# $Domain____:$
# $Namespace_:$
# $Class_____:$
# $Name______:$
# $Variant___:$
# $Revision__:$
#**********************************************************************************************************************
#</BASDKey>

package TestCd_Dio_EcucProc;
use strict;
use warnings;
use conf_process;
use Data::Dumper;


use constant ENABLE_TESTS => 0;

my @PostBuildNames_a = ("DioConfig_4Cyl", "DioConfig_6Cyl");
my @TestList_a = (
    \&PostBuildNameInvalid,
    \&PortShortName_Invalid,
    \&PortShortName_NotEqual_DioRbHwPort,
    \&PortIdAndChannelId_NotEmpty,
    \&PinNumber_GT_15,
    \&DioChannelNameUsedMoreThanOnce,
    \&HardwareResUsedMoreThanOnce,
);

#----------------------------------------------------------------------------------------------------------------------
# Generate: Called by the configuration framework to allow ECUC processors to generate output files
#
# Parameters:
# $_[1]: Destination paths for generated files [IN]
# $_[2]: Path to this ECUC processor [IN]
#----------------------------------------------------------------------------------------------------------------------
sub Forward
{
    if(ENABLE_TESTS == 1)
    {
        my $path_reports_s  = $_[1][6];

        if(-e $path_reports_s . "Dio_Report.txt")
        {
            print " Report file found checking for errors and info\n";
            my ($ErrorMsg_pa, $InfoMsg_pa) = GetErrorsFromReportFile($path_reports_s . "Dio_Report.txt");

            # Execute Test steps
            foreach my $TestCase_pf (@TestList_a)
            {
                # Run Checks
                my $TestConfig_ph = &$TestCase_pf("DoCheck",$ErrorMsg_pa, $InfoMsg_pa);
            }
        }

        print " Pushing test data\n";

        # Execute Test steps
        foreach my $TestCase_pf (@TestList_a)
        {
            # Run Test
            my $TestConfig_ph = &$TestCase_pf("PushConfig");
        }
    }
}

sub GetErrorsFromReportFile
{
    my $report_file_s = $_[0];
    my @ErrorMsg_a;
    my @InfoMsg_a;
    my $FileContent_s = conf_process::GetFileContent('TestCd_Dio', $report_file_s);

    while ($FileContent_s =~ s/(# (?:ERROR|INFO) in configuration script of.*?)^$(.*)/$2/ms)
    {
        my $Match_s = $1;

        if ($Match_s =~ m/ERROR/)
        {
            push(@ErrorMsg_a, $Match_s);
        }
        elsif ($Match_s =~ m/INFO/)
        {
            push(@InfoMsg_a, $Match_s);
        }
        else
        {
             conf_process::Exit("Something went wrong in GetErrorsFromReportFile");
        }
    }

    return (\@ErrorMsg_a, \@InfoMsg_a);
}

sub PortIdAndChannelId_NotEmpty
{
    my $Mode_s         = $_[0];
    my $ErrorMsg_pa    = $_[1];
    my $InfoMsg_pa     = $_[2];

    my $TestDesc        = "Test for non empty PortId and ChannelId (" . GetSubName() . ")";

    print "  $TestDesc\n";

    if ($Mode_s eq "PushConfig")
    {
        conf_process::Push(
            "Dio",
            ["Dio"],
            {
                'Dio__KEY'  => {'content' => 'Dio'},
                'DioConfig' => {
                    'DioConfig__KEY' => {'content' => $PostBuildNames_a[0]},
                    'DioPort'        => {
                        'DioPort__KEY' => {'content' => "Port_98"},
                        'DioPortId'    => {'content' => 1},
                        'DioRbHwPort'  => {'content' => 97},
                        'DioChannel'   => {
                            'DioChannel__KEY' => {'content' => GetSubName()},
                            'DioRbHwPin'      => {'content' => 0},
                            'DioChannelId'    => {'content' => 1},
                        },
                    },
                },
            },
            '/AUTOSAR_Dio/EcucModuleDefs'
        );
        conf_process::Push(
            "Dio",
            ["Dio"],
            {
                'Dio__KEY'  => {'content' => 'Dio'},
                'DioConfig' => {
                    'DioConfig__KEY' => {'content' => $PostBuildNames_a[0]},
                    'DioPort'        => {
                        'DioPort__KEY' => {'content' => "Port_98"},
                        'DioPortId'    => {'content' => 1},
                        'DioRbHwPort'  => {'content' => 97},
                        'DioChannel'   => {
                            'DioChannel__KEY' => {'content' => GetSubName()},
                            'DioRbHwPin'      => {'content' => 0},
                            'DioChannelId'    => {'content' => 1},
                        },
                    },
                },
            },
            '/AUTOSAR_Dio/EcucModuleDefs'
        );

    }
    elsif ($Mode_s eq "DoCheck")
    {
        CheckResult(
            $ErrorMsg_pa,
            '(# PortId not empty, please remove PortId from configuration file|# ChannelId not empty, please remove ChannelId from configuration file)',
            2
        );
    }
}

sub PostBuildNameInvalid
{
    my $Mode_s         = $_[0];
    my $ErrorMsg_pa    = $_[1];
    my $InfoMsg_pa     = $_[2];

    my $TestDesc        = "Test for invalid PostBuild Name (" . GetSubName() . ")";
    my $PostBuildName0_s = "DioConfig4Cyl";
    my $PostBuildName1_s = "DioConfig_";

    print "  $TestDesc\n";

    if ($Mode_s eq "PushConfig")
    {
        conf_process::Push(
            "Dio",
            ["Dio"],
            {
                'Dio__KEY'  => {'content' => 'Dio'},
                'DioConfig' => {
                    'DioConfig__KEY' => {'content' => $PostBuildName0_s},
                    'DioPort'        => {
                        'DioPort__KEY' => {'content' => 99},
                        'DioRbHwPort'  => {'content' => 99},
                        'DioChannel'   => {
                            'DioChannel__KEY' => {'content' => GetSubName()},
                            'DioRbHwPin'      => {'content' => 0},
                        },
                    },
                },
            },
            '/AUTOSAR_Dio/EcucModuleDefs'
        );
        conf_process::Push(
            "Dio",
            ["Dio"],
            {
                'Dio__KEY'  => {'content' => 'Dio'},
                'DioConfig' => {
                    'DioConfig__KEY' => {'content' => $PostBuildName1_s},
                    'DioPort'        => {
                        'DioPort__KEY' => {'content' => 99},
                        'DioRbHwPort'  => {'content' => 99},
                        'DioChannel'   => {
                            'DioChannel__KEY' => {'content' => GetSubName()},
                            'DioRbHwPin'      => {'content' => 0},
                        },
                    },
                },
            },
            '/AUTOSAR_Dio/EcucModuleDefs'
        );

    }
    elsif ($Mode_s eq "DoCheck")
    {
        CheckResult(
            $ErrorMsg_pa,
            "# Invalid Postbuild in DioConfig shortname.*# Configured Postbuild Name: ($PostBuildName0_s|$PostBuildName1_s)",
            2
        );
    }
}

sub PortShortName_Invalid
{
    my $Mode_s         = $_[0];
    my $ErrorMsg_pa    = $_[1];
    my $InfoMsg_pa     = $_[2];

    my $TestDesc       = "Test for invalid DioPort shortname(" . GetSubName() . ")";
    my $PortName_s     = "Hugo";

    print "  $TestDesc\n";

    if ($Mode_s eq "PushConfig")
    {
        conf_process::Push(
            "Dio",
            ["Dio"],
            {
                'Dio__KEY'  => {'content' => 'Dio'},
                'DioConfig' => {
                    'DioConfig__KEY' => {'content' => $PostBuildNames_a[0]},
                    'DioPort'        => {
                        'DioPort__KEY' => {'content' => $PortName_s},
                        'DioRbHwPort'  => {'content' => 99},
                        'DioChannel'   => {
                            'DioChannel__KEY' => {'content' => GetSubName()},
                            'DioRbHwPin'      => {'content' => 0},
                        },
                    },
                },
            },
            '/AUTOSAR_Dio/EcucModuleDefs'
        );
    }
    elsif ($Mode_s eq "DoCheck")
    {
        CheckResult(
            $ErrorMsg_pa,
            "The Shortname of the Port container is not valid.*Port container shortname: $PortName_s",
            1
        );
    }
}

sub PortShortName_NotEqual_DioRbHwPort
{
    my $Mode_s         = $_[0];
    my $ErrorMsg_pa    = $_[1];
    my $InfoMsg_pa     = $_[2];

    my $TestDesc       = "Test check if PortShortName is equal to DioRbHwPort (" . GetSubName() . ")";
    my $PortName_s;
    my $PortNum_s;

    if (GetMcuMachineInfo("MachineFam") eq 'MCU_RB_IFX_UC1')
    {
        $PortName_s = "Port_99";
        $PortNum_s  = 98;
    }
    else
    {
        $PortName_s = "Port_P";
        $PortNum_s  = "B";
    }

    print "  $TestDesc\n";

    if ($Mode_s eq "PushConfig")
    {
        if (GetMcuMachineInfo("MachineFam") eq 'MCU_RB_IFX_UC1')
        {
            conf_process::Push(
                "Dio",
                ["Dio"],
                {
                    'Dio__KEY'  => {'content' => 'Dio'},
                    'DioConfig' => {
                        'DioConfig__KEY' => {'content' => $PostBuildNames_a[0]},
                        'DioPort'        => {
                            'DioPort__KEY' => {'content' => $PortName_s},
                            'DioRbHwPort'  => {'content' => $PortNum_s},
                            'DioChannel'   => {
                                'DioChannel__KEY' => {'content' => GetSubName()},
                                'DioRbHwPin'      => {'content' => 0},
                            },
                        },
                    },
                },
                '/AUTOSAR_Dio/EcucModuleDefs'
            );
        }
        else
        {
            conf_process::Push(
                "Dio",
                ["Dio"],
                {
                    'Dio__KEY'  => {'content' => 'Dio'},
                    'DioConfig' => {
                        'DioConfig__KEY' => {'content' => $PostBuildNames_a[0]},
                        'DioPort'        => {
                            'DioPort__KEY' => {'content' => $PortName_s},
                            'DioRbHwPort'  => {'content' => $PortNum_s},
                            'DioChannel'   => {
                                'DioChannel__KEY' => {'content' => GetSubName()},
                                'DioRbHwPin'      => {'content' => 0},
                            },
                        },
                    },
                },
                '/AUTOSAR_Dio/EcucModuleDefs'
            );
        }
    }
    elsif ($Mode_s eq "DoCheck")
    {
        CheckResult(
            $ErrorMsg_pa,
            "# DioPort container shortname: $PortName_s.*# does not match.*# DioRbHwPort:                 $PortNum_s",
            1
        );
    }
}

sub PinNumber_GT_15
{
    my $Mode_s          = $_[0];
    my $ErrorMsg_pa     = $_[1];
    my $InfoMsg_pa      = $_[2];

    my $TestDesc        = "Test for DioRbHwPin > 15 (" . GetSubName() . ")";
    my $PortName_s      = "Port_XX";
    my $PortNum_s       = "XX";
    my @DioRbHwPin_a    = (16, "ABC");

    print "  $TestDesc\n";

    if ($Mode_s eq "PushConfig")
    {
        conf_process::Push(
            "Dio",
            ["Dio"],
            {
                'Dio__KEY'  => {'content' => 'Dio'},
                'DioConfig' => {
                    'DioConfig__KEY' => {'content' => $PostBuildNames_a[0]},
                    'DioPort'        => {
                        'DioPort__KEY' => {'content' => $PortName_s},
                        'DioRbHwPort'  => {'content' => $PortNum_s},
                        'DioChannel'   => {
                            'DioChannel__KEY' => {'content' => GetSubName() . "_0"},
                            'DioRbHwPin'      => {'content' => $DioRbHwPin_a[0]},
                        },
                    },
                },
            },
            '/AUTOSAR_Dio/EcucModuleDefs'
        );
        conf_process::Push(
            "Dio",
            ["Dio"],
            {
                'Dio__KEY'  => {'content' => 'Dio'},
                'DioConfig' => {
                    'DioConfig__KEY' => {'content' => $PostBuildNames_a[0]},
                    'DioPort'        => {
                        'DioPort__KEY' => {'content' => $PortName_s},
                        'DioRbHwPort'  => {'content' => $PortNum_s},
                        'DioChannel'   => {
                            'DioChannel__KEY' => {'content' => GetSubName() . "_1"},
                            'DioRbHwPin'      => {'content' => $DioRbHwPin_a[1]},
                        },
                    },
                },
            },
            '/AUTOSAR_Dio/EcucModuleDefs'
        );
    }
    elsif ($Mode_s eq "DoCheck")
    {
        CheckResult(
            $ErrorMsg_pa,
            "# DioRbHwPin: (?:$DioRbHwPin_a[0]|$DioRbHwPin_a[1]) is invalid",
            scalar(@DioRbHwPin_a)
        );
    }
}

sub DioChannelNameUsedMoreThanOnce
{
    my $Mode_s         = $_[0];
    my $ErrorMsg_pa    = $_[1];
    my $InfoMsg_pa     = $_[2];

    my $TestDesc       = "Test if DioChannel Shortname can only exist once per PostbuildConfig (" . GetSubName() . ")";

    my $DioRbHwPin  = 15;

    my $PortName0_s = "Port_96";
    my $PortNum0_s  = 96;

    my $PortName1_s = "Port_95";
    my $PortNum1_s  = 95;

    print "  $TestDesc\n";

    if ($Mode_s eq "PushConfig")
    {
        conf_process::Push(
            "TestCd_Dio",
            ["Dio"],
            {
                'Dio__KEY'  => {'content' => 'Dio'},
                'DioConfig' => {
                    'DioConfig__KEY' => {'content' => $PostBuildNames_a[0]},
                    'DioPort'        => {
                        'DioPort__KEY' => {'content' => $PortName0_s},
                        'DioRbHwPort'  => {'content' => $PortNum0_s},
                        'DioChannel'   => {
                            'DioChannel__KEY' => {'content' => GetSubName()},
                            'DioRbHwPin'      => {'content' => $DioRbHwPin},
                        },
                    },
                },
            },
            '/AUTOSAR_Dio/EcucModuleDefs'
        );
        conf_process::Push(
            "Dio",
            ["Dio"],
            {
                'Dio__KEY'  => {'content' => 'Dio'},
                'DioConfig' => {
                    'DioConfig__KEY' => {'content' => $PostBuildNames_a[0]},
                    'DioPort'        => {
                        'DioPort__KEY' => {'content' => $PortName1_s},
                        'DioRbHwPort'  => {'content' => $PortNum1_s},
                        'DioChannel'   => {
                            'DioChannel__KEY' => {'content' => GetSubName()},
                            'DioRbHwPin'      => {'content' => $DioRbHwPin},
                        },
                    },
                },
            },
            '/AUTOSAR_Dio/EcucModuleDefs'
        );
    }
    elsif ($Mode_s eq "DoCheck")
    {
        CheckResult(
            $ErrorMsg_pa,
            "# Multiple occurrence of DioChannel in a PostBuild configuration.*# DioChannel:        " . GetSubName(),
            1
        );
    }
}

sub HardwareResUsedMoreThanOnce
{
    my $Mode_s          = $_[0];
    my $ErrorMsg_pa     = $_[1];
    my $InfoMsg_pa      = $_[2];

    my $TestDesc        = "Test if double used hardware resource leads to warning (" . GetSubName() . ")";

    my $PortName_s      = "Port_94";
    my $PortNum_s       = 94;
    my $DioRbHwPin      = 15;

    print "  $TestDesc\n";

    if ($Mode_s eq "PushConfig")
    {
        conf_process::Push(
            "Dio",
            ["Dio"],
            {
                'Dio__KEY'  => {'content' => 'Dio'},
                'DioConfig' => {
                    'DioConfig__KEY' => {'content' => $PostBuildNames_a[0]},
                    'DioPort'        => {
                        'DioPort__KEY' => {'content' => $PortName_s},
                        'DioRbHwPort'  => {'content' => $PortNum_s},
                        'DioChannel'   => {
                            'DioChannel__KEY' => {'content' => GetSubName()},
                            'DioRbHwPin'      => {'content' => $DioRbHwPin},
                        },
                    },
                },
            },
            '/AUTOSAR_Dio/EcucModuleDefs'
        );
        conf_process::Push(
            "Dio",
            ["Dio"],
            {
                'Dio__KEY'  => {'content' => 'Dio'},
                'DioConfig' => {
                    'DioConfig__KEY' => {'content' => $PostBuildNames_a[0]},
                    'DioPort'        => {
                        'DioPort__KEY' => {'content' => $PortName_s},
                        'DioRbHwPort'  => {'content' => $PortNum_s},
                        'DioChannel'   => {
                            'DioChannel__KEY' => {'content' => GetSubName() . "_1"},
                            'DioRbHwPin'      => {'content' => $DioRbHwPin},
                        },
                    },
                },
            },
            '/AUTOSAR_Dio/EcucModuleDefs'
        );
    }
    elsif ($Mode_s eq "DoCheck")
    {
        CheckResult(
            $InfoMsg_pa,
            "# More than one signal is configured for one hardware resource.*# HardwareResUsedMoreThanOnce, HardwareResUsedMoreThanOnce_1",
            1
        );
    }
}

sub GetMcuMachineInfo
{
    my $InfoType   = $_[0];
    my $McuEcuc_ph = conf_process::Pop("Mcu");

    if (defined $McuEcuc_ph)
    {
        if($InfoType eq "MachineFam")
        {
            return $McuEcuc_ph->{'McuRbCpuInformation'}{'McuRbMachineFam'}{'content'};
        }
        elsif($InfoType eq "MachineType")
        {
            return $McuEcuc_ph->{'McuRbCpuInformation'}{'McuRbMachineType'}{'content'};
        }
        elsif($InfoType eq "MachineSubType")
        {
            return $McuEcuc_ph->{'McuRbCpuInformation'}{'McuRbMachineSubType'}{'content'};
        }
        else
        {
            conf_process::Exit("ERROR: Invalid parameter for GetMcuMachineInfo (valid ones are MachineFam, MachineType, MachineSubType)");
        }
    }
    else
    {
        conf_process::Exit("ERROR: Mcu Machine Type information not available");
    }
}

sub CheckResult
{
    my $ErrorMsg_pa             = $_[0];
    my $RexExp_s                = $_[1];
    my $ExpectedNumOfErrors     = $_[2];

    my $ErrCnt_s = 0;

    foreach my $ErrorMsg_s (@{$ErrorMsg_pa})
    {
        if($ErrorMsg_s =~ m/$RexExp_s/ms)
        {
            $ErrCnt_s++;
        }
    }

    if($ErrCnt_s == $ExpectedNumOfErrors)
    {
        print "    Passed found $ErrCnt_s Error/Info Message(s)\n";
    }
    else
    {
        print "    FAILED !!! (Expected Number of erros: $ExpectedNumOfErrors Occured Number: $ErrCnt_s )\n";
    }
}

sub GetSubName
{
    if ((caller(1))[3] =~ /.*::(.*)$/)
    {
        return $1;
    }
}

#----------------------------------------------------------------------------------------------------------------------
# Anonymous function required at the end of any Perl module
#----------------------------------------------------------------------------------------------------------------------
{
    1;
}
