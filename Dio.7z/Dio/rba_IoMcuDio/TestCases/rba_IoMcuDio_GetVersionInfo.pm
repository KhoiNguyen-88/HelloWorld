#// ----------------------------------------------------------------------------
#// COPYRIGHT RESERVED, 2012, Robert Bosch GmbH. All rights reserved.  The
#/ reproduction, distribution and utilization of this document as well as the
#// communication of its contents to others without explicit authorization is
#// prohibited.  Offenders will be held liable for the payment of damages.  All
#// rights reserved in the event of the grant of a patent, utility model or
#// design.
#// ----------------------------------------------------------------------------
#//! \file
#//! \brief
#//!
#//! $Source: T $
#//! $Author:  $
#//! $Revision:  $
#//! $Date: ST $
#//!
#//! User documentation: doc Folder
#// ----------------------------------------------------------------------------
#// History:
#// ---------------------------------------------------------------------------
#######################################################################

#######################################################################

package rba_IoMcuDio_GetVersionInfo;

#######################################################################

=head1 Test-Specification for rba_IoMcuDio

This is the test-specification as xml-describtion

<TestConfiguration>
 <TC_Id>rba_IoMcuDio_GetVersionInfo.pm</TC_Id>
 <TC_BL><BASDKey>$Variant___:$$Revision__:$</BASDKey></TC_BL>
 <TC_Spec></TC_Spec>
 <TC_EnvCond></TC_EnvCond>
 <TC_ExpRes></TC_ExpRes>
 <TestStep></TestStep>
 <TestMethod></TestMethod>
 <TestPrep></TestPrep>
 <TestType>automated</TestType>
 <Environment></Environment>
 <ResConsumption></ResConsumption>
 <CoveredReq_Id>
    BSW_SWS_rba_IoMcuDio-322,
    BSW_SWS_rba_IoMcuDio-709,
    BSW_SWS_rba_IoMcuDio-2720
 </CoveredReq_Id>
 <CoveredReq_Doc>BSW_SWS_MCAL_IoMcuDio_RBA</CoveredReq_Doc>
</TestConfiguration>

=cut

#######################################################################

use STEPS_general;
use STEPS_NET;
use STEPS_NET_Reports;
use STEPS_BSWITF;
use STEPS_BSWITF_BSW;
use STEPS_BSWITF_ECU;
use STEPS_BSWITF_Debugger;

use rba_IoMcuDio_TestLib; # library for own tests

#===============================================================================
# global variables
my $TestResult_s; # test result of the test case (result overall test steps)
my $ude_s = undef; # handle for accessing ude functionality

my $versionId_s;
my $moduleId_s;
my $testType_s;

# constants
use constant SERVICE_ID => 0x01;


sub TC_set_parameters
{
  # Here we can set initial parameters for the testcase_s
  $versionId_s = 6;
  $moduleId_s = 255;
  $TestResult_s = RESULT_PASSED;
  $ude_s = new UdeControl();
  return 1;
}

sub TC_initialization
{
  BSWITF_Init();    ### Initialisation of the BSWITF
  return 1;
}

sub TC_stimulation_and_measurement
{
    # variables containing describing text
    my $testStep_s;
    my $testStepDesc_s;
    my $testStepExpectedBehav_s;
    my $testStepResult_s;

    # variables containing values relevant for appraising the test step result
    my $BreakPointReached_s;
    my $testStepReturnValue_s;

    my $testcdStruct_s = $ude_s->getStructObject( "TestCd_rba_IoMcuDio_st" );
    my $testcase_s     = $ude_s->getStructComponent( $testcdStruct_s, "stTestcase_en" );
    my $versionInfo_s  = $ude_s->getStructComponent( $testcdStruct_s, "stVersionInfo_st" );
	my $TestCaseSelected_s = "TESTCD_MCUDIO_GET_VERSION_INFO";

    # Start of test steps
    ############################################################################
    $testStep_s              = "rba_IoMcuDio_GetVersionInfo test step 1";
    $testStepDesc_s          = "Call the GetVersionInfo function";
    $testStepExpectedBehav_s = "- Correct vendor id in return parameter\n" .
                               "- Correct module id in return parameter\n" .
                               "- Correct sw_major_version in return parameter\n" .
                               "- Correct sw_minor_version in return parameter\n" .
                               "- Correct sw_patch_version in return parameter";

	my $detReportEnabled_s = checkDetStatus($ude_s);
	if($detReportEnabled_s == 1)
	{
		$testStepExpectedBehav_s .= "\n- Call for Det_ReportError in the function is activated.";
	}
	else
	{
		$detReportEnabled_s = 0;
		$testStepExpectedBehav_s .= "\n- No call of Det_ReportError in the function.";
	}

	printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

	### Prepare test step execution
    $testStepResult_s = RESULT_PASSED;

    ### Execute test step
    if($detReportEnabled_s)
    {
        $BreakPointReached_s = execTestCaseEvalDetReportErrorBreakPoint( $ude_s, $TestCaseSelected_s, SERVICE_ID );
    }
	else
	{
       execTestCase( $ude_s, $TestCaseSelected_s );
	}

	### Evaluate test step result
    if( $ude_s->readEnumObject( $testcase_s )  eq  "TESTCD_MCUDIO_TEST_NOTTESTABLE_E" )
    {
        $testStepResult_s = RESULT_NOT_TESTABLE;

        printNotTestableReason(" RBA_IOMCUDIO_CFG_VERSION_INFO_API is not activated.");

	}
	else
    {
		if($detReportEnabled_s && $BreakPointReached_s)
        {
        	$testStepResult_s = RESULT_FAILED;
        	printFailedReason("Det_ReportError was called in the function.");
        }
		else
		{
			$testStepReturnValue_s = $ude_s->readStructComponentValue( $versionInfo_s, "vendorID" );
			if( $testStepReturnValue_s != $versionId_s )
			{
				$testStepResult_s = RESULT_FAILED;
				printFailedReason("Incorrect vendor ID, expected value: $versionId_s, test value: " . sprintf("%d.", $testStepReturnValue_s) );
			}

			$testStepReturnValue_s = $ude_s->readStructComponentValue( $versionInfo_s, "moduleID" );
			if( $testStepReturnValue_s != $moduleId_s )
			{
				$testStepResult_s = RESULT_FAILED;
				printFailedReason("Incorrect module ID, expected value: $moduleId_s , test value: " . sprintf("%d.", $testStepReturnValue_s));
			}

			$testStepReturnValue_s = $ude_s->readStructComponentValue( $versionInfo_s, "sw_major_version" );
			if( $testStepReturnValue_s != 3 )
			{
				$testStepResult_s = RESULT_FAILED;
				printFailedReason("Incorrect sw_major_version, expected value: 3, test value: " . sprintf("%d.", $testStepReturnValue_s));
			}

			$testStepReturnValue_s = $ude_s->readStructComponentValue( $versionInfo_s, "sw_minor_version" );
			if( $testStepReturnValue_s != 32 )
			{
				$testStepResult_s = RESULT_FAILED;
				printFailedReason("sw_minor_version, expected value: 30, test value: " . sprintf("%d.", $testStepReturnValue_s));
			}

			$testStepReturnValue_s = $ude_s->readStructComponentValue( $versionInfo_s, "sw_patch_version" );
			if( $testStepReturnValue_s != 0 )
			{
				$testStepResult_s = RESULT_FAILED;
				printFailedReason("Incorrect sw_patch_version, expected value: 0, test value: " . sprintf("%d.", $testStepReturnValue_s));
			}
		}
	}

    ### Result documentation
	if( RESULT_NOT_TESTABLE eq $testStepResult_s)
	{
		$TestResult_s = RESULT_NOT_TESTABLE;
    	printTestStepResult($testStepResult_s);
		return 1;
	}
    elsif( RESULT_FAILED eq $testStepResult_s )
    {
        $TestResult_s = RESULT_FAILED;
    }
    printTestStepResult($testStepResult_s);

   #---------------------------------------------------------------------------

	if($detReportEnabled_s)
    {
    	# Start of test steps 2
	    ############################################################################
	    $testStep_s              = "rba_IoMcuDio_GetVersionInfo test step 2";
	    $testStepDesc_s          = "Call the rba_IoMcuDio_GetVersionInfo function with NULL Pointer";
	    $testStepExpectedBehav_s = "- No Execution of GetVersionInfo function read with RBA_IOMCUDIO_E_PARAM_NULL DET Error.";
	    printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

	    ### Prepare test step execution
	    $testStepResult_s = RESULT_PASSED;
	    $TestCaseSelected_s = "TESTCD_MCUDIO_GET_VERSION_INFO_NULL";

	    ### Execute test step
	    $BreakPointReached_s = execTestCaseEvalDetReportErrorBreakPoint( $ude_s, $TestCaseSelected_s, SERVICE_ID, 0x05);

	    ### Evaluate test step result
	    if($BreakPointReached_s != 1)
	    {
	    	$testStepResult_s = RESULT_FAILED;
	    	$TestResult_s = RESULT_FAILED;
	        printFailedReason("Det_ReportError RBA_IOMCUDIO_E_PARAM_NULL was not called in the function.");
	    }

	    ### Result documentation
	    printTestStepResult($testStepResult_s);
	    #---------------------------------------------------------------------------
    }
    $ude_s->setEnumObject( $testcase_s, "TESTCD_DIO_IDLE" );
    return 1;
}


sub TC_evaluation
{
	evaluation_TestResult( $ude_s, $TestResult_s );
    return 1;
}

sub TC_finalization {
### exit the test environment

  # clear the handle to enable following test cases to have access to the ude
  undef($ude_s);

  BSWITF_Exit();
  return 1;
}

1;
