#!/usr/bin/perl
#----------------------------------------------------------------------------
# COPYRIGHT RESERVED, 2012, Robert Bosch GmbH. All rights reserved.  The
# reproduction, distribution and utilization of this document as well as the
# communication of its contents to others without explicit authorization is
# prohibited.  Offenders will be held liable for the payment of damages.  All
# rights reserved in the event of the grant of a patent, utility model or
# design.
#----------------------------------------------------------------------------
#//! \file
#//! \brief
#//!
#//! $Source: T $
#//! $Author:  $
#//! $Revision:  $
#//! $Date: ST $
#//!
#//! User documentation: doc Folder
#// ----------------------------------------------------------------------------
#// History:
#// ---------------------------------------------------------------------------
#######################################################################

#===============================================================================
package rba_IoMcuDio_TestLib;

#===============================================================================
use warnings;
use strict;
use UdeControl;

use STEPS_general;
use STEPS_NET;
use STEPS_NET_Reports;
use STEPS_BSWITF;
use STEPS_BSWITF_BSW;
use STEPS_BSWITF_ECU;
use STEPS_BSWITF_Debugger;

use feature qw/switch/;
use base qw(Exporter);
use vars qw(@EXPORT);

use constant AR_MODULE_ID => 255;

use constant RESULT_FAILED => 0;
use constant RESULT_PASSED => 1;
use constant RESULT_NOT_TESTABLE => 2;

@EXPORT = qw(RESULT_FAILED RESULT_PASSED RESULT_NOT_TESTABLE AR_MODULE_ID execTestCase execTestCaseEvalDetReportErrorBreakPoint printTestStepInfo printFailedReason printTestStepResult checkDetStatus printNotTestableReason evaluation_TestResult);

#===============================================================================
sub execTestCase
{
    my $ude_s = shift;
    my $testCaseName_s = shift;
    
    my $testcdStruct_s = $ude_s->getStructObject( "TestCd_rba_IoMcuDio_st" );
    my $testcase_s     = $ude_s->getStructComponent( $testcdStruct_s, "stTestcase_en" );
    
    #---------------------------------------------------------------------------
    # start test execution
    $ude_s->setEnumObject( $testcase_s, $testCaseName_s );

    #---------------------------------------------------------------------------
    # wait until test case has been finished
    my $timeoutCnt_s = 0;
    do {
        select(undef, undef, undef, 0.1); # sleep 100ms
        $timeoutCnt_s++;
        if( $timeoutCnt_s > 100 ) # 10s expired
        {
            $ude_s->udeDie("##ERROR execution of test step: timeout");
        }
    } while ( $ude_s->readEnumObject( $testcase_s )  eq  $testCaseName_s );
}

#===============================================================================

sub execTestCaseEvalDetReportErrorBreakPoint
{
	my $ude_s = shift;
    my $testCaseName_s = shift;
    my $serviceId_s = shift;
    my $errorId_s = shift;
    my $BreakPointHit_s = 0;
    
    my $testcdStruct_s = $ude_s->getStructObject( "TestCd_rba_IoMcuDio_st" );
	my $testcase_s     = $ude_s->getStructComponent( $testcdStruct_s, "stTestcase_en" );
	
	$ude_s->addBreakpoint( "Det_ReportError" );
    
    #---------------------------------------------------------------------------
    # start test execution
    print"\n *************    $testCaseName_s    ************   \n";
    $ude_s->setEnumObject( $testcase_s, $testCaseName_s );

    #---------------------------------------------------------------------------
    # wait until test case has been finished
    my $timeoutCnt_s = 0;
    do {
   	
		# evaluate breakpoint
    	if( !($ude_s->targetProgramIsRunning()) )
    	{
			# breakpoint hit
    		if( ($ude_s->readLocalVar( "ModuleId" ) == AR_MODULE_ID) && ($ude_s->readLocalVar( "ApiId" ) == $serviceId_s) ) 
    		{
				# check also the error id?
    			if( defined($errorId_s) )
    			{
					# DetReportError called with correct parameters
    				if( $ude_s->readLocalVar( "ErrorId" ) == $errorId_s)
    				{
    					$BreakPointHit_s = 1;
    				}
    			}
    			else
    			{
				
					# DetReportError called with correct parameters
    				$BreakPointHit_s = 2;
    			}
    			#print"\n module matched\n";
    			$ude_s->go();
    		}
    		else
    		{
			
    			$ude_s->go();
    		}
    	}
    	        
		select(undef, undef, undef, 0.1); # sleep 100ms
        $timeoutCnt_s++;
        if( $timeoutCnt_s > 100 ) # 10s expired
        {
            $ude_s->udeDie("##ERROR execution of test step: timeout");
        }
    } while ( $ude_s->readEnumObject( $testcase_s )  eq  $testCaseName_s );
    $ude_s->removeBreakpointsAll();
    $ude_s->go();
    return $BreakPointHit_s;
}
sub checkDetStatus
{
    my $ude_s = shift;
    
    my $testcdStruct_s = $ude_s->getStructObject( "TestCd_rba_IoMcuDio_st" );
    my $testcase_s  = $ude_s->getStructComponent( $testcdStruct_s, "stTestcase_en" );
    my $testCaseName_s = "TESTCD_MCUDIO_CHECK_DET_ENABLE";
    
    #---------------------------------------------------------------------------
    # start test execution
    $ude_s->setEnumObject( $testcase_s, $testCaseName_s );
    #---------------------------------------------------------------------------
    # wait until test case has been finished
    my $timeoutCnt_s = 0;
    do {
        select(undef, undef, undef, 0.1); # sleep 100ms
        $timeoutCnt_s++;
        if( $timeoutCnt_s > 100 ) # 10s expired
        {
            $ude_s->udeDie("##ERROR checkDetStatus execution of test step: timeout");
        }
    } while ( $ude_s->readEnumObject( $testcase_s )  eq  $testCaseName_s );
    
    my $detReportEnabled_s = $ude_s->readStructComponentValue( $testcdStruct_s, "isDetReportEnabled_b" );

    # remove all breakpoints, if breakpoint checking is later used
    S_w2log( 3, ( "#" x 80 ) . "\n", "black" );
    if($detReportEnabled_s)
    {
        $ude_s->removeBreakpointsAll();
        S_w2log( 3, "Test running with DET error report enabled." . "\n", "blue" );
    }
    else
    {
        S_w2log( 3, "Test running with DET error report disabled." . "\n", "blue" );
    }
    S_w2log( 3, ( "#" x 80 ) . "\n", "black" );
    S_w2log( 3, "\n", "black" );
	
    return $detReportEnabled_s;
}
sub printTestStepInfo
{
    my $testStep_s              = shift;
    my $testStepDesc_s          = shift;

    my $testStepExpectedBehav_s = shift;
    
    S_w2log(3, ("#" x 80) . "\n", "black");
    S_w2log(3, "<B>--- " . $testStep_s . " ---</B>\n", "black");
    S_w2log(3, "# <U>Test step description:</U>\n", "black");
    S_w2log(3, $testStepDesc_s . "\n", "black");
    S_w2log(3, "\n", "black");
    S_w2log(3, "# <U>Test step expected behaviour:</U>\n", "black");
    S_w2log(3, $testStepExpectedBehav_s . "\n", "black");
    S_w2log(3, "\n", "black");
    S_w2log(3, "# <U>Test step result:</U>\n", "black");
}


sub printFailedReason
{
    my $failedReason_s = shift;
    
    S_w2log(3, $failedReason_s . "\n", "red");
}

sub printNotTestableReason
{
	
    my $notTestableReason_s = shift;
    
    S_w2log(3, $notTestableReason_s . "\n", "mediumblue");
	
}


sub printTestStepResult
{
    my $testStepResultStatus_s = shift;
    
    my $color_s;
    my $text_s;
    
    given ($testStepResultStatus_s)
    {
        when(RESULT_FAILED)
        {
            $text_s = "<B>FAILED</B>";
            $color_s = "red";
        }
        when(RESULT_PASSED)
        {
            $text_s = "<B>PASSED</B>";
            $color_s = "green";
        }
        when(RESULT_NOT_TESTABLE)
        {
            $text_s = "<B>NOT TESTABLE</B> ";
            $color_s = "mediumblue";
        }
        default
        {
            $text_s = "<B>PARAMETER ERROR</B> ";
            $color_s = "cyan";
        }
    }
        
    S_w2log(3, "\n", "black");
    S_w2log(3, $text_s . "\n", $color_s);
    S_w2log(3, "\n", "black");
    S_w2log( 3, ( "#" x 80 ) . "\n", "black" );
    S_w2log(3, "\n", "black");
    S_w2log(3, "\n", "black");
}

sub evaluation_TestResult
{
    my $ude_s = shift;
    my $TestResult_s = shift;
    
    if( RESULT_PASSED == $TestResult_s ) 
    {
        S_w2log( 3, "Test Result: PASSED \n", "green" );
        S_set_verdict("VERDICT_PASS");
    }
    elsif( RESULT_FAILED == $TestResult_s )
    {
        S_w2log( 3, "\n Test Result: FAILED \n", "red" );
        S_set_verdict("VERDICT_FAIL");
    }
    elsif( RESULT_NOT_TESTABLE == $TestResult_s )
    {
    	S_w2log( 3, "\n Test Result: NOT TESTABLE, API not activated \n", "blue" );
        S_set_verdict("VERDICT_NONE");
    }
	else
	{
		$ude_s->udeDie("##ERROR invalid value of TestResult_s: $TestResult_s");
	}
}

#============================================================================EOF
1; # don't remove this statement
#============================================================================EOF

