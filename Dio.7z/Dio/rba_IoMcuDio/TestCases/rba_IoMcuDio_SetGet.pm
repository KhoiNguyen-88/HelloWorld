#// ----------------------------------------------------------------------------
#// COPYRIGHT RESERVED, 2012, Robert Bosch GmbH. All rights reserved.  The
#/ reproduction, distribution and utilization of this document as well as the
#// communication of its contents to others without explicit authorization is
#// prohibited.  Offenders will be held liable for the payment of damages.  All
#// rights reserved in the event of the grant of a patent, utility model or
#// design.
#// ----------------------------------------------------------------------------
#//! \file
#//! \brief
#//!
#//! $Source: T $
#//! $Author:  $
#//! $Revision:  $
#//! $Date: ST $
#//!
#//! User documentation: doc Folder
#// ----------------------------------------------------------------------------
#// History:
#// ---------------------------------------------------------------------------
#######################################################################

#######################################################################

package rba_IoMcuDio_SetGet;

#######################################################################

=head1 Test-Specification for rba_IoMcuDio

This is the test-specification as xml-describtion

<TestConfiguration>
 <TC_Id>rba_IoMcuDio_SetGet.pm</TC_Id>
 <TC_BL><BASDKey>$Variant___:$$Revision__:$</BASDKey></TC_BL>
 <TC_Spec></TC_Spec>
 <TC_EnvCond></TC_EnvCond>
 <TC_ExpRes></TC_ExpRes>
 <TestStep></TestStep>
 <TestMethod></TestMethod>
 <TestPrep></TestPrep>
 <TestType>automated</TestType>
 <Environment></Environment>
 <ResConsumption></ResConsumption>
 <CoveredReq_Id>
    BSW_SWS_rba_IoMcuDio-322,
    BSW_SWS_rba_IoMcuDio-447,
    BSW_SWS_rba_IoMcuDio-2570,
    BSW_SWS_rba_IoMcuDio-2720,
    BSW_SWS_rba_IoMcuDio-2721,
    BSW_SWS_rba_IoMcuDio-2733,
    BSW_SWS_rba_IoMcuDio-2760,
    BSW_SWS_rba_IoMcuDio-2765
  </CoveredReq_Id>
 <CoveredReq_Doc>BSW_SWS_MCAL_IoMcuDio_RBA</CoveredReq_Doc>
</TestConfiguration>

=cut

#######################################################################

use STEPS_general;
use STEPS_NET;
use STEPS_NET_Reports;
use STEPS_BSWITF;
use STEPS_BSWITF_BSW;
use STEPS_BSWITF_ECU;
use STEPS_BSWITF_Debugger;

use rba_IoMcuDio_TestLib; # library for own tests

#===============================================================================
# global variables
my $TestResult_s; # test result of the test case (result overall test steps)
my $ude_s = undef; # handle for accessing ude functionality

use constant SERVICE_ID_SET => 0x04;
use constant SERVICE_ID_GET => 0x03;

sub TC_set_parameters
{
  $TestResult_s = RESULT_PASSED;
  $ude_s = new UdeControl();
  return 1;
}

sub TC_initialization
{
  BSWITF_Init();    ### Initialisation of the BSWITF
  return 1;
}

sub TC_stimulation_and_measurement
{
    # variables containing describing text
    my $testStep_s;
    my $testStepDesc_s;
    my $testStepExpectedBehav_s;
    my $testStepResult_s;
    my $TestCaseSelected_s;

    my $testcdStruct_s = $ude_s->getStructObject( "TestCd_rba_IoMcuDio_st" );
    my $testcase_s     = $ude_s->getStructComponent( $testcdStruct_s, "stTestcase_en" );
	my $diolevel_s     = $ude_s->getStructComponent( $testcdStruct_s, "rba_IoMcuDio_LevelType_en" );
    my $dioread_s     = $ude_s->getStructComponent( $testcdStruct_s, "rba_IoMcuDio_Read_en" );

	my $itf_output = $ude_s->readVar("TestCd_rba_IoMcuDio_ITF_output_u8");
	my $read_result_s;
	my $BreakPointReached_s = 0;

	#--------------------------------------------------------------------------------------------------------------
    #TEST 1
	#WRITE the DIO CHANNEL with value 1 and read the result

	$testStep_s              = "Set the output channel HIGH and readback the result";
	$testStepDesc_s          = "Call the rba_IoMcuDio_Set function and make the output channel as HIGH, then read the level of output channel back by using the rba_IoMcuDio_Get function.";
	$testStepExpectedBehav_s = "physical level of the selected output channel should be 1.";
	printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

	$testStepResult_s = RESULT_PASSED;

    $ude_s->setStructComponentValue( $testcdStruct_s, "rba_IoMcuDio_PinType_u16", $itf_output );
	$ude_s->setEnumObject( $diolevel_s, "rba_IoSigDio_stActive_e" );


	$TestCaseSelected_s = "TESTCD_MCUDIO_WRITECHANNEL";
	execTestCase( $ude_s, $TestCaseSelected_s );

	$TestCaseSelected_s = "TESTCD_MCUDIO_READCHANNEL";
	execTestCase( $ude_s, $TestCaseSelected_s );

	$read_result_s = $ude_s->readEnumObject($dioread_s);

	if($read_result_s ne "rba_IoSigDio_stActive_e")
	{
		$testStepResult_s = RESULT_FAILED;
		printFailedReason("Incorrect level of output channel, expected value: 1, test valve: $read_result_s ");
	}

	if( RESULT_FAILED eq $testStepResult_s )
	{
		$TestResult_s = RESULT_FAILED;
	}
	printTestStepResult($testStepResult_s);

	#--------------------------------------------------------------------------------------------------------------
	#TEST 2
	#WRITE the DIO CHANNEL with value 0 and read the result
	$testStep_s              = "Set the output channel LOW and readback the result";
	$testStepDesc_s          = "Call the rba_IoMcuDio_Set function and make the output channel as LOW, then read the level of output channel back by using the rba_IoMcuDio_Get function.";
	$testStepExpectedBehav_s = "physical level of the selected output channel should be 0";
	printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

	### Prepare test step execution
	$testStepResult_s = RESULT_PASSED;

	$ude_s->setStructComponentValue( $testcdStruct_s, "rba_IoMcuDio_PinType_u16", $itf_output );
	$ude_s->setEnumObject( $diolevel_s, "rba_IoSigDio_stIdle_e" );


	$TestCaseSelected_s = "TESTCD_MCUDIO_WRITECHANNEL";
	execTestCase( $ude_s, $TestCaseSelected_s );

	$TestCaseSelected_s = "TESTCD_MCUDIO_READCHANNEL";
	execTestCase( $ude_s, $TestCaseSelected_s );

	$read_result_s = $ude_s->readEnumObject( $dioread_s);

	if($read_result_s ne "rba_IoSigDio_stIdle_e")
	{
		$testStepResult_s = RESULT_FAILED;
		printFailedReason("Incorrect level of output channel, expected value: 0, test valve: $read_result_s ");
	}

	if( RESULT_FAILED eq $testStepResult_s )
	{
		$TestResult_s = RESULT_FAILED;
	}
	printTestStepResult($testStepResult_s);

	#DET Check
    #----------------------------------------------------------------------------------------------------------------------------------------------------------------------

	my $detReportEnabled_s = checkDetStatus($ude_s);
	if($detReportEnabled_s == 1)
	{
		$testStepExpectedBehav_s .= "\n- Call for Det_ReportError in the function is activated.";
	}
	else
	{
		$detReportEnabled_s = 0;
		$testStepExpectedBehav_s .= "\n- No call of Det_ReportError in the function.";
	}

	#----------------------------------------------------------------------------------------------------------------------------------------------------------------------

		### Prepare test step execution
		$testStepResult_s = RESULT_PASSED;

		$testStep_s              = "DET error check for rba_IoMcuDio_Set function";
		$testStepDesc_s          = "Call the rba_IoMcuDio_Set function with invalid signal level";
		$testStepExpectedBehav_s = "Function should return E_NOT_OK and DET error should be reported if enabled";
		printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

		$TestCaseSelected_s = "TESTCD_MCUDIO_WRITECHANNEL_DET";
		$ude_s->setStructComponentValue( $testcdStruct_s, "rba_IoMcuDio_PinType_u16", $itf_output );

		$ude_s->setVar("TestCd_rba_IoMcuDio_SetDetVar_en", 0x06);       # passing invalid signal level (allowed are 0 and 1).

			if($detReportEnabled_s)
			{
				$BreakPointReached_s = execTestCaseEvalDetReportErrorBreakPoint( $ude_s, $TestCaseSelected_s, SERVICE_ID_SET, 0x04 );

				if( ($BreakPointReached_s != 1) || ($ude_s->readVar("TestCd_rba_IoMcuDio_retval_u8") != 1) )    # E_OK -> 0x00, E_NOT_OK -> 0x01
				{
					$testStepResult_s = RESULT_FAILED;
					printFailedReason("Det_ReportError function is not called");
				}

				### Result documentation
				if( RESULT_FAILED eq $testStepResult_s )
				{
					$TestResult_s = RESULT_FAILED;
				}
				printTestStepResult($testStepResult_s);
			}

			else
			{
				execTestCase( $ude_s, $TestCaseSelected_s );
				if($ude_s->readVar("TestCd_rba_IoMcuDio_retval_u8") != 1)             # E_OK -> 0x00, E_NOT_OK -> 0x01
				{
					$testStepResult_s = RESULT_FAILED;
					printFailedReason("Function return value is wrong");
				}

				### Result documentation
				if( RESULT_FAILED eq $testStepResult_s )
				{
					$TestResult_s = RESULT_FAILED;
				}
				printTestStepResult($testStepResult_s);
			}

	#--------------------------------------------------------------------------------------------------------------

		### Prepare test step execution
		$testStepResult_s = RESULT_PASSED;

		$testStep_s              = "DET error check for rba_IoMcuDio_Get function";
		$testStepDesc_s          = "Call the rba_IoMcuDio_Get function with Null pointer as an argument for storing the level";
		$testStepExpectedBehav_s = "Function should return E_NOT_OK and DET error should be reported if enabled";
		printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

		$TestCaseSelected_s = "TESTCD_MCUDIO_READCHANNEL_DET";
		$ude_s->setStructComponentValue( $testcdStruct_s, "rba_IoMcuDio_PinType_u16", $itf_output );

		$ude_s->setVar("TestCd_rba_IoMcuDio_GetDetVar_ptr_en", 0x00);       # Null Pointer

		if($detReportEnabled_s)
		{
			$BreakPointReached_s = execTestCaseEvalDetReportErrorBreakPoint( $ude_s, $TestCaseSelected_s, SERVICE_ID_GET, 0x05 );

			if( ($BreakPointReached_s != 1) || ($ude_s->readVar("TestCd_rba_IoMcuDio_retval_u8") != 1) )    # E_OK -> 0x00, E_NOT_OK -> 0x01
			{
				$testStepResult_s = RESULT_FAILED;
				printFailedReason("Det_ReportError function is not called");
			}

			### Result documentation
			if( RESULT_FAILED eq $testStepResult_s )
			{
				$TestResult_s = RESULT_FAILED;
			}
			printTestStepResult($testStepResult_s);
		}

		else
		{
			execTestCase( $ude_s, $TestCaseSelected_s );
			if($ude_s->readVar("TestCd_rba_IoMcuDio_retval_u8") != 1)             # E_OK -> 0x00, E_NOT_OK -> 0x01
			{
				$testStepResult_s = RESULT_FAILED;
				printFailedReason("Function return value is wrong");
			}

			### Result documentation
			if( RESULT_FAILED eq $testStepResult_s )
			{
				$TestResult_s = RESULT_FAILED;
			}
			printTestStepResult($testStepResult_s);
		}

}


sub TC_evaluation
{
    evaluation_TestResult( $ude_s, $TestResult_s );
    return 1;
}

sub TC_finalization
{
### exit the test environment

  # clear the handle to enable following test cases to have access to the ude
  undef($ude_s);

  BSWITF_Exit();
  return 1;
}

1;
