#// ----------------------------------------------------------------------------
#// COPYRIGHT RESERVED, 2012, Robert Bosch GmbH. All rights reserved.  The
#/ reproduction, distribution and utilization of this document as well as the
#// communication of its contents to others without explicit authorization is
#// prohibited.  Offenders will be held liable for the payment of damages.  All
#// rights reserved in the event of the grant of a patent, utility model or
#// design.
#// ----------------------------------------------------------------------------
#//! \file
#//! \brief
#//!
#//! $Source: T $
#//! $Author:  $
#//! $Revision:  $
#//! $Date: ST $
#//!
#//! User documentation: doc Folder
#// ----------------------------------------------------------------------------
#// History:
#// ---------------------------------------------------------------------------
#######################################################################

#######################################################################

package rba_IoMcuDio_SetDir;

#######################################################################

=head1 Test-Specification for rba_IoMcuDio

This is the test-specification as xml-describtion

<TestConfiguration>
 <TC_Id>rba_IoMcuDio_SetDir.pm</TC_Id>
 <TC_BL><BASDKey>$Variant___:$$Revision__:$</BASDKey></TC_BL>
 <TC_Spec></TC_Spec>
 <TC_EnvCond></TC_EnvCond>
 <TC_ExpRes></TC_ExpRes>
 <TestStep></TestStep>
 <TestMethod></TestMethod>
 <TestPrep></TestPrep>
 <TestType>automated</TestType>
 <Environment></Environment>
 <ResConsumption></ResConsumption>
 <CoveredReq_Id>
    BSW_SWS_rba_IoMcuDio-322,
    BSW_SWS_rba_IoMcuDio-447,
    BSW_SWS_rba_IoMcuDio-2570,
    BSW_SWS_rba_IoMcuDio-2720,
    BSW_SWS_rba_IoMcuDio-2721,
    BSW_SWS_rba_IoMcuDio-2733,
    BSW_SWS_rba_IoMcuDio-2763
 </CoveredReq_Id>
 <CoveredReq_Doc>BSW_SWS_MCAL_IoMcuDio_RBA</CoveredReq_Doc>
</TestConfiguration>

=cut

#######################################################################

use STEPS_general;
use STEPS_NET;
use STEPS_NET_Reports;
use STEPS_BSWITF;
use STEPS_BSWITF_BSW;
use STEPS_BSWITF_ECU;
use STEPS_BSWITF_Debugger;

use strict;
use warnings;
use rba_IoMcuDio_TestLib; # library for own tests

# global variables
my $TestResult_s; # test result of the test case (result overall test steps)
my $ude_s = undef; # handle for accessing ude functionality

# constants
use constant SERVICE_ID_SETDIR => 0x06;
use constant E_PARAM_SIGNAL => 0x02;
use constant E_PARAM_DIRECTION => 0x03;
use constant E_PORT_PIN_ID_UNKNOWN => 0x06;


sub TC_set_parameters
{
  # Here we can set initial parameters for the testcase_s
  $TestResult_s = RESULT_PASSED;
  $ude_s = new UdeControl();

  return 1;
}

sub TC_initialization
{
  BSWITF_Init();    ### Initialisation of the BSWITF
  return 1;
}

sub TC_stimulation_and_measurement
{
	# variables containing describing text
	my $testStep_s;
	my $testStepDesc_s;
	my $testStepExpectedBehav_s;
	my $testStepResult_s;
	my $detReportEnabled_s;
	my $read_result_s;
	my $TestCaseSelected_s;

	# variables containing values relevant for appraising the test step result
    my $BreakPointReached_s = 0;
	my $itf_output = $ude_s->readVar("TestCd_rba_IoMcuDio_ITF_output_u8");
	my $itf_input = $ude_s->readVar("TestCd_rba_IoMcuDio_ITF_input_u8");
	my $itf_numsignals = $ude_s->readVar("TestCd_rba_IoMcuDio_ITF_num_signals_u8");
	my $itf_unknown_signal = $ude_s->readVar("TestCd_rba_IoMcuDio_ITF_unkonwn_ID_signal_u8");

   	my $testcdStruct_s = $ude_s->getStructObject( "TestCd_rba_IoMcuDio_st" );
	my $testcase_s     = $ude_s->getStructComponent( $testcdStruct_s, "stTestcase_en" );
	my $diolevel_s     = $ude_s->getStructComponent( $testcdStruct_s, "rba_IoMcuDio_LevelType_en" );
	my $dioread_s     = $ude_s->getStructComponent( $testcdStruct_s, "rba_IoMcuDio_Read_en" );
	my $diodir_s     = $ude_s->getStructComponent( $testcdStruct_s, "rba_IoMcuDio_Dir_en" );

	#Test 1
    #-------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	$ude_s->setStructComponentValue( $testcdStruct_s, "rba_IoMcuDio_PinType_u16", $itf_input );    # input signal is selected
   	$ude_s->setEnumObject( $diodir_s, "rba_IoSigDio_stDirectionOut_e" );
	$TestCaseSelected_s = "TESTCD_MCUDIO_SETDIRECTION";
	$testStepResult_s = RESULT_PASSED;

	$testStep_s              = "rba_IoMcuDio_SetDir function test";
	$testStepDesc_s          = "Change the direction of Input signal as OUTPUT";
	$testStepExpectedBehav_s = "Function should return E_OK and direction should be changed to output";
	printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

	execTestCase( $ude_s, $TestCaseSelected_s );
	if($ude_s->readVar("TestCd_rba_IoMcuDio_retval_u8") != 0)             # E_OK -> 0x00, E_NOT_OK -> 0x01
	{
		$testStepResult_s = RESULT_FAILED;
		printFailedReason("Function return value is wrong");
	}
	else
	{
        $ude_s->setStructComponentValue( $testcdStruct_s, "rba_IoMcuDio_PinType_u16", $itf_output );    # output signal is selected
		$ude_s->setEnumObject( $diolevel_s, "rba_IoSigDio_stActive_e" );
		$TestCaseSelected_s = "TESTCD_MCUDIO_WRITECHANNEL";
		execTestCase( $ude_s, $TestCaseSelected_s );
		$TestCaseSelected_s = "TESTCD_MCUDIO_READCHANNEL";
		execTestCase( $ude_s, $TestCaseSelected_s );
		$read_result_s = $ude_s->readEnumObject($dioread_s);
		if($read_result_s ne "rba_IoSigDio_stActive_e")
		{
			$testStepResult_s = RESULT_FAILED;
			printFailedReason("Direction is not set to output because pin output is not set to Active");
		}
		else
		{
			$ude_s->setEnumObject( $diolevel_s, "rba_IoSigDio_stIdle_e" );
			$TestCaseSelected_s = "TESTCD_MCUDIO_WRITECHANNEL";
			execTestCase( $ude_s, $TestCaseSelected_s );
			$TestCaseSelected_s = "TESTCD_MCUDIO_READCHANNEL";
			execTestCase( $ude_s, $TestCaseSelected_s );
			$read_result_s = $ude_s->readEnumObject($dioread_s);
			if($read_result_s ne "rba_IoSigDio_stIdle_e")
			{
				$testStepResult_s = RESULT_FAILED;
				printFailedReason("Direction is not set to output because pin output is not set to Idle");
			}
			else
			{
				#change the direction back to Input
			   	$ude_s->setEnumObject( $diodir_s, "rba_IoSigDio_stDirectionIn_e" );
				$TestCaseSelected_s = "TESTCD_MCUDIO_SETDIRECTION";
				execTestCase( $ude_s, $TestCaseSelected_s );
			}
		}
	}
	### Result documentation
	if( RESULT_FAILED eq $testStepResult_s )
	{
		$TestResult_s = RESULT_FAILED;
	}
	printTestStepResult($testStepResult_s);

	#Test 2
    # ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

	$ude_s->setStructComponentValue( $testcdStruct_s, "rba_IoMcuDio_PinType_u16", $itf_output);    # ouput signal is selected
   	$ude_s->setEnumObject( $diodir_s, "rba_IoSigDio_stDirectionIn_e" );
	$TestCaseSelected_s = "TESTCD_MCUDIO_SETDIRECTION";
	$testStepResult_s = RESULT_PASSED;

	$testStep_s              = "rba_IoMcuDio_SetDir function test";
	$testStepDesc_s          = "Change the direction of Output signal as INPUT";
	$testStepExpectedBehav_s = "Function should return E_OK and direction should be changed to input";
	printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

	execTestCase( $ude_s, $TestCaseSelected_s );

	if($ude_s->readVar("TestCd_rba_IoMcuDio_retval_u8") != 0)             # E_OK -> 0x00, E_NOT_OK -> 0x01
	{
		$testStepResult_s = RESULT_FAILED;
		printFailedReason("Function return value is wrong");
	}
	else
	{
		$TestCaseSelected_s = "TESTCD_MCUDIO_READCHANNEL";
		execTestCase( $ude_s, $TestCaseSelected_s );
		$read_result_s = $ude_s->readEnumObject($dioread_s);
		if($read_result_s eq "rba_IoSigDio_stActive_e")
		{
			$ude_s->setEnumObject( $diolevel_s, "rba_IoSigDio_stIdle_e" );
		}
		else
		{
			$ude_s->setEnumObject( $diolevel_s, "rba_IoSigDio_stActive_e" );
		}

		$TestCaseSelected_s = "TESTCD_MCUDIO_WRITECHANNEL";
		execTestCase( $ude_s, $TestCaseSelected_s );
		$TestCaseSelected_s = "TESTCD_MCUDIO_READCHANNEL";
		execTestCase( $ude_s, $TestCaseSelected_s );
		$read_result_s = $ude_s->readEnumObject($dioread_s);
		if($read_result_s eq $diolevel_s)
		{
			$testStepResult_s = RESULT_FAILED;
			printFailedReason("Direction is not set to input because pin output is changed with rba_IoMcuDio_Set function");
		}
		else
		{
			#change the direction back to Output
		   	$ude_s->setEnumObject( $diodir_s, "rba_IoSigDio_stDirectionOut_e" );
			$TestCaseSelected_s = "TESTCD_MCUDIO_SETDIRECTION";
			execTestCase( $ude_s, $TestCaseSelected_s );
		}
	}
	### Result documentation
	if( RESULT_FAILED eq $testStepResult_s )
	{
		$TestResult_s = RESULT_FAILED;
	}
	printTestStepResult($testStepResult_s);

	#DET Check
    #----------------------------------------------------------------------------------------------------------------------------------------------------------------------

	$detReportEnabled_s = checkDetStatus($ude_s);
	if($detReportEnabled_s == 1)
	{
		$testStepExpectedBehav_s .= "\n- Call for Det_ReportError in the function is activated.";
	}
	else
	{
		$detReportEnabled_s = 0;
		$testStepExpectedBehav_s .= "\n- No call of Det_ReportError in the function.";
	}

	#Test 3
    #----------------------------------------------------------------------------------------------------------------------------------------------------------------------

	$testStep_s              = "rba_IoMcuDio_SetDir function test";
	$testStepDesc_s          = "Call rba_IoMcuDio_SetDir function with invalid signal number";
	$testStepExpectedBehav_s = "Function should return E_NOT_OK and DET error should be reported if enabled";
	printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

	$TestCaseSelected_s = "TESTCD_MCUDIO_SETDIRECTION";
	$testStepResult_s = RESULT_PASSED;

	$ude_s->setStructComponentValue( $testcdStruct_s, "rba_IoMcuDio_PinType_u16", $itf_numsignals );    # invalid signal number is passed
	#$ude_s->setEnumObject( $diodir_s, "rba_IoSigDio_stDirectionIn_e" );
	$ude_s->setVar("TestCd_rba_IoMcuDio_SetDirDetVar_en", 0x00);

	if( $detReportEnabled_s == 1 )
	{
		$BreakPointReached_s = execTestCaseEvalDetReportErrorBreakPoint( $ude_s, $TestCaseSelected_s, SERVICE_ID_SETDIR, E_PARAM_SIGNAL );

		if( ($BreakPointReached_s != 1) || ($ude_s->readVar("TestCd_rba_IoMcuDio_retval_u8") != 1) )    # E_OK -> 0x00, E_NOT_OK -> 0x01
		{
			$testStepResult_s = RESULT_FAILED;
			printFailedReason("Det_ReportError function is not called");
		}

		### Result documentation
		if( RESULT_FAILED eq $testStepResult_s )
		{
			$TestResult_s = RESULT_FAILED;
		}
		printTestStepResult($testStepResult_s);
	}

	else
	{
		execTestCase( $ude_s, $TestCaseSelected_s );
		if($ude_s->readVar("TestCd_rba_IoMcuDio_retval_u8") != 1)             # E_OK -> 0x00, E_NOT_OK -> 0x01
		{
			$testStepResult_s = RESULT_FAILED;
			printFailedReason("Function return value is wrong");
		}

		### Result documentation
		if( RESULT_FAILED eq $testStepResult_s )
		{
			$TestResult_s = RESULT_FAILED;
		}
		printTestStepResult($testStepResult_s);
	}

	#Test 4
    #-------------------------------------------------------------------------------------------------------------------------------------------------------------------

	$TestCaseSelected_s = "TESTCD_MCUDIO_SETDIRECTION_DET";
	$testStepResult_s = RESULT_PASSED;

	$testStep_s              = "rba_IoMcuDio_SetDir function test";
	$testStepDesc_s          = "Call rba_IoMcuDio_SetDir function with invalid direction";
	$testStepExpectedBehav_s = "Function should return E_NOT_OK and DET error should be reported if enabled";
	printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

	$ude_s->setStructComponentValue( $testcdStruct_s, "rba_IoMcuDio_PinType_u16", $itf_input );    # input signal is selected
    $ude_s->setVar("TestCd_rba_IoMcuDio_SetDirDetVar_en", 0x06);       # passing invalid direction (allowed are 0 and 1).

	if( $detReportEnabled_s == 1 )
	{
		$BreakPointReached_s = execTestCaseEvalDetReportErrorBreakPoint( $ude_s, $TestCaseSelected_s, SERVICE_ID_SETDIR, E_PARAM_DIRECTION );

		if( ($BreakPointReached_s != 1) || ($ude_s->readVar("TestCd_rba_IoMcuDio_retval_u8") != 1) )    # E_OK -> 0x00, E_NOT_OK -> 0x01
		{
			$testStepResult_s = RESULT_FAILED;
			printFailedReason("Det_ReportError function is not called");
		}

		### Result documentation
		if( RESULT_FAILED eq $testStepResult_s )
		{
			$TestResult_s = RESULT_FAILED;
		}
		printTestStepResult($testStepResult_s);
	}

	else
	{
		execTestCase( $ude_s, $TestCaseSelected_s );
		if($ude_s->readVar("TestCd_rba_IoMcuDio_retval_u8") != 1)             # E_OK -> 0x00, E_NOT_OK -> 0x01
		{
			$testStepResult_s = RESULT_FAILED;
			printFailedReason("Function return value is wrong");
		}

		### Result documentation
		if( RESULT_FAILED eq $testStepResult_s )
		{
			$TestResult_s = RESULT_FAILED;
		}
		printTestStepResult($testStepResult_s);
	}

	#Test 5
    #-------------------------------------------------------------------------------------------------------------------------------------------------------------------

	$TestCaseSelected_s = "TESTCD_MCUDIO_SETDIRECTION_DET";
	$testStepResult_s = RESULT_PASSED;

	$ude_s->setStructComponentValue( $testcdStruct_s, "rba_IoMcuDio_PinType_u16", $itf_unknown_signal );    # signal with unknown pin ID is selected
    $ude_s->setVar("TestCd_rba_IoMcuDio_SetDirDetVar_en", 0x00);

	$testStep_s              = "rba_IoMcuDio_SetDir function test";
	$testStepDesc_s          = "Call rba_IoMcuDio_SetDir function with signal with unknown pin ID";
	$testStepExpectedBehav_s = "Function should return E_NOT_OK and DET error should be reported if enabled";
	printTestStepInfo($testStep_s, $testStepDesc_s, $testStepExpectedBehav_s);

	if( $detReportEnabled_s == 1 )
	{
		$BreakPointReached_s = execTestCaseEvalDetReportErrorBreakPoint( $ude_s, $TestCaseSelected_s, SERVICE_ID_SETDIR, E_PORT_PIN_ID_UNKNOWN );

		if( ($BreakPointReached_s != 1) || ($ude_s->readVar("TestCd_rba_IoMcuDio_retval_u8") != 1) )    # E_OK -> 0x00, E_NOT_OK -> 0x01
		{
			$testStepResult_s = RESULT_FAILED;
			printFailedReason("Det_ReportError function is not called");
		}

		### Result documentation
		if( RESULT_FAILED eq $testStepResult_s )
		{
			$TestResult_s = RESULT_FAILED;
		}
		printTestStepResult($testStepResult_s);
	}

	else
	{
		execTestCase( $ude_s, $TestCaseSelected_s );
		if($ude_s->readVar("TestCd_rba_IoMcuDio_retval_u8") != 1)             # E_OK -> 0x00, E_NOT_OK -> 0x01
		{
			$testStepResult_s = RESULT_FAILED;
			printFailedReason("Function return value is wrong");
		}

		### Result documentation
		if( RESULT_FAILED eq $testStepResult_s )
		{
			$TestResult_s = RESULT_FAILED;
		}
		printTestStepResult($testStepResult_s);
	}

	return 1;
}

sub TC_evaluation
{
	evaluation_TestResult( $ude_s, $TestResult_s );
    return 1;
}

sub TC_finalization
{
### exit the test environment

  # clear the handle to enable following test cases to have access to the ude
  undef($ude_s);

  BSWITF_Exit();
  return 1;
}

1;
