/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, 2010 Robert Bosch GmbH. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:$
 * $Namespace_:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 **********************************************************************************************************************
</BASDKey>*/

#include "TestCd_rba_IoMcuDio_ITF.h"
#include "Mcu.h"

TestCd_rba_IoMcuDio_tst TestCd_rba_IoMcuDio_st;
Std_ReturnType TestCd_rba_IoMcuDio_retval_u8;
rba_IoSigDio_stSignal_ten TestCd_rba_IoMcuDio_SetDetVar_en;
rba_IoSigDio_stDirection_ten TestCd_rba_IoMcuDio_SetDirDetVar_en;
rba_IoSigDio_stSignal_ten *TestCd_rba_IoMcuDio_GetDetVar_ptr_en;
volatile uint8 TestCd_rba_IoMcuDio_ITF_num_signals_u8 = RBA_IOMCUDIO_NR_OF_DIO_CHANNELS;
volatile uint8 TestCd_rba_IoMcuDio_ITF_input_u8  = rba_IoMcuDioConf_rba_IoMcuDio_SignalDio_ITF_DIO_Input;
volatile uint8 TestCd_rba_IoMcuDio_ITF_output_u8 = rba_IoMcuDioConf_rba_IoMcuDio_SignalDio_ITF_DIO_Output;
volatile uint8 TestCd_rba_IoMcuDio_ITF_unkonwn_ID_signal_u8 = DioConf_DioChannel_ITF_unknown;

void TestCd_rba_IoMcuDio_Itf_10ms(void)
{
    // Dummy reads (and volatile declaration) are needed to prevent Tasking compiler form removing unused variables
    (void)TestCd_rba_IoMcuDio_ITF_num_signals_u8;
    (void)TestCd_rba_IoMcuDio_ITF_input_u8;
    (void)TestCd_rba_IoMcuDio_ITF_output_u8;
    (void)TestCd_rba_IoMcuDio_ITF_unkonwn_ID_signal_u8;

    switch( TestCd_rba_IoMcuDio_st.stTestcase_en )
        {

            case TESTCD_MCUDIO_CHECK_DET_ENABLE:
			{
				TestCd_rba_IoMcuDio_st.isDetReportEnabled_b = FALSE;
					#if( RBA_IOMCUDIO_CFG_DEV_ERROR_DETECT == STD_ON )
                TestCd_rba_IoMcuDio_st.isDetReportEnabled_b = TRUE;
					#endif
                TestCd_rba_IoMcuDio_st.stTestcase_en = TESTCD_MCUDIO_TEST_PASSED;
			}
			break;

            case TESTCD_MCUDIO_GET_VERSION_INFO:
            {
                #if ( RBA_IOMCUDIO_CFG_VERSION_INFO_API == STD_ON )
                    rba_IoMcuDio_GetVersionInfo( &(TestCd_rba_IoMcuDio_st.stVersionInfo_st) );
                    TestCd_rba_IoMcuDio_st.retVal_b      = TRUE;
                    TestCd_rba_IoMcuDio_st.stTestcase_en = TESTCD_MCUDIO_TEST_PASSED;
                #else
                    TestCd_rba_IoMcuDio_st.stTestcase_en = TESTCD_MCUDIO_TEST_NOTTESTABLE_E;
                #endif
            }
            break;

			case TESTCD_MCUDIO_GET_VERSION_INFO_NULL:
            {
                #if ( RBA_IOMCUDIO_CFG_VERSION_INFO_API == STD_ON )
                    rba_IoMcuDio_GetVersionInfo((void*)0);
                    TestCd_rba_IoMcuDio_st.stTestcase_en = TESTCD_MCUDIO_TEST_PASSED;
                #else
                    TestCd_rba_IoMcuDio_st.stTestcase_en = TESTCD_MCUDIO_TEST_NOTTESTABLE_E;
                #endif
            }
            break;

            case TESTCD_MCUDIO_WRITECHANNEL:
            {
                TestCd_rba_IoMcuDio_retval_u8 = rba_IoMcuDio_Set(TestCd_rba_IoMcuDio_st.rba_IoMcuDio_PinType_u16, TestCd_rba_IoMcuDio_st.rba_IoMcuDio_LevelType_en);
                TestCd_rba_IoMcuDio_st.stTestcase_en = TESTCD_MCUDIO_TEST_PASSED;

            }
			break;


            case TESTCD_MCUDIO_READCHANNEL:
            {
                TestCd_rba_IoMcuDio_retval_u8 = rba_IoMcuDio_Get(TestCd_rba_IoMcuDio_st.rba_IoMcuDio_PinType_u16, &(TestCd_rba_IoMcuDio_st.rba_IoMcuDio_Read_en));
                TestCd_rba_IoMcuDio_st.stTestcase_en = TESTCD_MCUDIO_TEST_PASSED;

            }
			break;

            case TESTCD_MCUDIO_SETDIRECTION:
			{
                TestCd_rba_IoMcuDio_retval_u8 = rba_IoMcuDio_SetDir(TestCd_rba_IoMcuDio_st.rba_IoMcuDio_PinType_u16, TestCd_rba_IoMcuDio_st.rba_IoMcuDio_Dir_en);
                TestCd_rba_IoMcuDio_st.stTestcase_en = TESTCD_MCUDIO_TEST_PASSED;

            }
			break;

            case TESTCD_MCUDIO_SWITCHOFF:
			{
                TestCd_rba_IoMcuDio_retval_u8 = rba_IoMcuDio_SwitchOff(TestCd_rba_IoMcuDio_st.rba_IoMcuDio_PinType_u16);
                TestCd_rba_IoMcuDio_st.stTestcase_en = TESTCD_MCUDIO_TEST_PASSED;

			}
			break;

            case TESTCD_MCUDIO_READCHANNEL_DET:
            {

                TestCd_rba_IoMcuDio_retval_u8 = rba_IoMcuDio_Get(TestCd_rba_IoMcuDio_st.rba_IoMcuDio_PinType_u16, TestCd_rba_IoMcuDio_GetDetVar_ptr_en);
                TestCd_rba_IoMcuDio_st.stTestcase_en = TESTCD_MCUDIO_TEST_PASSED;

            }
            break;

            case TESTCD_MCUDIO_WRITECHANNEL_DET:
            {
                TestCd_rba_IoMcuDio_retval_u8 = rba_IoMcuDio_Set(TestCd_rba_IoMcuDio_st.rba_IoMcuDio_PinType_u16, TestCd_rba_IoMcuDio_SetDetVar_en);
                TestCd_rba_IoMcuDio_st.stTestcase_en = TESTCD_MCUDIO_TEST_PASSED;

            }
            break;

            case TESTCD_MCUDIO_SETDIRECTION_DET:
            {
                TestCd_rba_IoMcuDio_retval_u8 = rba_IoMcuDio_SetDir(TestCd_rba_IoMcuDio_st.rba_IoMcuDio_PinType_u16, TestCd_rba_IoMcuDio_SetDirDetVar_en);
                TestCd_rba_IoMcuDio_st.stTestcase_en = TESTCD_MCUDIO_TEST_PASSED;

            }
            break;

			case TESTCD_MCUDIO_IDLE:
			{
				// nothing to do
			}
			break;

			case TESTCD_MCUDIO_TEST_DONE:
			{
				// nothing to do
			}
			break;


			case TESTCD_MCUDIO_TEST_PASSED:
			{
				// nothing to do
			}
			break;


			case TESTCD_MCUDIO_TEST_FAILED:
			{
				// nothing to do
			}
			break;


			case TESTCD_MCUDIO_TEST_NOTTESTABLE_E:
			{
				// nothing to do
			}
			break;

            case TESTCD_MCUDIO_UNDEFINED:
            {
                // nothing to do
            }
			break;

			default:
			{
				TestCd_rba_IoMcuDio_st.stTestcase_en = TESTCD_MCUDIO_UNDEFINED;
			}
			break;
        }

}
