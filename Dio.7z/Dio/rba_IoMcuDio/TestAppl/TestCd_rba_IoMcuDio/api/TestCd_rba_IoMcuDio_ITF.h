/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, 2010 Robert Bosch GmbH. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:$
 * $Namespace_:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 **********************************************************************************************************************
</BASDKey>*/

#ifndef TESTCD_RBA_IOMCUDIO_ITF_H
#define TESTCD_RBA_IOMCUDIO_ITF_H
#include "rba_BswSrv.h"
#include "rba_IoMcuDio.h"

typedef enum
{
	TESTCD_MCUDIO_IDLE=0,
	TESTCD_MCUDIO_CHECK_DET_ENABLE,
    TESTCD_MCUDIO_GET_VERSION_INFO,
    TESTCD_MCUDIO_GET_VERSION_INFO_NULL,
	TESTCD_MCUDIO_WRITECHANNEL,
    TESTCD_MCUDIO_READCHANNEL,
	TESTCD_MCUDIO_SETDIRECTION,
	TESTCD_MCUDIO_SWITCHOFF,
	TESTCD_MCUDIO_READCHANNEL_DET,
	TESTCD_MCUDIO_WRITECHANNEL_DET,
	TESTCD_MCUDIO_SETDIRECTION_DET,
	TESTCD_MCUDIO_TEST_DONE,
	TESTCD_MCUDIO_TEST_PASSED,
	TESTCD_MCUDIO_TEST_FAILED,
	TESTCD_MCUDIO_TEST_NOTTESTABLE_E,
    TESTCD_MCUDIO_UNDEFINED

} testcd_rba_IoMcuDio_Case_te;


typedef struct
{
    uint32 numbOfCalls_u32;
    testcd_rba_IoMcuDio_Case_te stTestcase_en;
    boolean retVal_b;
    boolean isDetReportEnabled_b;
    Std_VersionInfoType stVersionInfo_st;
    rba_IoSigDio_idSignal_tu16 rba_IoMcuDio_PinType_u16;
	rba_IoSigDio_stSignal_ten rba_IoMcuDio_LevelType_en;
	rba_IoSigDio_stSignal_ten rba_IoMcuDio_Read_en;
	rba_IoSigDio_stDirection_ten rba_IoMcuDio_Dir_en;
} TestCd_rba_IoMcuDio_tst;

/* Extern declarations for variables accessed through ITF */
extern TestCd_rba_IoMcuDio_tst TestCd_rba_IoMcuDio_st;
extern Std_ReturnType TestCd_rba_IoMcuDio_retval_u8;
extern rba_IoSigDio_stSignal_ten TestCd_rba_IoMcuDio_SetDetVar_en;
extern rba_IoSigDio_stDirection_ten TestCd_rba_IoMcuDio_SetDirDetVar_en;
extern rba_IoSigDio_stSignal_ten *TestCd_rba_IoMcuDio_GetDetVar_ptr_en;
extern volatile uint8 TestCd_rba_IoMcuDio_ITF_num_signals_u8;
extern volatile uint8 TestCd_rba_IoMcuDio_ITF_input_u8;
extern volatile uint8 TestCd_rba_IoMcuDio_ITF_output_u8;
extern volatile uint8 TestCd_rba_IoMcuDio_ITF_unkonwn_ID_signal_u8;

#define TESTCD_RBA_IOMCUDIO_HALT(x)  RBA_BSWSRV_DEBUG_HALT()

void TestCd_rba_IoMcuDio_Itf_10ms(void);

#endif /* TESTCD_RBA_IOMCUDIO_H_ */
