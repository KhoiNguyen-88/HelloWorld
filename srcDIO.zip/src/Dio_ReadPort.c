/*<RBHead>
 *************************************************************************
 *                                                                       *
 *                      ROBERT BOSCH GMBH                                *
 *                          STUTTGART                                    *
 *                                                                       *
 *          Alle Rechte vorbehalten - All rights reserved                *
 *                                                                       *
 *************************************************************************

 *************************************************************************
 *    Administrative Information (automatically filled in by eASEE)      *
 *************************************************************************
 *
 * $Filename__:$
 *
 * $Author____:$
 *
 * $Function__:$
 *
 *************************************************************************
 * $Domain____:$
 * $User______:$
 * $Date______:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 * $Type______:$
 * $State_____:$
 * $Generated_:$
 *************************************************************************
 *
 * $UniqueName:$
 * $Component_:$
 *
 *
 *************************************************************************
</RBHead>*/

/*-------------------------------------------------------------------------------------------------------------------*
 * Includes
 *-------------------------------------------------------------------------------------------------------------------*/
/*!
 * \rba_comp Dio
 *  @{
 */
#include "Dio.h"

#if (DIO_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#if (!defined(DET_AR_RELEASE_MAJOR_VERSION) || (DET_AR_RELEASE_MAJOR_VERSION != DIO_AR_RELEASE_MAJOR_VERSION))
    #error "AUTOSAR major version undefined or mismatched"
#endif
#if (!defined(DET_AR_RELEASE_MINOR_VERSION) || ((DET_AR_RELEASE_MINOR_VERSION != 0) && \
                                                (DET_AR_RELEASE_MINOR_VERSION != 2)))
    #error "AUTOSAR minor version undefined or mismatched"
#endif
#endif

#if (MCU_RB_MACHINE_FAM == MCU_RB_IFX_UC1)
#elif (MCU_RB_MACHINE_FAM == MCU_RB_JDP_UC1)
    #include "rba_Reg.h"
    #include RBA_REG_SIUL2_H
#else
    #error "Machine family not supported"
#endif

#include "Dio_Prv.h"

#if (defined(DIO_NUMBER_OF_PORTNAMES) && (DIO_NUMBER_OF_PORTNAMES > 0))

#define  DIO_START_SEC_CODE
#include DIO_MEMMAP_H

/*!
 ***************************************************************************************************
 * \brief Returns the value of all pins of the specified DIO port
 *
 * \attention This API is not available for ports >= Port_R in JDP DEV4
 * \attention The return value is controller specific. Direct value of the port input register.
 * This means the API returns.
 * \code
 * MSB                         LSB
 * +-----+-----+-----+-----+-----+
 * |Pin15| ... | ... | ... |Pin00|    IFX
 * +-----+-----+-----+-----+-----+
 *
 * +-----+-----+-----+-----+-----+
 * |Pin00| ... | ... | ... |Pin15|    JDP
 * +-----+-----+-----+-----+-----+
 * \endcode
 * See Dio_Rb_GetPinPos() how to abstract this to be independent of the used controller
 *
 * \param[in] PortId        The signal name / symbolic name which is specified at configuration time
 *                          for the current signal
 *
 * \note                    If DET is active, invalid ChannelId's will be reported to DET.
 *
 * \return                  The physical level of all port pins of the specified port
 *
 * \rba_example
 * \code
 * #include "Dio.h"
 * void main(void)
 * {
 *      Dio_PortLevelType PortLevel;
 *      PortLevel = Dio_ReadPort(DioConf_DioRbPortName_<DioRbPortName>);
 * }
 * \endcode
 ***************************************************************************************************
 */
Dio_PortLevelType Dio_ReadPort(Dio_PortType PortId)
{
    Dio_PortLevelType stResult_uo = 0;

    /* Check if PostBuild config pointer is initialized */
    if(Dio_PbConfig_pcst == NULL_PTR)
    {
#if (DIO_DEV_ERROR_DETECT == STD_ON)
        (void)Det_ReportError(DIO_MODULE_ID, DIO_INSTANCE_ID, DIO_SERVICE_ID_READ_PORT, DIO_E_PARAM_CONFIG);
#endif
    }
    /* Check if PortId is in valid range and is valid in this PostBuild configuration */
    else if((PortId >= DIO_NUMBER_OF_PORTNAMES) || (Dio_PbConfig_pcst->PortName_pcu8[PortId] == DIO_RB_INVALID_PORTNAME_MARKER))
    {
#if (DIO_DEV_ERROR_DETECT == STD_ON)
        (void)Det_ReportError(DIO_MODULE_ID, DIO_INSTANCE_ID, DIO_SERVICE_ID_READ_PORT, DIO_E_PARAM_INVALID_PORT_ID);
#endif
    }
    else
    {
#if (MCU_RB_MACHINE_FAM == MCU_RB_IFX_UC1)
        /* Pointer to Input Register */
        volatile uint32* adInReg_pvu32;

        /* Get address of the Input Register */
        /* MR12 RULE 11.4,11.6 VIOLATION: The warning is uncritical and non-removable since cast is required to
           manipulate register address. - Approved by MISRA2012_SUPPORT_TEAM. */
        adInReg_pvu32 = (volatile uint32*)((uint32)Dio_PortInfo_acpu32[Dio_PbConfig_pcst->PortName_pcu8[PortId]] + (uint32)DIO_RB_IN_OFFSET);

        /* Get state */
        stResult_uo =  (Dio_PortLevelType)*adInReg_pvu32;
#elif (MCU_RB_MACHINE_FAM == MCU_RB_JDP_UC1)
        stResult_uo = SIUL2_PD.PGPDI[Dio_PbConfig_pcst->PortName_pcu8[PortId]];
#else
    #error "Machine family not supported"
#endif
    }

    return stResult_uo;
}

#define  DIO_STOP_SEC_CODE
#include DIO_MEMMAP_H

/* DIO_NUMBER_OF_PORTNAMES > 0 */
#endif

 /*<RBHead>
  *************************************************************************
  * List Of Changes
  *
  * $History$
  *
  *************************************************************************
 </RBHead>*/

 /*<RBHead>
  **********************************************************************************************************************
  * End of header file: $Name______:$
  **********************************************************************************************************************
 </RBHead>*/

/*! @} */
