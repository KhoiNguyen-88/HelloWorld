/*<RBHead>
 *************************************************************************
 *                                                                       *
 *                      ROBERT BOSCH GMBH                                *
 *                          STUTTGART                                    *
 *                                                                       *
 *          Alle Rechte vorbehalten - All rights reserved                *
 *                                                                       *
 *************************************************************************

 *************************************************************************
 *    Administrative Information (automatically filled in by eASEE)      *
 *************************************************************************
 *
 * $Filename__:$
 *
 * $Author____:$
 *
 * $Function__:$
 *
 *************************************************************************
 * $Domain____:$
 * $User______:$
 * $Date______:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 * $Type______:$
 * $State_____:$
 * $Generated_:$
 *************************************************************************
 *
 * $UniqueName:$
 * $Component_:$
 *
 *
 *************************************************************************
</RBHead>*/

/*-------------------------------------------------------------------------------------------------------------------*
 * Includes
 *-------------------------------------------------------------------------------------------------------------------*/
/*!
 * \rba_comp Dio
 *  @{
 */
#include "Dio.h"
#include "Dio_Prv.h"

#if (defined(DIO_NUMBER_OF_SIGNALS) && (DIO_NUMBER_OF_SIGNALS > 0))

#define  DIO_START_SEC_CODE
#include DIO_MEMMAP_H

/*!
 ***************************************************************************************************
 * \brief Dio_Rb_MoInitCheck of PostBuild pointer
 *
 * \param[in] ConfigPtr    Pointer to a post build configuration structure
 *
 * \retval E_OK            Passed pointer is     equal to the active PostBuild pointer
 * \retval E_NOT_OK        Passed pointer is NOT equal to the active PostBuild pointer
 *
 * \rba_example
 * \code
 * #include "Dio.h"
 * void main(void)
 * {
 *       Dio_Rb_MoInitCheck((const Dio_ConfigType*)&Dio_PostBuildConfigName_Ex_4Cyl);
 * }
 * \endcode
 ***************************************************************************************************
 */
Std_ReturnType Dio_Rb_MoInitCheck(const Dio_ConfigType* ConfigPtr)
{
    Std_ReturnType retval_uo;

    if(ConfigPtr == Dio_PbConfig_pcst)
    {
        retval_uo = E_OK;
    }
    else
    {
        retval_uo = E_NOT_OK;
    }

    return retval_uo;
}

#define  DIO_STOP_SEC_CODE
#include DIO_MEMMAP_H

/* DIO_NUMBER_OF_SIGNALS > 0 */
#endif

/*<RBHead>
 *************************************************************************
 * List Of Changes
 *
 * $History$
 *
 *************************************************************************
</RBHead>*/

/*<RBHead>
 **********************************************************************************************************************
 * End of header file: $Name______:$
 **********************************************************************************************************************
</RBHead>*/

/*! @} */
