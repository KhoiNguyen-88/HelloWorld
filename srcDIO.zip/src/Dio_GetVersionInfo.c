/*<RBHead>
 *************************************************************************
 *                                                                       *
 *                      ROBERT BOSCH GMBH                                *
 *                          STUTTGART                                    *
 *                                                                       *
 *          Alle Rechte vorbehalten - All rights reserved                *
 *                                                                       *
 *************************************************************************

 *************************************************************************
 *    Administrative Information (automatically filled in by eASEE)      *
 *************************************************************************
 *
 * $Filename__:$
 *
 * $Author____:$
 *
 * $Function__:$
 *
 *************************************************************************
 * $Domain____:$
 * $User______:$
 * $Date______:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 * $Type______:$
 * $State_____:$
 * $Generated_:$
 *************************************************************************
 *
 * $UniqueName:$
 * $Component_:$
 *
 *
 *************************************************************************
</RBHead>*/

/*-------------------------------------------------------------------------------------------------------------------*
 * Includes
 *-------------------------------------------------------------------------------------------------------------------*/
/*!
 * \rba_comp Dio
 *  @{
 */
#include "Dio.h"

#if (DIO_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#if (!defined(DET_AR_RELEASE_MAJOR_VERSION) || (DET_AR_RELEASE_MAJOR_VERSION != DIO_AR_RELEASE_MAJOR_VERSION))
    #error "AUTOSAR major version undefined or mismatched"
#endif
#if (!defined(DET_AR_RELEASE_MINOR_VERSION) || ((DET_AR_RELEASE_MINOR_VERSION != 0) && \
                                                (DET_AR_RELEASE_MINOR_VERSION != 2)))
    #error "AUTOSAR minor version undefined or mismatched"
#endif
#endif

#if (DIO_VERSION_INFO_API == STD_ON)

#define  DIO_START_SEC_CODE
#include DIO_MEMMAP_H

/*!
 ***************************************************************************************************
 * \brief Returns the version information of the DIO module
 *
 * \param[in,out] VersionInfo   Pointer where to store the version information of this module

 * \return                      void
 *
 * \rba_example
 * \code
 * #include "dio.h"
 * void main(void)
 * {
 *      Std_VersionInfoType *VersionInfo;
 *      Dio_GetVersionInfo(VersionInfo);
 * }
 * \endcode
 *
 * \note Will only be available if the configuration parameter DioVersionInfoApi is set to true
 ***************************************************************************************************
 */
void Dio_GetVersionInfo(Std_VersionInfoType *VersionInfo)
{
    if (VersionInfo == NULL_PTR)
    {
#if (DIO_DEV_ERROR_DETECT == STD_ON)
        (void)Det_ReportError(DIO_MODULE_ID, DIO_INSTANCE_ID, DIO_SERVICE_ID_GET_VERSION_INFO, DIO_E_PARAM_POINTER);
#endif
    }
    else
    {
        VersionInfo->vendorID           = DIO_VENDOR_ID;
        VersionInfo->moduleID           = DIO_MODULE_ID;
        VersionInfo->sw_major_version   = DIO_SW_MAJOR_VERSION;
        VersionInfo->sw_minor_version   = DIO_SW_MINOR_VERSION;
        VersionInfo->sw_patch_version   = DIO_SW_PATCH_VERSION;
    }
}

#define  DIO_STOP_SEC_CODE
#include DIO_MEMMAP_H

#endif

/*<RBHead>
 *************************************************************************
 * List Of Changes
 *
 * $History$
 *
 *************************************************************************
</RBHead>*/

/*<RBHead>
 **********************************************************************************************************************
 * End of header file: $Name______:$
 **********************************************************************************************************************
</RBHead>*/

/*! @} */
