/*<RBHead>
 *************************************************************************
 *                                                                       *
 *                      ROBERT BOSCH GMBH                                *
 *                          STUTTGART                                    *
 *                                                                       *
 *          Alle Rechte vorbehalten - All rights reserved                *
 *                                                                       *
 *************************************************************************

 *************************************************************************
 *    Administrative Information (automatically filled in by eASEE)      *
 *************************************************************************
 *
 * $Filename__:$
 *
 * $Author____:$
 *
 * $Function__:$
 *
 *************************************************************************
 * $Domain____:$
 * $User______:$
 * $Date______:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 * $Type______:$
 * $State_____:$
 * $Generated_:$
 *************************************************************************
 *
 * $UniqueName:$
 * $Component_:$
 *
 *
 *************************************************************************
</RBHead>*/

/*-------------------------------------------------------------------------------------------------------------------*
 * Includes
 *-------------------------------------------------------------------------------------------------------------------*/
/*!
 * \rba_comp Dio
 *  @{
 */
#include "Dio.h"
#include "Mcu.h"

#if (DIO_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#if (!defined(DET_AR_RELEASE_MAJOR_VERSION) || (DET_AR_RELEASE_MAJOR_VERSION != DIO_AR_RELEASE_MAJOR_VERSION))
    #error "AUTOSAR major version undefined or mismatched"
#endif
#if (!defined(DET_AR_RELEASE_MINOR_VERSION) || ((DET_AR_RELEASE_MINOR_VERSION != 0) && \
                                                (DET_AR_RELEASE_MINOR_VERSION != 2)))
    #error "AUTOSAR minor version undefined or mismatched"
#endif
#endif

#include "Dio_Prv.h"

#if (defined(DIO_NUMBER_OF_PINPOS) && (DIO_NUMBER_OF_PINPOS > 0))

#define  DIO_START_SEC_CODE
#include DIO_MEMMAP_H

/*!
 ***************************************************************************************************
 * \brief Returns the bit position of the passed Dio Channel in the result value of Dio_ReadPort()
 *
 * This function takes care about the controller specific behavior of Dio_ReadPort()
 * The return value for a signal which is configured on
 * \code
 * JDP: PA_00 is 15
 * IFX: P0_00 is  0
 * \endcode
 * So this API can be used to build a mask to extract all required Dio Channels from the
 * return value of Dio_ReadPort(). This mask will be valid for IFX and JDP. The user does not need
 * to take care of it!  See Dio_ReadPort() for more details.
 *
 * \param[in] PinPosId_u8   The signal name / symbolic name which is specified at configuration time
 *                          for the current signal
 * \param[out] PinPos_pu8   Bit position of the passed Dio Channel in the return value of Dio_ReadPort()
 *
 * \note                    If DET is active, invalid PinPosId's will be reported to DET.
 *
 * \retval E_OK             No error occurred
 * \retval E_NOT_OK         An error occurred
 *
 * \rba_example
 * \code
 * #include "Dio.h"
 * void main(void)
 * {
 *      Dio_PortLevelType PortLevel;
 *      uint8             PinPos_u8;
 *      Std_ReturnType    stResult;
 *
 *      -- A = Content of DioRbPortName config parameter
 *      -- B = The Shortname of the configured Dio Channel
 *
 *      PortLevel = Dio_ReadPort(DioConf_DioRbPortName_<A>);
 *      stResult  = Dio_Rb_GetPinPos(DioConf_DioRbPinPos_<B>, &PinPos_u8)
 *
 * }
 * \endcode
 ***************************************************************************************************
 */
Std_ReturnType Dio_Rb_GetPinPos(uint8 PinPosId_u8, uint8* PinPos_pu8)
{
    Std_ReturnType xRet_uo = E_NOT_OK;

    /* Check if PostBuild config pointer is initialized */
    if(Dio_PbConfig_pcst == NULL_PTR)
    {
#if (DIO_DEV_ERROR_DETECT == STD_ON)
        (void)Det_ReportError(DIO_MODULE_ID, DIO_INSTANCE_ID, DIO_SERVICE_ID_GET_PIN_POS, DIO_E_PARAM_CONFIG);
#endif
    }
    /* Check if PinPosId_u8 is in valid range and is valid in this PostBuild configuration */
    else if((PinPosId_u8 >= DIO_NUMBER_OF_PINPOS) || (Dio_PbConfig_pcst->PinPos_pcu8[PinPosId_u8] == DIO_RB_INVALID_PINPOS_MARKER))
    {
#if (DIO_DEV_ERROR_DETECT == STD_ON)
        (void)Det_ReportError(DIO_MODULE_ID, DIO_INSTANCE_ID, DIO_SERVICE_ID_GET_PIN_POS, DIO_E_PARAM_INVALID_PINPOS_ID);
#endif
    }
    else
    {
        xRet_uo = E_OK;
#if (MCU_RB_MACHINE_FAM == MCU_RB_IFX_UC1)
        *PinPos_pu8 = Dio_PbConfig_pcst->PinPos_pcu8[PinPosId_u8];
#elif (MCU_RB_MACHINE_FAM == MCU_RB_JDP_UC1)
        /* Adjust the return value to be controller independent */
        *PinPos_pu8 = (uint8)((sizeof(Dio_PortLevelType)*8u)-1u) - Dio_PbConfig_pcst->PinPos_pcu8[PinPosId_u8];
#else
    #error "Machine family not supported"
#endif
    }

    return xRet_uo;
}

#define  DIO_STOP_SEC_CODE
#include DIO_MEMMAP_H

/* DIO_NUMBER_OF_PINPOS > 0 */
#endif

 /*<RBHead>
  *************************************************************************
  * List Of Changes
  *
  * $History$
  *
  *************************************************************************
 </RBHead>*/

 /*<RBHead>
  **********************************************************************************************************************
  * End of header file: $Name______:$
  **********************************************************************************************************************
 </RBHead>*/

/*! @} */
