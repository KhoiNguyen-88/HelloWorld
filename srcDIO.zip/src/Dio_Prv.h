/*<RBHead>
 *************************************************************************
 *                                                                       *
 *                      ROBERT BOSCH GMBH                                *
 *                          STUTTGART                                    *
 *                                                                       *
 *          Alle Rechte vorbehalten - All rights reserved                *
 *                                                                       *
 *************************************************************************

 *************************************************************************
 *    Administrative Information (automatically filled in by eASEE)      *
 *************************************************************************
 *
 * $Filename__:$
 *
 * $Author____:$
 *
 * $Function__:$
 *
 *************************************************************************
 * $Domain____:$
 * $User______:$
 * $Date______:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 * $Type______:$
 * $State_____:$
 * $Generated_:$
 *************************************************************************
 *
 * $UniqueName:$
 * $Component_:$
 *
 *
 *************************************************************************
</RBHead>*/

#ifndef DIO_PRV_H
#define DIO_PRV_H

#include "Mcu.h"

#if (MCU_RB_MACHINE_FAM == MCU_RB_IFX_UC1)
    /* Offsets in bytes from the base address of every module. This is checked automatically in TestCd_DioOffsetChk_Ifx.c */
    #define DIO_RB_OUT_OFFSET                   0x00u
    #define DIO_RB_OMR_OFFSET                   0x04u
    #define DIO_RB_IN_OFFSET                    0x24u
    #define DIO_RB_INVALID_CHANNELID_MARKER     0xFFu
#elif (MCU_RB_MACHINE_FAM == MCU_RB_JDP_UC1)
    #define DIO_RB_INVALID_CHANNELID_MARKER     0xFFFFu
#else
    #error "Machine family not supported"
#endif

#define DIO_RB_INVALID_PORTNAME_MARKER          0xFFu
#define DIO_RB_INVALID_PINPOS_MARKER            0xFFu

#define  DIO_START_SEC_DEFAULT_PBS_CLEARED_32
#include DIO_MEMMAP_H
extern const Dio_ConfigType* Dio_PbConfig_pcst;
#define  DIO_STOP_SEC_DEFAULT_PBS_CLEARED_32
#include DIO_MEMMAP_H

/* DIO_PRV_H */
#endif

/*<RBHead>
 *************************************************************************
 * List Of Changes
 *
 * $History$
 *
 *************************************************************************
</RBHead>*/

/*<RBHead>
 **********************************************************************************************************************
 * End of header file: $Name______:$
 **********************************************************************************************************************
</RBHead>*/
