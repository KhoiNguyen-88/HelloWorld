/*<RBHead>
 *************************************************************************
 *                                                                       *
 *                      ROBERT BOSCH GMBH                                *
 *                          STUTTGART                                    *
 *                                                                       *
 *          Alle Rechte vorbehalten - All rights reserved                *
 *                                                                       *
 *************************************************************************

 *************************************************************************
 *    Administrative Information (automatically filled in by eASEE)      *
 *************************************************************************
 *
 * $Filename__:$
 *
 * $Author____:$
 *
 * $Function__:$
 *
 *************************************************************************
 * $Domain____:$
 * $User______:$
 * $Date______:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 * $Type______:$
 * $State_____:$
 * $Generated_:$
 *************************************************************************
 *
 * $UniqueName:$
 * $Component_:$
 *
 *
 *************************************************************************
</RBHead>*/

/*-------------------------------------------------------------------------------------------------------------------*
 * Includes
 *-------------------------------------------------------------------------------------------------------------------*/
/*!
 * \rba_comp Dio
 *  @{
 */
#include "Dio.h"

#if (DIO_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#if (!defined(DET_AR_RELEASE_MAJOR_VERSION) || (DET_AR_RELEASE_MAJOR_VERSION != DIO_AR_RELEASE_MAJOR_VERSION))
    #error "AUTOSAR major version undefined or mismatched"
#endif
#if (!defined(DET_AR_RELEASE_MINOR_VERSION) || ((DET_AR_RELEASE_MINOR_VERSION != 0) && \
                                                (DET_AR_RELEASE_MINOR_VERSION != 2)))
    #error "AUTOSAR minor version undefined or mismatched"
#endif
#endif

#include "Dio_Prv.h"

#if (defined(DIO_NUMBER_OF_SIGNALS) && (DIO_NUMBER_OF_SIGNALS > 0))

/*-------------------------------------------------------------------------------------------------------------------*
 * Globals
 *-------------------------------------------------------------------------------------------------------------------*/
#define  DIO_START_SEC_DEFAULT_PBS_CLEARED_32
#include DIO_MEMMAP_H

const Dio_ConfigType* Dio_PbConfig_pcst;

#define  DIO_STOP_SEC_DEFAULT_PBS_CLEARED_32
#include DIO_MEMMAP_H


#define  DIO_START_SEC_CODE
#include DIO_MEMMAP_H

/*!
 ***************************************************************************************************
 * \brief The Dio_Init function initializes all global variables of the DIO module
 *
 * \param[in] ConfigPtr     Pointer to a post build configuration structure
 *
 * \attention               Has to be called before any other Dio function.
 *
 * \note                    Normally not called by the user. This function is called by EcuM
 *
 * \return                  void
 *
 * \rba_example
 * \code
 * #include "Dio.h"
 * void main(void)
 * {
 *       Dio_Init((const Dio_ConfigType*)&Dio_PostBuildConfigName_Ex_4Cyl);
 * }
 * \endcode
 ***************************************************************************************************
 */
void Dio_Init(const Dio_ConfigType* ConfigPtr)
{
    if (ConfigPtr == NULL_PTR)
    {
#if (DIO_DEV_ERROR_DETECT == STD_ON)
        // This IoSigDio implementation only supports post-build configuration
        (void)Det_ReportError(DIO_MODULE_ID, DIO_INSTANCE_ID, DIO_SERVICE_ID_INIT, DIO_E_PARAM_CONFIG);
#endif
    }
    else
    {
        Dio_PbConfig_pcst = ConfigPtr;
    }
}

#define  DIO_STOP_SEC_CODE
#include DIO_MEMMAP_H

/* DIO_NUMBER_OF_SIGNALS > 0 */
#endif

/*<RBHead>
 *************************************************************************
 * List Of Changes
 *
 * $History$
 *
 *************************************************************************
</RBHead>*/

/*<RBHead>
 **********************************************************************************************************************
 * End of header file: $Name______:$
 **********************************************************************************************************************
</RBHead>*/

/*! @} */
