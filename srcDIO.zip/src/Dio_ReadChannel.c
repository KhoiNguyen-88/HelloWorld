/*<RBHead>
 *************************************************************************
 *                                                                       *
 *                      ROBERT BOSCH GMBH                                *
 *                          STUTTGART                                    *
 *                                                                       *
 *          Alle Rechte vorbehalten - All rights reserved                *
 *                                                                       *
 *************************************************************************

 *************************************************************************
 *    Administrative Information (automatically filled in by eASEE)      *
 *************************************************************************
 *
 * $Filename__:$
 *
 * $Author____:$
 *
 * $Function__:$
 *
 *************************************************************************
 * $Domain____:$
 * $User______:$
 * $Date______:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 * $Type______:$
 * $State_____:$
 * $Generated_:$
 *************************************************************************
 *
 * $UniqueName:$
 * $Component_:$
 *
 *
 *************************************************************************
</RBHead>*/

/*-------------------------------------------------------------------------------------------------------------------*
 * Includes
 *-------------------------------------------------------------------------------------------------------------------*/
/*!
 * \rba_comp Dio
 *  @{
 */
#include "Dio.h"

#include "Mcu.h"
#if (!defined(MCU_AR_RELEASE_MAJOR_VERSION) || (MCU_AR_RELEASE_MAJOR_VERSION != DIO_AR_RELEASE_MAJOR_VERSION))
    #error "AUTOSAR major version undefined or mismatched"
#endif
#if (!defined(MCU_AR_RELEASE_MINOR_VERSION) || ((MCU_AR_RELEASE_MINOR_VERSION != 0) && \
                                                (MCU_AR_RELEASE_MINOR_VERSION != 2)))
    #error "AUTOSAR minor version undefined or mismatched"
#endif

#if (DIO_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#if (!defined(DET_AR_RELEASE_MAJOR_VERSION) || (DET_AR_RELEASE_MAJOR_VERSION != DIO_AR_RELEASE_MAJOR_VERSION))
    #error "AUTOSAR major version undefined or mismatched"
#endif
#if (!defined(DET_AR_RELEASE_MINOR_VERSION) || ((DET_AR_RELEASE_MINOR_VERSION != 0) && \
                                                (DET_AR_RELEASE_MINOR_VERSION != 2)))
    #error "AUTOSAR minor version undefined or mismatched"
#endif
#endif

#if (MCU_RB_MACHINE_FAM == MCU_RB_IFX_UC1)
#elif (MCU_RB_MACHINE_FAM == MCU_RB_JDP_UC1)
    #include "rba_Reg.h"
    #include RBA_REG_SIUL2_H
#else
    #error "Machine family not supported"
#endif

#include "Dio_Prv.h"

#if (defined(DIO_NUMBER_OF_SIGNALS) && (DIO_NUMBER_OF_SIGNALS > 0))

#define  DIO_START_SEC_CODE
#include DIO_MEMMAP_H

/*!
 ***************************************************************************************************
 * \brief Returns the value of the specified DIO channel
 *
 * \param[in] ChannelId     The signal name / symbolic name which is specified at configuration time
 *                          for the current signal
 *
 * \note                    If DET is active, invalid ChannelId's will be reportet to DET.
 *
 * \retval STD_LOW          The physical level of the corresponding pin is LOW
 * \retval STD_HIGH         The physical level of the corresponding pin is HIGH
 *
 * \rba_example
 * \code
 * #include "Dio.h"
 * void main(void)
 * {
 *      Dio_LevelType PinLevel;
 *      PinLevel = Dio_ReadChannel(InputPin);
 * }
 * \endcode
 ***************************************************************************************************
 */
Dio_LevelType Dio_ReadChannel(Dio_ChannelType ChannelId)
{
    Dio_LevelType stResult_uo;             /* Return value of read port pin */

    /* Return value is initialized with "STD_LOW" default value for all error cases */
    stResult_uo = STD_LOW;

    /* Check if PostBuild config pointer is initialized */
    if(Dio_PbConfig_pcst == NULL_PTR)
    {
#if (DIO_DEV_ERROR_DETECT == STD_ON)
        (void)Det_ReportError(DIO_MODULE_ID, DIO_INSTANCE_ID, DIO_SERVICE_ID_READ_CHANNEL, DIO_E_PARAM_CONFIG);
#endif
    }
    /* Check if ChannelId is in valid range and is valid in this PostBuild configuration */
    else if((ChannelId >= DIO_NUMBER_OF_SIGNALS) || (Dio_PbConfig_pcst->SignalConfig_pcst[ChannelId].PinNumber_uo == DIO_RB_INVALID_CHANNELID_MARKER))
    {
#if (DIO_DEV_ERROR_DETECT == STD_ON)
        (void)Det_ReportError(DIO_MODULE_ID, DIO_INSTANCE_ID, DIO_SERVICE_ID_READ_CHANNEL, DIO_E_PARAM_INVALID_CHANNEL_ID);
#endif
    }
    else
    {
#if (MCU_RB_MACHINE_FAM == MCU_RB_IFX_UC1)
        /* Pointer to Input Register */
        volatile uint32* adInReg_pvu32;

        /* Get address of the Input Register */
        /* MR12 RULE 11.4,11.6 VIOLATION: The warning is uncritical and non-removable since cast is required to
           manipulate register address. - Approved by MISRA2012_SUPPORT_TEAM. */
        adInReg_pvu32 = (volatile uint32*)((uint32)Dio_PortInfo_acpu32[Dio_PbConfig_pcst->SignalConfig_pcst[ChannelId].PortId_u8] + (uint32)DIO_RB_IN_OFFSET);

        /* Get state */
        stResult_uo =  (uint8)((*adInReg_pvu32 >> Dio_PbConfig_pcst->SignalConfig_pcst[ChannelId].PinNumber_uo) & 0x1uL);
#elif (MCU_RB_MACHINE_FAM == MCU_RB_JDP_UC1)
        stResult_uo = SIUL2_PD.GPDI[Dio_PbConfig_pcst->SignalConfig_pcst[ChannelId].PinNumber_uo] & 0x01u;
#else
    #error "Machine family not supported"
#endif
    }

    /* Return read value */
    return((stResult_uo == 0) ? STD_LOW : STD_HIGH);
}

#define  DIO_STOP_SEC_CODE
#include DIO_MEMMAP_H

/* DIO_NUMBER_OF_SIGNALS > 0 */
#endif

 /*<RBHead>
  *************************************************************************
  * List Of Changes
  *
  * $History$
  *
  *************************************************************************
 </RBHead>*/

 /*<RBHead>
  **********************************************************************************************************************
  * End of header file: $Name______:$
  **********************************************************************************************************************
 </RBHead>*/

/*! @} */
