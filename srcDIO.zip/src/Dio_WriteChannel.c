/*<RBHead>
 *************************************************************************
 *                                                                       *
 *                      ROBERT BOSCH GMBH                                *
 *                          STUTTGART                                    *
 *                                                                       *
 *          Alle Rechte vorbehalten - All rights reserved                *
 *                                                                       *
 *************************************************************************

 *************************************************************************
 *    Administrative Information (automatically filled in by eASEE)      *
 *************************************************************************
 *
 * $Filename__:$
 *
 * $Author____:$
 *
 * $Function__:$
 *
 *************************************************************************
 * $Domain____:$
 * $User______:$
 * $Date______:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 * $Type______:$
 * $State_____:$
 * $Generated_:$
 *************************************************************************
 *
 * $UniqueName:$
 * $Component_:$
 *
 *
 *************************************************************************
</RBHead>*/

/*-------------------------------------------------------------------------------------------------------------------*
 * Includes
 *-------------------------------------------------------------------------------------------------------------------*/
/*!
 * \rba_comp Dio
 *  @{
 */
#include "Dio.h"

#include "Mcu.h"
#if (!defined(MCU_AR_RELEASE_MAJOR_VERSION) || (MCU_AR_RELEASE_MAJOR_VERSION != DIO_AR_RELEASE_MAJOR_VERSION))
    #error "AUTOSAR major version undefined or mismatched"
#endif
#if (!defined(MCU_AR_RELEASE_MINOR_VERSION) || ((MCU_AR_RELEASE_MINOR_VERSION != 0) && \
                                                (MCU_AR_RELEASE_MINOR_VERSION != 2)))
    #error "AUTOSAR minor version undefined or mismatched"
#endif

#if (DIO_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#if (!defined(DET_AR_RELEASE_MAJOR_VERSION) || (DET_AR_RELEASE_MAJOR_VERSION != DIO_AR_RELEASE_MAJOR_VERSION))
    #error "AUTOSAR major version undefined or mismatched"
#endif
#if (!defined(DET_AR_RELEASE_MINOR_VERSION) || ((DET_AR_RELEASE_MINOR_VERSION != 0) &&\
                                                (DET_AR_RELEASE_MINOR_VERSION != 2)))
    #error "AUTOSAR minor version undefined or mismatched"
#endif
#endif

#if (MCU_RB_MACHINE_FAM == MCU_RB_IFX_UC1)
#elif (MCU_RB_MACHINE_FAM == MCU_RB_JDP_UC1)
    #include "rba_Reg.h"
    #include RBA_REG_SIUL2_H
#else
    #error "Machine family not supported"
#endif

#include "Dio_Prv.h"

#if (defined(DIO_NUMBER_OF_SIGNALS) && (DIO_NUMBER_OF_SIGNALS > 0))

#define  DIO_START_SEC_CODE
#include DIO_MEMMAP_H

/*!
 ***************************************************************************************************
 * \brief Sets the value of the specified DIO channel
 *
 * \param[in] ChannelId     The signal name / symbolic name which is specified at configuration time
 *                          for the current signal
 * \param[in] Level         Pin level of processor port pin referenced by ChannelId. Valid values are
 *                          STD_LOW and STD_HIGH
 *
 * \note                    If DET is active, invalid ChannelId's will be reportet to DET.
 *
 * \return                  void
 *
 * \rba_example
 * \code
 * #include "Dio.h"
 * void main(void)
 * {
 *      Dio_WriteChannel(OutputPin, (Dio_LevelType)1);
 * }
 * \endcode
 ***************************************************************************************************
 */
void Dio_WriteChannel(Dio_ChannelType ChannelId, Dio_LevelType Level)
{
    /* Check if PostBuild config pointer is initialised */
    if(Dio_PbConfig_pcst == NULL_PTR)
    {
#if (DIO_DEV_ERROR_DETECT == STD_ON)
        (void)Det_ReportError(DIO_MODULE_ID, DIO_INSTANCE_ID, DIO_SERVICE_ID_WRITE_CHANNEL, DIO_E_PARAM_CONFIG);
#endif
    }
    /* Check if ChannelId is in valid range and is valid in this PostBuild configuration */
    else if((ChannelId >= DIO_NUMBER_OF_SIGNALS) || (Dio_PbConfig_pcst->SignalConfig_pcst[ChannelId].PinNumber_uo == DIO_RB_INVALID_CHANNELID_MARKER))
    {
#if (DIO_DEV_ERROR_DETECT == STD_ON)
        (void)Det_ReportError(DIO_MODULE_ID, DIO_INSTANCE_ID, DIO_SERVICE_ID_WRITE_CHANNEL, DIO_E_PARAM_INVALID_CHANNEL_ID);
#endif
    }
    else{
#if (MCU_RB_MACHINE_FAM == MCU_RB_IFX_UC1)
        /* Pointer to Output (Modification) Register */
        volatile uint32 *adOutModReg_pvu32;

        /* Get address of the Output (Modification) Register */
        /* MR12 RULE 11.4,11.6 VIOLATION: The warning is uncritical and non-removable since cast is required to
           manipulate register address. - Approved by MISRA2012_SUPPORT_TEAM. */
        adOutModReg_pvu32 = (uint32*)((uint32)Dio_PortInfo_acpu32[Dio_PbConfig_pcst->SignalConfig_pcst[ChannelId].PortId_u8] + (uint32)DIO_RB_OMR_OFFSET);

        /* Write 'stValue_b' into Output Modification Register (OMR) */
        *adOutModReg_pvu32 = ( ((0x1uL &  (uint32)Level) <<  Dio_PbConfig_pcst->SignalConfig_pcst[ChannelId].PinNumber_uo)        |
                               ((0x1uL & ~(uint32)Level) << (Dio_PbConfig_pcst->SignalConfig_pcst[ChannelId].PinNumber_uo + 16))
        );
#elif (MCU_RB_MACHINE_FAM == MCU_RB_JDP_UC1)
        SIUL2_PD.GPDO[Dio_PbConfig_pcst->SignalConfig_pcst[ChannelId].PinNumber_uo] = Level;
#else
    #error "Machine family not supported"
#endif
    }
}

#define  DIO_STOP_SEC_CODE
#include DIO_MEMMAP_H

/* DIO_NUMBER_OF_SIGNALS > 0 */
#endif

 /*<RBHead>
  *************************************************************************
  * List Of Changes
  *
  * $History$
  *
  *************************************************************************
 </RBHead>*/

 /*<RBHead>
  **********************************************************************************************************************
  * End of header file: $Name______:$
  **********************************************************************************************************************
 </RBHead>*/

/*! @} */
