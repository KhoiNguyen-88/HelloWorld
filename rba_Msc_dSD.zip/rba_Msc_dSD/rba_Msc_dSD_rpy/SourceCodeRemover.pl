use warnings;
use strict;

my @InputFiles_a = ('rba_Msc.sbs');
my @OutputFiles_a = ('rba_Msc_mod.sbs');

my $SearchPattern_s = '_bodyData =';
my $EndPattern_s = '";';

my $TextLine_s;
my $Output_s;

parseInputFile();

sub parseInputFile{
    my $FileHandle;
    my $counter = 0;
    
	if (scalar(@InputFiles_a) == scalar(@OutputFiles_a)){        
        for($counter = 0; $counter<scalar(@InputFiles_a); $counter++){
            $Output_s = "";
            
            open($FileHandle, $InputFiles_a[$counter]) or die "Cannot open file $InputFiles_a[$counter]";
            
            while(defined($TextLine_s = <$FileHandle>)){
                if($TextLine_s !~ /$SearchPattern_s/){
                    $Output_s .= $TextLine_s;
                }else{
                    if ($TextLine_s =~ /(.*- _bodyData = ")(.*)";.*/){
                        if (defined($2)){
                            $Output_s .= $1 . '";' . "\n";
                        }
                    }else{
                        $TextLine_s =~ /(.*- _bodyData).*/;
                        $Output_s .= $1 . ' = "";' . "\n";
                        while(defined($TextLine_s = <$FileHandle>) and ($TextLine_s !~ /$EndPattern_s/)){}                  
                    }
                }                
            }
            
            writeOutputFile($OutputFiles_a[$counter]);
            
            close($FileHandle);
        }        
    }
}

sub writeOutputFile{
    my $outputfile = shift;
    my $FileHandle;

    #write output file	
	open($FileHandle, '>', $outputfile) or die "File $outputfile could not be written";
	print $FileHandle $Output_s;
	close $FileHandle;
}