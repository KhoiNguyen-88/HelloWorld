/*<RBHead>
 *************************************************************************
 *                                                                       *
 *                      ROBERT BOSCH GMBH                                *
 *                          STUTTGART                                    *
 *                                                                       *
 *          Alle Rechte vorbehalten - All rights reserved                *
 *                                                                       *
 *************************************************************************

 *************************************************************************
 *    Administrative Information (automatically filled in by eASEE)      *
 *************************************************************************
 *
 * $Filename__:$
 *
 * $Author____:$
 *
 * $Function__:$
 *
 *************************************************************************
 * $Domain____:$
 * $User______:$
 * $Date______:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 * $Type______:$
 * $State_____:$
 * $Generated_:$
 *************************************************************************
 *
 * $UniqueName:$
 * $Component_:$
 *
 *
 *************************************************************************
 * List Of Changes
 *
 * $History___:
 *
 *
 * $
 *
 *************************************************************************
</RBHead>*/

#ifndef DCM_H_
#define DCM_H_

typedef uint8 Dcm_ResetModeType;

typedef enum {
  DCM_ENABLE_RX_TX_NORM,
  DCM_ENABLE_RX_DISABLE_TX_NORM,
  DCM_DISABLE_RX_ENABLE_TX_NORM,
  DCM_DISABLE_RX_TX_NORMAL,
  DCM_ENABLE_RX_TX_NM,
  DCM_ENABLE_RX_DISABLE_TX_NM,
  DCM_DISABLE_RX_ENABLE_TX_NM,
  DCM_DISABLE_RX_TX_NM,
  DCM_ENABLE_RX_TX_NORM_NM,
  DCM_ENABLE_RX_DISABLE_TX_NORM_NM,
  DCM_DISABLE_RX_ENABLE_TX_NORM_NM,
  DCM_DISABLE_RX_TX_NORM_NM
} Dcm_CommunicationModeType;
typedef uint8 Dcm_SesCtrlType;

#define DCM_ALL_SESSION_LEVEL 0xFF
#define DCM_DEFAULT_SESSION   0x01
#define DCM_PROGRAMMING_SESSION 0x02
#define DCM_EXTENDED_DIAGNOSTIC_SESSION 0x03
#define DCM_SAFETY_SYSTEM_DIAGNOSTIC_SESSION 0x04

#define DCM_NO_RESET        0
#define DCM_RESET_EXECUTION 8
#define DCM_HARD_RESET     0x01
#define DCM_SOFT_RESET     0x03
#define DCM_ENABLE_RAPID_POWER_SHUTDOWN_RESET 0x04

#endif /* DCM_H_ */
