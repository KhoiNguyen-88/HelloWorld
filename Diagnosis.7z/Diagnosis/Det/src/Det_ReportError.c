/*<RBHead>
 ***************************************************************************************************
 *
 * (C) All rights reserved by ROBERT BOSCH GMBH, STUTTGART
 *
 ***************************************************************************************************
 *
 *    __   __   ___  ___
 *   /_ / /  / /__  /    /__/
 *  /__/ /__/ __ / /__  /  /
 *
 *
 ***************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Filename__:$
 * $Author____:$
 * $Function__:$
 * $Domain____:$
 * $User______:$
 * $Date______:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 * $Type______:$
 * $State_____:$
 * $FDEF______:$
 *
 * List of changes
 * $History___:$
 ***************************************************************************************************
 </RBHead>*/


/**************************************************************************************************/
/* Preprocessor includes                                                                          */
/**************************************************************************************************/

#include "Det_Priv.h"

#if(DET_SW_MAJOR_VERSION  != 1)
       #error BOSCH:DET.H is not compatible with DET_REPORTERROR.C
#endif
#if(DET_SW_MINOR_VERSION  != 0)
       #error BOSCH:DET.H is not compatible with DET_REPORTERROR.C
#endif
#if(DET_SW_PATCH_VERSION  != 0)
       #error BOSCH:DET.H is not compatible with DET_REPORTERROR.C
#endif

#if(DET_AR_RELEASE_MAJOR_VERSION  != 4)
       #error BOSCH:DET.H is not compatible with DET_REPORTERROR.C
#endif
#if(DET_AR_RELEASE_MINOR_VERSION  != 0)
       #error BOSCH:DET.H is not compatible with DET_REPORTERROR.C
#endif
#if(DET_AR_RELEASE_REVISION_VERSION  != 0)
       #error BOSCH:DET.H is not compatible with DET_REPORTERROR.C
#endif
#if(DET_VENDOR_ID != 6)
       #error BOSCH:DET.H is not compatible with DET_REPORTERROR.C
#endif
#define DET_START_SEC_CODE
#include "memmap.h"
/***************************************************************************************************
 * @ingroup DET
 *
 *  Interface function provided to Service to report development errors.
 *  The call of Det_ReportError will cause calls to all configured callback functions
 *  ( Hook function)
 *
 * @param[in]       ModuleId        Module ID of calling module.
 * @param[in]       InstanceId      The identifier of the index based instance of a module, starting from 0,
 *                                  If the module is a single instance module it shall pass 0 as the InstanceId.
 * @param[in]       ApiId           ID of API service in which error is detected (defined in SWS of calling module)
 * @param[in]       ErrorId         ID of detected development error (defined in SWS of calling module).
 * @param[out]      None
 * @return          Std_ReturnType  returns always E_OK (is required for services)
 *
 ****************************************************************************************************/
FUNC(Std_ReturnType, DET_CODE) Det_ReportError(uint16 ModuleId, uint8 InstanceId, uint8 ApiId, uint8 ErrorId)
{
    static volatile uint32 Det_CtrDbg_u32 = 0;
    static volatile uint16 Det_DbgModuleId_u16 = 0;

    SchM_Enter_Det(DET_SCHM_EXCLSV_AREA);   /* for making this function re-entrant */

    /* Wrap location index if necessary */
    if (Det_Ctr == DET_CONFIG)
    {
        Det_Ctr = 0;
    }

    /* Debug feature to be able to catch a specific DET entry */
    if (ModuleId == Det_DbgModuleId_u16)
    {
        Det_CtrDbg_u32++;
    }

    /* Passed values are logged into the array in the index that Det counter is currently pointing */
    Det_Errors[Det_Ctr].moduleId   = ModuleId;
    Det_Errors[Det_Ctr].instanceId = InstanceId;
    Det_Errors[Det_Ctr].apiId      = ApiId;
    Det_Errors[Det_Ctr].errorId    = ErrorId;

    /* After storing into the current location the index value is incremented here,so that the value are stored
       into a fresh location when the values are logged for the next time */
    Det_Ctr++;

    SchM_Exit_Det(DET_SCHM_EXCLSV_AREA);    /* for making this function re-entrant */

    return E_OK;
}
#define DET_STOP_SEC_CODE
#include "memmap.h"
