/*<RBHead>
 ***************************************************************************************************
 *
 * (C) All rights reserved by ROBERT BOSCH GMBH, STUTTGART
 *
 ***************************************************************************************************
 *
 *    __   __   ___  ___
 *   /_ / /  / /__  /    /__/
 *  /__/ /__/ __ / /__  /  /
 *
 *
 ***************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Filename__:$
 * $Author____:$
 * $Function__:$
 * $Domain____:$
 * $User______:$
 * $Date______:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 * $Type______:$
 * $State_____:$
 * $FDEF______:$
 *
 * List of changes
 * $History___:$
 ***************************************************************************************************
 </RBHead>*/


#ifndef SCHM_DET_H
#define SCHM_DET_H
#include "rba_BswSrv.h"

/* Entire file is manually created as a quick patch to make Det run by CDG-SMT/ESA1-Nk 2010-11-19 */
#define DET_SCHM_EXCLSV_AREA (0)

#define SchM_Enter_Det(ExclusiveArea) rba_BswSrv_GetLockCommon()      /* TODO: Provide a proper Multicore implementation here */
#define SchM_Exit_Det(ExclusiveArea) rba_BswSrv_ReleaseLockCommon()       /* TODO: Provide a proper Multicore implementation here */

#endif
