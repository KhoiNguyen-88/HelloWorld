/*<RBHead>
 ***************************************************************************************************
 *
 * (C) All rights reserved by ROBERT BOSCH GMBH, STUTTGART
 *
 ***************************************************************************************************
 *
 *    __   __   ___  ___
 *   /_ / /  / /__  /    /__/
 *  /__/ /__/ __ / /__  /  /
 *
 *
 ***************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Filename__:$
 * $Author____:$
 * $Function__:$
 * $Domain____:$
 * $User______:$
 * $Date______:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 * $Type______:$
 * $State_____:$
 * $FDEF______:$
 *
 * List of changes
 * $History___:$
 ***************************************************************************************************
 </RBHead>*/


/**************************************************************************************************/
/* Preprocessor includes                                                                          */
/**************************************************************************************************/

#include "Det_Priv.h"

#if(DET_SW_MAJOR_VERSION  != 1)
       #error BOSCH:DET.H is not compatible with DET_INIT.C
#endif
#if(DET_SW_MINOR_VERSION  != 0)
       #error BOSCH:DET.H is not compatible with DET_INIT.C
#endif
#if(DET_SW_PATCH_VERSION  != 0)
       #error BOSCH:DET.H is not compatible with DET_INIT.C
#endif

#if(DET_AR_RELEASE_MAJOR_VERSION  != 4)
       #error BOSCH:DET.H is not compatible with DET_INIT.C
#endif
#if(DET_AR_RELEASE_MINOR_VERSION  != 0)
       #error BOSCH:DET.H is not compatible with DET_INIT.C
#endif
#if(DET_AR_RELEASE_REVISION_VERSION  != 0)
       #error BOSCH:DET.H is not compatible with DET_INIT.C
#endif
#if(DET_VENDOR_ID != 6)
       #error BOSCH:DET.H is not compatible with DET_INIT.C
#endif
#define DET_START_SEC_CODE
#include "memmap.h"
/***************************************************************************************************

Function name       : FUNC(void,DET_CODE) Det_Init(void)
Parameters (in)     : None
Parameters (out)    : None
Return value        : None
Description         : Service for initialization of the Development Error Tracer.
                      After calling this API DET is initialised and can be used for
                      tracing the development error.

****************************************************************************************************/

 FUNC(void,DET_CODE) Det_Init(void)
   {
	Det_Ctr=0; /*Initialise the counter to Zero*/
	return;
   }
#define DET_STOP_SEC_CODE
#include "memmap.h"
