/*<RBHead>
 ***************************************************************************************************
 *
 * (C) All rights reserved by ROBERT BOSCH GMBH, STUTTGART
 *
 ***************************************************************************************************
 *
 *    __   __   ___  ___
 *   /_ / /  / /__  /    /__/
 *  /__/ /__/ __ / /__  /  /
 *
 *
 ***************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Filename__:$
 * $Author____:$
 * $Function__:$
 * $Domain____:$
 * $User______:$
 * $Date______:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 * $Type______:$
 * $State_____:$
 * $FDEF______:$
 *
 * List of changes
 * $History___:$
 ***************************************************************************************************
 </RBHead>*/


/**************************************************************************************************/
/* Preprocessor includes                                                                          */
/**************************************************************************************************/
#include "Det_Priv.h"

#if(DET_SW_MAJOR_VERSION  != 1)
       #error BOSCH:DET.H is not compatible with DET.C
#endif
#if(DET_SW_MINOR_VERSION  != 0)
       #error BOSCH:DET.H is not compatible with DET.C
#endif
#if(DET_SW_PATCH_VERSION  != 0)
       #error BOSCH:DET.H is not compatible with DET.C
#endif

#if(DET_AR_RELEASE_MAJOR_VERSION  != 4)
       #error BOSCH:DET.H is not compatible with DET.C
#endif
#if(DET_AR_RELEASE_MINOR_VERSION  != 0)
       #error BOSCH:DET.H is not compatible with DET.C
#endif
#if(DET_AR_RELEASE_REVISION_VERSION  != 0)
       #error BOSCH:DET.H is not compatible with DET.C
#endif
#if(DET_VENDOR_ID != 6)
       #error BOSCH:DET.H is not compatible with DET.C
#endif
#define DET_START_SEC_CODE
#include "memmap.h"

/***************************************************************************************************/
/* Variables																				       */
/***************************************************************************************************/
#define DET_START_SEC_VAR_NOINIT_UNSPECIFIED
#include "memmap.h" 
VAR(Det_ErrorRepType, DET_VAR)   Det_Errors[DET_CONFIG]; 
#define DET_STOP_SEC_VAR_NOINIT_UNSPECIFIED
#include "memmap.h"

#define DET_START_SEC_VAR_NOINIT_8BIT
#include "memmap.h" 
VAR(uint8, DET_VAR)   Det_Ctr; 
#define DET_STOP_SEC_VAR_NOINIT_8BIT
#include "memmap.h"
