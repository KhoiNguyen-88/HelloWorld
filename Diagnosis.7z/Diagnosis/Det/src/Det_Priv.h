/*<RBHead>
 ***************************************************************************************************
 *
 * (C) All rights reserved by ROBERT BOSCH GMBH, STUTTGART
 *
 ***************************************************************************************************
 *
 *    __   __   ___  ___
 *   /_ / /  / /__  /    /__/
 *  /__/ /__/ __ / /__  /  /
 *
 *
 ***************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Filename__:$
 * $Author____:$
 * $Function__:$
 * $Domain____:$
 * $User______:$
 * $Date______:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 * $Type______:$
 * $State_____:$
 * $FDEF______:$
 *
 * List of changes
 * $History___:$
 ***************************************************************************************************
 </RBHead>*/


/**************************************************************************************************/
/* Preprocessor includes                                                                          */
/**************************************************************************************************/

#ifndef DET_PRIV_H
#define DET_PRIV_H
#include "Det.h"
#include "SchM_Det.h"

/*
 ***************************************************************************************************
 * Type definitions
 ***************************************************************************************************
 */
typedef struct
{
	uint16 	moduleId;
	uint8	instanceId;
	uint8	apiId;
	uint8	errorId;
	
}Det_ErrorRepType;

/*
 ***************************************************************************************************
 * Extern declarations
 ***************************************************************************************************
 */

#define DET_START_SEC_VAR_NOINIT_UNSPECIFIED
#include "memmap.h" 
extern	VAR(Det_ErrorRepType, DET_VAR)   Det_Errors[DET_CONFIG]; /* Array to store the error logs*/
#define DET_STOP_SEC_VAR_NOINIT_UNSPECIFIED
#include "memmap.h"

#define DET_START_SEC_VAR_NOINIT_8BIT
#include "memmap.h" 
extern	VAR(uint8, DET_VAR)   Det_Ctr;  /* Det counter used for calculating Error Logs*/
#define DET_STOP_SEC_VAR_NOINIT_8BIT
#include "memmap.h"
#endif/*Det_Priv_h*/
