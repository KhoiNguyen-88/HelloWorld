/*<RBHead>
 ***************************************************************************************************
 *
 * (C) All rights reserved by ROBERT BOSCH GMBH, STUTTGART
 *
 ***************************************************************************************************
 *
 *    __   __   ___  ___
 *   /_ / /  / /__  /    /__/
 *  /__/ /__/ __ / /__  /  /
 *
 *
 ***************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Filename__:$
 * $Author____:$
 * $Function__:$
 * $Domain____:$
 * $User______:$
 * $Date______:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 * $Type______:$
 * $State_____:$
 * $FDEF______:$
 *
 * List of changes
 * $History___:$
 ***************************************************************************************************
 </RBHead>*/


/**************************************************************************************************/
/* Preprocessor includes                                                                          */
/**************************************************************************************************/

#ifndef DET_H
#define DET_H
#include "Det_Cfg.h"

#define DET_SW_MAJOR_VERSION    (1)
#define DET_SW_MINOR_VERSION    (0)
#define DET_SW_PATCH_VERSION    (0)
#define DET_VENDOR_ID           (6)
#define DET_MODULE_ID           (15)
#define DET_AR_RELEASE_MAJOR_VERSION    (4)
#define DET_AR_RELEASE_MINOR_VERSION    (0)
#define DET_AR_RELEASE_REVISION_VERSION (0)

#define DET_INSTANCE_ID         (0)
#define DET_START_SEC_CODE
#include "MemMap.h"
/***************************************************************************************************
Function name     	: FUNC(void,DET_CODE) Det_Init (void)
Parameters (in) 	: None
Parameters (out)	: None
Return value    	: None
Description     	: Service for initialization of the Development Error Tracer.
 ****************************************************************************************************/

extern FUNC(void,DET_CODE) Det_Init(void);
/***************************************************************************************************
Function name     	: FUNC(void,DET_CODE) Det_Start (
                                                   void
                                                  )
Parameters (in) 	: None
Parameters (out)	: None
Return value      	: None
Description         : Service for starting DET ,after the Det_Init has been called.
****************************************************************************************************/

extern FUNC(void,DET_CODE) Det_Start(void);

/***************************************************************************************************
 * @ingroup DET
 *
 *  Interface function provided to Service to report development errors.
 *  The call of Det_ReportError will cause calls to all configured callback functions
 *  ( Hook function)
 *
 * @param[in]       ModuleId        Module ID of calling module.
 * @param[in]       InstanceId      The identifier of the index based instance of a module, starting from 0,
 *                                  If the module is a single instance module it shall pass 0 as the InstanceId.
 * @param[in]       ApiId           ID of API service in which error is detected (defined in SWS of calling module)
 * @param[in]       ErrorId         ID of detected development error (defined in SWS of calling module).
 * @param[out]      None
 * @return          Std_ReturnType  returns always E_OK (is required for services)
 *
 ****************************************************************************************************/

extern FUNC(Std_ReturnType, DET_CODE) Det_ReportError(uint16 ModuleId, uint8 InstanceId, uint8 ApiId, uint8 ErrorId);


/**************************************************************************************************

Function name      : FUNC(void,DET_CODE) Det_GetVersionInfo
                       (
                           P2VAR(Std_VersionInfoType, AUTOMATIC, DET_APPL_DATA) versioninfo
                       )
Parameters (in)    : Pointer to structure-object of type Std_VersionInfoType
Parameters (out)   : Version info of this module
Return value       : None
Description        : This function when called, gives the version info as per Std_VersionInfoType


**************************************************************************************************/

extern FUNC(void,DET_CODE) Det_GetVersionInfo
                   (
                       P2VAR(Std_VersionInfoType, AUTOMATIC, DET_APPL_DATA) versioninfo
                    );
#define DET_STOP_SEC_CODE
#include "MemMap.h"
#endif/*DET_H*/
