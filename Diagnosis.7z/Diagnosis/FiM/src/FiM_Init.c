/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\FiM$
 * $Class_____:C$
 * $Name______:FiM_Init$
 * $Variant___:AR40.10.0.0$
 * $Revision__:1$
 **********************************************************************************************************************
 </BASDKey>*/

/**
 **************************************************************************************************
 * FiM_Init.c
 * Initialization functions  for Function Inhibition Manager
 * Design specification: AUTOSAR_SWS_FunctionInhibitionManager.pdf Version 4.0 Rev0002
 **************************************************************************************************
 */
#include "FiM_Init.h"
#include "FiM_Cfg.h"
#include "FiM.h"
#include "FiM_Utils.h"
#include "FiM_Status.h"
#include "FiM_Monitor.h"

#if (FIM_CFG_FIM_USED   ==  FIM_CFG_ON)

/**
 **************************************************************************************************
 * FiM global variables
 **************************************************************************************************
 */
/* Pointer to Global Config Structure */

#define FIM_START_SEC_RAM_INIT
#include "FiM_Cfg_MemMap.h"
P2CONST(FiM_ConfigType, FIM_VAR, FIM_CONST) FiM_ConfigParam_pcs = NULL_PTR;
#define FIM_STOP_SEC_RAM_INIT
#include "FiM_Cfg_MemMap.h"

#define FIM_START_SEC_RAM_CLEARED
#include "FiM_Cfg_MemMap.h"
/* Status initialization variable during Init and ReInit */
VAR(boolean,FIM_VAR_POWER_ON_INIT) FiM_StatusInitialized_b;
VAR(boolean,FIM_VAR_POWER_ON_INIT) FiM_DemInitStatus_b;
#define FIM_STOP_SEC_RAM_CLEARED
#include "FiM_Cfg_MemMap.h"

/**
 **************************************************************************************************
 * FiM_Init (public API)
 **************************************************************************************************
 */
#define FIM_START_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"

FUNC(void,FIM_CODE) FiM_Init(P2CONST(FiM_ConfigType, FIM_VAR, FIM_APPL_CONST) FiMConfigPtr)
{
    if(!FiM_Priv_GetStatusInitialized())
    {
        if(FiMConfigPtr != NULL_PTR)
        {
            FiM_ConfigParam_pcs = FiMConfigPtr;
        }
        else
        {
            FiM_ConfigParam_pcs = &FIM_POSTBUILD_CONFIGSET_NAME;
        }

        FiM_Priv_SetStatusInitialized(FALSE);
        FiM_Priv_SetDemInitStatus(FALSE);

#if (FIM_CFG_DEM_TRIGGERFIMREPORTS == FIM_CFG_OFF)
        FiM_Priv_MonitorInit();
#endif

        FiM_Priv_SetStatusInitialized(TRUE);
    }
    else
    {
        FIM_PRIV_DET_ERROR(FIM_INIT_ID,FIM_E_INITIALIZED_ALREADY);
    }
}

/**
 **************************************************************************************************
 * FiM_DemInit (public API)
 **************************************************************************************************
 */
FUNC(void,FIM_CODE) FiM_DemInit(void)
{
    if (FiM_Priv_GetStatusInitialized())
    {
        if(!FiM_Priv_IsDemInitCalled())
        {
            /* Setting the Re-Initialization requested flag to TRUE */
            FiM_Priv_SetDemInitStatus(TRUE);

            /* For the cyclic mode, the actual Re-initialization of the monitoring state machine is done as part of the FiM_MainFunction,
             * this is to ensure that the FiM_MainFunction and FiM_DemInit are not running in parallel
             */

            FiM_Priv_StatusInit();

        }
        else
        {
            FIM_PRIV_DET_ERROR(FIM_DEMINIT_ID, FIM_E_DEMINIT_CALLED_ALREADY);
        }
    }
    else
    {
        FIM_PRIV_DET_ERROR(FIM_DEMINIT_ID, FIM_E_NOT_INITIALIZED);
    }

}

#define FIM_STOP_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"

#endif /*FIM_CFG_FIM_USED   ==  FIM_CFG_ON*/

/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.10.0.0; 1     16.06.2015 LIB8FE
 *   CSCRM00879912
 * 
 * AR40.10.0.0; 0     17.04.2015 LIB8FE
 *   CSCRM00825119
 * 
 * AR40.9.0.0; 1     23.12.2014 BPE4COB
 *   CSCRM00756374
 * 
 * AR40.9.0.0; 0     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.8.0.0; 0     17.03.2014 PMJ3KOR
 *   CSCRM00620467
 * 
 * AR40.7.0.0; 3     21.11.2013 GIN9COB
 *   CSCRM00598921
 * 
 * AR40.7.0.0; 2     23.10.2013 BPE4COB
 *   CSCRM00560923: Provided Memmap header
 * 
 * AR40.7.0.0; 1     17.09.2013 BPE4COB
 *   CSCRM00533943: [FiM]Implemented Multicore Support
 * 
 * AR40.7.0.0; 0     22.08.2013 BPE4COB
 *   CSCRM00479164: Updated Bamf and header file inclusions
 * 
 * AR40.6.0.0; 2     03.07.2013 BPE4COB
 *   CSCRM00547036 : Review Points Fixed.
 * 
 * $
 **********************************************************************************************************************
 </BASDKey>*/
/* FC_VariationPoint_END */

