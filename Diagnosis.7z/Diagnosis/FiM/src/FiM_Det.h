/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\FiM$
 * $Class_____:H$
 * $Name______:FiM_Det$
 * $Variant___:AR40.10.0.0$
 * $Revision__:1$
 **********************************************************************************************************************
 </BASDKey>*/

/**
 **************************************************************************************************
 * FiM_Det.h
 * Version header to be used by the Det or by Det reports
 * Design specification: AUTOSAR_SWS_FunctionInhibitionManager.pdf Version 4.0 Rev0002
 **************************************************************************************************
 */

#ifndef FIM_DET_H
#define FIM_DET_H

#include "Det.h"
#include "FiM_Utils.h"
#include "FiM_Version.h"

/* public DET report API IDs for FiM according to Autosar*/
#define FIM_INIT_ID						0x00
#define FIM_GETFUNCTIONPERMISSION_ID	0x01
#define FIM_DEMTRIGGERONEVENTSTATUS_ID	0x02
#define FIM_DEMINIT_ID					0x03
#define FIM_GETVERSIONINFO_ID			0x04
#define FIM_MAINFUNCTION_ID				0x05

/* private DET report API IDs for FiM (RB-specific), start with 0xB* */
#define FIM_PRIV_STATUSINIT_ID				0xB1
#define FIM_PRIV_MONITOR_ID					0xB2
#define FIM_PRIV_MONITORCOUNTERDEC_ID		0xB3
#define FIM_PRIV_FIDCOUNTDEC_ID				0xB4
#define FIM_PRIV_DEMGETEVENTSTATUS_ID		0xB5

/* standard error ids for DET API interfaces, OBD services report the development errors to DET module */
#define FIM_E_WRONG_PERMISSION_REQ					 0x01
#define FIM_E_WRONG_TRIGGER_ON_EVENT				 0x02
#define FIM_E_FID_OUT_OF_RANGE						 0x03
#define FIM_E_EVENTID_OUT_OF_RANGE					 0x04
#define FIM_E_INVALID_POINTER						 0x05
#define FIM_E_INVALID_EVENTSTATUSEXTENDEDTYPE		 0x06

/* RB-specific errors start with 0xB* */
#define FIM_E_FID_COUNTERNEGATIVE				 0xB1
#define FIM_E_FID_MONITORUNPLAUSIBLE			 0xB2
#define FIM_E_MONITORSTATE_INVALID				 0xB3
#define FIM_E_NOT_INITIALIZED					 0xB4
#define FIM_E_DEMGETEVENTSTATUS_NOK				 0xB5
//#define FIM_E_CALL_DURING_DEMINIT				 0xB6
#define FIM_E_DEMINIT_NOT_CALLED				 0xB7
#define FIM_E_DEMINIT_CALLED_ALREADY			 0xB8
#define FIM_E_INITIALIZED_ALREADY				 0xB9

/* FiM uses below mentioned DET API interface function to report the development error to DET Module */
LOCAL_INLINE void FIM_PRIV_DET_ERROR (uint8 FiM_ApiId, uint8 FiM_ErrorId)
{
#if (FIM_CFG_DEV_ERROR_DETECT != FIM_CFG_OFF)
    FIM_USE_VAR(Det_ReportError(FIM_MODULE_ID, FIM_INSTANCE_ID, FiM_ApiId, FiM_ErrorId));
#else
    FIM_USE_VAR(FiM_ApiId);
    FIM_USE_VAR(FiM_ErrorId);
#endif
}

#endif /* include protection */

/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.10.0.0; 1     14.07.2015 WUG3ABT
 *   Checkout by wug3abt
 * 
 * AR40.10.0.0; 0     16.06.2015 LIB8FE
 *   CSCRM00879912
 * 
 * AR40.9.0.0; 1     23.12.2014 BPE4COB
 *   CSCRM00756374
 * 
 * AR40.9.0.0; 0     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.8.0.0; 0     17.03.2014 PMJ3KOR
 *   CSCRM00620467
 * 
 * AR40.6.0.0; 1     03.07.2013 BPE4COB
 *   CSCRM00547036 : Review Points Fixed.
 * 
 * AR40.6.0.0; 0     14.06.2013 BPE4COB
 *   Implemented CSCRM00526806
 * 
 * AR40.5.0.0; 0     15.11.2012 WUG3ABT
 *   CSCRM00472092:
 *   introduce additional flag to support GetFunctionPermission during reinit
 * 
 * AR40.4.0.0; 3     07.08.2012 WUG3ABT
 *   CSCRM00356132
 *   Complete Det reports
 * 
 * AR40.4.0.0; 2     07.08.2012 WUG3ABT
 *   adapt to new name schema
 * 
 * $
 **********************************************************************************************************************
 </BASDKey>*/
/* FC_VariationPoint_END */
