/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\FiM$
 * $Class_____:C$
 * $Name______:FiM_Dem$
 * $Variant___:AR40.11.0.0$
 * $Revision__:1$
 **********************************************************************************************************************
 </BASDKey>*/

/**
 **************************************************************************************************
 * FiM_Dem.c
 * Interface functions to Dem for Function Inhibition Manager, i.e. FiM_DemTriggerOnEventStatus()
 * Design specification: AUTOSAR_SWS_FunctionInhibitionManager.pdf Version 4.0 Rev0002
 **************************************************************************************************
 */

#include "FiM_Init.h"
#include "FiM.h"
#include "Dem.h"
#include "FiM_Det.h"
#include "FiM_Status.h"
#include "FiM_Monitor.h"
#include "FiM_Cfg_SchM.h"

#if (FIM_CFG_FIM_USED    ==    FIM_CFG_ON)
/**
 **************************************************************************************************
 * FiM_Dem_TriggerOnEventStatus (public API)
 **************************************************************************************************
 */
#if (FIM_CFG_DEM_TRIGGERFIMREPORTS == FIM_CFG_ON)

#define FIM_START_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"

FUNC(void,FIM_CODE) FiM_DemTriggerOnEventStatus(VAR(Dem_EventIdType, AUTOMATIC) EventId,VAR(uint8, AUTOMATIC) EventStatusOld, VAR(uint8, AUTOMATIC) EventStatusNew)
{
    VAR(uint32, AUTOMATIC) idxFidOffset_u32 = 0;
    VAR(uint32, AUTOMATIC) idxEnd_u32 = 0;
    VAR(FiM_FunctionIdType, AUTOMATIC) FId_uo = 0;
    VAR(FiM_InhibitionMaskType, AUTOMATIC) inhMaskConfig_uo = 0;
    VAR(boolean, AUTOMATIC) inhMaskChanged_b = FALSE;
    VAR(boolean, AUTOMATIC) inhMaskSet_b = FALSE;
#if (FIM_CFG_SERVICE07_VISIBLE_ERROR_API == FIM_CFG_ON)
    VAR(boolean, AUTOMATIC) serv07MaskChanged_b = FALSE;
    VAR(Dem_DTCKindType, AUTOMATIC) dtcKind = DEM_DTC_KIND_ALL_DTCS;
#endif

    if(FiM_Priv_GetStatusInitialized())
    {
        /* Check whether the Re-initialization is completed */
        if(FiM_Priv_IsDemInitCalled())
        {
            if((EventId <= FIM_CFG_NUMBEROFDEMEVENTIDS) && (EventId > 0))
            {
                inhMaskChanged_b = (((EventStatusOld & FIM_INHIBITION_BITS_MASK) ^ (EventStatusNew & FIM_INHIBITION_BITS_MASK)) != 0u);

#if (FIM_CFG_SERVICE07_VISIBLE_ERROR_API == FIM_CFG_ON)
                if(Dem_GetDtcKindOfEvent(EventId, &dtcKind) == E_OK)
                {
                    if(dtcKind == DEM_DTC_KIND_EMISSION_REL_DTCS)
                    {
                        /* Calculation of service$07 visibility entry*/
                        serv07MaskChanged_b = (((EventStatusOld & FIM_PENDING_BITS_MASK) ^ (EventStatusNew & FIM_PENDING_BITS_MASK)) != 0u);
                    }
                }
#endif

                /* Did the inhibition relevant bits change at all? */
                if(( inhMaskChanged_b)
#if (FIM_CFG_SERVICE07_VISIBLE_ERROR_API == FIM_CFG_ON)
                        || (serv07MaskChanged_b)
#endif
                )
                {
                    if(FiM_ConfigParam_pcs != NULL_PTR)
                    {
                        idxEnd_u32 = (FiM_ConfigParam_pcs->FiM_Cfg_NumOffsetEventptr[EventId+1]);
                        idxFidOffset_u32 = (FiM_ConfigParam_pcs->FiM_Cfg_NumOffsetEventptr[EventId]);

                        /* loop through all FIds attached to the event */
                        while( idxFidOffset_u32 < idxEnd_u32 )
                        {
                            FId_uo = (FiM_ConfigParam_pcs->FiM_CfgInhibitSourceMatrixptr[idxFidOffset_u32]);
                            inhMaskConfig_uo = (FiM_ConfigParam_pcs->FiM_CfgInhibitMaskMatrixptr[idxFidOffset_u32]);

                            /* did the inhibition bits of the configured mask change? */
                            if(inhMaskChanged_b)
                            {
                                if(( FiM_Priv_IsInhibitionChanged(EventStatusNew, EventStatusOld, inhMaskConfig_uo, &inhMaskSet_b)))
                                {
                                    if(inhMaskSet_b)
                                    {
                                        /* if FAILED, increment counter and lock FId */
                                        FiM_Priv_FIdCountInc(FId_uo);
                                    }
                                    else
                                    {
                                        /* if NOT FAILED, decrement counter and check whether lock can be released */
                                        FiM_Priv_FIdCountDec(FId_uo);
                                    }
                                }
                            }

#if (FIM_CFG_SERVICE07_VISIBLE_ERROR_API == FIM_CFG_ON)
                            if(serv07MaskChanged_b)
                            {
                                if(FiM_Priv_IsInhMaskServ07Relevant(inhMaskConfig_uo))
                                {
                                    /* Calculate service$07 entry for event */
                                    if((EventStatusNew & FIM_PENDING_BITS_MASK) == FIM_PENDING_BITS_MASK)
                                    {
                                        /* if EVENT is visible in service$07 then increment counter for FId */
                                        FiM_Priv_FIdServ07CountInc(FId_uo);
                                    }
                                    else
                                    {
                                        if((EventStatusNew & FIM_PENDING_BITS_MASK) != FIM_PENDING_BITS_MASK)
                                        {
                                            /* if EVENT is visible in service$07 then decrement counter for FId */
                                            FiM_Priv_FIdServ07CountDec(FId_uo);
                                        }
                                    }
                                }
                            }
#endif
                            idxFidOffset_u32++;
                        }
                    }
                    else
                    {
                        FIM_PRIV_DET_ERROR(FIM_DEMTRIGGERONEVENTSTATUS_ID,FIM_E_INVALID_POINTER);
                    }
                }
            }
            /* detect development errors / plausibility checks */
            else
            {
                if((EventId > FIM_CFG_NUMBEROFDEMEVENTIDS) || (EventId == DEM_EVENTID_INVALID))
                {
                    FIM_PRIV_DET_ERROR(FIM_DEMTRIGGERONEVENTSTATUS_ID,FIM_E_EVENTID_OUT_OF_RANGE);
                }
            }
        }
        /* FiM is not yet Re-initialized */
        else
        {
            FIM_PRIV_DET_ERROR(FIM_DEMTRIGGERONEVENTSTATUS_ID,FIM_E_DEMINIT_NOT_CALLED);
        }
    }
    /* detect development errors / plausibility checks */
    else
    {
        FIM_PRIV_DET_ERROR(FIM_DEMTRIGGERONEVENTSTATUS_ID,FIM_E_NOT_INITIALIZED);
    }
    return;
}

#define FIM_STOP_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"

#endif
#endif /*FIM_CFG_FIM_USED    ==    FIM_CFG_ON*/

/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.11.0.0; 1     16.12.2015 LIB8FE
 *   CSCRM01004877
 * 
 * AR40.11.0.0; 0     05.10.2015 LIB8FE
 *   CSCRM00981002
 * 
 * AR40.10.0.0; 2     14.07.2015 WUG3ABT
 *   Checkout by wug3abt
 * 
 * AR40.10.0.0; 1     16.06.2015 LIB8FE
 *   CSCRM00879912
 * 
 * AR40.10.0.0; 0     26.02.2015 LIB8FE
 *   CSCRM00788202
 * 
 * AR40.9.0.0; 2     06.01.2015 GJ83ABT
 *   CSCRM00751490
 * 
 * AR40.9.0.0; 1     23.12.2014 BPE4COB
 *   CSCRM00756374
 * 
 * AR40.9.0.0; 0     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.8.0.0; 0     17.03.2014 PMJ3KOR
 *   CSCRM00620467
 * 
 * AR40.7.0.0; 4     21.11.2013 GIN9COB
 *   CSCRM00598921
 * 
 * $
 **********************************************************************************************************************
 </BASDKey>*/
/* FC_VariationPoint_END */
