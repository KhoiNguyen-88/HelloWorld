/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\FiM$
 * $Class_____:C$
 * $Name______:FiM_Version$
 * $Variant___:AR40.10.0.0$
 * $Revision__:0$
 **********************************************************************************************************************
 </BASDKey>*/

/**
 **************************************************************************************************
 * FiM_Version.c
 * version API for Function Inhibition Manager
 * Design specification: AUTOSAR_SWS_FunctionInhibitionManager.pdf Version 4.0 Rev0002
 **************************************************************************************************
 */
#include "FiM_Cfg.h"
#include "FiM.h"
#include "FiM_Det.h"
#include "FiM_Version.h"
#include "Dem.h"
#include "Bfx.h"

/**
 **************************************************************************************************
 * version compatibility check for Det according to [AR402:FIM023]
 **************************************************************************************************
 */
#ifndef DET_AR_RELEASE_MAJOR_VERSION
#error DET_AR_RELEASE_MAJOR_VERSION is not defined or not visible via Det.h (see AUTOSAR 4.0.2 BSW00318 and BSW004) !
#else
#if (DET_AR_RELEASE_MAJOR_VERSION != FIM_AR_RELEASE_MAJOR_VERSION)
#error DET_AR_RELEASE_MAJOR_VERSION is not compatible to the FiM version (see AUTOSAR 4.0.2 BSW00318 and BSW004) !
#endif
#endif

#ifndef DET_AR_RELEASE_MINOR_VERSION
#error DET_AR_RELEASE_MINOR_VERSION is not defined or not visible via Det.h (see AUTOSAR 4.0.2 BSW00318 and BSW004) !
#else
#if (DET_AR_RELEASE_MINOR_VERSION != FIM_AR_RELEASE_MINOR_VERSION)
#error DET_AR_RELEASE_MINOR_VERSION is not compatible to the FiM version (see AUTOSAR 4.0.2 BSW00318 and BSW004) !
#endif
#endif

/**
 **************************************************************************************************
 * version compatibility check for Dem [AR402:FIM023]
 **************************************************************************************************
 */
#ifndef DEM_AR_RELEASE_MAJOR_VERSION
#error DEM_AR_RELEASE_MAJOR_VERSION is not defined or not visible via Dem.h (see AUTOSAR 4.0.2 BSW00318 and BSW004) !
#else
#if (DEM_AR_RELEASE_MAJOR_VERSION != FIM_AR_RELEASE_MAJOR_VERSION)
#error DEM_AR_RELEASE_MAJOR_VERSION is not compatible to the FiM version (see AUTOSAR 4.0.2 BSW00318 and BSW004) !
#endif
#endif

#ifndef DEM_AR_RELEASE_MINOR_VERSION
#error DEM_AR_RELEASE_MINOR_VERSION is not defined or not visible via Dem.h (see AUTOSAR 4.0.2 BSW00318 and BSW004) !
#else
#if (DEM_AR_RELEASE_MINOR_VERSION != FIM_AR_RELEASE_MINOR_VERSION)
#error DEM_AR_RELEASE_MINOR_VERSION is not compatible to the FiM version (see AUTOSAR 4.0.2 BSW00318 and BSW004) !
#endif
#endif

/**
 **************************************************************************************************
 * version compatibility check for Bfx [AR402:FIM023]
 **************************************************************************************************
 */
#ifndef BFX_AR_RELEASE_MAJOR_VERSION
#error BFX_AR_RELEASE_MAJOR_VERSION is not defined or not visible via Bfx.h (see AUTOSAR 4.0.2 BSW00318 and BSW004) !
#else
#if (BFX_AR_RELEASE_MAJOR_VERSION != FIM_AR_RELEASE_MAJOR_VERSION)
#error BFX_AR_RELEASE_MAJOR_VERSION is not compatible to the FiM version (see AUTOSAR 4.0.2 BSW00318 and BSW004) !
#endif
#endif

#ifndef BFX_AR_RELEASE_MINOR_VERSION
#error BFX_AR_RELEASE_MINOR_VERSION is not defined or not visible via Bfx.h (see AUTOSAR 4.0.2 BSW00318 and BSW004) !
#else
#if (BFX_AR_RELEASE_MINOR_VERSION != FIM_AR_RELEASE_MINOR_VERSION)
#error BFX_AR_RELEASE_MINOR_VERSION is not compatible to the FiM version (see AUTOSAR 4.0.2 BSW00318 and BSW004) !
#endif
#endif

#if (FIM_CFG_FIM_USED   ==  FIM_CFG_ON)
/**
 **************************************************************************************************
 * FiM_GetVersionInfo (public API)
 **************************************************************************************************
 */
#if (FIM_CFG_VERSION_INFO_API == FIM_CFG_ON)
#define FIM_START_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"

FUNC(void,FIM_CODE) FiM_GetVersionInfo(P2VAR(Std_VersionInfoType, AUTOMATIC, FIM_APPL_DATA) versioninfo)
{

    if (versioninfo != NULL_PTR)
    {
        versioninfo->vendorID = FIM_VENDOR_ID;
        versioninfo->moduleID = FIM_MODULE_ID;
        versioninfo->sw_major_version = FIM_SW_MAJOR_VERSION;
        versioninfo->sw_minor_version = FIM_SW_MINOR_VERSION;
        versioninfo->sw_patch_version = FIM_SW_PATCH_VERSION;
    }
    else
    {
        FIM_PRIV_DET_ERROR(FIM_GETVERSIONINFO_ID,FIM_E_INVALID_POINTER);
    }
    return;
}

#define FIM_STOP_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"
#endif

#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 0     16.06.2015 LIB8FE
*   CSCRM00879912
* 
* AR40.9.0.0; 0     17.11.2014 GJ83ABT
*   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
* 
* AR40.8.0.0; 0     17.03.2014 PMJ3KOR
*   CSCRM00620467
* 
* AR40.7.0.0; 1     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 0     23.10.2013 BPE4COB
*   CSCRM00560923: Provided Memmap header
* 
* AR40.6.0.0; 0     14.06.2013 BPE4COB
*   Implemented CSCRM00526806
* 
* AR40.5.0.0; 1     07.01.2013 KAN1COB
*   Git transfer - >c7b60f6605db2476a382daf05b17f6c7f088f2d2
*   Fix- Obd Drv cycle and warmup cyce not configured in operationcycles
*   * CSCRM00479194 - [INT-Dem] pending review findings from CSCRM00434163
*   CSCRM00483492 - [INT-Dem] Fix findings -Vendor Specific parameters optional
*   CSCRM00479560 - [INT-DEM] Issue from PAC_DevDiagnosis November build
*   CSCRM00479557 - [INT-DEM] Remove compilation warnings
*   CSCRM00484190 - [INT-Dem] Fix Medium/Strong review findings
*   CSCRM00484194 - [INT-Dem] Fix Medium/Strong review findings
*   CSCRM00480461 : Fix Reviewfindings : 
*   Review12_636_COMP_Dem_AR40_5_2012-10_3.xls
*   CSCRM00482583: OBD: Fix review findings
*   Changes during code analysis of Defect CSCRM00467070 (DemClearDTCBehavior)
*   QAC-warning
*   
*   CSCRM00479820 - [INT-FIM] Fix review findings
*   CSCRM00479857 - [INT - FIM] remove BCT errors and warnings shown in 
*   problemes log
* 
* AR40.5.0.0; 0     11.10.2012 KAN1COB
*   CSCRM00383045 - [FiM] Zero configuration support
* 
* AR40.5_2012-07; 0     17.07.2012 WUG3ABT
*   code review solved
*   CSCRM00371650
*   - define to enum conversion
*   - LARGE_RAM to RAM only rename
*   - typos
*   - function does not need a return value
*   - new function ChangeAndReset bits
*   - removed unnecessary header includes
* 
* AR40.4.0.0; 1     09.07.2012 BRM2COB
*   History info updated.
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
