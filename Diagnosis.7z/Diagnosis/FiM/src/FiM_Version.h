/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\FiM$
 * $Class_____:H$
 * $Name______:FiM_Version$
 * $Variant___:AR40.11.0.0$
 * $Revision__:0$
 **********************************************************************************************************************
 </BASDKey>*/

/**
 **************************************************************************************************
 * FiM_Version.h
 * Version header for Function Inhibition Manager
 * Design specification: AUTOSAR_SWS_FunctionInhibitionManager.pdf Version 4.0 Rev0002
 **************************************************************************************************
 */

#ifndef FIM_VERSION_H
#define FIM_VERSION_H

/* instance number of the FIM, there is only one instance */
#define FIM_INSTANCE_ID                        0
/* vendor ID for CUBAS module. RB has been assigned the value 6 */
#define FIM_VENDOR_ID                          6
/* module ID as assigned in the AUTOSAR architecture = 011 */
#define FIM_MODULE_ID                          11

/* major AUTOSAR version */
#define FIM_AR_RELEASE_MAJOR_VERSION           4
/* minor AUTOSAR version */
#define FIM_AR_RELEASE_MINOR_VERSION           0
/* AUTOSAR revision */
#define FIM_AR_RELEASE_REVISION_VERSION        2

/* CUBAS FIM module SW major version */
#define FIM_SW_MAJOR_VERSION                   11
/* CUBAS FIM module SW minor version */
#define FIM_SW_MINOR_VERSION                   0
/* CUBAS FIM module SW bugfix version */
#define FIM_SW_PATCH_VERSION                   0

#endif /* include protection */

/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.11.0.0; 0     06.08.2015 LIB8FE
 *   CSCRM00965314
 * 
 * AR40.10.0.0; 0     16.06.2015 LIB8FE
 *   CSCRM00879912
 * 
 * AR40.9.0.0; 1     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.9.0.0; 0     12.09.2014 DDO5KOR
 *   CSCRM00717760
 * 
 * AR40.8.0.0; 0     17.03.2014 PMJ3KOR
 *   CSCRM00620467
 * 
 * AR40.6.0.0; 0     14.06.2013 BPE4COB
 *   Implemented CSCRM00526806
 * 
 * AR40.5.0.0; 0     08.01.2013 WUG3ABT
 *   rename file variant of files that do not fit into the schema
 *   
 *   no change of content
 * 
 * AR40.5_2012-07; 0     17.07.2012 WUG3ABT
 *   code review solved
 *   CSCRM00371650
 *   - define to enum conversion
 *   - LARGE_RAM to RAM only rename
 *   - typos
 *   - function does not need a return value
 *   - new function ChangeAndReset bits
 *   - removed unnecessary header includes
 * 
 * AR40.4.0.0; 1     09.07.2012 BRM2COB
 *   History info updated.
 * 
 * AR40.4.0.0; 0     05.07.2012 DCO2SI
 *   CSCRM00432316
 *   release version name for Cubas Release
 *   AR40.4.0.0 introduced
 *   no functional change
 * 
 * $
 **********************************************************************************************************************
 </BASDKey>*/
/* FC_VariationPoint_END */
