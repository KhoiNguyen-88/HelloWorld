/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\FiM$
 * $Class_____:H$
 * $Name______:FiM_Priv_Data$
 * $Variant___:AR40.10.0.0$
 * $Revision__:1$
 **********************************************************************************************************************
 </BASDKey>*/

#ifndef FIM_PRIV_DATA_H
#define FIM_PRIV_DATA_H

/**
 **************************************************************************************************
 * Includes
 **************************************************************************************************
 */

#include "FiM_Cfg_Fids.h"
#include "FiM_Cfg.h"
/**
 **************************************************************************************************
 * FiM configuration derived types
 **************************************************************************************************
 */

/* Fim inhibition mask configuration [AR402:FIM096_Conf], */
/* values for FiM_InhibitionMaskType */
#define FIM_RB_NO_INHIBITS              0u  /* limit added for neutral calibration, RB-specific */
#define FIM_CFG_LAST_FAILED             1u  /* TESTFAILED = 1 */
#define FIM_CFG_NOT_TESTED              2u  /* TNCTOC = 1 */
#define FIM_CFG_TESTED                  3u  /* TNCTOC = 0 */
#define FIM_CFG_TESTED_AND_FAILED       4u  /* TESTFAILED = 1 AND TNCTOC = 0 */
#define FIM_CFG_FAILED_OR_NOT_TESTED    5u  /* TESTFAILED = 1 OR TNCTOC = 1, RB-specific */

/* type for FiM status handling */

#if (FIM_CFG_MAXIMUM_EVENTS_PER_FID_CALC <= 0xFF)
typedef uint8 FiM_FIdStatusCounterType;
#define FIM_CFG_STATUSCOUNTERMAX 0xFF
#else
typedef uint16 FiM_FIdStatusCounterType;
#define FIM_CFG_STATUSCOUNTERMAX 0xFFFF
#endif

#if (FIM_CFG_FIM_USED   ==  FIM_CFG_ON)

/**
 **************************************************************************************************
 * FiM configuration derived access functions
 **************************************************************************************************
 */

/* prototypes for data structures */

#define FIM_START_SEC_ROM_CONST
#include "FiM_Cfg_MemMap.h"

extern CONST (FiM_NumOffsetEventType, FIM_CONST) FiM_Cfg_NumOffsetEvent_auo[FIM_CFG_NUMBEROFDEMEVENTIDS + 2];
extern CONST (FiM_FunctionIdType, FIM_CONST) FiM_CfgInhibitSourceMatrix_au16[FIM_CFG_MAX_TOTAL_LINKS_CALC];
extern CONST (FiM_InhibitionMaskType, FIM_CONST) FiM_CfgInhibitMaskMatrix_au16[FIM_CFG_MAX_TOTAL_LINKS_CALC];

#define FIM_STOP_SEC_ROM_CONST
#include "FiM_Cfg_MemMap.h"

#endif /*FIM_CFG_FIM_USED   ==  FIM_CFG_ON*/

#endif /* include protection */

/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.10.0.0; 1     14.07.2015 WUG3ABT
 *   Checkout by wug3abt
 * 
 * AR40.10.0.0; 0     26.03.2015 LIB8FE
 *   CSCRM00782640
 * 
 * AR40.9.0.0; 0     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.8.0.0; 0     17.03.2014 PMJ3KOR
 *   CSCRM00620467
 * 
 * AR40.7.0.0; 4     12.12.2013 GET1COB
 *   CSCRM00597621
 * 
 * AR40.7.0.0; 3     21.11.2013 GIN9COB
 *   CSCRM00598921
 * 
 * AR40.7.0.0; 2     23.10.2013 BPE4COB
 *   CSCRM00560923: Provided Memmap header
 * 
 * AR40.7.0.0; 1     20.10.2013 HNH2ABT
 *   CSCRM00583641
 * 
 * AR40.7.0.0; 0     22.08.2013 BPE4COB
 *   CSCRM00479164: Updated Bamf and header file inclusions
 * 
 * AR40.6.0.0; 1     03.07.2013 BPE4COB
 *   CSCRM00547036 : Review Points Fixed.
 * 
 * $
 **********************************************************************************************************************
 </BASDKey>*/
/* FC_VariationPoint_END */
