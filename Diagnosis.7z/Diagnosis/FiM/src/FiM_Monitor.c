/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\FiM$
 * $Class_____:C$
 * $Name______:FiM_Monitor$
 * $Variant___:AR40.11.0.0$
 * $Revision__:0$
 **********************************************************************************************************************
 </BASDKey>*/

/**
 **************************************************************************************************
 * FiM_Monitor.c
 * source for background monitor of Function Inhibition Manager
 * (only used with LARGE / RUNTIME optimal configuration
 **************************************************************************************************
 */

#include "FiM_Priv_Data.h"

#if (FIM_CFG_FIM_USED   ==  FIM_CFG_ON)

#if (FIM_CFG_DEM_TRIGGERFIMREPORTS == FIM_CFG_OFF)

#include "Dem.h"
#include "FiM.h"
#include "Rte_FiM.h"
#include "FiM_Version.h"
#include "FiM_Utils.h"
#include "FiM_Det.h"
#include "FiM_Status.h"
#include "Std_Types.h"
#include "FiM_Monitor.h"
#include "FiM_Init.h"
#include "FiM_Cfg_SchM.h"
#include "FiM_Cfg_Callback.h"

/**
 **************************************************************************************************
 * local defines
 **************************************************************************************************
 */

/**
 **************************************************************************************************
 * global variables
 **************************************************************************************************
 */

#define FIM_START_SEC_RAM_INIT
#include "FiM_Cfg_MemMap.h"
/* Variable to store the State of the monitoring state machine */
static VAR(FiM_Priv_MonitorStateType, FIM_VAR) FiM_Priv_MonitorState_e = FIM_PRIV_MONSTATE_INIT;
/* Variable to store the Current Monitoring FID */
static VAR(FiM_FunctionIdType, FIM_VAR) FiM_Priv_CurrentMonitoringFId_uo = 1;
/* Variable to store the Current Monitoring Event Id */
static VAR(Dem_EventIdType, FIM_VAR) FiM_Priv_CurrentMonitoringEventId_uo = 0;
#define FIM_STOP_SEC_RAM_INIT
#include "FiM_Cfg_MemMap.h"

/* cyclic monitoring process is called in the FiM_MainFunction */

#define FIM_START_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"

FUNC(void, FIM_CODE) FiM_Priv_MonitorProc(void)
{
#if (FIM_CFG_SERVICE07_VISIBLE_ERROR_API == FIM_CFG_ON)
    VAR(Dem_DTCKindType, AUTOMATIC) dtcKind = DEM_DTC_KIND_ALL_DTCS;
#endif

    switch (FiM_Priv_MonitorState_e)
    {
        case FIM_PRIV_MONSTATE_INIT:
        {
            FIM_PRIV_ENTERLOCK_MONITOR();

            /* Switch CURRENT and LAST Index of the two bit arrays */
            if (FiM_CurrentIdx == 0)
            {
                FiM_LastIdx = 0;
                FiM_CurrentIdx = 1;
            }
            else
            {
                FiM_LastIdx = 1;
                FiM_CurrentIdx = 0;
            }

            FIM_PRIV_EXITLOCK_MONITOR();

            /* Reset the CURRENT bit array to Zero */
            FIM_USE_VAR( FIM_LIBMEMSET(FiM_FIdStatusBitArray_au8[FiM_CurrentIdx], FIM_PRIV_ZERO,
                    sizeof(FiM_FIdStatusBitArray_au8[FiM_CurrentIdx])));
#if (FIM_CFG_SERVICE07_VISIBLE_ERROR_API == FIM_CFG_ON)
            FIM_USE_VAR( FIM_LIBMEMSET(FiM_FIdStatusServ07BitArray_au8[FiM_CurrentIdx], FIM_PRIV_ZERO,
                    sizeof(FiM_FIdStatusServ07BitArray_au8[FiM_CurrentIdx])));
#endif
            /* Initialize the values for CHECK state */
            FiM_Priv_CurrentMonitoringFId_uo = 0;
            FiM_Priv_CurrentMonitoringEventId_uo = 1;

            /* Transit to next state CHECK */
            FiM_Priv_MonitorState_e = FIM_PRIV_MONSTATE_CHECK;
        }
            break;

        case FIM_PRIV_MONSTATE_CHECK:
        {
            VAR(uint32, AUTOMATIC) idxFidOffset_u32;
            VAR(uint32, AUTOMATIC) idxEnd_u32;
            VAR(FiM_FunctionIdType, AUTOMATIC) FId_uo;
            VAR(uint8, AUTOMATIC) demExtendedEventStatus_u8;
#if (FIM_CFG_SERVICE07_VISIBLE_ERROR_API == FIM_CFG_ON)
            VAR(uint8, AUTOMATIC) inhMaskConfig_uo = 0;
#endif

            VAR(Dem_EventIdType, AUTOMATIC) numberOfEvents_uo = FIM_PRIV_EVENTSPERMONITORCHECK;

            while (numberOfEvents_uo > 0u)
            {
                numberOfEvents_uo--;
                /* Ask for the event status */
                if (Dem_GetEventStatus(FiM_Priv_CurrentMonitoringEventId_uo, &demExtendedEventStatus_u8) == E_OK)
                {
                    if (FiM_ConfigParam_pcs != NULL_PTR)
                    {
                        idxEnd_u32 =
                                (FiM_ConfigParam_pcs->FiM_Cfg_NumOffsetEventptr[FiM_Priv_CurrentMonitoringEventId_uo + 1]);
                        idxFidOffset_u32 =
                                (FiM_ConfigParam_pcs->FiM_Cfg_NumOffsetEventptr[FiM_Priv_CurrentMonitoringEventId_uo]);

                        /* loop through all FIds attached to the event and check configured inhibit mask */
                        while (idxFidOffset_u32 < idxEnd_u32)
                        {
                            /* Get the Inhibited Fid from the inhibition source matrix */
                            FId_uo = (FiM_ConfigParam_pcs->FiM_CfgInhibitSourceMatrixptr[idxFidOffset_u32]);
                            /* if new inhibit situation is a match: lock that particular Fid */
                            if (FiM_Priv_IsInhibitionSet(demExtendedEventStatus_u8,
                                    (FiM_ConfigParam_pcs->FiM_CfgInhibitMaskMatrixptr[idxFidOffset_u32])))
                            {
                                /* Set the CURRENT bit array to 1 for fulfilled inhibitions */
                                FiM_Priv_SetInhStatus(FId_uo);
                            }

#if (FIM_CFG_SERVICE07_VISIBLE_ERROR_API == FIM_CFG_ON)
                            if(Dem_GetDtcKindOfEvent(FiM_Priv_CurrentMonitoringEventId_uo, &dtcKind) == E_OK)
                            {
                                if(dtcKind == DEM_DTC_KIND_EMISSION_REL_DTCS)
                                {
                                    /* Calculate service$07 entry for event */
                                    inhMaskConfig_uo = (FiM_ConfigParam_pcs->FiM_CfgInhibitMaskMatrixptr[idxFidOffset_u32]);

                                    if (((demExtendedEventStatus_u8 & FIM_PENDING_BITS_MASK) == FIM_PENDING_BITS_MASK)
                                            && (FiM_Priv_IsInhMaskServ07Relevant(inhMaskConfig_uo)))
                                    {
                                        /* if EVENT is visible in service$07 then increment counter for FId */
                                        FiM_Priv_SetServ07InhStatus(FId_uo);
                                    }
                                }
                            }
#endif
                            /* Increment the Fid Offset by 1*/
                            idxFidOffset_u32++;
                        }
                    }
                    else
                    {
                        FIM_PRIV_DET_ERROR(FIM_PRIV_MONITOR_ID, FIM_E_INVALID_POINTER);
                    }
                }

                FiM_Priv_CurrentMonitoringEventId_uo++;

                if (FiM_Priv_CurrentMonitoringEventId_uo > FIM_CFG_NUMBEROFDEMEVENTIDS)
                {
#if(FIM_FIDPERMISSION_CALLBACK_SUPPORTED != FIM_FIDPERMISSION_CALLBACK_SUPPORTED_OFF)
                    /* all FId states initialized for checking phase */
                    FiM_Priv_MonitorState_e = FIM_PRIV_MONSTATE_CALLBACK;
#else
                    /* all FId states initialized for checking phase */
                    FiM_Priv_MonitorState_e = FIM_PRIV_MONSTATE_INIT;
#endif
                    FiM_Priv_CurrentMonitoringFId_uo = 1;
                    FiM_Priv_CurrentMonitoringEventId_uo = 0;
                    break;
                }

            } /* while (numberOfEvents)*/
        } /* case FIM_PRIV_MONSTATE_CHECK */
            break;

#if(FIM_FIDPERMISSION_CALLBACK_SUPPORTED != FIM_FIDPERMISSION_CALLBACK_SUPPORTED_OFF)
        case FIM_PRIV_MONSTATE_CALLBACK:
        {
            VAR(FiM_FunctionIdType, AUTOMATIC) FId_uo;
            VAR(FiM_FunctionIdType, AUTOMATIC) Fid_BytePosition_u0;
            VAR(uint8, AUTOMATIC) Fid_BitPosition_u8;
            VAR(uint8, AUTOMATIC) Fid_BitMask_u8;
            VAR(boolean, AUTOMATIC) Fid_NewPermission;
            VAR(boolean, AUTOMATIC) Fid_OldPermission;

            VAR(uint16_least, AUTOMATIC) numberOfFIds_u16 = FIM_PRIV_FIDSPERMONITORCALLBACK;

            /* Start processing subset of FIDs */
            while (numberOfFIds_u16 > 0u)
            {
                numberOfFIds_u16--;
                /* Get the Current monitoring Fid into a LOcal variable */
                FId_uo = FiM_Priv_CurrentMonitoringFId_uo;
                /* Calculate the Fid Byte position */
                Fid_BytePosition_u0 = (FId_uo / 8);
                /* Calculate the Fid bit position */
                Fid_BitPosition_u8 = (uint8) (FId_uo % 8);
                /* Calculate the Bit mask */
                Fid_BitMask_u8 = (uint8) (1u << Fid_BitPosition_u8);

                /* Checking the new permission state of that Particular FID */
                if (((FiM_FIdStatusBitArray_au8[FiM_CurrentIdx][Fid_BytePosition_u0]) & Fid_BitMask_u8) == 0)
                {
                    Fid_NewPermission = TRUE;
                }
                else
                {
                    Fid_NewPermission = FALSE;
                }

                /* Checking the old permission status of that particular FID */
                if (((FiM_FIdStatusBitArray_au8[FiM_LastIdx][Fid_BytePosition_u0]) & Fid_BitMask_u8) == 0)
                {
                    Fid_OldPermission = TRUE;
                }
                else
                {
                    Fid_OldPermission = FALSE;
                }

                /* Compare the LAST and CURRENT bit array to detect the inhibition status */
                if (Fid_NewPermission != Fid_OldPermission)
                {
                    /* Invoke the callback function for that particular Fid */
                    FIM_USE_VAR( FIM_FIDPERMISSION_ST_CH_CALLBACK_FUNCTION(FId_uo, Fid_OldPermission, Fid_NewPermission));
                }

                /* Increment the Current monitoring Fid by 1 */
                FiM_Priv_CurrentMonitoringFId_uo++;

                /* if all FIds are processed in INIT state */
                if (FiM_Priv_CurrentMonitoringFId_uo > FIM_CFG_NUMBEROFFIDS)
                {
                    /* Init values for CHECK state */
                    FiM_Priv_CurrentMonitoringFId_uo = 1;
                    /* Reset the Current Monitoring EventId */
                    FiM_Priv_CurrentMonitoringEventId_uo = 0;

                    /* transit to next state INIT */
                    FiM_Priv_MonitorState_e = FIM_PRIV_MONSTATE_INIT;

                    break;
                }
            }
        }
            break;
#endif
        default:
        {
            // detect development errors / plausibility checks
            FIM_PRIV_DET_ERROR(FIM_PRIV_MONITOR_ID, FIM_E_MONITORSTATE_INVALID);

            /* Init values for CHECK state */
            FiM_Priv_CurrentMonitoringFId_uo = 1;
            FiM_Priv_CurrentMonitoringEventId_uo = 0;
            /* Transit to next state INIT */
            FiM_Priv_MonitorState_e = FIM_PRIV_MONSTATE_INIT;
        }
            break;
    }
    return;
}

/* functions are only required by test cases */
#ifdef FIM_UNIT_TEST_SUITE

/* returns the state of the monitoring state machine */
FiM_Priv_MonitorStateType FiM_Priv_MonitorGetState(void)
{
    return FiM_Priv_MonitorState_e;
}

/* set the state of the monitoring state machine */
FUNC(void, FIM_CODE) FiM_Priv_MonitorSetState(VAR(FiM_Priv_MonitorStateType, AUTOMATIC) newState)
{
    FiM_Priv_MonitorState_e = newState;
}
#endif

/* initialize the monitoring state machine only during FiM_Init */
void FiM_Priv_MonitorInit(void)
{
    /* Protection locks are not required as this function is called only during Init */
    FiM_Priv_MonitorState_e = FIM_PRIV_MONSTATE_INIT;
    FiM_Priv_CurrentMonitoringFId_uo = 1;
    FiM_Priv_CurrentMonitoringEventId_uo = 0;
    FiM_LastIdx = 0;
    FiM_CurrentIdx = 1;
}

#define FIM_STOP_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"

#endif /* FIM_CFG_DEM_TRIGGERFIMREPORTS == FIM_CFG_OFF */

#endif /*FIM_CFG_FIM_USED   ==  FIM_CFG_ON*/

/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.11.0.0; 0     05.10.2015 LIB8FE
 *   CSCRM00981002
 * 
 * AR40.10.0.0; 2     14.07.2015 WUG3ABT
 *   Checkout by wug3abt
 * 
 * AR40.10.0.0; 1     16.06.2015 LIB8FE
 *   CSCRM00879912
 * 
 * AR40.10.0.0; 0     23.03.2015 LIB8FE
 *   CSCRM00797506
 * 
 * AR40.9.0.0; 3     06.01.2015 GJ83ABT
 *   CSCRM00751490
 * 
 * AR40.9.0.0; 2     23.12.2014 BPE4COB
 *   CSCRM00756374
 * 
 * AR40.9.0.0; 1     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.9.0.0; 0     17.09.2014 PJR4KOR
 *   CSCRM00716299
 * 
 * AR40.8.0.0; 2     18.03.2014 BPE4COB
 *   CSCRM00539627: Support single callback function
 * 
 * AR40.8.0.0; 1     17.03.2014 PMJ3KOR
 *   CSCRM00620467
 * 
 * $
 **********************************************************************************************************************
 </BASDKey>*/
/* FC_VariationPoint_END */
