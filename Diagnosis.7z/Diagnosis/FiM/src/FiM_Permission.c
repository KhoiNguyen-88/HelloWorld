/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\FiM$
 * $Class_____:C$
 * $Name______:FiM_Permission$
 * $Variant___:AR40.10.0.0$
 * $Revision__:1$
 **********************************************************************************************************************
 </BASDKey>*/

/**
 **************************************************************************************************
 * FiM_Permission.c
 * API for getting FId permission for Function Inhibition Manager
 * Design specification: AUTOSAR_SWS_FunctionInhibitionManager.pdf Version 4.0 Rev0002
 **************************************************************************************************
 */
#include "FiM_Init.h"
#include "FiM_Cfg.h"
#include "FiM.h"
#include "FiM_Det.h"
#include "FiM_Status.h"

#if (FIM_CFG_FIM_USED   ==  FIM_CFG_ON)
#define FIM_START_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"
/**
 **************************************************************************************************
 * FiM_GetFunctionPermission API (public API)
 **************************************************************************************************
 */

FUNC(Std_ReturnType,FIM_CODE) FiM_GetFunctionPermission(
VAR(FiM_FunctionIdType, AUTOMATIC) FID,
P2VAR (boolean, AUTOMATIC,FIM_APPL_DATA)Permission )
{
    VAR(Std_ReturnType, AUTOMATIC) retVal = E_NOT_OK;

    if( (FiM_Priv_GetStatusInitialized()) &&
    (FiM_Priv_IsDemInitCalled()) &&
    (FID > 0) &&
    (FID <= FIM_CFG_NUMBEROFFIDS) &&
    (Permission != NULL_PTR))
    {
        *Permission = FiM_Priv_FIdGetPermission(FID);
        retVal = E_OK;
    }
    else
    {
        if(!FiM_Priv_GetStatusInitialized())
        {
            FIM_PRIV_DET_ERROR(FIM_GETFUNCTIONPERMISSION_ID,FIM_E_NOT_INITIALIZED);
        }
        if(!FiM_Priv_IsDemInitCalled())
        {
            FIM_PRIV_DET_ERROR(FIM_GETFUNCTIONPERMISSION_ID,FIM_E_DEMINIT_NOT_CALLED);
        }
        if((FID > FIM_CFG_NUMBEROFFIDS) || (FID == 0))
        {
            FIM_PRIV_DET_ERROR(FIM_GETFUNCTIONPERMISSION_ID,FIM_E_FID_OUT_OF_RANGE);
        }
        if(Permission == NULL_PTR)
        {
            FIM_PRIV_DET_ERROR(FIM_GETFUNCTIONPERMISSION_ID,FIM_E_INVALID_POINTER);
        }
    }

    return retVal;
}

#if (FIM_CFG_SERVICE07_VISIBLE_ERROR_API == FIM_CFG_ON)
// ---------------------------------------------------------------------------------------------------------------------
// FiM_GetMode07Visibility API (public API)
// ---------------------------------------------------------------------------------------------------------------------
// TO read the service$07 visibility counter for the FID
FUNC(Std_ReturnType,FIM_CODE) FiM_GetService07Visibility(
VAR(FiM_FunctionIdType, AUTOMATIC) FID,
P2VAR (boolean, AUTOMATIC,FIM_APPL_DATA)Visibility )
{
    VAR(Std_ReturnType, AUTOMATIC) retVal = E_NOT_OK;

    if( FiM_Priv_GetStatusInitialized() && (FiM_Priv_IsDemInitCalled())
    && ((FID > 0) && (FID <= FIM_CFG_NUMBEROFFIDS) && (Visibility != NULL_PTR)))
    {
        *Visibility = FALSE;
        retVal = E_OK;

#if (FIM_CFG_DEM_TRIGGERFIMREPORTS == FIM_CFG_ON)
        if (FiM_FIdServ07StatusCounter_auo[FID] > 0)
        {
            *Visibility = TRUE;
        }
#else
        if(((FiM_FIdStatusServ07BitArray_au8[FiM_LastIdx][(FID/8)]) & ((uint8)(1u << (uint8)(FID%8)))) > 0u )
        {
            *Visibility = TRUE;
        }
#endif
    }

    return retVal;
}

#endif

#define FIM_STOP_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"
#endif /*FIM_CFG_FIM_USED   ==  FIM_CFG_ON*/

/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.10.0.0; 1     14.07.2015 WUG3ABT
 *   Checkout by wug3abt
 * 
 * AR40.10.0.0; 0     16.06.2015 LIB8FE
 *   CSCRM00879912
 * 
 * AR40.9.0.0; 1     23.12.2014 BPE4COB
 *   CSCRM00756374
 * 
 * AR40.9.0.0; 0     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.8.0.0; 1     25.03.2014 PJR4KOR
 *   CSIS102288.0898.016
 * 
 * AR40.8.0.0; 0     17.03.2014 PMJ3KOR
 *   CSCRM00620467
 * 
 * AR40.7.0.0; 1     21.11.2013 GIN9COB
 *   CSCRM00598921
 * 
 * AR40.7.0.0; 0     23.10.2013 BPE4COB
 *   CSCRM00560923: Provided Memmap header
 * 
 * AR40.6.0.0; 0     14.06.2013 BPE4COB
 *   Implemented CSCRM00526806
 * 
 * AR40.5.0.0; 1     15.11.2012 WUG3ABT
 *   CSCRM00472092:
 *   introduce additional flag to support GetFunctionPermission during reinit
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
