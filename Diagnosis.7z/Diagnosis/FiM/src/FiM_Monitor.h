/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\FiM$
 * $Class_____:H$
 * $Name______:FiM_Monitor$
 * $Variant___:AR40.9.0.0$
 * $Revision__:0$
 **********************************************************************************************************************
 </BASDKey> */

/**
 **************************************************************************************************
 * FiM_Monitot.h
 * header for background monitor or FiM
 **************************************************************************************************
 */

#ifndef FIM_MONITOR_H
#define FIM_MONITOR_H

#include "FiM_Priv_Data.h"

/**
 **************************************************************************************************
 * type definitions
 **************************************************************************************************
 */

typedef enum
{
    FIM_PRIV_MONSTATE_INIT = 0, FIM_PRIV_MONSTATE_CHECK, FIM_PRIV_MONSTATE_CALLBACK
} FiM_Priv_MonitorStateType;

/* check the configured number of FIds per cycle, but maximum the total number of FIds */
#if (FIM_CFG_FIDS_PER_MONITORCYCLE_ECUC > FIM_CFG_NUMBEROFFIDS)
#define FIM_PRIV_FIDSPERMONITORCALLBACK         FIM_CFG_NUMBEROFFIDS
#else
#define FIM_PRIV_FIDSPERMONITORCALLBACK         FIM_CFG_FIDS_PER_MONITORCYCLE_ECUC
#endif

/* check the configured number of events per cycle, but maximum the total number of events */
#if (FIM_CFG_EVENTS_PER_MONITORCYCLE_ECUC > FIM_CFG_NUMBEROFDEMEVENTIDS)
#define FIM_PRIV_EVENTSPERMONITORCHECK      FIM_CFG_NUMBEROFDEMEVENTIDS
#else
#define FIM_PRIV_EVENTSPERMONITORCHECK      FIM_CFG_EVENTS_PER_MONITORCYCLE_ECUC
#endif

/* configuration value for counter monitor array size. maximum is the available number of FIDs */
#define FIM_PRIV_FIDCOUNTERSPERMONITORCHECK FIM_CFG_NUMBEROFFIDS

/**
 **************************************************************************************************
 * function prototypes
 **************************************************************************************************
 */

#if (FIM_CFG_FIM_USED   ==  FIM_CFG_ON)
#define FIM_START_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"

extern FUNC(void, FIM_CODE)
FiM_Priv_MonitorProc(void);

extern FUNC(void, FIM_CODE)
FiM_Priv_MonitorInit(void);

/*functions are only required by test cases */
#ifdef FIM_UNIT_TEST_SUITE
extern FUNC(FiM_Priv_MonitorStateType, FIM_CODE) FiM_Priv_MonitorGetState(void);
extern FUNC(void, FIM_CODE) FiM_Priv_MonitorSetState(VAR(FiM_Priv_MonitorStateType, AUTOMATIC) newState);
#endif

#define FIM_STOP_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"
#endif /*FIM_CFG_FIM_USED   ==  FIM_CFG_ON*/

#endif /* include protection */

/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.9.0.0; 0     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.8.0.0; 2     13.06.2014 WUG3ABT
 *   CSCRM00673682
 * 
 * AR40.8.0.0; 1     18.03.2014 BPE4COB
 *   CSCRM00539627: Support single callback function
 * 
 * AR40.8.0.0; 0     17.03.2014 PMJ3KOR
 *   CSCRM00620467
 * 
 * AR40.7.0.0; 1     21.11.2013 GIN9COB
 *   CSCRM00598921
 * 
 * AR40.7.0.0; 0     23.10.2013 BPE4COB
 *   CSCRM00560923: Provided Memmap header
 * 
 * AR40.6.0.0; 1     03.07.2013 BPE4COB
 *   CSCRM00547036 : Review Points Fixed.
 * 
 * AR40.6.0.0; 0     14.06.2013 BPE4COB
 *   Implemented CSCRM00526806
 * 
 * AR40.5.0.0; 1     14.11.2012 WUG3ABT
 *   CSCRM00371659
 *   protect test interfaces with compiler switches
 * 
 * AR40.5.0.0; 0     11.10.2012 KAN1COB
 *   CSCRM00383045 - [FiM] Zero configuration support
 * 
 * $
 **********************************************************************************************************************
 </BASDKey>*/
/* FC_VariationPoint_END */
