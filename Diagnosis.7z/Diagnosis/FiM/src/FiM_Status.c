/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\FiM$
 * $Class_____:C$
 * $Name______:FiM_Status$
 * $Variant___:AR40.11.0.0$
 * $Revision__:0$
 **********************************************************************************************************************
 </BASDKey>*/

/**
 **************************************************************************************************
 * FiM.c
 * FId status sources for Function Inhibition Manager
 * Design specification: AUTOSAR_SWS_FunctionInhibitionManager.pdf Version 4.0 Rev0002
 **************************************************************************************************
 */
#include "FiM.h"
#include "FiM_Init.h"
#include "FiM_Version.h"
#include "FiM_Utils.h"
#include "FiM_Priv_Data.h"
#include "FiM_Status.h"
#include "Dem.h"

#if (FIM_CFG_FIM_USED   ==  FIM_CFG_ON)

/**
 **************************************************************************************************
 * FiM global variables
 **************************************************************************************************
 */
#if (FIM_CFG_DEM_TRIGGERFIMREPORTS == FIM_CFG_OFF)
#define FIM_START_SEC_RAM_CLEARED
#include "FiM_Cfg_MemMap.h"
VAR(uint8, FIM_VAR) FiM_FIdStatusBitArray_au8[2][(FIM_CFG_NUMBEROFFIDS + 1 + 7) / 8];
#if (FIM_CFG_SERVICE07_VISIBLE_ERROR_API == FIM_CFG_ON)
/* Bit array for Mode07 visible entry */
VAR(uint8, FIM_VAR) FiM_FIdStatusServ07BitArray_au8[2][(FIM_CFG_NUMBEROFFIDS + 1 + 7) / 8];
#endif
#define FIM_STOP_SEC_RAM_CLEARED
#include "FiM_Cfg_MemMap.h"

#define FIM_START_SEC_RAM_INIT
#include "FiM_Cfg_MemMap.h"
VAR(uint8, FIM_VAR) FiM_LastIdx = 0;
VAR(uint8, FIM_VAR) FiM_CurrentIdx = 1;
#define FIM_STOP_SEC_RAM_INIT
#include "FiM_Cfg_MemMap.h"

#else

#define FIM_START_SEC_RAM_CLEARED
#include "FiM_Cfg_MemMap.h"
VAR(FiM_FIdStatusCounterType, FIM_VAR) FiM_FIdStatusCounter_auo[FIM_CFG_NUMBEROFFIDS+1];
#if (FIM_CFG_SERVICE07_VISIBLE_ERROR_API == FIM_CFG_ON)
/* Variable to hold the number of service$07 entry for the given FID */
VAR(FiM_FIdStatusCounterType, FIM_VAR) FiM_FIdServ07StatusCounter_auo[FIM_CFG_NUMBEROFFIDS+1];
#endif
#define FIM_STOP_SEC_RAM_CLEARED
#include "FiM_Cfg_MemMap.h"
#endif

/**
 **************************************************************************************************
 * FiM_Status private functions
 **************************************************************************************************
 */
/* Initialize the FiM status array */

#define FIM_START_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"

FUNC (void,FIM_CODE) FiM_Priv_StatusInit(void)
{
    VAR(FiM_FunctionIdType, AUTOMATIC) FId_uo;
    VAR(Dem_EventIdType, AUTOMATIC) eventId_uo;
    VAR(uint32, AUTOMATIC) idxFidOffset_u32;
    VAR(uint32, AUTOMATIC) idxEnd_u32;
    VAR(uint8, AUTOMATIC) demExtendedEventStatus_u8;
#if (FIM_CFG_SERVICE07_VISIBLE_ERROR_API == FIM_CFG_ON)
    VAR(uint8, AUTOMATIC) inhMaskConfig_uo = 0;
    VAR(Dem_DTCKindType, AUTOMATIC) dtcKind = DEM_DTC_KIND_ALL_DTCS;
#endif

#if (FIM_CFG_DEM_TRIGGERFIMREPORTS == FIM_CFG_OFF)
    /* Clear the Current 2 bit array to avoid having the Old data in the new array */
    FIM_USE_VAR (FIM_LIBMEMSET(FiM_FIdStatusBitArray_au8[FiM_CurrentIdx], FIM_PRIV_ZERO,
            sizeof(FiM_FIdStatusBitArray_au8[FiM_CurrentIdx])));
#if (FIM_CFG_SERVICE07_VISIBLE_ERROR_API == FIM_CFG_ON)
    FIM_USE_VAR (FIM_LIBMEMSET(FiM_FIdStatusServ07BitArray_au8[FiM_CurrentIdx], FIM_PRIV_ZERO,
            sizeof(FiM_FIdStatusServ07BitArray_au8[FiM_CurrentIdx])));
#endif
#else
    FIM_PRIV_ENTERLOCK_STATUS();
    FIM_USE_VAR(FIM_LIBMEMSET(FiM_FIdStatusCounter_auo, FIM_PRIV_ZERO,(FIM_CFG_NUMBEROFFIDS+1)));
#if (FIM_CFG_SERVICE07_VISIBLE_ERROR_API == FIM_CFG_ON)
    FIM_USE_VAR(FIM_LIBMEMSET(FiM_FIdServ07StatusCounter_auo, FIM_PRIV_ZERO,(FIM_CFG_NUMBEROFFIDS+1)));
#endif
    FIM_PRIV_EXITLOCK_STATUS();
#endif

    /* No protection lock is needed Since because Initialization status shall be set only after collecting the event status
     * of all the events during FiM_Init and the other interface will be allowed to report a status change of an event only when the Init flag is set.
     */

    /* Ask for Dem event status and calculate inhibit mask */
    for (eventId_uo = 1; eventId_uo <= FIM_CFG_NUMBEROFDEMEVENTIDS; eventId_uo++)
    {
        if (Dem_GetEventStatus(eventId_uo, &demExtendedEventStatus_u8) == E_OK)
        {
            if (FiM_ConfigParam_pcs != NULL_PTR)
            {
                idxEnd_u32 = (FiM_ConfigParam_pcs->FiM_Cfg_NumOffsetEventptr[eventId_uo + 1]);
                idxFidOffset_u32 = (FiM_ConfigParam_pcs->FiM_Cfg_NumOffsetEventptr[eventId_uo]);

                /* loop through all FIds attached to the event and check configured inhibit mask */
                while (idxFidOffset_u32 < idxEnd_u32)
                {
                    if (FiM_Priv_IsInhibitionSet(demExtendedEventStatus_u8,
                            (FiM_ConfigParam_pcs->FiM_CfgInhibitMaskMatrixptr[idxFidOffset_u32])))
                    {
                        /* if FAILED, increment counter and lock FId */
                        FId_uo = (FiM_ConfigParam_pcs->FiM_CfgInhibitSourceMatrixptr[idxFidOffset_u32]);
                        /* Set the CURRENT bit array to 1 for fulfilled inhibitions */
#if (FIM_CFG_DEM_TRIGGERFIMREPORTS == FIM_CFG_OFF)
                        FiM_Priv_SetInhStatus(FId_uo);
#else
                        FiM_Priv_FIdCountInc(FId_uo);
#endif
                    }

#if (FIM_CFG_SERVICE07_VISIBLE_ERROR_API == FIM_CFG_ON)
                    if(Dem_GetDtcKindOfEvent(eventId_uo, &dtcKind) == E_OK)
                    {
                        if (dtcKind == DEM_DTC_KIND_EMISSION_REL_DTCS)
                        {
                            /* Calculate service$07 entry for event */
                            inhMaskConfig_uo = (FiM_ConfigParam_pcs->FiM_CfgInhibitMaskMatrixptr[idxFidOffset_u32]);
                            FId_uo = (FiM_ConfigParam_pcs->FiM_CfgInhibitSourceMatrixptr[idxFidOffset_u32]);

                            if (((demExtendedEventStatus_u8 & FIM_PENDING_BITS_MASK) == FIM_PENDING_BITS_MASK)
                                    && (FiM_Priv_IsInhMaskServ07Relevant(inhMaskConfig_uo)))
                            {
#if (FIM_CFG_DEM_TRIGGERFIMREPORTS == FIM_CFG_OFF)
                                FiM_Priv_SetServ07InhStatus(FId_uo);
#else
                                FiM_Priv_FIdServ07CountInc(FId_uo);
#endif
                            }
                        }
                    }
#endif

                    idxFidOffset_u32++;
                }
            }
            else
            {
                FIM_PRIV_DET_ERROR(FIM_PRIV_STATUSINIT_ID, FIM_E_INVALID_POINTER);
            }
        }
    }

#if (FIM_CFG_DEM_TRIGGERFIMREPORTS == FIM_CFG_OFF)
    FIM_PRIV_ENTERLOCK_MONITOR();
    /* Switch the LAST Index from 0 to 1,Since All calls to GetFunctionPermission() query to the LAST bit array. */
    /* And the CURRENT bit remains the same as it will get updated as part of the FIM task */
    FiM_LastIdx = FiM_CurrentIdx;
    FIM_PRIV_EXITLOCK_MONITOR();
#endif

}

#define FIM_STOP_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"

#endif /*FIM_CFG_FIM_USED   ==  FIM_CFG_ON*/
/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.11.0.0; 0     05.10.2015 LIB8FE
 *   CSCRM00981002
 * 
 * AR40.10.0.0; 2     14.07.2015 WUG3ABT
 *   Checkout by wug3abt
 * 
 * AR40.10.0.0; 1     16.06.2015 LIB8FE
 *   CSCRM00879912
 * 
 * AR40.10.0.0; 0     23.03.2015 LIB8FE
 *   CSCRM00797506
 * 
 * AR40.9.0.0; 2     06.01.2015 GJ83ABT
 *   CSCRM00751490
 * 
 * AR40.9.0.0; 1     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.9.0.0; 0     17.09.2014 PJR4KOR
 *   CSCRM00716299
 * 
 * AR40.8.0.0; 1     17.03.2014 PMJ3KOR
 *   CSCRM00620467
 * 
 * AR40.8.0.0; 0     26.12.2013 BPE4COB
 *   CSCRM00594546: [Det][Dlt][Fim] Usage of rba_BswSrvLibs for memcpy, memset, 
 *   memcmp, etc.
 * 
 * AR40.7.0.0; 2     21.11.2013 GIN9COB
 *   CSCRM00598921
 * 
 * $
 **********************************************************************************************************************
 </BASDKey>*/
/* FC_VariationPoint_END */
