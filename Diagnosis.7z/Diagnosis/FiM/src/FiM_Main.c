/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\FiM$
 * $Class_____:C$
 * $Name______:FiM_Main$
 * $Variant___:AR40.10.0.0$
 * $Revision__:0$
 **********************************************************************************************************************
 </BASDKey>*/

/**
 **************************************************************************************************
 * FiM_Main.c
 * Main Function for Function Inhibition Manager
 * Design specification: AUTOSAR_SWS_FunctionInhibitionManager.pdf Version 4.0 Rev0002
 **************************************************************************************************
 */
#include "FiM_Init.h"
#include "FiM_Cfg.h"
#include "FiM.h"
#include "FiM_Det.h"
#include "FiM_Status.h"
#include "FiM_Monitor.h"

#if (FIM_CFG_FIM_USED   ==  FIM_CFG_ON)

#define FIM_START_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"
/**
 **************************************************************************************************
 * FiM Main function (public API)
 * This main function is called directly by the Basic Software Module Scheduler.
 **************************************************************************************************
 */
FUNC(void,FIM_CODE) FiM_MainFunction(void)
{
#if (FIM_CFG_DEM_TRIGGERFIMREPORTS == FIM_CFG_OFF)
    if (FiM_Priv_GetStatusInitialized())
    {
        if(FiM_Priv_IsDemInitCalled())
        {
            FiM_Priv_MonitorProc();
        }
        else
        {
            FIM_PRIV_DET_ERROR(FIM_MAINFUNCTION_ID, FIM_E_DEMINIT_NOT_CALLED);
        }
    }
    else
    {
        FIM_PRIV_DET_ERROR(FIM_MAINFUNCTION_ID, FIM_E_NOT_INITIALIZED);
    }
#endif /* FIM_CFG_DEM_TRIGGERFIMREPORTS == FIM_CFG_OFF */
}

#define FIM_STOP_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"

#endif /*FIM_CFG_FIM_USED   ==  FIM_CFG_ON*/

/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.10.0.0; 0     16.06.2015 LIB8FE
 *   CSCRM00879912
 * 
 * AR40.9.0.0; 1     23.12.2014 BPE4COB
 *   CSCRM00756374
 * 
 * AR40.9.0.0; 0     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.8.0.0; 0     17.03.2014 PMJ3KOR
 *   CSCRM00620467
 * 
 * AR40.7.0.0; 1     21.11.2013 GIN9COB
 *   CSCRM00598921
 * 
 * AR40.7.0.0; 0     23.10.2013 BPE4COB
 *   CSCRM00560923: Provided Memmap header
 * 
 * AR40.6.0.0; 2     03.07.2013 BPE4COB
 *   CSCRM00547036 : Review Points Fixed.
 * 
 * AR40.6.0.0; 1     17.06.2013 BPE4COB
 *   Compiler switches for the FiM_MainFunction is updated.
 * 
 * AR40.6.0.0; 0     14.06.2013 BPE4COB
 *   Implemented CSCRM00526806
 * 
 * AR40.5.0.0; 0     11.10.2012 KAN1COB
 *   CSCRM00383045 - [FiM] Zero configuration support
 * 
 * $
 **********************************************************************************************************************
 </BASDKey>*/
/* FC_VariationPoint_END */
