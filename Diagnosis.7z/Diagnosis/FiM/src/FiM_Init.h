/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\FiM$
 * $Class_____:H$
 * $Name______:FiM_Init$
 * $Variant___:AR40.10.0.0$
 * $Revision__:0$
 **********************************************************************************************************************
 </BASDKey>*/

/**
 **************************************************************************************************
 * FiM_Init.h
 * Initialization header for Function Inhibition Manager
 * Design specification: AUTOSAR_SWS_FunctionInhibitionManager.pdf Version 4.0 Rev0002
 **************************************************************************************************
 */
#ifndef FIM_INIT_H
#define FIM_INIT_H

#include "FiM_Priv_Data.h"
#include "FiM_Det.h"

#if (FIM_CFG_FIM_USED   ==  FIM_CFG_ON)

/**
 **************************************************************************************************
 * global variables
 **************************************************************************************************
 */
#define FIM_START_SEC_RAM_CLEARED
#include "FiM_Cfg_MemMap.h"
extern VAR( boolean, FIM_VAR_POWER_ON_INIT ) FiM_StatusInitialized_b;
extern VAR( boolean, FIM_VAR_POWER_ON_INIT ) FiM_DemInitStatus_b;
#define FIM_STOP_SEC_RAM_CLEARED
#include "FiM_Cfg_MemMap.h"

#define FIM_START_SEC_RAM_INIT
#include "FiM_Cfg_MemMap.h"
extern P2CONST( FiM_ConfigType, FIM_VAR, FIM_CONST ) FiM_ConfigParam_pcs;
#define FIM_STOP_SEC_RAM_INIT
#include "FiM_Cfg_MemMap.h"
/**
 **************************************************************************************************
 * private inline functions
 **************************************************************************************************
 */

/* set the initialization status variable */

#define FIM_START_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"

LOCAL_INLINE FUNC(void, FIM_CODE) FiM_Priv_SetStatusInitialized(VAR(boolean, AUTOMATIC) status)
{
    FiM_StatusInitialized_b = status;
}

/* return the initialization status variable */
LOCAL_INLINE FUNC(boolean, FIM_CODE) FiM_Priv_GetStatusInitialized(void)
{
    return FiM_StatusInitialized_b;
}

/* set the re-initialization status variable */
LOCAL_INLINE FUNC(void, FIM_CODE) FiM_Priv_SetDemInitStatus(VAR(boolean, AUTOMATIC) status)
{
    FiM_DemInitStatus_b = status;
}


/* return the re-initialization status variable */
LOCAL_INLINE FUNC(boolean, FIM_CODE) FiM_Priv_IsDemInitCalled(void)
{
    return FiM_DemInitStatus_b;
}

#define FIM_STOP_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"

#endif /* include protection */

#endif /*FIM_CFG_FIM_USED   ==  FIM_CFG_ON*/

/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.10.0.0; 0     14.07.2015 WUG3ABT
 *   Checkout by wug3abt
 * 
 * AR40.9.0.0; 1     23.12.2014 BPE4COB
 *   CSCRM00756374
 * 
 * AR40.9.0.0; 0     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.8.0.0; 0     17.03.2014 PMJ3KOR
 *   CSCRM00620467
 * 
 * AR40.7.0.0; 1     21.11.2013 GIN9COB
 *   CSCRM00598921
 * 
 * AR40.7.0.0; 0     23.10.2013 BPE4COB
 *   CSCRM00560923: Provided Memmap header
 * 
 * AR40.6.0.0; 0     14.06.2013 BPE4COB
 *   Implemented CSCRM00526806
 * 
 * AR40.5.0.0; 1     15.11.2012 WUG3ABT
 *   CSCRM00472092:
 *   introduce additional flag to support GetFunctionPermission during reinit
 * 
 * AR40.5.0.0; 0     11.10.2012 KAN1COB
 *   CSCRM00383045 - [FiM] Zero configuration support
 * 
 * AR40.5_2012-07; 0     17.07.2012 WUG3ABT
 *   code review solved
 *   CSCRM00371650
 *   - define to enum conversion
 *   - LARGE_RAM to RAM only rename
 *   - typos
 *   - function does not need a return value
 *   - new function ChangeAndReset bits
 *   - removed unnecessary header includes
 * 
 * $
 **********************************************************************************************************************
 </BASDKey>*/
/* FC_VariationPoint_END */
