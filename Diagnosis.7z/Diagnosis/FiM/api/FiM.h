/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\FiM$
 * $Class_____:H$
 * $Name______:FiM$
 * $Variant___:AR40.10.0.0$
 * $Revision__:0$
 **********************************************************************************************************************
 </BASDKey>*/

#ifndef FIM_H
#define FIM_H

#include "FiM_Types.h"
#include "Dem_Types.h"
#include "FiM_Cfg.h"
#include "FiM_Cfg_Fids.h"
#include "FiM_PBcfg.h"
#include "FiM_Version.h"

/**
 * \defgroup FIM_H
 *  The header file contains all the interface functions required in Autosar.
 *  see AUTOSAR_SWS_FunctionInhibitionManager.pdf Version 4.0 Rev0002
 *  To use this interface include the header <b>FiM.h</b>
 */

/**
 * @ingroup FIM_H
 *
 * This service returns the version information of this module.
 * The function FiM_GetVersionInfo shall return the version information of the FIM module.
 * The version information includes: Module Id, Vendor Id, Vendor specific version numbers.
 *\n
 * @param[in]         versioninfo A pointer to the struct with the version information.\n
 * @see [AR402:FIM078],[AR402:STD015]
 *@return void
 */

#define FIM_START_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"

#if (FIM_CFG_VERSION_INFO_API == FIM_CFG_ON)
extern FUNC(void,FIM_CODE) FiM_GetVersionInfo(P2VAR( Std_VersionInfoType, AUTOMATIC, FIM_APPL_DATA ) versioninfo);
#endif

/**
 * @ingroup FIM_H
 * This service reports the permission state to the functionality.
 *\n
 * @param[in]         FID - The function ID that is going to be checked for its inhibition status.\n
 * @param[in]         Permission A pointer to a variable that will contain the result of the inhibition check. true/false function may/may not run.\n
 * @see [AR402:FIM011]
 * @return            E_OK The request is accepted.\n
 *                    E_NOT_OK: if the request is not accepted.
 */
extern FUNC(Std_ReturnType,FIM_CODE) FiM_GetFunctionPermission(VAR(FiM_FunctionIdType, AUTOMATIC) FID,
        P2VAR (boolean, AUTOMATIC, FIM_APPL_DATA) Permission);

#if (FIM_CFG_SERVICE07_VISIBLE_ERROR_API == FIM_CFG_ON)
/**
 * @ingroup FIM_H
 * This service reports the service$07 visible entry for the FID.
 *\n
 * @param[in]         FID - The function ID that is going to be checked for its service$07 visibility.\n
 * @param[in]         Visibility A pointer to a variable that will contain the result of the service07 visibility counter.
 * @return            E_OK The request is accepted.\n
 *                    E_NOT_OK: if the request is not accepted.
 */
extern FUNC(Std_ReturnType,FIM_CODE) FiM_GetService07Visibility(VAR(FiM_FunctionIdType, AUTOMATIC) FID,
        P2VAR (boolean, AUTOMATIC, FIM_APPL_DATA) Visibility);
#endif

/**
 * @ingroup FIM_H
 *  This service initializes the FiM at init time
 *  The ECU State Manager shall call the function FiM_Init during the startup phase of the ECU in order to initialize
 *  the permission states of the FIDs based on the event data of the DEM.
 *  The FIM is not functional until this function has been called.
 * @param[in] FiMConfigPtr Pointer to a data structure for the post build parameters of the FIM.
 * @see [AR402:FIM077]
 * @return void
 */

extern FUNC(void,FIM_CODE) FiM_Init(P2CONST(FiM_ConfigType, FIM_VAR, FIM_APPL_CONST) FiMConfigPtr);

/**
 *  @ingroup FIM_H
 *  This service is provided to the Dem in order to call the FiM upon status changes.
 *   If the FIM module does not calculate the inhibition states in a cyclic way (as defined in
 *   configuration parameter FIM_CYCLIC_EVENT_EVALUATION = FALSE), the module DEM shall call the function
 *   FiM_DemTriggerOnEventStatus whenever the status of an events changes.
 *   In case the FIM module calculates the inhibition states in a cyclic way (as defined in configuration
 *   parameter FIM_CYCLIC_EVENT_EVALUATION = TRUE), the FIM has to query all event status information from the DEM.
 *   In that case, the DEM does not have to call the function FiM_DemTriggerOnEventStatus.
 * @param[in] EventId The id of the event that's status has changed.
 * @param[in] EventStatusOld The old value of the status.
 * @param[in] EventStatusNew The new value of the status.
 * @see [AR402:FIM021]
 * @return void
 */
#if (FIM_CFG_DEM_TRIGGERFIMREPORTS == FIM_CFG_ON)
extern FUNC(void,FIM_CODE) FiM_DemTriggerOnEventStatus(VAR(Dem_EventIdType, AUTOMATIC) EventId,VAR(uint8, AUTOMATIC) EventStatusOld, VAR(uint8, AUTOMATIC) EventStatusNew);
#endif

/**
 *  @ingroup FIM_H
 *  Initialize the DEM funtionality.\n
 *  The DEM shall call FiM_DemInit to re-initialize the FIM module in case the DEM detects a status change \n
 *  of a certain number of events (DEM implementation specific), e.g. clearance of event memory in the DEM.\n
 * @param void
 * @see [AR402:FIM006]\n
 * @return void
 */
extern FUNC(void,FIM_CODE) FiM_DemInit(void);

/**
 * @ingroup FIM_H
 * The main function of the FIM.
 * AUTOSAR deviations:
 *         in contrast to requirement AR402:FIM070, this function is always there, regardless of the value of the
 *         configuration parameter FIM_CYCLIC_EVENT_EVALUATION.
 * @param void
 * @see [AR402:FIM060]
 * @return void
 */
extern FUNC(void,FIM_CODE) FiM_MainFunction(void);

#define FIM_STOP_SEC_ROM_CODE
#include "FiM_Cfg_MemMap.h"

#endif /* include protection */

/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.10.0.0; 0     16.04.2015 CLH2SI
 *   CSCRM00764027
 * 
 * AR40.9.0.0; 1     06.01.2015 GJ83ABT
 *   CSCRM00751490
 * 
 * AR40.9.0.0; 0     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.8.0.0; 0     17.03.2014 PMJ3KOR
 *   CSCRM00620467
 * 
 * AR40.7.0.0; 3     21.11.2013 GIN9COB
 *   CSCRM00598921
 * 
 * AR40.7.0.0; 2     19.11.2013 BPE4COB
 *   CSCRM00576398: [FiM] Updated version.h inclusion as per SWS_BSW_00036
 * 
 * AR40.7.0.0; 1     23.10.2013 BPE4COB
 *   CSCRM00560923: Provided Memmap header
 * 
 * AR40.7.0.0; 0     22.08.2013 BPE4COB
 *   CSCRM00564506: Provided bug fixes.
 * 
 * AR40.6.0.0; 2     03.07.2013 BPE4COB
 *   CSCRM00547036 : Review Points Fixed.
 * 
 * AR40.6.0.0; 1     17.06.2013 BPE4COB
 *   Compiler switches for the FiM_MainFunction is updated.
 * 
 * $
 **********************************************************************************************************************
 </BASDKey>*/
/* FC_VariationPoint_END */
