/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\FiM$
 * $Class_____:H$
 * $Name______:FiM_Types$
 * $Variant___:AR40.9.0.0$
 * $Revision__:1$
 **********************************************************************************************************************
 </BASDKey>*/

/**
 * \defgroup FIM_TYPES_H
 * The header types for the FiM.
 * @see AUTOSAR_SWS_FunctionInhibitionManager.pdf Version 4.0 Rev0002
 */

#ifndef FIM_TYPES_H
#define FIM_TYPES_H

#include "Std_Types.h"
#include "Rte_FiM_Type.h"
#include "rba_BswSrv.h"

/* Abstraction to the MemSet, MemCompare and MemCopy Library function */
#define FIM_LIBMEMCOPY(xDest_pv,xSrc_pcv,numBytes_u32)             rba_BswSrv_MemCopy((xDest_pv),(xSrc_pcv),(uint32)(numBytes_u32))
#define FIM_LIBMEMSET(xDest_pv,xPattern_u32,numBytes_u32)          rba_BswSrv_MemSet((xDest_pv),(xPattern_u32),(uint32)(numBytes_u32))
#define FIM_LIBMEMCOMP(xSrc1_pcv,xSrc2_pcv,numBytes_u32)           rba_BswSrv_MemCompare((xSrc1_pcv),(xSrc2_pcv),(uint32)(numBytes_u32))

/**
 * @ingroup FIM_TYPES_H
 * Base type for Inhibition Mask.
 *
 */
typedef uint8 FiM_InhibitionMaskType;

/**
 * @ingroup FIM_TYPES_H
 * Base type for Event offsets
 *
 */
typedef uint32 FiM_NumOffsetEventType;

/**
 * @ingroup FIM_TYPES_H
 *  typedef struct \n
 *  {\n
 *   	P2CONST(FiM_NumOffsetEventType, TYPEDEF, FIM_CONST) FiM_Cfg_NumOffsetEventptr;    	 pointer to a constant array of type FiM_NumOffsetEventType \n
 * 	 	P2CONST(FiM_FunctionIdType, TYPEDEF, FIM_CONST) FiM_CfgInhibitSourceMatrixptr;     	 pointer to a constant array of type FiM_FunctionIdType\n
 *  	P2CONST(FiM_InhibitionMaskType, TYPEDEF, FIM_CONST) FiM_CfgInhibitMaskMatrixptr;  	 pointer to a constant array of type FiM_InhibitionMaskType\n
 *  }FiM_ConfigType;
 */

typedef struct
{
    P2CONST(FiM_NumOffsetEventType, TYPEDEF, FIM_CONST) FiM_Cfg_NumOffsetEventptr;
    P2CONST(FiM_FunctionIdType, TYPEDEF, FIM_CONST) FiM_CfgInhibitSourceMatrixptr;
    P2CONST(FiM_InhibitionMaskType, TYPEDEF, FIM_CONST) FiM_CfgInhibitMaskMatrixptr;
}FiM_ConfigType;

#endif /* include protection */

/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.9.0.0; 1     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.9.0.0; 0     17.09.2014 PJR4KOR
 *   CSCRM00716299
 * 
 * AR40.8.0.0; 1     17.03.2014 PMJ3KOR
 *   CSCRM00620467
 * 
 * AR40.8.0.0; 0     26.12.2013 BPE4COB
 *   CSCRM00594546: [Det][Dlt][Fim] Usage of rba_BswSrvLibs for memcpy, memset, 
 *   memcmp, etc.
 * 
 * AR40.6.0.0; 1     03.07.2013 BPE4COB
 *   CSCRM00547036 : Review Points Fixed.
 * 
 * AR40.6.0.0; 0     14.06.2013 BPE4COB
 *   Implemented CSCRM00526806
 * 
 * AR40.5.0.0; 0     27.11.2012 WUG3ABT
 *   CSCRM00437891:
 *   change include header to rte_types.h
 * 
 * AR40.4.0.0; 4     10.09.2012 WUG3ABT
 *   CSCRM00450729
 *   Remove the unused FiM_InhibitMaskType
 * 
 * AR40.4.0.0; 3     27.08.2012 WUG3ABT
 *   CSCRM00440340
 * 
 * AR40.4.0.0; 2     27.08.2012 WUG3ABT
 *   merge branch back to trunk
 * 
 * $
 **********************************************************************************************************************
 </BASDKey>*/
/* FC_VariationPoint_END */
