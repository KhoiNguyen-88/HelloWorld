You find documentation of our released components here:

file://///bosch.com/dfsrb/DfsDE/DIV/CDG/Prj/CUBAS/10_SystemStack/01_Diagnosis/Diagnosis-Intranet/Deliveries.htm