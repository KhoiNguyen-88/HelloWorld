/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_EventRecheck$
* $Variant___:AR40.9.0.2$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_DEPENDENCY_H
#define DEM_DEPENDENCY_H


#include "Dem_Cfg_Nodes.h"
#include "Dem_Cfg_StorageCondition.h"
#include "Dem_Cfg_Main.h"
#include "Dem_Dependencies.h"
#include "Dem_Mapping.h"


#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"



#if (DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON)

void Dem_DependencyInit(void);
void Dem_DependencyRestartCyclicCheck(void);
void Dem_RecheckNodeNotRecoverableRequest(void);
void Dem_DependencyMainFunction(void);


#else

DEM_INLINE void Dem_DependencyInit(void) {}
DEM_INLINE void Dem_DependencyRestartCyclicCheck(void) {}
DEM_INLINE void Dem_RecheckNodeNotRecoverableRequest(void) {}
DEM_INLINE void Dem_DependencyMainFunction(void) {}

#endif




#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.9.0.2; 0     12.03.2015 CLH2SI
*   CSCRM00581269
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 0     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.6.0.0; 1     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.6.0.0; 0     23.05.2013 CRA1COB
*   CSCRM00467195
* 
* AR40.5.0.0; 0     30.11.2012 KAN1COB
*   See: check in comment ofCOMP: DEM40.5_2012-11;5
* 
* AR40.4.0.0; 1     27.06.2012 BRM2COB
*   GIT to eASEE 27-06
* 
* AR40.4.0.0; 0     14.02.2012 CLH2SI
*   GIT-SYNC: a0008d733d3a94fa3e0a3e39260972344e821bef
* 
* AR40.0.0.1; 1     21.12.2011 SKK2ABT
*   Remove misra warning
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
