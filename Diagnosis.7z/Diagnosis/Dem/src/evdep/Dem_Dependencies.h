/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_Dependencies$
* $Variant___:AR40.11.0.1$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_NODES_H
#define DEM_NODES_H


#include "Dem_Types.h"
#include "Dem_Cfg_Nodes.h"
#include "Dem_Cfg_NodeId.h"
#include "Dem_Cfg_StorageCondition.h"
#include "Dem_Array.h"
#include "Dem_Bits8.h"


#if (DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON)


#define DEM_NODE_INFINITE_RECOVERIES  255
#define DEM_NODE_NO_RECOVERIES          0

#define DEM_NODESTATUS_FAILED                   0
#define DEM_NODESTATUS_SUSPICIOUS               1
#define DEM_NODESTATUS_NOTINIT                  2
#define DEM_NODESTATUS_NOTAVAILABLE             3
#define DEM_NODESTATUS_FAILEDFILTERED           4
#define DEM_NODESTATUS_FAILEDNOTRECOVERABLE     5
#define DEM_NODESTATUS_COUNT                    6


#define DEM_NODESTATUS__NODEMASK               ((uint8)0x80)
#define DEM_NODESTATUS__ANCESTORMASK           ((uint8)0x7F)


DEM_INLINE void Dem_NodeStatusSet(uint8 *status)            { (*status) |= DEM_NODESTATUS__NODEMASK;  }
DEM_INLINE void Dem_NodeStatusReset(uint8 *status)          { (*status) &= (uint8)~DEM_NODESTATUS__NODEMASK; }
DEM_INLINE Dem_boolean_least Dem_NodeStatusIsSet(uint8 status)  { return ((status) & DEM_NODESTATUS__NODEMASK) > 0; }
DEM_INLINE uint8 Dem_NodeStatusAncestorCounter(uint8 status)  { return ((status) & DEM_NODESTATUS__ANCESTORMASK); }

/*DEM_INLINE void Dem_NodeStatus__overwriteNodeStatus(uint8 *status, Dem_boolean_least setBit)
{
	if (setBit) {
		Dem_NodeStatusSet (status);
	} else {
		Dem_NodeStatusReset (status);
	}
}*/

DEM_INLINE Dem_boolean_least Dem_NodeStatusIsAnyAncestorSet (uint8 status) { return ((status) & DEM_NODESTATUS__ANCESTORMASK) > 0; }


typedef struct
{
	uint8 status[DEM_NODESTATUS_COUNT];
#if (DEM_CFG_DEPRECOVERYLIMIT == DEM_CFG_DEPRECOVERYLIMIT_ON)
	uint8 performedRecoveries;
#endif
	uint8 stateFlags;
} Dem_NodeState;

#define DEM_NODE_STATEFLAG_RECHECKONCLEAR    0
#define DEM_NODE_STATEFLAG_HASCAUSALFAULT    1
#define DEM_NODE_STATEFLAG_RECOVERYBLOCKED    2


typedef struct
{
#if (DEM_CFG_DEPRECOVERYLIMIT == DEM_CFG_DEPRECOVERYLIMIT_ON)
	uint8 allowedRecoveries;
#endif
#if (DEM_CFG_NODEFAILEDCALLBACK_COUNT > 0)
	uint8 nodeFailedCallbackIdx;
#endif
	uint8 paramFlags;
} Dem_NodeParam;

typedef void (*Dem_NodeFailedCallbackType)(boolean testFailed);


#define DEM_NODE_PARAMFLAG_IGNOREPRIORITY    0

#if (DEM_CFG_DEPRECOVERYLIMIT == DEM_CFG_DEPRECOVERYLIMIT_ON)
	#define DEM_NODES_INIT_ALLOWEDRECOVERIES(X)    (X),
#else
	#define DEM_NODES_INIT_ALLOWEDRECOVERIES(X)
#endif
#if (DEM_CFG_NODEFAILEDCALLBACK_COUNT > 0)
	#define DEM_NODES_INIT_NODEFAILEDCALLBACK(X)    (X),
#else
	#define DEM_NODES_INIT_NODEFAILEDCALLBACK(X)
#endif

#define DEM_NODES_INIT(ALLOWEDRECOVERIES,IGNORES_PRIO,NODEFAILEDCALLBACK)        \
    {                                              			  \
		DEM_NODES_INIT_ALLOWEDRECOVERIES(ALLOWEDRECOVERIES)   \
		DEM_NODES_INIT_NODEFAILEDCALLBACK(NODEFAILEDCALLBACK)  \
		((IGNORES_PRIO) << DEM_NODE_PARAMFLAG_IGNOREPRIORITY)   \
    }



#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

DEM_ARRAY_DECLARE(      Dem_NodeState, Dem_AllNodesState, DEM_NODEID_ARRAYLENGTH);

#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"



#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

DEM_ARRAY_DECLARE_CONST(Dem_NodeParam, Dem_AllNodesParam, DEM_NODEID_ARRAYLENGTH);
DEM_ARRAY_DECLARE_CONST(Dem_NodeFailedCallbackType, Dem_NodeFailedCallbacks, DEM_CFG_NODEFAILEDCALLBACK_ARRAYLENGTH);

#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"



#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

Dem_boolean_least Dem_SetNodeStatus (const Dem_NodeIdType NodeId, uint8 statusIndex);
Dem_boolean_least Dem_ResetNodeStatus (const Dem_NodeIdType NodeId, uint8 statusIndex);

Dem_boolean_least Dem_Dependencies_CheckEventIsCausal(Dem_EventIdType EventId, Dem_NodeIdType NodeId);





/*************   Status Querries   ***************/

DEM_INLINE boolean Dem_NodeIsFailed(Dem_NodeIdType NodeId)
{
	return (Dem_AllNodesState[NodeId].status[DEM_NODESTATUS_FAILED] != 0);
}

DEM_INLINE boolean Dem_NodeIsFailedItself(Dem_NodeIdType NodeId)
{
	return Dem_NodeStatusIsSet(Dem_AllNodesState[NodeId].status[DEM_NODESTATUS_FAILED]);
}

/**
 * @ingroup DEM_EXT_H
 *
 * Checks whether one of a ancestor(parent) node is failed.
 *
 * Don't use this function to check, whether a node can be used. Use isUsable or isRestictedUsable instead.
 *
 * @param[in] NodeId specifies the id of the node to be checked.
 * @return TRUE : The any ancestor node is failed. \n
 *		   FALSE: The node is valid. No event did report failed at an ancestor node.
 * @see Dem_NodeIsFailed
 */
DEM_INLINE boolean Dem_NodeAreAncestorsFailed(Dem_NodeIdType NodeId)
{
	return Dem_NodeStatusIsAnyAncestorSet(Dem_AllNodesState[NodeId].status[DEM_NODESTATUS_FAILED]);
}


DEM_INLINE boolean Dem_NodeIsSuspicious(Dem_NodeIdType NodeId)
{
   return (Dem_AllNodesState[NodeId].status[DEM_NODESTATUS_SUSPICIOUS] != 0);
}


DEM_INLINE boolean Dem_NodeIsSuspiciousItself(Dem_NodeIdType NodeId)
{
   return Dem_NodeStatusIsSet(Dem_AllNodesState[NodeId].status[DEM_NODESTATUS_SUSPICIOUS]);
}

/**
 * @ingroup DEM_EXT_H
 *
 * Checks whether one of the ancestor(parent) node is suspicious.
 *
 * If a node is marked as failed, it isn't marked automatically as suspicious.
 * Don't use this function to check, whether a node can be used. Use isUsable or isRestictedUsable instead.
 *
 * @param[in] NodeId specifies the id of the node to be checked.
 * @return TRUE : Any ancestor node is susipicous. \n
 *		   FALSE: The node is valid. No event did report susipicous at any ancestor node.

 * @see Dem_NodeIsSuspicious
 */
DEM_INLINE boolean Dem_NodeAreAncestorsSuspicious(Dem_NodeIdType NodeId)
{
	return Dem_NodeStatusIsAnyAncestorSet(Dem_AllNodesState[NodeId].status[DEM_NODESTATUS_SUSPICIOUS]);
}


DEM_INLINE boolean Dem_NodeIsFailedFilteredItself(Dem_NodeIdType NodeId)
{
   return (Dem_NodeStatusIsSet(Dem_AllNodesState[NodeId].status[DEM_NODESTATUS_FAILEDFILTERED]));
}

DEM_INLINE boolean Dem_NodeAreAllFailedFiltered(Dem_NodeIdType NodeId)
{
    return (   (Dem_AllNodesState[NodeId].status[DEM_NODESTATUS_FAILEDFILTERED] != 0)
            && (   Dem_AllNodesState[NodeId].status[DEM_NODESTATUS_FAILEDFILTERED]
                == Dem_AllNodesState[NodeId].status[DEM_NODESTATUS_FAILED]
               )
            );
}

/**
 * @ingroup DEM_EXT_H
 *
 * Deprecated: DO NOT USE!
 * Returns, if the node are any ancester status is set to FailedFitlered. Does not consider, whether all "Failed" information is filtered.
 *
 * @param[in] NodeId specifies the id of the node to be checked.
 * @return TRUE : The FailedFitlered is set for node or any ancestor. \n
 *         FALSE: No FailedFitlered information.
 *
 */
DEM_INLINE boolean Dem_NodeIsFailedFiltered(Dem_NodeIdType NodeId)
{
   return (Dem_AllNodesState[NodeId].status[DEM_NODESTATUS_FAILEDFILTERED] != 0);
}


DEM_INLINE boolean Dem_NodeIsFailedNotRecoverable(Dem_NodeIdType NodeId)
{
    return (Dem_AllNodesState[NodeId].status[DEM_NODESTATUS_FAILEDNOTRECOVERABLE] != 0);
}

DEM_INLINE boolean Dem_NodeIsFailedNotRecoverableItself(Dem_NodeIdType NodeId)
{
    return Dem_NodeStatusIsSet(Dem_AllNodesState[NodeId].status[DEM_NODESTATUS_FAILEDNOTRECOVERABLE]);
}


DEM_INLINE boolean Dem_NodeIsAvailable(Dem_NodeIdType NodeId)
{
	   return (Dem_AllNodesState[NodeId].status[DEM_NODESTATUS_NOTAVAILABLE] == 0);
}

/**
 * @ingroup DEM_EXT_H
 *
 * Checks whether one of the ancestor(parent) node is available.
 * A node may be unavailable due to a variant code configuration or other conditions.
 * Don't use this function to check, whether a node can be used. Use isUsable or isRestictedUsable instead.
 *
 * @param[in] NodeId specifies the id of the node to be checked.
 * @return TRUE : All ancestor nodes are available \n
 *		   FALSE: Any ancestor node is not available.
 * @see Dem_NodeIsAvailable
 */
DEM_INLINE boolean Dem_NodeAreAncestorsAvailable(Dem_NodeIdType NodeId)
{
	return !Dem_NodeStatusIsAnyAncestorSet(Dem_AllNodesState[NodeId].status[DEM_NODESTATUS_NOTAVAILABLE]);
}

DEM_INLINE boolean Dem_NodeIsInitialized(Dem_NodeIdType NodeId)
{
	   return (Dem_AllNodesState[NodeId].status[DEM_NODESTATUS_NOTINIT] == 0);
}

DEM_INLINE boolean Dem_NodeAreAncestorsInitialized(Dem_NodeIdType NodeId)
{
	return !Dem_NodeStatusIsAnyAncestorSet(Dem_AllNodesState[NodeId].status[DEM_NODESTATUS_NOTINIT]);
}

DEM_INLINE boolean Dem_NodeIsRestrictedUsable(Dem_NodeIdType NodeId)
{
	return (   (Dem_NodeIsInitialized(NodeId))
			&& (Dem_NodeIsAvailable(NodeId))
			&& (!Dem_NodeIsFailed(NodeId))
			);
}

DEM_INLINE boolean Dem_NodeIsUsable(Dem_NodeIdType NodeId)
{
	return (   (Dem_NodeIsRestrictedUsable(NodeId))
			&& (!Dem_NodeIsSuspicious(NodeId))
			);
}

/**
 * @ingroup DEM_EXT_H
 *
 * The function is defined as interface to query, whether a node's parents are restricted usable. The function returns
 * true, if the nodes parents may restrictedly be used (parents are not failed & parents are initialized & parents
 * are available, but parents may be suspicious). If the function returns false, the node's parents may not be used
 * (i.e. one of the 3 criteria is not met).
 *
 * @param[in] NodeId specifies the id of the node to be checked.
 * @return TRUE : All ancestor nodes are restricted usable \n
 *		   FALSE: Any ancestor node is not restricted usable.
 * @see Dem_NodeIsRestrictedUsable
 */
DEM_INLINE boolean Dem_NodeAreAncestorsRestrictedUsable(Dem_NodeIdType NodeId)
{
	return (   (Dem_NodeAreAncestorsInitialized(NodeId))
			&& (Dem_NodeAreAncestorsAvailable(NodeId))
			&& (!Dem_NodeAreAncestorsFailed(NodeId))
			);
}

 /**
 * @ingroup DEM_EXT_H
 *
 * The function is defined as interface to query, whether a node's parents are usable. The function returns true,
 * if the node parents may be used (parents are not failed & parents are not suspicious & parents are initialized
 * & parents are available). If the function returns false, the node's parents may not be used (i.e. one of the 4 criterias
 * is not met).
 *
 * @param[in] NodeId specifies the id of the node to be checked.
 * @return TRUE : All ancestor nodes are usable \n
 *		   FALSE: Any ancestor node is not usable.
 * @see Dem_NodeIsUsable
 */
DEM_INLINE boolean Dem_NodeAreAncestorsUsable(Dem_NodeIdType NodeId)
{
	return (   (Dem_NodeAreAncestorsRestrictedUsable(NodeId))
			&& (!Dem_NodeAreAncestorsSuspicious(NodeId))
			);
}





DEM_INLINE boolean Dem_NodeRecoveryAllowed (Dem_NodeIdType NodeId)
{
    DEM_UNUSED_PARAM(NodeId);

    return (TRUE
#if (DEM_CFG_DEPRECOVERYLIMIT == DEM_CFG_DEPRECOVERYLIMIT_ON)
            && (    (Dem_AllNodesState[NodeId].performedRecoveries < Dem_AllNodesParam[NodeId].allowedRecoveries)
                 || (DEM_NODE_INFINITE_RECOVERIES == Dem_AllNodesParam[NodeId].allowedRecoveries)
               )

#endif
           );
}


DEM_INLINE void Dem_NodeCallFailedCallback (Dem_NodeIdType NodeId, boolean failed)
{
#if (DEM_CFG_NODEFAILEDCALLBACK_COUNT > 0)
	if (Dem_AllNodesParam[NodeId].nodeFailedCallbackIdx != 0)
	{
		(Dem_NodeFailedCallbacks[Dem_AllNodesParam[NodeId].nodeFailedCallbackIdx])(failed);
	}
#else
	DEM_UNUSED_PARAM(NodeId);
	DEM_UNUSED_PARAM(failed);
#endif
}






void Dem_NodeSetFailed(Dem_NodeIdType NodeId, Dem_boolean_least failed, Dem_boolean_least forceReset);
void Dem_Dependencies_SetNodeFailed(Dem_NodeIdType NodeId, boolean EventIsCausal, boolean EventStorageFiltered, boolean EventIsRecoverable);
void Dem_Dependencies_ResetNodeFailed(Dem_NodeIdType NodeId);
void Dem_Dependencies_ResetNodeFailedFiltered(Dem_NodeIdType NodeId);
void Dem_Dependencies_ResetNodeFailedNotRecoverable(Dem_NodeIdType NodeId);

void Dem_NodeSetSuspicious(Dem_NodeIdType NodeId, Dem_boolean_least suspicious);
void Dem_NodeSetHasCausalFault (const Dem_NodeIdType NodeId, Dem_boolean_least causalFault);


/**
 *  @ingroup DEM_EXT_H
 *
 *  The function is defined as interface to the node processing (e.g. to deactivate for variant coding). The node
 *  processing may report whether the node (system component) is available in the project. The default value after power on
 *  is "node is available". If a node (system component) is marked as not available, all depending nodes are also
 *  marked as not available.
 *  The function may be called cyclically, but this is not necessary.
 *  To set the status of one node (NodeId), the function has to be called by only one responsible component
 *  (node processing of this NodeId).
 *
 *  HINT: Be sure what you do before setting nodes as "not available".
 *
 *  The minimum time slot between set and reset of the node status is one second.
 *
 *  @param[in] NodeId specifies the id of the node to be checked.
 *  @param[in] available    1 = node/system component is available \n
 *                      0 = node/system component is not available
 */
void Dem_NodeSetAvailable(Dem_NodeIdType NodeId, boolean available);

/**
 * @ingroup DEM_EXT_H
 *
 * The function is defined as interface to the node processing. The node processing has to report whether the node/node
 * (system component) is initialized. The default value after power on is "node is initialized". If a node
 * (system component) is marked as not initialized, all depending nodes are also marked as not initialized.
 * The function may be called cyclically, but this is not necessary.
 * To set the status of one node (NodeId), the function has to be called by only one responsible component
 * (node processing of this NodeId).
 *
 * HINT: Be sure what you do before setting node as "not initialized".
 *
 * The minimum time slot between set and reset of the node status is one second.
 *
 * @param[in] NodeId specifies the id of the node/node to be checked.
 * @param[in] init  1 = node/system component is initialized \n
 *             		0 = node/system component is not initialized
 */
void Dem_NodeSetInitialized(Dem_NodeIdType NodeId, boolean init);




DEM_INLINE void Dem_NodeSetRecovered(Dem_NodeIdType NodeId)
{
	DEM_UNUSED_PARAM(NodeId);
#if (DEM_CFG_DEPRECOVERYLIMIT == DEM_CFG_DEPRECOVERYLIMIT_ON)
	if (Dem_AllNodesState[NodeId].performedRecoveries < Dem_AllNodesParam[NodeId].allowedRecoveries)
	{
		Dem_AllNodesState[NodeId].performedRecoveries++;
	}
#endif
}

/**
 * @ingroup DEM_EXT_H
 *
 * This function returns whether a causal failure is present at a certain node. It returns
 * TRUE: if a monitoring assigned to this node has reported a causal failure (not preliminary causal).
 * FALSE: if none of the monitoring assigned to this node has reported a causal failure.
 *
 * Hint: For further description of "causal" refer to  function design.
 *
 * @param[in] NodeId specifies the id of the node to be checked.
 */

DEM_INLINE boolean Dem_NodeHasCausalFault (Dem_NodeIdType NodeId)
{
	return Dem_Bit8IsBitSet(Dem_AllNodesState[NodeId].stateFlags, DEM_NODE_STATEFLAG_HASCAUSALFAULT);
}

DEM_INLINE void Dem_NodeSetRecoveryBlocked (Dem_NodeIdType NodeId, Dem_boolean_least newHasTriggered)
{
	Dem_Bit8OverwriteBit(&(Dem_AllNodesState[NodeId].stateFlags), DEM_NODE_STATEFLAG_RECOVERYBLOCKED, newHasTriggered);
}

DEM_INLINE Dem_boolean_least Dem_NodeIsRecoveryBlocked (Dem_NodeIdType NodeId)
{
	return Dem_Bit8IsBitSet(Dem_AllNodesState[NodeId].stateFlags, DEM_NODE_STATEFLAG_RECOVERYBLOCKED);
}

DEM_INLINE void Dem_NodeSetRecheckOnClear (Dem_NodeIdType NodeId, Dem_boolean_least newRecheckOnClear)
{
	Dem_Bit8OverwriteBit(&(Dem_AllNodesState[NodeId].stateFlags), DEM_NODE_STATEFLAG_RECHECKONCLEAR, newRecheckOnClear);
}

DEM_INLINE Dem_boolean_least Dem_NodeIsRecheckOnClear (Dem_NodeIdType NodeId)
{
	return Dem_Bit8IsBitSet(Dem_AllNodesState[NodeId].stateFlags, DEM_NODE_STATEFLAG_RECHECKONCLEAR);
}

DEM_INLINE Dem_boolean_least Dem_NodeIgnorePriority(Dem_NodeIdType NodeId)
{
	return Dem_Bit8IsBitSet(Dem_AllNodesParam[NodeId].paramFlags, DEM_NODE_PARAMFLAG_IGNOREPRIORITY);
}



void Dem_NodeRecheckOnClear (void);











#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


#else

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


DEM_INLINE Dem_boolean_least Dem_Dependencies_CheckEventIsCausal(Dem_EventIdType EventId, Dem_NodeIdType NodeId)
{
    DEM_UNUSED_PARAM(EventId);
    DEM_UNUSED_PARAM(NodeId);
    return TRUE;
}
DEM_INLINE void Dem_Dependencies_ResetNodeFailed(Dem_NodeIdType NodeId)
{
    DEM_UNUSED_PARAM(NodeId);
}

DEM_INLINE void Dem_Dependencies_SetNodeFailed(Dem_NodeIdType NodeId, boolean EventIsCausal, boolean EventStorageFiltered, boolean EventIsRecoverable)
{
    DEM_UNUSED_PARAM(NodeId);
    DEM_UNUSED_PARAM(EventIsCausal);
    DEM_UNUSED_PARAM(EventStorageFiltered);
    DEM_UNUSED_PARAM(EventIsRecoverable);
}

DEM_INLINE void Dem_Dependencies_ResetNodeFailedFiltered(Dem_NodeIdType NodeId)
{
    DEM_UNUSED_PARAM(NodeId);
}


DEM_INLINE boolean Dem_NodeIsAvailable(Dem_NodeIdType NodeId)
{
    DEM_UNUSED_PARAM(NodeId);
    return TRUE;
}


DEM_INLINE boolean Dem_NodeRecoveryAllowed (Dem_NodeIdType NodeId)
{
    DEM_UNUSED_PARAM(NodeId);
    return TRUE;
}

DEM_INLINE void Dem_NodeSetRecovered(Dem_NodeIdType NodeId)
{
    DEM_UNUSED_PARAM(NodeId);
}

DEM_INLINE boolean Dem_NodeAreAllFailedFiltered(Dem_NodeIdType NodeId)
{
    DEM_UNUSED_PARAM(NodeId);
    return FALSE;
}



DEM_INLINE void Dem_NodeSetFailed(Dem_NodeIdType NodeId, Dem_boolean_least failed, Dem_boolean_least forceReset)
{
    DEM_UNUSED_PARAM(forceReset);
    DEM_UNUSED_PARAM(NodeId);
    DEM_UNUSED_PARAM(failed);
}

DEM_INLINE void Dem_NodeSetSuspicious(Dem_NodeIdType NodeId, Dem_boolean_least suspicious)
{
    DEM_UNUSED_PARAM(NodeId);
    DEM_UNUSED_PARAM(suspicious);
}

DEM_INLINE void Dem_NodeSetAvailable(Dem_NodeIdType NodeId, boolean available)
{
    DEM_UNUSED_PARAM(NodeId);
    DEM_UNUSED_PARAM(available);
}

DEM_INLINE void Dem_NodeSetInitialized(Dem_NodeIdType NodeId, boolean init)
{
    DEM_UNUSED_PARAM(NodeId);
    DEM_UNUSED_PARAM(init);
}

DEM_INLINE void Dem_NodeSetHasCausalFault (const Dem_NodeIdType NodeId, Dem_boolean_least causalFault)
{
    DEM_UNUSED_PARAM(NodeId);
    DEM_UNUSED_PARAM(causalFault);
}

DEM_INLINE void Dem_NodeSetRecheckOnClear (Dem_NodeIdType NodeId, Dem_boolean_least newRecheckOnClear) { DEM_UNUSED_PARAM(NodeId); DEM_UNUSED_PARAM(newRecheckOnClear); }
DEM_INLINE void Dem_NodeRecheckOnClear (void) {}



#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif


#endif





/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.1; 0     03.02.2016 CLH2SI
*   CSCRM01036799
* 
* AR40.11.0.0; 2     31.12.2015 VSA2COB
*   CSCRM01016285
* 
* AR40.11.0.0; 1     17.12.2015 XZA2ABT
*   CSCRM01010150
* 
* AR40.11.0.0; 0     24.11.2015 VSA2COB
*   CSCRM01013111
* 
* AR40.10.0.0; 0     10.07.2015 CLH2SI
*   CSCRM00938605
* 
* AR40.9.0.2; 0     12.03.2015 CLH2SI
*   CSCRM00581269
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
