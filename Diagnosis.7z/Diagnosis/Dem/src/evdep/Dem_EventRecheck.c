/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_EventRecheck$
* $Variant___:AR40.11.0.1$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#include "Dem_EventRecheck.h"
#include "Dem_Types.h"
#include "Dem_Events.h"
#include "Dem_EventStatus.h"
#include "Dem_EvBuffEvent.h"
#include "Dem_EvBuff.h"
#include "Dem_Lock.h"
#include "Dem_Mapping.h"
#include "Dem_Dependencies.h"
#include "Dem_Helpers.h"


#if (DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON)


#define DEM_START_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"

#define DEM_RECHECK_ABORT_LIMIT 3
#define DEM_RECHECK_DECREASE_VALUE_FOR_RECHECKED_EVENT  5
static uint8 Dem_Dependency_RecheckCausalityAbortCounter = 0;
static Dem_NodeIdIterator Dem_Dependency_RecheckCausalityNodeIt = DEM_NODEIDITERATOR_NEW();

static boolean Dem_RecheckRecheckNodeNotRecoverableRequested = FALSE;

#define DEM_STOP_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"




#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

void Dem_DependencyInit(void)
{
	Dem_EventIdListIterator2 evtIt;
	Dem_NodeIdIterator nodeIt;
	Dem_NodeIdType currentNode;

	/* set Failed state of all nodes according to failed state of events restored from NVM */
	for (Dem_NodeIdIteratorNew(&nodeIt); Dem_NodeIdIteratorIsValid(&nodeIt); Dem_NodeIdIteratorNext(&nodeIt))
	{
		currentNode = Dem_NodeIdIteratorCurrent(&nodeIt);

		DEM_ENTERLOCK_MON_BEFORE_INIT();

		for (Dem_EventIdListIterator2NewFromNodeId (&evtIt, currentNode);
				Dem_EventIdListIterator2IsValid(&evtIt);
				Dem_EventIdListIterator2Next (&evtIt))
		{
			if ( Dem_EvtSt_GetTestFailed(Dem_EventIdListIterator2Current(&evtIt)) )
			{
				Dem_SetNodeStatus (currentNode, DEM_NODESTATUS_FAILED);
				/* explicitly requested to have the same behavior on startup and on failed-report according callback */
				Dem_NodeCallFailedCallback(currentNode, TRUE);

				break; /* if at lest one event is failed, the node is failed and no further event of this
							node needs to be checked */
			}
		}

		DEM_EXITLOCK_MON_BEFORE_INIT();
	}
}








void Dem_DependencyRestartCyclicCheck(void)
{
   if (Dem_Dependency_RecheckCausalityAbortCounter < DEM_RECHECK_ABORT_LIMIT)
   {
      Dem_NodeIdIteratorNew(&Dem_Dependency_RecheckCausalityNodeIt);
      Dem_Dependency_RecheckCausalityAbortCounter++;
   }
}


void Dem_RecheckNodeNotRecoverableRequest(void)
{
    Dem_RecheckRecheckNodeNotRecoverableRequested = TRUE;
}

static void Dem_RecheckNodeNotRecoverable(void)
{
    Dem_NodeIdIterator nodeIt;
    Dem_NodeIdType node;

    if (Dem_RecheckRecheckNodeNotRecoverableRequested)
    {
        for (Dem_NodeIdIteratorNew(&nodeIt); Dem_NodeIdIteratorIsValid(&nodeIt); Dem_NodeIdIteratorNext(&nodeIt))
        {
            node = Dem_NodeIdIteratorCurrent(&nodeIt);
            if (Dem_NodeIsFailedNotRecoverableItself(node))
            {
                DEM_ENTERLOCK_MON();
                Dem_Dependencies_ResetNodeFailedNotRecoverable(node);
                DEM_EXITLOCK_MON();
            }
        }
    }
}






static Dem_boolean_least Dem_DependencyRecheckCausalityOfEvent (Dem_EventIdType EventId, Dem_NodeIdType NodeId)
{
    Dem_EvBuffEventType eventType = C_EVENTTYPE_SET_WAITINGFORMONITORING;
    Dem_boolean_least triggerEvBuffInsert = FALSE;
    Dem_boolean_least triggerCalcNodeHasFilteredStorage = FALSE;
    Dem_boolean_least checkPerformed = FALSE;
    Dem_boolean_least newIsCausal, areAllFulfilled;

    DEM_ENTERLOCK_MON();

    if (    Dem_EvtSt_GetTestFailed(EventId)
            && Dem_NodeIsAvailable (NodeId)
            && !Dem_EvtIsSuppressed(EventId)
       )
    {
        checkPerformed = TRUE;

        /* SEQUENTIAL and STORAGEISFILTERED */
        if (!Dem_EvtIsCausal(EventId))
        {
            newIsCausal = Dem_Dependencies_CheckEventIsCausal(EventId, NodeId);
            areAllFulfilled = Dem_StoCoAreAllFulfilled(Dem_EvtGetStorageConditions(EventId));


            /* STORAGEISFILTERED -> ISCAUSAL   and  SEQUENTIAL -> ISCAUSAL */
            if (newIsCausal)
            {
                if (areAllFulfilled)
                {
                    Dem_EvtSetCausal (EventId, TRUE);
                    Dem_EvtSetIsRecheckedAndWaitingForMonResult(EventId, TRUE);
                    Dem_EvtSetStorageFiltered (EventId, FALSE);

                    Dem_EvtSetInitMonitoring (EventId, DEM_INIT_MONITOR_STORAGE_REENABLED);

                    Dem_Dependencies_ResetNodeFailedFiltered(NodeId);
                    triggerEvBuffInsert = TRUE;
                }
                else
                {
                    Dem_StoCoRecheckReplacementStorage(Dem_EvtGetStorageConditions(EventId));
                }
            }

            /* SEQUENTIAL -> STORAGEISFILTERED */
            if (!Dem_EvtIsStorageFiltered(EventId) && newIsCausal && !areAllFulfilled)
            {
                Dem_StoCoSetHasFilteredEvent(Dem_EvtGetStorageConditions(EventId)
                            DEM_DEBUGDATA_PARAM((Dem_DebugDataType)EventId,0));
                triggerCalcNodeHasFilteredStorage = TRUE;
            }
        }

        /* INVALID_STATE: Causal & StorageFiltered shall not occure, but must be rechecked! */
        if (   Dem_EvtIsCausal(EventId)
            && Dem_EvtIsStorageFiltered(EventId)
        )
        {
            if (Dem_StoCoAreAllFulfilled(Dem_EvtGetStorageConditions(EventId)))
            {
                Dem_EvtSetStorageFiltered (EventId, FALSE);
            }
            else
            {
                Dem_EvtSetCausal (EventId, FALSE);
                Dem_StoCoSetHasFilteredEvent(Dem_EvtGetStorageConditions(EventId)
                                            DEM_DEBUGDATA_PARAM((Dem_DebugDataType)EventId,0));
            }
        }
    }

    DEM_EXITLOCK_MON();

    if (triggerEvBuffInsert)
    {
        DEM_ENTERLOCK_MON();
        if (!Dem_EvBuffInsert (eventType, EventId DEM_DEBUGDATA_PARAM((Dem_DebugDataType)0xffffffffu, (Dem_DebugDataType)0xffffffffu)))
        {
            Dem_EvtSetCausal (EventId, FALSE);
            Dem_EvtSetIsRecheckedAndWaitingForMonResult(EventId, FALSE);
        }
        DEM_EXITLOCK_MON();
   }

    return checkPerformed;
}


static void Dem_Dependency_RecheckCausalityMain (void)
{
    /* check all EventIds; whether they were not stored due to an evbuffer overflow */

    static Dem_EventIdIterator Dem_RecheckEventIterator = DEM_EVENTIDITERATORNEW;
    Dem_EventIdType eventId;
    sint16_least eventsCheckedCounter = DEM_MIN(80, DEM_EVENTID_COUNT); // search configured number, but at maximum number of events

    while (eventsCheckedCounter > 0)
    {
        eventsCheckedCounter--;
        eventId = Dem_EventIdIteratorCurrent(&Dem_RecheckEventIterator);

        /* if event is failed and either filtered or not causal  then perform recheck */
        if (   Dem_EvtSt_GetTestFailed(eventId)
            && (   !Dem_EvtIsCausal(eventId)
                || Dem_EvtIsStorageFiltered(eventId)
               )
           )
        {
            /* recheck causality, insert into SFB and set GCT */
            Dem_DependencyRecheckCausalityOfEvent(eventId, Dem_NodeIdFromEventId(eventId));

            /* the actual check is more time consuming so additionally dec the counter (load-balancing of mainfunction) */
            eventsCheckedCounter -= DEM_RECHECK_DECREASE_VALUE_FOR_RECHECKED_EVENT  ;
        }

        DEM_ENTERLOCK_MON();    /* D_212: interrupt lock */

        Dem_EventIdIteratorNext(&Dem_RecheckEventIterator);
        if (!Dem_EventIdIteratorIsValid(&Dem_RecheckEventIterator))
        {
            Dem_EventIdIteratorNew(&Dem_RecheckEventIterator);
        }

        DEM_EXITLOCK_MON();    /* D_212: interrupt lock */
    }
}



void Dem_DependencyMainFunction(void)
{
    Dem_Dependency_RecheckCausalityMain ();
    Dem_RecheckNodeNotRecoverable();
}

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif


/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.1; 0     03.02.2016 CLH2SI
*   CSCRM01036799
* 
* AR40.9.0.2; 0     12.03.2015 CLH2SI
*   CSCRM00581269
* 
* AR40.9.0.0; 1     22.08.2014 CLH2SI
*   CSCRM00688436
* 
* AR40.9.0.0; 0     20.08.2014 VSA2COB
*   CSCRM00698491
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 5     21.11.2013 AMN2KOR
*   CSCRM00591723
* 
* AR40.7.0.0; 4     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 3     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 2     08.08.2013 CLH2SI
*   CSCRM00532300
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
