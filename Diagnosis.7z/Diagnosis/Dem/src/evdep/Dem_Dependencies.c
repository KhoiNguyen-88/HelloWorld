/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_Dependencies$
* $Variant___:AR40.11.0.0$
* $Revision__:4$
**********************************************************************************************************************
</BASDKey>*/

#include "Dem_Ext.h"
#include "Dem_Events.h"
#include "Dem_EventStatus.h"
#include "Dem_Dependencies.h"
#include "Dem_Mapping.h"
#include "Dem_Cfg_ExtPrototypes.h"

#if (DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON)

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

DEM_ARRAY_DEFINE(      Dem_NodeState, Dem_AllNodesState, DEM_NODEID_ARRAYLENGTH);

#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"



#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

/* MISRA RULE 19.8 VIOLATION: A function-like macro shall not be invoked without all of its arguments, hence some of the arguments are optional based on configuration */
DEM_ARRAY_DEFINE_CONST(Dem_NodeParam, Dem_AllNodesParam, DEM_NODEID_ARRAYLENGTH, DEM_CFG_NODEPARAMS);
#if (DEM_CFG_NODEFAILEDCALLBACK_COUNT > 0)
DEM_ARRAY_DEFINE_CONST(Dem_NodeFailedCallbackType, Dem_NodeFailedCallbacks, DEM_CFG_NODEFAILEDCALLBACK_ARRAYLENGTH, DEM_CFG_NODEFAILEDCALLBACKS);
#endif

#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"



#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

Dem_boolean_least Dem_SetNodeStatus (const Dem_NodeIdType NodeId, uint8 statusIndex)
{
    Dem_NodeIdListIterator childIt;

    DEM_ASSERT_ISLOCKED();
	if (!Dem_NodeStatusIsSet(Dem_AllNodesState[NodeId].status[statusIndex]))
	{
		Dem_NodeStatusSet(&(Dem_AllNodesState[NodeId].status[statusIndex]));

		for (Dem_NodeIdListIteratorNewFromNodeId (&childIt, NodeId);
				Dem_NodeIdListIteratorIsValid (&childIt);
				Dem_NodeIdListIteratorNext (&childIt))
		{
			DEM_ASSERT(((Dem_AllNodesState[Dem_NodeIdListIteratorCurrent(&childIt)].status[statusIndex] & DEM_NODESTATUS__ANCESTORMASK) < DEM_NODESTATUS__ANCESTORMASK), DEM_DET_APIID_EVENTDEPENDENCY, 0);
			Dem_AllNodesState[Dem_NodeIdListIteratorCurrent(&childIt)].status[statusIndex]++;
		}
		return TRUE;
	}
	return FALSE;
}

Dem_boolean_least Dem_ResetNodeStatus (const Dem_NodeIdType NodeId, uint8 statusIndex)
{
    Dem_NodeIdListIterator childIt;

    DEM_ASSERT_ISLOCKED();
	if (Dem_NodeStatusIsSet(Dem_AllNodesState[NodeId].status[statusIndex]))
	{
		Dem_NodeStatusReset(&(Dem_AllNodesState[NodeId].status[statusIndex]));

		for (Dem_NodeIdListIteratorNewFromNodeId (&childIt, NodeId);
				Dem_NodeIdListIteratorIsValid (&childIt);
				Dem_NodeIdListIteratorNext (&childIt))
		{
			DEM_ASSERT(((Dem_AllNodesState[Dem_NodeIdListIteratorCurrent(&childIt)].status[statusIndex] & DEM_NODESTATUS__ANCESTORMASK) > 0), DEM_DET_APIID_EVENTDEPENDENCY, 1);
			Dem_AllNodesState[Dem_NodeIdListIteratorCurrent(&childIt)].status[statusIndex]--;
		}
		return TRUE;
	}
	return FALSE;
}


/* MISRA RULE 19.10 VIOLATION : Macro parameter FUNCTIONNAME may not be enclosed in (). */
#define DEM_NODE_CHECK_EVENTS_ATTRIBUTE(EVTIT, NODEID, FUNCTIONNAME, STATEVAR)             \
do {                                                                        \
	(STATEVAR) = FALSE;                                                     \
	for (Dem_EventIdListIterator2NewFromNodeId(&(EVTIT), NODEID);             \
			Dem_EventIdListIterator2IsValid(&(EVTIT));                        \
			Dem_EventIdListIterator2Next(&(EVTIT)))                           \
	{                                                                       \
		(STATEVAR) = (STATEVAR) || FUNCTIONNAME(Dem_EventIdListIterator2Current(&(EVTIT)));   \
	}                                                                       \
} while (FALSE)







Dem_boolean_least Dem_Dependencies_CheckEventIsCausal(Dem_EventIdType EventId, Dem_NodeIdType NodeId)
{
    Dem_EventIdListIterator2 evtIt;

    DEM_ASSERT_ISLOCKED();

    if (!Dem_NodeIdIsValid(NodeId))
    {
        return TRUE;
    }

    /* DSM_D_37: failure sequential, if one ancestor is invalid */
    if ( Dem_NodeStatusIsAnyAncestorSet(Dem_AllNodesState[NodeId].status[DEM_NODESTATUS_FAILED]) )
    {
        return FALSE;
    }
    else
    {
        if (Dem_NodeIgnorePriority(NodeId))
        {
            return TRUE;
        }
        else
        {
            Dem_EventIdListIterator2NewFromNodeId (&evtIt, NodeId);

            /* DSM_D_37: failure sequential, if monitoring with higher */
            /* prio at node has reported failure */
            while (Dem_EventIdListIterator2IsValid(&evtIt))
            {
                /* only check events with higher prio at node; not event itself nor lower prio events, therefore cancel loop */
                if (Dem_EventIdListIterator2Current(&evtIt) == EventId)
                {
                    return TRUE;
                }

                if ( Dem_EvtSt_GetTestFailed(Dem_EventIdListIterator2Current(&evtIt)) )
                {
                    return FALSE;
                }

                Dem_EventIdListIterator2Next (&evtIt);
            }
        }
    }

    /* should never be reached */
    DEM_ASSERT(FALSE, DEM_DET_APIID_EVENTDEPENDENCIES_ISCAUSAL, 0);
    return TRUE;
}




void Dem_Dependencies_SetNodeFailed(Dem_NodeIdType NodeId, boolean EventIsCausal, boolean EventStorageFiltered, boolean EventIsRecoverable)
{
    DEM_ASSERT_ISLOCKED();

    DEM_ASSERT(!(EventIsCausal && EventStorageFiltered), DEM_DET_APIID_EVENTDEPENDENCIES, 0);

    if (!Dem_NodeIdIsValid(NodeId))
    {
        return;
    }

    /* calculate statemachine */
    if (Dem_NodeIsFailedItself(NodeId))
    {
        if (Dem_NodeIsFailedFilteredItself(NodeId))
        {
            /* state FailedFiltered */
            if (EventIsCausal && !(EventStorageFiltered))
            {
                Dem_ResetNodeStatus(NodeId, DEM_NODESTATUS_FAILEDFILTERED);
                if (!EventIsRecoverable)
                {
                    Dem_SetNodeStatus(NodeId, DEM_NODESTATUS_FAILEDNOTRECOVERABLE);
                }
            }
        } else
        {
            /* state Failed */
            if (EventIsCausal && !EventIsRecoverable)
            {
                Dem_SetNodeStatus(NodeId, DEM_NODESTATUS_FAILEDNOTRECOVERABLE);
            }
        }
    } else
    {
        /* state Valid */
        Dem_SetNodeStatus(NodeId, DEM_NODESTATUS_FAILED);
        if (EventIsCausal && !EventIsRecoverable)
        {
            Dem_SetNodeStatus(NodeId, DEM_NODESTATUS_FAILEDNOTRECOVERABLE);
        } else
        {
            if (EventStorageFiltered)
            {
                Dem_SetNodeStatus(NodeId, DEM_NODESTATUS_FAILEDFILTERED);
            }
        }
    }

    /* todo: add to diagram */
    Dem_NodeCallFailedCallback(NodeId, TRUE);
}


void Dem_Dependencies_ResetNodeFailed(Dem_NodeIdType NodeId)
{
    Dem_boolean_least anyMonFailed;
    Dem_EventIdListIterator2 evtIt;

    if (!Dem_NodeIdIsValid(NodeId))
    {
        return;
    }

    DEM_ASSERT_ISLOCKED();

    DEM_NODE_CHECK_EVENTS_ATTRIBUTE (evtIt, NodeId, Dem_EvtSt_GetTestFailed, anyMonFailed);

    if (!anyMonFailed)
    {
        Dem_ResetNodeStatus(NodeId,DEM_NODESTATUS_FAILED);
        Dem_ResetNodeStatus(NodeId,DEM_NODESTATUS_FAILEDFILTERED);
        Dem_ResetNodeStatus(NodeId,DEM_NODESTATUS_FAILEDNOTRECOVERABLE);
        Dem_NodeCallFailedCallback(NodeId, FALSE);
    }
}


void Dem_Dependencies_ResetNodeFailedFiltered(Dem_NodeIdType NodeId)
{
    DEM_ASSERT_ISLOCKED();
    Dem_ResetNodeStatus(NodeId,DEM_NODESTATUS_FAILEDFILTERED);
}


void Dem_Dependencies_ResetNodeFailedNotRecoverable(Dem_NodeIdType NodeId)
{
    Dem_boolean_least anyMonNotRecoverable;
    Dem_EventIdListIterator2 evtIt;

    if (!Dem_NodeIdIsValid(NodeId))
    {
        return;
    }

    DEM_ASSERT_ISLOCKED();

    DEM_NODE_CHECK_EVENTS_ATTRIBUTE (evtIt, NodeId, Dem_EvtIsNotRecoverableTOC, anyMonNotRecoverable);

    if (!anyMonNotRecoverable)
    {
        Dem_ResetNodeStatus(NodeId,DEM_NODESTATUS_FAILEDNOTRECOVERABLE);
    }
}


void Dem_NodeSetSuspicious(Dem_NodeIdType NodeId, Dem_boolean_least suspicious)
{
	Dem_boolean_least anyMonSuspicious;
	Dem_EventIdListIterator2 evtIt;

	DEM_ENTERLOCK_MON_BEFORE_INIT();

	if (suspicious)
	{
		(void)Dem_SetNodeStatus (NodeId, DEM_NODESTATUS_SUSPICIOUS);
	}
	else
	{
		/* check if any event is testfailed at node */
		DEM_NODE_CHECK_EVENTS_ATTRIBUTE (evtIt, NodeId, Dem_EvtIsSuspicious, anyMonSuspicious);

		if (!anyMonSuspicious)
		{
			(void)Dem_ResetNodeStatus(NodeId,DEM_NODESTATUS_SUSPICIOUS);
		}
	}

	DEM_EXITLOCK_MON_BEFORE_INIT();
}



void Dem_NodeSetHasCausalFault (const Dem_NodeIdType NodeId, Dem_boolean_least causalFault)
{
	Dem_EventIdListIterator2 evtIt;
	Dem_boolean_least hasCausalFault;


	DEM_ENTERLOCK_MON_BEFORE_INIT();    /* D_212: interrupt lock */

	if (causalFault)
	{
		Dem_Bit8OverwriteBit(&(Dem_AllNodesState[NodeId].stateFlags), DEM_NODE_STATEFLAG_HASCAUSALFAULT, TRUE);
	}
	else
	{
		DEM_NODE_CHECK_EVENTS_ATTRIBUTE (evtIt, NodeId, Dem_EvtIsCausal, hasCausalFault);
		Dem_Bit8OverwriteBit(&(Dem_AllNodesState[NodeId].stateFlags), DEM_NODE_STATEFLAG_HASCAUSALFAULT, hasCausalFault);
	}

	DEM_EXITLOCK_MON_BEFORE_INIT();  /* D_212: interrupt lock */
}


void Dem_NodeSetAvailable(Dem_NodeIdType NodeId, boolean available)
{
	DEM_ENTERLOCK_MON_BEFORE_INIT();

	if (!available)
	{
		(void)Dem_SetNodeStatus (NodeId, DEM_NODESTATUS_NOTAVAILABLE);
	}
	else
	{
		(void)Dem_ResetNodeStatus(NodeId,DEM_NODESTATUS_NOTAVAILABLE);
	}

	DEM_EXITLOCK_MON_BEFORE_INIT();
}


void Dem_NodeSetInitialized(Dem_NodeIdType NodeId, boolean init)
{
	DEM_ENTERLOCK_MON_BEFORE_INIT();

	if (!init)
	{
		(void)Dem_SetNodeStatus (NodeId, DEM_NODESTATUS_NOTINIT);
	}
	else
	{
		(void)Dem_ResetNodeStatus(NodeId,DEM_NODESTATUS_NOTINIT);
	}

	DEM_EXITLOCK_MON_BEFORE_INIT();
}


void Dem_NodeRecheckOnClear (void)
{
	Dem_NodeIdIterator nodeIt;
	for (Dem_NodeIdIteratorNew(&nodeIt); Dem_NodeIdIteratorIsValid(&nodeIt); Dem_NodeIdIteratorNext(&nodeIt))
	{
		if (Dem_NodeIsRecheckOnClear(Dem_NodeIdIteratorCurrent(&nodeIt)))
		{
		    DEM_ENTERLOCK_MON();
		    Dem_NodeSetRecheckOnClear (Dem_NodeIdIteratorCurrent(&nodeIt), FALSE);
			Dem_Dependencies_ResetNodeFailed(Dem_NodeIdIteratorCurrent(&nodeIt));
			Dem_NodeSetHasCausalFault(Dem_NodeIdIteratorCurrent(&nodeIt), FALSE);
            DEM_EXITLOCK_MON();
		}
	}
}

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is depending on compiler switch setting */
Std_ReturnType Dem_GetComponentSuspicious (Dem_ComponentIdType ComponentId, boolean* ComponentSuspicious)
{
#if ((DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON) && (DEM_CFG_SUSPICIOUS_SUPPORT))
    if ((!Dem_NodeIdIsValid(ComponentId)) && (!Dem_NodeIsAvailable (ComponentId)))
    {
        return E_NOT_OK;
    }

    *ComponentSuspicious = Dem_NodeIsSuspicious(ComponentId);
    return E_OK;
#else
    DEM_UNUSED_PARAM(ComponentId);
    DEM_UNUSED_PARAM(ComponentSuspicious);
    return E_NOT_OK;
#endif
}

/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is depending on compiler switch setting */
Std_ReturnType Dem_GetComponentUsable (Dem_ComponentIdType ComponentId, boolean* ComponentUsable)
{
#if (DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON)
    if(!Dem_NodeIdIsValid(ComponentId))
    {
        return E_NOT_OK;
    }

    *ComponentUsable = Dem_NodeIsUsable(ComponentId);
    return E_OK;
#else
    DEM_UNUSED_PARAM(ComponentId);
    DEM_UNUSED_PARAM(ComponentUsable);
    return E_NOT_OK;
#endif
}

/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is depending on compiler switch setting */
Std_ReturnType Dem_GetComponentRestrictedUsable (Dem_ComponentIdType ComponentId, boolean* ComponentRestrictedUsable)
{
#if (DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON)
    if(!Dem_NodeIdIsValid(ComponentId))
    {
        return E_NOT_OK;
    }

   *ComponentRestrictedUsable = Dem_NodeIsRestrictedUsable(ComponentId);
    return E_OK;
#else
    DEM_UNUSED_PARAM(ComponentId);
    DEM_UNUSED_PARAM(ComponentRestrictedUsable);
    return E_NOT_OK;
#endif
}

/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is depending on compiler switch setting */
Std_ReturnType Dem_GetComponentInitialized (Dem_ComponentIdType ComponentId, boolean* ComponentInitialized)
{
#if (DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON)
    if(!Dem_NodeIdIsValid(ComponentId))
    {
        return E_NOT_OK;
    }

    *ComponentInitialized = Dem_NodeIsInitialized(ComponentId);
    return E_OK;
#else
    DEM_UNUSED_PARAM(ComponentId);
    DEM_UNUSED_PARAM(ComponentInitialized);
    return E_NOT_OK;
#endif
}

/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is depending on compiler switch setting */
Std_ReturnType Dem_GetComponentFailed (Dem_ComponentIdType ComponentId, boolean* ComponentFailed)
{
#if (DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON)
    if(!Dem_NodeIdIsValid(ComponentId))
    {
        return E_NOT_OK;
    }

    *ComponentFailed = Dem_NodeIsFailed(ComponentId);
    return E_OK;
#else
    DEM_UNUSED_PARAM(ComponentId);
    DEM_UNUSED_PARAM(ComponentFailed);
    return E_NOT_OK;
#endif
}

/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is depending on compiler switch setting */
Std_ReturnType Dem_GetComponentFailedItself(Dem_ComponentIdType ComponentId, boolean* ComponentFailedItself)
{
#if (DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON)
    if(!Dem_NodeIdIsValid(ComponentId))
    {
        return E_NOT_OK;
    }

   *ComponentFailedItself = Dem_NodeIsFailedItself(ComponentId);
    return E_OK;
#else
    DEM_UNUSED_PARAM(ComponentId);
    DEM_UNUSED_PARAM(ComponentFailedItself);
    return E_NOT_OK;
#endif
}

/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is depending on compiler switch setting */
Std_ReturnType Dem_GetComponentSuspiciousItself(Dem_ComponentIdType ComponentId, boolean* ComponentSuspiciousItself)
{
#if (DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON)
    if(!Dem_NodeIdIsValid(ComponentId))
    {
        return E_NOT_OK;
    }

   *ComponentSuspiciousItself = Dem_NodeIsSuspiciousItself(ComponentId);
    return E_OK;
#else
    DEM_UNUSED_PARAM(ComponentId);
    DEM_UNUSED_PARAM(ComponentSuspiciousItself);
    return E_NOT_OK;
#endif
}

/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is depending on compiler switch setting */
Std_ReturnType Dem_GetComponentAvailable(Dem_ComponentIdType ComponentId, boolean* ComponentAvailable)
{
#if (DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON)
    if(!Dem_NodeIdIsValid(ComponentId))
    {
        return E_NOT_OK;
    }

   *ComponentAvailable = Dem_NodeIsAvailable(ComponentId);
    return E_OK;
#else
    DEM_UNUSED_PARAM(ComponentId);
    DEM_UNUSED_PARAM(ComponentAvailable);
    return E_NOT_OK;
#endif
}

/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is depending on compiler switch setting */
Std_ReturnType Dem_GetComponentAreAncestorsInitialized(Dem_ComponentIdType ComponentId, boolean* ComponentAreAncestorsInitialized)
{
#if (DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON)
    if(!Dem_NodeIdIsValid(ComponentId))
    {
        return E_NOT_OK;
    }
   *ComponentAreAncestorsInitialized = Dem_NodeAreAncestorsInitialized(ComponentId);
    return E_OK;
#else
    DEM_UNUSED_PARAM(ComponentId);
    DEM_UNUSED_PARAM(ComponentAreAncestorsInitialized);
    return E_NOT_OK;
#endif
}

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 4     11.01.2016 NAL2KOR
*   CSCRM01015983
* 
* AR40.11.0.0; 3     31.12.2015 VSA2COB
*   CSCRM01016285
* 
* AR40.11.0.0; 2     18.12.2015 TVE5COB
*   CSCRM01013078
* 
* AR40.11.0.0; 1     24.11.2015 VSA2COB
*   CSCRM01013111
* 
* AR40.11.0.0; 0     10.11.2015 VSA2COB
*   Checkout by vsa2cob
* 
* AR40.10.0.0; 1     10.07.2015 CLH2SI
*   CSCRM00938605
* 
* AR40.10.0.0; 0     17.06.2015 VSA2COB
*   CSCRM00880343
* 
* AR40.9.0.2; 0     12.03.2015 CLH2SI
*   CSCRM00581269
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
