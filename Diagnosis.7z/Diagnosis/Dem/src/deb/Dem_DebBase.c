/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_DebBase$
* $Variant___:AR40.11.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/



#include "Dem_DebBase.h"
#include "Dem_DebSharing.h"
#include "Dem_DebArCounter.h"
#include "Dem_DebArTime.h"
#include "Dem_DebCtrBaseClass.h"
#include "Dem_DebMonInternal.h"
#include "Dem_Cfg_ExtPrototypes.h"
#include "Dem_Lib.h"
#include "Rte_Dem.h"
#include "Dem_Protected.h"


#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
DEM_CFG_DEB_DEFINE_ALL_PARAMSETS
#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"



#if ( (DEM_CFG_DEBCOUNTERBASECLASS == DEM_CFG_DEBCOUNTERBASECLASS_ON) && (!defined DEM_DEB_FORCE_CONST_CONFIG) )
#define DEM_START_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"
Dem_DebClass Dem_Cfg_DebClasses[DEM_CFG_DEB_NUMBEROFCLASSES] = DEM_CFG_DEB_CLASSES;
#define DEM_STOP_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"
#else
#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
const Dem_DebClass Dem_Cfg_DebClasses[DEM_CFG_DEB_NUMBEROFCLASSES] = DEM_CFG_DEB_CLASSES;
#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
#endif



#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
void Dem_DebSwitchToAlternativeParameters(void)
{
#if ( (DEM_CFG_DEBCOUNTERBASECLASS == DEM_CFG_DEBCOUNTERBASECLASS_ON) && (!defined DEM_DEB_FORCE_CONST_CONFIG) )
    Dem_Cfg_DebClasses[DEM_DEBMETH_IDX_ARCTRBASECLASS].paramSet = &Dem_Cfg_DebCounterBaseClass_Paramset_Alternative;
#endif
}
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"




/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 1     07.01.2016 TVE5COB
*   CSCRM01017790
* 
* AR40.11.0.0; 0     10.11.2015 VSA2COB
*   Checkout by vsa2cob
* 
* AR40.10.0.0; 0     18.06.2015 CLH2SI
*   CSCRM00880977
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
