/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_DebArCounter$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_DEBARCOUNTER_H
#define DEM_DEBARCOUNTER_H


#include "Dem_Types.h"


typedef struct
{
   boolean isJumpUpActive;
   boolean isJumpDownActive;
   sint16 minThreshold;
   sint16 maxThreshold;
   sint16 stepUp;
   sint16 stepDown;
   sint16 jumpUpValue;
   sint16 jumpDownValue;
   sint16 FDCThreshold;
   sint16 SuspiciousThreshold;
} Dem_DebArCounter_ParamSet;

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
void Dem_DebArCounter_GetLimits (const void* paramSet, uint16 paramIndex, sint16_least* MinThreshold, sint16_least* MaxThreshold);
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     10.11.2015 VSA2COB
*   Checkout by vsa2cob
* 
* AR40.8.0.0; 3     17.07.2014 SAL2COB
*   CSCRM00501728
* 
* AR40.8.0.0; 2     15.05.2014 VSA2COB
*   CSCRM00662943
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 4     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 3     19.11.2013 BRM2COB
*   
* 
* AR40.7.0.0; 2     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 1     20.08.2013 BRM2COB
*   CSCRM00548906 : Fix review findings
* 
* AR40.7.0.0; 0     20.08.2013 BRM2COB
*   
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
