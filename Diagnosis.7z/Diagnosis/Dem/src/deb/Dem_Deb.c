/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_Deb$
* $Variant___:AR40.11.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/


#include "Dem_Deb.h"
//#include "Dem_DebSharing.h" //already provided by Dem_Deb
#include "Dem_DebArCounter.h"
#include "Dem_DebArTime.h"
#include "Dem_DebMonInternal.h"
#include "Dem_DebCtrBaseClass.h"
#include "Dem_EvMemGen.h"
#include "Dem_DTCs.h"
#include "Dem_OperationCycle.h"
#include "Dem_EventFHandling.h"
#include "Dem_Cfg_ExtPrototypes.h"
#include "Rte_Dem.h"
#include "Dem_Protected.h"


#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"



Std_ReturnType Dem_DebGetDebounceCounter4Calculation (Dem_EventIdType EventId, sint16 *debounceCounter)
{
#if (DEM_CFG_DEBMONINTERNAL == DEM_CFG_DEBMONINTERNAL_ON)
	sint8 faultDetectionCounter;
#endif
	Std_ReturnType result;
	const void* paramSet;

#if (DEM_CFG_DEBMONINTERNAL == DEM_CFG_DEBMONINTERNAL_ON)
	if(Dem_EvtGetDebounceMethodIndex(EventId) == DEM_DEBMETH_IDX_MONINTERNAL)
	{
		paramSet = Dem_Cfg_DebClasses[Dem_EvtGetDebounceMethodIndex(EventId)].paramSet;

		/* Get the FDC value from the application. */
#ifdef DEM_CFG_GENERAL_GETFDC
		if (((const Dem_DebounceMonitorInternal*)paramSet)[Dem_EvtGetDebounceParamSetIndex(EventId)].funcPointer_GetFDC==NULL_PTR)
		{
			result = DEM_CFG_GENERAL_GETFDC(EventId,&faultDetectionCounter);
		}
		else
#endif
		{
		    /* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
			result = ((const Dem_DebounceMonitorInternal*)paramSet)[Dem_EvtGetDebounceParamSetIndex(EventId)].funcPointer_GetFDC(&faultDetectionCounter);
		}
		*debounceCounter = faultDetectionCounter;
	}
	else
#endif
	{
	    if (Dem_EvtIsResetFailureFilterRequested(EventId)
#if (!DEM_CFG_DTCSETTINGBLOCKSREPORTING)
	            || (Dem_EvtIsResetFailureFilterRequestedAfterDtcSetting(EventId) && Dem_IsEventEnabledByDtcSetting(EventId))
#endif
	    )
	    {
            *debounceCounter = 0;
	    }
	    else
	    {
            *debounceCounter = Dem_EvtGetDebounceLevel(EventId);
	    }
	    result = E_OK;
	}
	return result;
}

sint8 Dem_DebCalculateFaultDetectionCounter(Dem_EventIdType EventId, sint16 debounceCounter)
{
	Dem_DebGetLimits funcPoint;
	const void* paramSet;
	sint16_least MinThreshold;
	sint16_least MaxThreshold;

#if (DEM_CFG_DEBMONINTERNAL == DEM_CFG_DEBMONINTERNAL_ON)
	if(Dem_EvtGetDebounceMethodIndex(EventId) == DEM_DEBMETH_IDX_MONINTERNAL)
	{
		/* calculation was already done in Dem_DebGetDebounceCounter4Calculation. */
		return (sint8)debounceCounter;
	}
	else
#endif
	{
		funcPoint
				= Dem_Cfg_DebClasses[Dem_EvtGetDebounceMethodIndex(EventId)].funcPointer_GetLimits;
		paramSet = Dem_Cfg_DebClasses[Dem_EvtGetDebounceMethodIndex(EventId)].paramSet;

		(*funcPoint) (paramSet, Dem_EvtGetDebounceParamSetIndex(EventId), &MinThreshold,
				&MaxThreshold);

		{
			if (debounceCounter > 0)
			{
				DEM_ASSERT(MaxThreshold > 0,DEM_DET_APIID_GETFAULTDETECTIONCOUNTER, 0);

				return (sint8) (((sint32)debounceCounter * DEM_DEB_DEBLEVEL_MAXTHRESHOLD) / (MaxThreshold));
			}
			else if (debounceCounter < 0)
			{
				DEM_ASSERT(MaxThreshold>0,DEM_DET_APIID_GETFAULTDETECTIONCOUNTER,1);

				return  (sint8) (((sint32)debounceCounter * DEM_DEB_DEBLEVEL_MINTHRESHOLD) / (MinThreshold));
			}
			else
			{
			   /* Do Nothing */
			}
		}
		return 0;
	}
}



Std_ReturnType Dem_GetFaultDetectionCounter(Dem_EventIdType EventId, sint8* FaultDetectionCounter)
{
	sint16 debounceCounter;
	Std_ReturnType result;
	sint8 faultDetectionCtrVal = 0;

	if (!Dem_isEventIdValid(EventId))
	{
		DEM_DET(DEM_DET_APIID_GETFAULTDETECTIONCOUNTER, 2);
		return E_NOT_OK;
	}

	if(Dem_EvtIsSuppressed(EventId))
	{
		return E_NOT_OK;
	}

	result = Dem_DebGetDebounceCounter4Calculation (EventId, &debounceCounter);
	faultDetectionCtrVal = Dem_DebCalculateFaultDetectionCounter(EventId, debounceCounter);

	if (result == E_OK)
	{
		*FaultDetectionCounter = faultDetectionCtrVal;
	}
	return result;
}

Std_ReturnType Dem_ResetEventDebounceStatus (Dem_EventIdType EventId, Dem_DebounceResetStatusType DebounceResetStatus)
{

	if(Dem_EvtIsSuppressed(EventId))
	{
		return E_NOT_OK;
	}

	DEM_ENTERLOCK_MON();

	Dem_EvtSetLastReportedEvent(EventId, DEM_EVENT_STATUS_INVALIDREPORT);
	if (DebounceResetStatus == DEM_DEBOUNCE_STATUS_RESET)
	{
		Dem_EvtSetDebounceLevel(EventId, 0);
	}

	DEM_EXITLOCK_MON();
	return E_OK;
}

Std_ReturnType Dem_ManipulateEventDebounceStatus (Dem_EventIdType EventId, Dem_DebugDataType debug0, Dem_DebugDataType debug1, sint16 manipulationValue)
{
	sint32 maxThreshold = 0;
	sint32 minThreshold = 0;
	const void* paramSet;
	uint16 paramIndex = 0;
	sint32 jumpUpValue = 0;
	sint32 jumpDownValue = 0;
	boolean isJumpUpEnabled = FALSE;
	boolean isJumpDownEnabled = FALSE;

	sint32 debLevel;
	uint8_least debAction = DEM_DEBACTION_NOOP;
	Dem_EventStatusType status = DEM_EVENT_STATUS_INVALIDREPORT;

#if (DEM_CFG_DEBUGDATA == DEM_CFG_DEBUGDATA_OFF)
		DEM_UNUSED_PARAM(debug0);
		DEM_UNUSED_PARAM(debug1);
#endif

	if (!Dem_isEventIdValid(EventId))
	{
		return E_NOT_OK;
	}

	if (!Dem_OpMoIsInitialized())
	{
		DEM_DET(DEM_DET_APIID_SETEVENTSTATUS, DEM_E_UNINIT);
		return E_NOT_OK;
	}

	if ( !Dem_EvtAllEnableConditionsFulfilled(EventId)
		|| !Dem_isOperationCycleStarted(Dem_EvtGetOperationCycleId(EventId))
		|| Dem_EvtIsSuppressed(EventId)
		|| !Dem_IsEventReportingEnabledByDtcSetting(EventId))
	{
		return E_NOT_OK;
	}

	if (Dem_EvtGetDebounceMethodIndex(EventId) == 0)
	{
		return E_NOT_OK;
	}

#if (DEM_CFG_DEBARTIMEBASE == DEM_CFG_DEBARTIMEBASE_ON)
	if(Dem_EvtGetDebounceMethodIndex(EventId) == DEM_DEBMETH_IDX_ARTIME)
	{
		return E_NOT_OK;
	}
#endif

	paramSet = Dem_Cfg_DebClasses[Dem_EvtGetDebounceMethodIndex(EventId)].paramSet;
	paramIndex = Dem_EvtGetDebounceParamSetIndex(EventId);

#if(DEM_CFG_DEBCOUNTERBASECLASS == DEM_CFG_DEBCOUNTERBASECLASS_ON)
	if(Dem_EvtGetDebounceMethodIndex(EventId) == DEM_DEBMETH_IDX_ARCTRBASECLASS)
	{
		minThreshold = Dem_getDebCtrBaseClassPassedThreshold(paramSet,paramIndex);
		maxThreshold = Dem_getDebCtrBaseClassFailedThreshold(paramSet,paramIndex);
		jumpDownValue = Dem_getDebCtrBaseClassJumpDownValue(paramSet,paramIndex);
		jumpUpValue = Dem_getDebCtrBaseClassJumpUpValue(paramSet,paramIndex);
		isJumpDownEnabled = Dem_getDebCtrBaseClassIsJumpDown(paramSet,paramIndex);
		isJumpUpEnabled = Dem_getDebCtrBaseClassIsJumpUp(paramSet,paramIndex);
	}
#endif

#if(DEM_CFG_DEBARCOUNTERBASE == DEM_CFG_DEBARCOUNTERBASE_ON)
	if(Dem_EvtGetDebounceMethodIndex(EventId) == DEM_DEBMETH_IDX_ARCOUNTER)
	{
	    /* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
		minThreshold = ((const Dem_DebArCounter_ParamSet*) paramSet)[paramIndex].minThreshold;
		/* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
		maxThreshold = ((const Dem_DebArCounter_ParamSet*) paramSet)[paramIndex].maxThreshold;
		/* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
		jumpDownValue = ((const Dem_DebArCounter_ParamSet*) paramSet)[paramIndex].jumpDownValue;
		/* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
		jumpUpValue = ((const Dem_DebArCounter_ParamSet*) paramSet)[paramIndex].jumpUpValue;
		/* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
		isJumpDownEnabled = ((const Dem_DebArCounter_ParamSet*) paramSet)[paramIndex].isJumpDownActive;
		/* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
		isJumpUpEnabled = ((const Dem_DebArCounter_ParamSet*) paramSet)[paramIndex].isJumpUpActive;
	}
#endif

	debLevel = Dem_EvtGetDebounceLevel (EventId);

	if (Dem_EvtIsResetFailureFilterRequested(EventId))
	{
		debLevel = 0;
		DEM_ENTERLOCK_MON_BEFORE_INIT();
		Dem_EvtRequestResetFailureFilter(EventId, FALSE);
		DEM_EXITLOCK_MON_BEFORE_INIT();
	}

   /*--------DISTURBANCE_MEMORY---------------------------------------------------------------------------------*/
#if (DEM_CFG_DISTURBANCE_MEMORY == DEM_CFG_DISTURBANCE_MEMORY_ON)
	if (manipulationValue < 0)
	{
		if ((debLevel < maxThreshold) && (Dem_EvtGetLastReportedEvent(EventId) == DEM_EVENT_STATUS_PREFAILED))
		{
			debAction = DEM_DEBACTION_INC_DISTURBANCECTR;
		}
	}
#endif

	/*--------Check for minimum threshold---------------------------------------------------------------------------------*/

	if((debLevel == minThreshold) && (manipulationValue < 0))
	{

		return E_OK;
	}
	/*--------Check for maximum threshold---------------------------------------------------------------------------------*/
	if ((debLevel == maxThreshold) && (manipulationValue > 0))
	{

		return E_OK;
	}


	/*--------Jump down condition full filled?---------------------------------------------------------------------------------*/
	if ((manipulationValue < 0) && (((Dem_EvtGetLastReportedEvent (EventId) == DEM_EVENT_STATUS_PREFAILED) || (Dem_EvtGetLastReportedEvent (
					EventId) == DEM_EVENT_STATUS_FAILED)) && isJumpDownEnabled && (debLevel > jumpDownValue)
					&& ((debLevel == maxThreshold) || (DEM_CFG_LIMIT_RELEVANTFOR_JUMPING != DEM_CFG_LIMIT_RELEVANTFOR_JUMPING_ON))
	))
	{
		debLevel = jumpDownValue;
	}

	/*--------Jump up condition full filled?---------------------------------------------------------------------------------*/
	if ((manipulationValue > 0) && ((((Dem_EvtGetLastReportedEvent (EventId) == DEM_EVENT_STATUS_PREPASSED) || (Dem_EvtGetLastReportedEvent (
			EventId) == DEM_EVENT_STATUS_PASSED))  && isJumpUpEnabled && (debLevel < jumpUpValue))
			&&((debLevel == minThreshold)  || (DEM_CFG_LIMIT_RELEVANTFOR_JUMPING != DEM_CFG_LIMIT_RELEVANTFOR_JUMPING_ON))
	))
	{
		debLevel = jumpUpValue;
	}

	/*------------------Manipulation-----------------------------------------------------------------------*/
	debLevel = debLevel + manipulationValue;
	if (debLevel <= minThreshold)
	{
		debLevel = minThreshold;
		status = DEM_EVENT_STATUS_PASSED;
	}
	else if(debLevel < 0)
	{
		status = DEM_EVENT_STATUS_PREPASSED;
	}
	else
	{
		/* do nothing */
	}

	if (debLevel >= maxThreshold)
	{
		debLevel = maxThreshold;
		status = DEM_EVENT_STATUS_FAILED;
	}
	else if(debLevel > 0)
	{
		status = DEM_EVENT_STATUS_PREFAILED;
	}
	else
	{
		/* do nothing */
	}

	Dem_EvtSetDebounceLevel (EventId, (sint16) debLevel);
	Dem_EvtSetLastReportedEvent (EventId, status);

	if (debAction != DEM_DEBACTION_NOOP)
    {
      Dem_DebHandleDebounceAction(EventId, debAction, debug0, debug1);
    }

	if ((status == DEM_EVENT_STATUS_PASSED) || (status == DEM_EVENT_STATUS_FAILED))
   {

	#if (DEM_CFG_SETEVENTSTATUSALLOWEDCALLBACK == DEM_CFG_SETEVENTSTATUSALLOWEDCALLBACK_ON)
		  if (Dem_SetEventStatusAllowedHook(EventId, status) == E_OK)
	#endif
      {
    	  Dem_EvtProcessPassedAndFailed (EventId, status
                                 DEM_DEBUGDATA_PARAM(debug0 ,debug1));


         #if (DEM_CFG_SETEVENTSTATUSCALLNOTIFICATION == DEM_CFG_SETEVENTSTATUSCALLNOTIFICATION_ON)
         Dem_SetEventStatusCallNotification (EventId, faultlevel, debug0, debug1);
         #endif
      }
   }

   /*--------DISTURBANCE_MEMORY---------------------------------------------------------------------------------*/
#if(DEM_CFG_DISTURBANCE_MEMORY == DEM_CFG_DISTURBANCE_MEMORY_ON)
	if(Dem_DistMemIsReportFailedNecessary(EventId, status))
	{
			Dem_DistMemReportFailed(EventId
									DEM_DEBUGDATA_PARAM(debug0 ,debug1));
	}
#endif

   if (status == DEM_EVENT_STATUS_FAILED)
   {
      Dem_EvMemGenReportFailedEvent(EventId);
   }

	return E_OK;
}

void Dem_DebMainFunction(void)
{
#if (DEM_CFG_DEBARTIMEBASE == DEM_CFG_DEBARTIMEBASE_ON)

	Dem_EventIdIterator eventIt;
	Dem_DebCyclic funcPoint;
	Dem_EventIdType eventId;
	const void* paramSet;

	for (Dem_EventIdIteratorNew (&eventIt); Dem_EventIdIteratorIsValid (&eventIt); Dem_EventIdIteratorNext (
			&eventIt))
	{
		eventId = Dem_EventIdIteratorCurrent(&eventIt);
		funcPoint = Dem_Cfg_DebClasses[Dem_EvtGetDebounceMethodIndex (eventId)].funcPointer_Cyclic;
		paramSet = Dem_Cfg_DebClasses[Dem_EvtGetDebounceMethodIndex (eventId)].paramSet;

		if (funcPoint != NULL_PTR)
		{
			DEM_ASSERT (Dem_EvtGetDebounceParamSetIndex (eventId) < Dem_Cfg_DebClasses[Dem_EvtGetDebounceMethodIndex (eventId)].paramCount, DEM_DET_APIID_DEBMAINFUNCTION, 0);
			(*funcPoint) (eventId, paramSet, Dem_EvtGetDebounceParamSetIndex (eventId));
		}
	}

#endif
}

/*------------------HandleDebouncerResetConditions-----------------------------------------------------------------------*/
boolean Dem_DebHandleResetConditions (Dem_EventIdType EventId)
{
    boolean continueProcessing = TRUE;

    if (!Dem_IsEventEnabledByDtcSetting(EventId))
    {
#if (DEM_CFG_DTCSETTINGBLOCKSREPORTING)
        if(Dem_IsEvtDebBehaviorReset(EventId))
        {
            Dem_EvtSetDebounceLevel(EventId, 0);
        }
        Dem_EvtSetLastReportedEvent(EventId, DEM_EVENT_STATUS_INVALIDREPORT);
        continueProcessing = FALSE;
#else
        if(Dem_IsEvtDebBehaviorReset(EventId))
        {
            DEM_ENTERLOCK_MON();
            Dem_EvtRequestResetFailureFilterAfterDtcSetting(EventId, TRUE);
            DEM_EXITLOCK_MON();
        }
#endif
    }
    else
    {
        if (Dem_EvtIsResetFailureFilterRequestedAfterDtcSetting(EventId))
        {
            DEM_ENTERLOCK_MON();
            Dem_EvtRequestResetFailureFilterAfterDtcSetting(EventId, FALSE);
            Dem_EvtSetDebounceLevel(EventId, 0);
            DEM_EXITLOCK_MON();
        }
    }


    if (!Dem_EvtAllEnableConditionsFulfilled(EventId))
    {
        if(Dem_IsEvtDebBehaviorReset(EventId))
        {
            Dem_EvtSetDebounceLevel(EventId, 0);
        }
        Dem_EvtSetLastReportedEvent(EventId, DEM_EVENT_STATUS_INVALIDREPORT);
        continueProcessing = FALSE;
    }

    if (Dem_EvtIsResetFailureFilterRequested(EventId))
    {
        DEM_ENTERLOCK_MON();
        Dem_EvtRequestResetFailureFilter(EventId, FALSE);
        Dem_EvtSetDebounceLevel (EventId, 0);
        DEM_EXITLOCK_MON();
    }

    return continueProcessing;
}

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"



/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 1     07.01.2016 TVE5COB
*   CSCRM01017790
* 
* AR40.11.0.0; 0     04.09.2015 LIB8FE
*   CSCRM00975861
* 
* AR40.10.0.0; 2     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 1     10.07.2015 TVE5COB
*   CSCRM00848667
* 
* AR40.10.0.0; 0     18.06.2015 CLH2SI
*   CSCRM00880977
* 
* AR40.9.0.0; 2     16.10.2014 BPE4COB
*   CSCRM00696471
* 
* AR40.9.0.0; 1     22.08.2014 CLH2SI
*   CSCRM00688436
* 
* AR40.9.0.0; 0     20.08.2014 VSA2COB
*   CSCRM00698491
* 
* AR40.8.0.0; 8     18.07.2014 GJ83ABT
*   CSCRM00697002
* 
* AR40.8.0.0; 7     17.07.2014 SAL2COB
*   CSCRM00501728
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
