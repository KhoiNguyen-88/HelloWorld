/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_DebSharing$
* $Variant___:AR40.10.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_DEBSHARING_H
#define DEM_DEBSHARING_H


/* FC_VariationPoint_START */

/*
 * Debouncer is restructured to simplify re-use in DGS implementation. Following constraints have to be considered.
 *
 * Reuse of debouncer files in DGS implementation:
 * Dem_Deb.c -> remove
 * Dem_Deb.h -> replace with specific implementation: reduce to #include section
 * Dem_DebArCounter.c -> copy
 * Dem_DebArCounter.h -> copy
 * Dem_DebArTime.c -> copy
 * Dem_DebArTime.h -> copy
 * Dem_DebCtrBaseClass.c -> copy
 * Dem_DebCtrBaseClass.h -> copy
 * Dem_DebBase.c -> copy
 * Dem_DebBase.h -> copy
 * Dem_DebMonInternal.h -> copy
 * Dem_DebSharing.h -> specific implementation in CDG and DGS
 *
 * Stubbing using defines:
 * - create empty define DEM_CFG_DEB_DEFINE_ALL_PARAMSETS
 * - use DEM_DEB_FORCE_CONST_CONFIG to make Dem_Cfg_DebClasses const
 * - use DEM_DEB_LOCAL_CALC_PARAMS to define parameters
 * - set #defines of double include protection to remove unwanted header content
 *
 */

/* FC_VariationPoint_END */


#define DEM_DEB_LOCAL_CALC_PARAMS


#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 0     18.06.2015 CLH2SI
*   CSCRM00880977
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
