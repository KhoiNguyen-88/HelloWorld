/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_DebArCounter$
* $Variant___:AR40.10.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/

#include "Dem_DebArCounter.h"
#include "Dem_Deb.h"
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

void Dem_DebArCounter_GetLimits(const void* paramSet,
        uint16 paramIndex,
        sint16_least* MinThreshold,
        sint16_least* MaxThreshold)
{
    /* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
	*MinThreshold = ((const Dem_DebArCounter_ParamSet*) paramSet)[paramIndex].minThreshold;
	/* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
	*MaxThreshold = ((const Dem_DebArCounter_ParamSet*) paramSet)[paramIndex].maxThreshold;
}
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 0     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 4     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 3     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 2     20.08.2013 BRM2COB
*   CSCRM00548906 : Fix review findings
* 
* AR40.7.0.0; 1     20.08.2013 BRM2COB
*   
* 
* AR40.7.0.0; 0     08.08.2013 CLH2SI
*   CSCRM00532300
* 
* AR40.6.0.0; 1     27.06.2013 BRM2COB
*   CSCRM00513119 : Debounce CounterClass Alg
* 
* AR40.6.0.0; 0     23.05.2013 CRA1COB
*   CSCRM00467195
* 
* AR40.4.0.0; 5     17.04.2013 GJ83ABT
*   CSCRM00517299
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
