/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_DebCtrBaseClass$
* $Variant___:AR40.11.0.0$
* $Revision__:4$
**********************************************************************************************************************
</BASDKey>*/


#include "Dem_DebCtrBaseClass.h"
#include "Dem_DebArCounter.h"
#include "Dem_Deb.h"
#include "Dem_Events.h"
#include "Dem_EventStatus.h"
#include "Dem_Lib.h"


#if(DEM_CFG_DEBCOUNTERBASECLASS == DEM_CFG_DEBCOUNTERBASECLASS_ON || DEM_CFG_DEBARCOUNTERBASE == DEM_CFG_DEBARCOUNTERBASE_ON)
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#if(DEM_CFG_DEBCOUNTERBASECLASS == DEM_CFG_DEBCOUNTERBASECLASS_ON)
void Dem_DebCounterBaseClass_GetLimits(const void* paramSet, uint16 paramIndex,sint16_least* MinThreshold,sint16_least* MaxThreshold)
{
	*MaxThreshold = Dem_getDebCtrBaseClassFailedThreshold(paramSet,paramIndex);
	*MinThreshold = Dem_getDebCtrBaseClassPassedThreshold(paramSet,paramIndex);
}
#endif

uint8_least Dem_DebCounterBaseClass_Filter(Dem_EventIdType EventId, Dem_EventStatusType* status, const void* paramSet, uint16 paramIndex
                                           DEM_DEB_LOCAL_CALC_PARAMS)
{
	sint32 maxThreshold = 0;
	sint32 minThreshold = 0;
	sint32 stepDown = 0;
	sint32 stepUp = 0;
	sint32 jumpUpValue = 0;
	sint32 jumpDownValue = 0;
	boolean isJumpUpEnabled = FALSE;
	boolean isJumpDownEnabled = FALSE;
	sint32 debLevel = 0;
	uint8_least debAction = DEM_DEBACTION_NOOP;
#if((DEM_CFG_SUPPORTEVENTMEMORYENTRY_ONFDCTHRESHOLD == DEM_CFG_SUPPORTEVENTMEMORYENTRY_ONFDCTHRESHOLD_ON)||\
   (DEM_CFG_SUPPORT_EVENT_FDCTHRESHOLDREACHED))
	sint32 FDCThreshold = 0;
#endif
#if(DEM_CFG_SUSPICIOUS_SUPPORT)
    sint32 SuspiciousThreshold = 0;
#endif

#if(DEM_CFG_DEBCOUNTERBASECLASS == DEM_CFG_DEBCOUNTERBASECLASS_ON)
	if(Dem_EvtGetDebounceMethodIndex(EventId) == DEM_DEBMETH_IDX_ARCTRBASECLASS)
	{
		minThreshold = Dem_getDebCtrBaseClassPassedThreshold(paramSet,paramIndex);
		maxThreshold = Dem_getDebCtrBaseClassFailedThreshold(paramSet,paramIndex);
		jumpDownValue = Dem_getDebCtrBaseClassJumpDownValue(paramSet,paramIndex);
		jumpUpValue = Dem_getDebCtrBaseClassJumpUpValue(paramSet,paramIndex);
		isJumpDownEnabled = Dem_getDebCtrBaseClassIsJumpDown(paramSet,paramIndex);
		isJumpUpEnabled = Dem_getDebCtrBaseClassIsJumpUp(paramSet,paramIndex);
		/* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
		stepDown = ((const Dem_DebCounterBaseClass_ParamSet*) paramSet)[paramIndex].stepDown;
		/* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
		stepUp = ((const Dem_DebCounterBaseClass_ParamSet*) paramSet)[paramIndex].stepUp;
		debLevel = Dem_EvtGetDebounceLevel (EventId);
#if((DEM_CFG_SUPPORTEVENTMEMORYENTRY_ONFDCTHRESHOLD == DEM_CFG_SUPPORTEVENTMEMORYENTRY_ONFDCTHRESHOLD_ON)||\
    (DEM_CFG_SUPPORT_EVENT_FDCTHRESHOLDREACHED))
		FDCThreshold = ((const Dem_DebCounterBaseClass_ParamSet*) paramSet)[paramIndex].FDCThreshold;
#endif
#if(DEM_CFG_SUSPICIOUS_SUPPORT)
		/* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
		SuspiciousThreshold = ((const Dem_DebCounterBaseClass_ParamSet*) paramSet)[paramIndex].SuspiciousThreshold;
#endif
	}
#endif

#if(DEM_CFG_DEBARCOUNTERBASE == DEM_CFG_DEBARCOUNTERBASE_ON)
	if(Dem_EvtGetDebounceMethodIndex(EventId) == DEM_DEBMETH_IDX_ARCOUNTER)
	{
	    /* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
		minThreshold = ((const Dem_DebArCounter_ParamSet*) paramSet)[paramIndex].minThreshold;
		/* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
		maxThreshold = ((const Dem_DebArCounter_ParamSet*) paramSet)[paramIndex].maxThreshold;
		/* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
		jumpDownValue = ((const Dem_DebArCounter_ParamSet*) paramSet)[paramIndex].jumpDownValue;
		/* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
		jumpUpValue = ((const Dem_DebArCounter_ParamSet*) paramSet)[paramIndex].jumpUpValue;
		/* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
		isJumpDownEnabled = ((const Dem_DebArCounter_ParamSet*) paramSet)[paramIndex].isJumpDownActive;
		/* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
		isJumpUpEnabled = ((const Dem_DebArCounter_ParamSet*) paramSet)[paramIndex].isJumpUpActive;
		/* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
		stepDown = ((const Dem_DebArCounter_ParamSet*) paramSet)[paramIndex].stepDown;
		/* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
		stepUp = ((const Dem_DebArCounter_ParamSet*) paramSet)[paramIndex].stepUp;
#if((DEM_CFG_SUPPORTEVENTMEMORYENTRY_ONFDCTHRESHOLD == DEM_CFG_SUPPORTEVENTMEMORYENTRY_ONFDCTHRESHOLD_ON)||\
    (DEM_CFG_SUPPORT_EVENT_FDCTHRESHOLDREACHED))
		/* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
		FDCThreshold = ((const Dem_DebArCounter_ParamSet*) paramSet)[paramIndex].FDCThreshold;
#endif
#if(DEM_CFG_SUSPICIOUS_SUPPORT)
        /* MR12 RULE 11.5 VIOLATION: a fast and resource optimized support of different debounce startegies is only possible through this mechanism  */
        SuspiciousThreshold = ((const Dem_DebArCounter_ParamSet*) paramSet)[paramIndex].SuspiciousThreshold;
#endif
		debLevel = Dem_EvtGetDebounceLevel (EventId);
	}

#endif


	if (Dem_EvtIsResetFailureFilterRequested(EventId))
	{
		debLevel = 0;
		DEM_ENTERLOCK_MON_BEFORE_INIT();
		Dem_EvtRequestResetFailureFilter(EventId, FALSE);
		DEM_EXITLOCK_MON_BEFORE_INIT();
	}

#if (DEM_CFG_DISTURBANCE_MEMORY == DEM_CFG_DISTURBANCE_MEMORY_ON)
	if ((*status == DEM_EVENT_STATUS_PASSED) || (*status == DEM_EVENT_STATUS_PREPASSED))
	{
		if ((debLevel < maxThreshold) && (Dem_EvtGetLastReportedEvent(EventId) == DEM_EVENT_STATUS_PREFAILED))
		{
			debAction |= DEM_DEBACTION_INC_DISTURBANCECTR;
		}
	}
#endif


	switch (*status)
	{
	case DEM_EVENT_STATUS_PREPASSED:
	{
		if (debLevel == minThreshold)
		{
#if(DEM_CFG_SUSPICIOUS_SUPPORT)
        if (SuspiciousThreshold != DEM_MAXSINT16)
        {
            debAction |= DEM_DEBACTION_RESETSUSPICIOUS;
        }
#endif
#if (DEM_CFG_SUPPORT_EVENT_FDCTHRESHOLDREACHED)
        debAction |= DEM_DEBACTION_RESETFDCTHRESHOLDREACHED;
#endif
			*status = DEM_EVENT_STATUS_PASSED;
			return debAction;
		}

		if (((Dem_EvtGetLastReportedEvent (EventId) == DEM_EVENT_STATUS_PREFAILED) || (Dem_EvtGetLastReportedEvent (
				EventId) == DEM_EVENT_STATUS_FAILED)) && isJumpDownEnabled && (debLevel > jumpDownValue)
				&& ((debLevel == maxThreshold) || (DEM_CFG_LIMIT_RELEVANTFOR_JUMPING != DEM_CFG_LIMIT_RELEVANTFOR_JUMPING_ON))
		)
		{
			debLevel = (jumpDownValue + stepDown);
		}
		else
		{
			debLevel = (debLevel + stepDown);
		}

		if (debLevel <= minThreshold)
		{
			debLevel = minThreshold;
			*status = DEM_EVENT_STATUS_PASSED;
		}

		if (debLevel <= minThreshold)
		{
			debLevel = minThreshold;
			*status = DEM_EVENT_STATUS_PASSED;
		}
#if (DEM_CFG_SUPPORT_EVENT_FDCTHRESHOLDREACHED)
        if ( debLevel < FDCThreshold)
        {
            debAction |= DEM_DEBACTION_RESETFDCTHRESHOLDREACHED;
        }
#endif
#if(DEM_CFG_SUSPICIOUS_SUPPORT)
		if ((SuspiciousThreshold != DEM_MAXSINT16) && (debLevel < SuspiciousThreshold))
		{
		    debAction |= DEM_DEBACTION_RESETSUSPICIOUS;
		}
#endif
		break;
	}

	case DEM_EVENT_STATUS_PREFAILED:
	{

		if (debLevel == maxThreshold)
		{
#if(DEM_CFG_SUPPORT_EVENT_FDCTHRESHOLDREACHED)
            debAction |= DEM_DEBACTION_SETFDCTHRESHOLDREACHED;
#endif
			*status = DEM_EVENT_STATUS_FAILED;
			return debAction;
		}

		if ((((Dem_EvtGetLastReportedEvent (EventId) == DEM_EVENT_STATUS_PREPASSED) || (Dem_EvtGetLastReportedEvent (
				EventId) == DEM_EVENT_STATUS_PASSED))  && isJumpUpEnabled && (debLevel < jumpUpValue))
				&&((debLevel == minThreshold)  || (DEM_CFG_LIMIT_RELEVANTFOR_JUMPING != DEM_CFG_LIMIT_RELEVANTFOR_JUMPING_ON))
		)
		{
			debLevel = (jumpUpValue + stepUp);
		}
		else
		{
			debLevel = (debLevel + stepUp);
		}

		if (debLevel >= maxThreshold)
		{
			debLevel = maxThreshold;
			*status = DEM_EVENT_STATUS_FAILED;
		}

#if ((DEM_CFG_SUPPORTEVENTMEMORYENTRY_ONFDCTHRESHOLD == DEM_CFG_SUPPORTEVENTMEMORYENTRY_ONFDCTHRESHOLD_ON)||\
	(DEM_CFG_SUPPORT_EVENT_FDCTHRESHOLDREACHED))
		if ( debLevel >= FDCThreshold)
		{
			debAction |= DEM_DEBACTION_SETFDCTHRESHOLDREACHED;
#if(DEM_CFG_SUPPORTEVENTMEMORYENTRY_ONFDCTHRESHOLD == DEM_CFG_SUPPORTEVENTMEMORYENTRY_ONFDCTHRESHOLD_ON)
			if(*status != DEM_EVENT_STATUS_FAILED)
			{
				debAction |= DEM_DEBACTION_ALLOW_BUFFER_INSERT;
			}
#endif
		}
#endif

#if(DEM_CFG_SUSPICIOUS_SUPPORT)
            if ((SuspiciousThreshold != DEM_MAXSINT16) && (debLevel < maxThreshold))
            {
                if (debLevel >= SuspiciousThreshold)
                {
                    debAction |= DEM_DEBACTION_SETSUSPICIOUS;
                }
            }
#endif
		break;
	}

	case DEM_EVENT_STATUS_PASSED:
	{
#if(DEM_CFG_SUSPICIOUS_SUPPORT)
        if (SuspiciousThreshold != DEM_MAXSINT16)
        {
            debAction |= DEM_DEBACTION_RESETSUSPICIOUS;
        }
#endif
#if (DEM_CFG_SUPPORT_EVENT_FDCTHRESHOLDREACHED)
        debAction |= DEM_DEBACTION_RESETFDCTHRESHOLDREACHED;
#endif
		if (debLevel == minThreshold)
		{
			return debAction;
		}
		debLevel = minThreshold;
		break;
	}

	case DEM_EVENT_STATUS_FAILED:
	{
#if((DEM_CFG_SUPPORTEVENTMEMORYENTRY_ONFDCTHRESHOLD == DEM_CFG_SUPPORTEVENTMEMORYENTRY_ONFDCTHRESHOLD_ON)||\
    (DEM_CFG_SUPPORT_EVENT_FDCTHRESHOLDREACHED))
            debAction |= DEM_DEBACTION_SETFDCTHRESHOLDREACHED;
#endif
		if (debLevel == maxThreshold)
		{
			return debAction;
		}
		debLevel = maxThreshold;
		break;
	}

	default:
	{
		return debAction;
	}
	}




	Dem_EvtSetDebounceLevel (EventId, (sint16) debLevel);
	Dem_EvtSetLastReportedEvent (EventId, *status);

	return debAction;
}
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif
/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 4     31.12.2015 SUH4COB
*   CSCRM01025280
* 
* AR40.11.0.0; 3     03.12.2015 VSA2COB
*   CSCRM00876353
* 
* AR40.11.0.0; 2     24.11.2015 VSA2COB
*   CSCRM01013111
* 
* AR40.11.0.0; 1     20.11.2015 SUH4COB
*   CSCRM00540538
* 
* AR40.11.0.0; 0     10.11.2015 VSA2COB
*   Checkout by vsa2cob
* 
* AR40.10.0.0; 1     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 0     18.06.2015 CLH2SI
*   CSCRM00880977
* 
* AR40.9.0.0; 1     16.10.2014 BPE4COB
*   CSCRM00696471
* 
* AR40.9.0.0; 0     22.08.2014 CLH2SI
*   CSCRM00688436
* 
* AR40.8.0.0; 4     17.07.2014 SAL2COB
*   CSCRM00501728
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
