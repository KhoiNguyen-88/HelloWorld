/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_StorageCondition$
* $Variant___:AR40.11.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/
#include "Std_Types.h"

#include "Dem_StorageCondition.h"
#include "Dem_EventFHandling.h"
#include "Dem_EventRecheck.h"
#include "Rte_Dem.h"
#include "Dem_Protected.h"

#if (DEM_CFG_STORAGECONDITION == DEM_CFG_STORAGECONDITION_ON)


#define DEM_START_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"

Dem_StoCoState Dem_StoCoAllStates = { DEM_CFG_STOCO_INITIALSTATE, 0,0,0,0
#if (DEM_CFG_DEBUGDATA != DEM_CFG_DEBUGDATA_OFF)
    ,{0},{0}
#endif
};

#define DEM_STOP_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"



#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

const Dem_StoCoParam Dem_StoCoAllParams = DEM_CFG_STOCO_PARAMS;

#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
#endif


#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


Std_ReturnType Dem_SetStorageCondition (uint8 StorageConditionID, boolean ConditionFulfilled)
{
#if (DEM_CFG_STORAGECONDITION == DEM_CFG_STORAGECONDITION_ON)

  Dem_StoCoList storageConditionBitmask;

  if (StorageConditionID >= DEM_STORAGECONDITION_COUNT)
  {
    DEM_DET(DEM_DET_APIID_SETSTORAGECONDITION, DEM_E_PARAM_CONFIG);
    return E_NOT_OK;
  }

   storageConditionBitmask = (Dem_StoCoList)(1u << StorageConditionID);

   DEM_ENTERLOCK_MON_BEFORE_INIT();

   if (ConditionFulfilled)
   {
      Dem_StoCoAllStates.isActive |= storageConditionBitmask;
   }
   else
   {
      Dem_StoCoAllStates.isActive &= (Dem_StoCoList)(~(uint32)storageConditionBitmask);
      Dem_DependencyRestartCyclicCheck(); /* restart recheck to avoid following behavior:
                                                       2 events (or more) are filtered and causal to each other
                                                       recheck-algorithm is in the middle of both monitorings and will next reach
                                                       lower prio monitoring: lower prio monitoring will be considered as causal,
                                                       because higher prio monitoring is rechecked afterwards. */
   }

   DEM_EXITLOCK_MON_BEFORE_INIT();

   return E_OK;

#else
   DEM_UNUSED_PARAM(StorageConditionID);
   DEM_UNUSED_PARAM(ConditionFulfilled);
   return E_NOT_OK;
#endif
}

Std_ReturnType Dem_GetStorageCondition (uint8 StorageConditionID, boolean* ConditionFulfilled)
{
#if (DEM_CFG_STORAGECONDITION == DEM_CFG_STORAGECONDITION_ON)

    Dem_StoCoList storageConditionBitmask;

    storageConditionBitmask = (Dem_StoCoList)(1u << StorageConditionID);

    *ConditionFulfilled = (0 != (Dem_StoCoAllStates.isActive & storageConditionBitmask));

    return E_OK;

#else
   DEM_UNUSED_PARAM(StorageConditionID);
   DEM_UNUSED_PARAM(ConditionFulfilled);
   return E_NOT_OK;
#endif
}




#if (DEM_CFG_STORAGECONDITION == DEM_CFG_STORAGECONDITION_ON)
void Dem_StoCoMainFunction(void)
{
   uint16_least i;
   Dem_StoCoList stoco_mask;
   for (i=0; i<DEM_STORAGECONDITION_COUNT; i++)
   {
      stoco_mask = (Dem_StoCoList)(1u << i);
      if (Dem_StoCoAllParams.replacementEvent[i] != DEM_EVENTID_INVALID)
      {
         if( (stoco_mask & Dem_StoCoAllStates.isReplacementEventRequested) != 0u )
         {

            (void)Dem_SetEventStatusWithEnvData(Dem_StoCoAllParams.replacementEvent[i], DEM_EVENT_STATUS_FAILED
#if (DEM_CFG_DEBUGDATA != DEM_CFG_DEBUGDATA_OFF)
                /* if debugdata is only 8 bit: use lower 8 bits */
               ,(Dem_DebugDataType)(Dem_StoCoAllStates.eventId[i]), Dem_StoCoAllStates.debug1[i]
#else
               ,0,0
#endif
               );


            DEM_ENTERLOCK_MON();       /* DSM_D_212 */

            Dem_StoCoAllStates.isReplacementEventRequested &=    (Dem_StoCoList)(~(uint32)stoco_mask);
            Dem_StoCoAllStates.hasGoodCheckTrigger &=            (Dem_StoCoList)(~(uint32)stoco_mask);
            Dem_StoCoAllStates.isReplacementEventStored |= stoco_mask;

            DEM_EXITLOCK_MON();       /* DSM_D_212 */
         }

         if( (stoco_mask & Dem_StoCoAllStates.isReplacementEventStored & Dem_StoCoAllStates.isActive) != 0u )
         {
            (void)Dem_SetEventStatusWithEnvData (Dem_StoCoAllParams.replacementEvent[i], DEM_EVENT_STATUS_PASSED,0,0);

            DEM_ENTERLOCK_MON();       /* DSM_D_212 */

            Dem_StoCoAllStates.isReplacementEventRequested &= (Dem_StoCoList)(~(uint32)stoco_mask);
            Dem_StoCoAllStates.hasGoodCheckTrigger &=         (Dem_StoCoList)(~(uint32)stoco_mask);
            Dem_StoCoAllStates.isReplacementEventStored &=    (Dem_StoCoList)(~(uint32)stoco_mask);

            DEM_EXITLOCK_MON();       /* DSM_D_212 */
         }
      }
      else
      {
         if( (stoco_mask & Dem_StoCoAllStates.isActive) != 0u )
         {
            DEM_ENTERLOCK_MON();       /* DSM_D_212 */
            {
               Dem_StoCoAllStates.isReplacementEventRequested &= (Dem_StoCoList)(~(uint32)stoco_mask);
               Dem_StoCoAllStates.hasGoodCheckTrigger &=         (Dem_StoCoList)(~(uint32)stoco_mask);
               Dem_StoCoAllStates.isReplacementEventStored &=    (Dem_StoCoList)(~(uint32)stoco_mask);
            }
            DEM_EXITLOCK_MON();       /* DSM_D_212 */
         }
      }
   }
}

#endif



#if (DEM_CFG_STORAGECONDITION == DEM_CFG_STORAGECONDITION_ON)

void Dem_StoCoRecheckReplacementStorage(Dem_StoCoList storageConditions)
{
    DEM_ASSERT_ISLOCKED();

    /* if (any storagecondition is disabled) AND (none of the disabled stoco has stored or requested the replacement failure) */
    if (    ((storageConditions & (Dem_StoCoList)(~Dem_StoCoAllStates.isActive)) > 0u)
         && ((storageConditions & (Dem_StoCoList)(~Dem_StoCoAllStates.isActive) & (Dem_StoCoAllStates.isReplacementEventRequested | Dem_StoCoAllStates.isReplacementEventStored)) == 0u)
       )
    {
        Dem_StoCoAllStates.isReplacementEventRequested |= (storageConditions & (Dem_StoCoList)(~Dem_StoCoAllStates.isActive));
    }
}

#endif


#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 1     07.01.2016 TVE5COB
*   CSCRM01017790
* 
* AR40.11.0.0; 0     19.11.2015 XZA2ABT
*   Checkout by xza2abt
* 
* AR40.10.0.0; 2     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 1     10.07.2015 CLH2SI
*   CSCRM00938605
* 
* AR40.10.0.0; 0     16.04.2015 CLH2SI
*   CSCRM00764027
* 
* AR40.9.0.0; 0     21.11.2014 CLH2SI
*   CSCRM00712155
* 
* AR40.8.0.0; 1     18.07.2014 GJ83ABT
*   CSCRM00697002
* 
* AR40.8.0.0; 0     10.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 3     21.11.2013 AMN2KOR
*   CSCRM00591723
* 
* AR40.7.0.0; 2     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
