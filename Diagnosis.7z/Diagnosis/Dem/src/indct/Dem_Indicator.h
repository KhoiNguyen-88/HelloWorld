/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************
* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_Indicator$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/



#ifndef DEM_INDICATOR_H
#define DEM_INDICATOR_H

#include "Dem_IndicatorAttributes.h"


#if (DEM_CFG_EVT_INDICATOR == DEM_CFG_EVT_INDICATOR_ON)
typedef struct
{
	uint16 blinkingCtr;
	uint16 continousCtr;
} Dem_IndicatorStatus;


#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"
DEM_ARRAY_DECLARE(Dem_IndicatorStatus, Dem_AllIndicatorStatus, DEM_INDICATORID_ARRAYLENGTH);
#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

DEM_INLINE uint16 Dem_IndicatorGetBlinkingCounter(uint8 indicatorId)
{
	return (Dem_AllIndicatorStatus[indicatorId].blinkingCtr);
}

DEM_INLINE uint16 Dem_IndicatorGetContinuousCounter(uint8 indicatorId)
{
	return (Dem_AllIndicatorStatus[indicatorId].continousCtr);
}

DEM_INLINE void Dem_IndicatorSetContinuousCtr(uint8 indicatorId, uint16 continuousCtr)
{
	Dem_AllIndicatorStatus[indicatorId].continousCtr = continuousCtr;
}

DEM_INLINE void Dem_IndicatorSetBlinkingCtr(uint8 indicatorId, uint16 blinkingCtr)
{
	Dem_AllIndicatorStatus[indicatorId].blinkingCtr = blinkingCtr;
}

DEM_INLINE void Dem_IndicatorIncrementBehaviourCounter(uint8 indicatorId, uint8 indicatorBehaviour)
{
	uint16 blinkingCounter = Dem_IndicatorGetBlinkingCounter(indicatorId);
	uint16 countinuousCounter = Dem_IndicatorGetContinuousCounter(indicatorId);

	if((DEM_INDICATOR_CONTINUOUS & indicatorBehaviour)!=0u)
	{
		countinuousCounter++;
		Dem_IndicatorSetContinuousCtr(indicatorId, countinuousCounter);
	}

	if((DEM_INDICATOR_BLINKING & indicatorBehaviour)!=0u)
	{
		blinkingCounter++;
		Dem_IndicatorSetBlinkingCtr(indicatorId, blinkingCounter);
	}
}

DEM_INLINE void Dem_IndicatorDecrementBehaviourCounter(uint8 indicatorId, uint8 indicatorBehaviour)
{
	uint16 blinkingCounter = Dem_IndicatorGetBlinkingCounter(indicatorId);
	uint16 countinuousCounter = Dem_IndicatorGetContinuousCounter(indicatorId);

	if (((DEM_INDICATOR_CONTINUOUS & indicatorBehaviour) != 0u)  && (countinuousCounter > 0u))
	{
		countinuousCounter--;
		Dem_IndicatorSetContinuousCtr(indicatorId, countinuousCounter);
	}

	if (((DEM_INDICATOR_BLINKING & indicatorBehaviour) != 0u) && (blinkingCounter > 0u))
	{
		blinkingCounter--;
		Dem_IndicatorSetBlinkingCtr(indicatorId, blinkingCounter);
	}
}

DEM_INLINE uint8 Dem_EvtGetIndicatorStatus(uint8 indicatorId)
{
    uint8 IndicatorStatus;

    DEM_ENTERLOCK_MON();

	if((Dem_IndicatorGetBlinkingCounter(indicatorId) > 0u) && (Dem_IndicatorGetContinuousCounter(indicatorId) == 0u))
	{
	    IndicatorStatus = DEM_INDICATOR_BLINKING;
	}
	else if((Dem_IndicatorGetBlinkingCounter(indicatorId) == 0u) && (Dem_IndicatorGetContinuousCounter(indicatorId) > 0u))
	{
	    IndicatorStatus = DEM_INDICATOR_CONTINUOUS;
	}
	else if((Dem_IndicatorGetBlinkingCounter(indicatorId) > 0u) && (Dem_IndicatorGetContinuousCounter(indicatorId) > 0u))
	{
	    IndicatorStatus = DEM_INDICATOR_BLINK_CONT;
	}
	else
	{
	    IndicatorStatus = DEM_INDICATOR_OFF;
	}

	DEM_EXITLOCK_MON();

	return IndicatorStatus;
}



/**
 * @ingroup DEM_H
 *
 * Sets the indicator status for a particular event.
 *
 * @param [in] EventId                 Identification of an event by assigned EventId.
 * @param [in] IndicatorId             Number of indicator
 * @param [in] IndicatorActivation     TRUE/FALSE: set the indicator status according to the configuration
 * @return  E_OK = Set Indicator Status operation was successful \n
 *          E_NOT_OK = Set Indicator Status operation failed or is not supported
 */
Std_ReturnType Dem_SetIndicatorStatusForEvent (Dem_EventIdType EventId, Dem_IndicatorIdType IndicatorId, boolean IndicatorActivation);

#else

#define Dem_SetIndicatorStatusForEvent(X,Y,Z)   (E_NOT_OK)

#endif
void Dem_UpdateISO14229WIRStatus (Dem_EventIdType EventId);


#endif

/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     21.12.2015 NAL2KOR
*   CSCRM00957431
* 
* AR40.10.0.0; 1     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 0     10.07.2015 CLH2SI
*   CSCRM00938605
* 
* AR40.9.0.0; 3     15.01.2015 LIB8FE
*   CSCRM00771713
* 
* AR40.9.0.0; 2     14.01.2015 TVE5COB
*   CSCRM00769536
* 
* AR40.9.0.0; 1     13.10.2014 VSA2COB
*   CSCRM00720752
* 
* AR40.9.0.0; 0     25.08.2014 BPE4COB
*   CSCRM00641522
* 
* AR40.8.0.0; 2     18.07.2014 UDKOEGEL
*   CSCRM00533942
* 
* AR40.8.0.0; 1     17.07.2014 BRM2COB
*   Checkout by brm2cob
* 
* AR40.8.0.0; 0     19.06.2014 BRM2COB
*   
* 
* $
**********************************************************************************************************************
</BASDKey>*/
