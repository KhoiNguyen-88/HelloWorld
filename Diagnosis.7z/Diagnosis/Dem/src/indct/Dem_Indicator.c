/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_Indicator$
* $Variant___:AR40.11.0.0$
* $Revision__:2$
**********************************************************************************************************************
</BASDKey>*/


#include "Dem_Types.h"
#include "Dem_EventStatus.h"
#include "Dem_Prv_CallEvtStChngdCbk.h"
#include "Rte_Dem.h"
#include "Dem_Protected.h"
/* FC_VariationPoint_START */
#include "Dem_ObdMain.h"
/* FC_VariationPoint_END */

#if (DEM_CFG_EVT_INDICATOR == DEM_CFG_EVT_INDICATOR_ON)

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

DEM_ARRAY_DEFINE(Dem_IndicatorStatus, Dem_AllIndicatorStatus, DEM_INDICATORID_ARRAYLENGTH);

#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

#endif



#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#if(DEM_CFG_EVT_INDICATOR == DEM_CFG_EVT_INDICATOR_ON)

Std_ReturnType Dem_SetIndicatorStatusForEvent (Dem_EventIdType EventId, Dem_IndicatorIdType IndicatorId, boolean IndicatorActivation)
{

    Std_ReturnType retVal = E_NOT_OK;
    Dem_EventIndicatorAttributeIterator it;
    uint16_least currentIndicAttrib = 0;
    uint8 indicatorBehaviour;
    Dem_EventStatusExtendedType statusOld, statusNew, dtcStByteOld;

    for ( Dem_EventIndicatorAttributeIteratorNew(EventId, &it);
            Dem_EventIndicatorAttributeIsValid(EventId, &it);
            Dem_EventIndicatorAttributeNext(&it)
    )
    {
        currentIndicAttrib = Dem_EventIndicatorAttributeCurrent(&it);

        if (Dem_IsIndicatorAttributeValid(currentIndicAttrib))
        {
            if (   (Dem_IndicatorAttrib_GetIndicatorId(currentIndicAttrib) == IndicatorId)
                    && (Dem_IndicatorAttrib_IsApiControl(currentIndicAttrib) == TRUE)
            )
            {

                DEM_ENTERLOCK_MON_BEFORE_INIT();
                indicatorBehaviour = Dem_IndicatorAttrib_GetBehaviour(currentIndicAttrib);

                if (IndicatorActivation == TRUE)
                {
                    Dem_IndicatorAttribSetHealingCycCtr(currentIndicAttrib, 0);
                    Dem_IndicatorAttribSetFailureCycCtr(currentIndicAttrib, 0xFF);
                    Dem_IndicatorIncrementBehaviourCounter(IndicatorId, indicatorBehaviour);
                }
                else
                {
                    Dem_IndicatorAttribSetHealingCycCtr(currentIndicAttrib, 0xFF);
                    Dem_IndicatorAttribSetFailureCycCtr(currentIndicAttrib, 0);
                    Dem_IndicatorDecrementBehaviourCounter(IndicatorId, indicatorBehaviour);
                }
                retVal = E_OK;
                DEM_EXITLOCK_MON_BEFORE_INIT();

                break;
            }
        }
    }

    DEM_ENTERLOCK_MON_BEFORE_INIT();
    Dem_StatusChange_GetOldStatus(EventId, &statusOld, &dtcStByteOld);
    statusNew = Dem_EvtGetIsoByte(EventId);

    if (IndicatorActivation)
    {
        Dem_EvtSt_HandleIndicatorOn(EventId);
    }
    else
    {
        Dem_UpdateISO14229WIRStatus(EventId);
    }

    statusNew = Dem_EvtGetIsoByte(EventId);

    DEM_EXITLOCK_MON_BEFORE_INIT();

    if (statusNew != statusOld )
    {
        Dem_CallBackTriggerOnEventStatus(EventId, statusOld, statusNew, dtcStByteOld);
    }

    return retVal;
}

#endif

#if (DEM_CFG_EVT_INDICATOR != DEM_CFG_EVT_INDICATOR_PROJECTSPECIFIC)


/* MISRA RULE 16.7 VIOLATION: Function defined according to AR Spec IndicatorStatus not changed if OBD is OFF */
Std_ReturnType Dem_GetIndicatorStatus(uint8 IndicatorId, Dem_IndicatorStatusType* IndicatorStatus)
{

	Std_ReturnType ret_val;

/* FC_VariationPoint_START */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
   if (IndicatorId == DEM_OBD_CFG_MIL_INDICATOR_ID)
   {
      *IndicatorStatus = Dem_ObdMil;
      return E_OK;
   }
#endif
 /* FC_VariationPoint_END */

#if (DEM_CFG_EVT_INDICATOR == DEM_CFG_EVT_INDICATOR_ON)

	if(!Dem_isIndicatorIdValid(IndicatorId))
	{
		return E_NOT_OK;
	}

	*IndicatorStatus = Dem_EvtGetIndicatorStatus(IndicatorId);
 	ret_val = E_OK;
#else
	DEM_UNUSED_PARAM(IndicatorId);
	DEM_UNUSED_PARAM(IndicatorStatus);
	ret_val = E_NOT_OK;
#endif
   return ret_val;
}


FUNC(Std_ReturnType, Dem_CODE) Dem_SetWIRStatus (
        VAR(Dem_EventIdType, AUTOMATIC) EventId,
        VAR(boolean, AUTOMATIC) WIRStatus
)
{
    Std_ReturnType ret_val = E_OK;

    Dem_DtcIdType dtcId;
    Dem_EventStatusExtendedType statusOld, statusNew, dtcStByteOld;


    statusOld = DEM_ISO14229BYTE_INITVALUE;
    statusNew = DEM_ISO14229BYTE_INITVALUE;
    dtcStByteOld = DEM_ISO14229BYTE_INITVALUE;

    if(!Dem_isEventIdValid(EventId))
    {
        return E_NOT_OK;
    }

    DEM_ENTERLOCK_MON();

    dtcId= Dem_DtcIdFromEventId (EventId);

    if((!Dem_IsEventReportingEnabledByDtcSetting(EventId)) || (!Dem_DtcIsAvailable(dtcId)))
    {
        ret_val = E_NOT_OK;
    }
    else if (Dem_EvtRequestsWarningIndicator(EventId))
    {
        if (WIRStatus)
        {
            /*Set Bit corresponding to WIRStatus as TRUE within Dem_AllEventsState[EventId].state
                Invoke Dem_EvtSetWIR to set WIRStatus bit for that event*/

            Dem_StatusChange_GetOldStatus(EventId, &statusOld, &dtcStByteOld);
            statusNew = statusOld;
            Dem_EvtSetWIRExtern(EventId, TRUE);
            if (!Dem_ISO14229ByteIsWarningIndicatorRequested(statusOld))
            {
                Dem_EvtSt_HandleIndicatorOn(EventId);
                statusNew = Dem_EvtGetIsoByte(EventId);
#if (DEM_CFG_TRIGGERFIMREPORTS == DEM_CFG_TRIGGERFIMREPORTS_ON)
                FiM_DemTriggerOnEventStatus (EventId, statusOld, statusNew);
#endif
            }
        }
        else
        {
            /*Set Bit corresponding to WIRStatus as FALSE within Dem_AllEventsState[EventId].state*/
            Dem_EvtSetWIRExtern(EventId, FALSE);
            Dem_StatusChange_GetOldStatus(EventId, &statusOld, &dtcStByteOld);
            statusNew = statusOld;
            if (Dem_ISO14229ByteIsWarningIndicatorRequested(statusOld))
            {
					Dem_UpdateISO14229WIRStatus(EventId);
                    statusNew = Dem_EvtGetIsoByte(EventId);
#if (DEM_CFG_TRIGGERFIMREPORTS == DEM_CFG_TRIGGERFIMREPORTS_ON)
                    FiM_DemTriggerOnEventStatus (EventId, statusOld, statusNew);
#endif
            }
            else
            {
                //nothing to do
            }
        }
    }
    else
    {
        ret_val =  E_NOT_OK;
    }
    DEM_EXITLOCK_MON();

    if (statusNew != statusOld )
    {
        Dem_CallBackTriggerOnEventStatus(EventId, statusOld, statusNew, dtcStByteOld);
    }

    return ret_val;
}

#endif



void Dem_UpdateISO14229WIRStatus (Dem_EventIdType EventId)
{
    if (        (!Dem_EvtIsWIRExternal(EventId))
            &&  (!Dem_ObdEvtIsRequestingMil(EventId))
            &&  (!Dem_isAnyIndicatorAttribOn(EventId))
    )
    {
        Dem_EvtSt_HandleIndicatorOff(EventId);
    }
}

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 2     11.01.2016 NAL2KOR
*   CSCRM01015983
* 
* AR40.11.0.0; 1     07.01.2016 TVE5COB
*   CSCRM01017790
* 
* AR40.11.0.0; 0     21.12.2015 NAL2KOR
*   CSCRM00957431
* 
* AR40.10.0.0; 2     10.07.2015 CLH2SI
*   CSCRM00938605
* 
* AR40.10.0.0; 1     17.06.2015 LIB8FE
*   CSCRM00764040
* 
* AR40.10.0.0; 0     20.04.2015 VSA2COB
*   CSCRM00790403
* 
* AR40.9.0.0; 4     15.01.2015 LIB8FE
*   CSCRM00771713
* 
* AR40.9.0.0; 3     14.01.2015 TVE5COB
*   CSCRM00769536
* 
* AR40.9.0.0; 2     17.11.2014 GJ83ABT
*   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
* 
* AR40.9.0.0; 1     13.10.2014 VSA2COB
*   CSCRM00720752
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
