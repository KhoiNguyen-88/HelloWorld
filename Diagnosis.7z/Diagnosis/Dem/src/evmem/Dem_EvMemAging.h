/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_EvMemAging$
* $Variant___:AR40.11.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_EVMEMAGING_H
#define DEM_EVMEMAGING_H


#if (DEM_CFG_EVMEM_AGING_METHOD != DEM_CFG_EVMEM_AGING_METHOD_USER)
/* ----------------------------------------------------------------------------
   INLINE Functions
   ----------------------------------------------------------------------------
*/
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
uint16_least      Dem_EvMemGetCurrentAgingCycleCounter(Dem_EventIdType EventId);
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
DEM_INLINE uint16_least Dem_EvMemGetCurrentAgingCycleCounterInt(Dem_EventIdType EventId)
{

#if (DEM_CFG_EVMEM_AGING_METHOD == DEM_CFG_EVMEM_AGING_METHOD_AGINGCYC_DIFF_UP)   || \
    (DEM_CFG_EVMEM_AGING_METHOD == DEM_CFG_EVMEM_AGING_METHOD_AGINGCYC_DIFF_DOWN) || \
    (DEM_CFG_EVMEM_AGING_METHOD == DEM_CFG_EVMEM_AGING_METHOD_AGINGCYC_STORE)
    return Dem_EvMemGetCurrentAgingCycleCounter(EventId);
#else
    DEM_EVMEM_USEVAR(EventId);
    return 0;
#endif
}


/* ----------------------------------------------------------------------------
   Defines
   ----------------------------------------------------------------------------
*/

/* aging state */
#define DEM_EVMEM_AGING_STATE                   ((DEM_EVMEM_STSMASK_TESTCOMPLETE_TAC * DEM_EVMEM_BOOL2DEC(Dem_LibGetParamBool(DEM_CFG_EVMEM_TESTCOMPLETE_TAC_SUPPORTED))) | \
                                                  DEM_EVMEM_STSMASK_CONFIRMED)
/* aging mask */
#define DEM_EVMEM_AGING_MASK                    ((DEM_EVMEM_STSMASK_TESTFAILED_TAC   * DEM_EVMEM_BOOL2DEC(Dem_LibGetParamBool(DEM_CFG_EVMEM_TESTFAILED_TAC_SUPPORTED)))   | \
                                                 (DEM_EVMEM_STSMASK_TESTCOMPLETE_TAC * DEM_EVMEM_BOOL2DEC(Dem_LibGetParamBool(DEM_CFG_EVMEM_TESTCOMPLETE_TAC_SUPPORTED))) | \
                                                  DEM_EVMEM_STSMASK_TESTFAILED| \
                                                  DEM_EVMEM_STSMASK_CONFIRMED)
/* aging state for TFSLC*/
#define DEM_EVMEM_TFSLC_AGING_STATE             ((DEM_EVMEM_STSMASK_TESTCOMPLETE_TAC * DEM_EVMEM_BOOL2DEC(Dem_LibGetParamBool(DEM_CFG_EVMEM_TESTCOMPLETE_TAC_SUPPORTED))) | \
                                                  DEM_EVMEM_STSMASK_TESTFAILED_SLC)
/* aging mask for TFSLC */
#define DEM_EVMEM_TFSLC_AGING_MASK              ((DEM_EVMEM_STSMASK_TESTFAILED_TAC   * DEM_EVMEM_BOOL2DEC(Dem_LibGetParamBool(DEM_CFG_EVMEM_TESTFAILED_TAC_SUPPORTED)))   | \
                                                 (DEM_EVMEM_STSMASK_TESTCOMPLETE_TAC * DEM_EVMEM_BOOL2DEC(Dem_LibGetParamBool(DEM_CFG_EVMEM_TESTCOMPLETE_TAC_SUPPORTED))) | \
                                                  DEM_EVMEM_STSMASK_TESTFAILED| \
                                                  DEM_EVMEM_STSMASK_TESTFAILED_SLC)

/* ----------------------------------------------------------------------------
 Aging
 ----------------------------------------------------------------------------
 */

DEM_INLINE Dem_boolean_least Dem_EvMemIsAged(Dem_EventIdType EventId, uint16_least LocId, uint16_least StatusNew)
{
	DEM_EVMEM_USEVAR(LocId);
	DEM_EVMEM_USEVAR(EventId);

	return (Dem_boolean_least)((StatusNew & DEM_EVMEM_STSMASK_AGED) != 0u);

}


DEM_INLINE uint16_least Dem_EvMemGetEventMemAgingCounterScaled(const Dem_EvMemEventMemoryType *EventMemory)
{
	uint16_least AgingCounter;

	if (Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_COUNT_DOWN))
	{
		AgingCounter = Dem_EvtGetAgingThreshold(Dem_EvMemGetEventMemEventIdByPtr(EventMemory)) - Dem_EvMemGetEventMemAgingCounterByPtr(EventMemory);
	}
	else if (Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_AGINGCYC_DIFF_UP))
	{
		if ((Dem_EvMemGetEventMemStatusByPtr(EventMemory) & DEM_EVMEM_STSMASK_TESTFAILED) != 0u)
		{
			AgingCounter = 0;
		}
		else if ((Dem_EvMemGetEventMemStatusByPtr(EventMemory) & DEM_EVMEM_STSMASK_AGED) != 0u)
		{
			AgingCounter = Dem_EvtGetAgingThreshold(Dem_EvMemGetEventMemEventIdByPtr(EventMemory));
		}
		else
		{
			AgingCounter = (uint16_least)((Dem_EvMemAgingCounterType)(Dem_EvMemGetCurrentAgingCycleCounterInt(Dem_EvMemGetEventMemEventIdByPtr(EventMemory)) - Dem_EvMemGetEventMemAgingCounterByPtr(EventMemory)));
		}
	}
	else if (Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_AGINGCYC_DIFF_DOWN))
	{
		if ((Dem_EvMemGetEventMemStatusByPtr(EventMemory) & DEM_EVMEM_STSMASK_TESTFAILED) != 0u)
		{
			AgingCounter = Dem_EvtGetAgingThreshold(Dem_EvMemGetEventMemEventIdByPtr(EventMemory));
		}
		else if ((Dem_EvMemGetEventMemStatusByPtr(EventMemory) & DEM_EVMEM_STSMASK_AGED) != 0u)
		{
			AgingCounter = 0;
		}
		else
		{
			AgingCounter = Dem_EvtGetAgingThreshold(Dem_EvMemGetEventMemEventIdByPtr(EventMemory)) -
			((uint16_least)((Dem_EvMemAgingCounterType)(Dem_EvMemGetCurrentAgingCycleCounterInt(Dem_EvMemGetEventMemEventIdByPtr(EventMemory)) - Dem_EvMemGetEventMemAgingCounterByPtr(EventMemory))));
		}
	}
	else if (Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_AGINGCYC_STORE))
	{
		if ((Dem_EvMemGetEventMemStatusByPtr(EventMemory) & DEM_EVMEM_STSMASK_TESTFAILED) != 0u)
		{
			AgingCounter = Dem_EvMemGetEventMemAgingCounterByPtr(EventMemory);
		}
		else
		{
			AgingCounter = (uint16_least)((Dem_EvMemAgingCounterType)(Dem_EvMemGetEventMemAgingCounterByPtr(EventMemory) + Dem_EvtGetAgingThreshold(Dem_EvMemGetEventMemEventIdByPtr(EventMemory))));
		}
	}
	else
	{ /* no Scaling */
		AgingCounter = Dem_EvMemGetEventMemAgingCounterByPtr(EventMemory);
	}

	return AgingCounter;
}


DEM_INLINE void Dem_EvMemSetAgingCounterOnAgingCycle(Dem_EventIdType EventId, uint16_least LocId, uint16_least* StatusNew, uint16_least* WriteSts)
{

	Dem_boolean_least IsAgingThresholdReached;

	if (!Dem_EvMemIsAged(EventId, LocId, *StatusNew))
	{
		if ((Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_COUNT_UP)) ||
				(Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_COUNT_DOWN)))
		{
			if (((*StatusNew & DEM_EVMEM_AGING_MASK) == DEM_EVMEM_AGING_STATE)
#if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)
			        || ((*StatusNew & DEM_EVMEM_TFSLC_AGING_MASK) == DEM_EVMEM_TFSLC_AGING_STATE)
#endif
			    )
			{
			    if(Dem_EvMemGetEventMemAgingCounter(LocId) < Dem_EvtGetAgingThreshold(EventId))
			    {
			        Dem_EvMemSetEventMemAgingCounter(LocId, (uint16_least)(Dem_EvMemGetEventMemAgingCounter(LocId) + 1u));
			    }

#if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)

			    if(Dem_EvMemGetEventMemAgingCounterForTFSLC(LocId) < Dem_EvtGetAgingThresholdForTFSLC(EventId))
			    {
			        Dem_EvMemSetEventMemAgingCounterForTFSLC(LocId, (uint16_least)(Dem_EvMemGetEventMemAgingCounterForTFSLC(LocId) + 1u));
			    }
#endif
				*WriteSts = *WriteSts | DEM_EVMEM_WRITEMASK_DATA;
			}
			if ((*StatusNew & (DEM_EVMEM_STSMASK_CONFIRMED
#if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)
			             | DEM_EVMEM_STSMASK_TESTFAILED_SLC
#endif
			)) != 0u)
			{
				if (Dem_LibGetParamBool(DEM_CFG_EVMEM_TESTFAILED_TAC_SUPPORTED))
				{
					*StatusNew = *StatusNew & (uint16_least)(~(uint16_least)DEM_EVMEM_STSMASK_TESTFAILED_TAC);
				}
				if (Dem_LibGetParamBool(DEM_CFG_EVMEM_TESTCOMPLETE_TAC_SUPPORTED))
				{
					*StatusNew = *StatusNew & (uint16_least)(~(uint16_least)DEM_EVMEM_STSMASK_TESTCOMPLETE_TAC);
				}
			}
		}
	}

	/* check aging flag */
	IsAgingThresholdReached = FALSE;
	if ((Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_COUNT_UP)) ||
			(Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_COUNT_DOWN)))
	{
	    IsAgingThresholdReached = (Dem_boolean_least)((Dem_EvMemGetEventMemAgingCounter(LocId) >= Dem_EvtGetAgingThreshold(EventId)) && (Dem_EvtGetAgingThreshold(EventId) != 0)
#if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)
		                                        && (Dem_EvMemGetEventMemAgingCounterForTFSLC(LocId) >= Dem_EvtGetAgingThresholdForTFSLC(EventId))
#endif
		                                      );
	}

	if ((Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_AGINGCYC_STORE)) ||
			(Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_AGINGCYC_DIFF_UP)) ||
			(Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_AGINGCYC_DIFF_DOWN)))
	{

		Dem_EvMemAgingCounterType AgingCounterDiff;
		Dem_EvMemAgingCounterType TFSLCAgingCounterDiff;

		AgingCounterDiff = (Dem_EvMemAgingCounterType)(Dem_EvMemGetCurrentAgingCycleCounterInt(EventId) - Dem_EvMemGetEventMemAgingCounter(LocId));
		TFSLCAgingCounterDiff = (Dem_EvMemAgingCounterType)(Dem_EvMemGetCurrentAgingCycleCounterInt(EventId) - Dem_EvMemGetEventMemAgingCounterForTFSLC(LocId));

		IsAgingThresholdReached = (Dem_boolean_least)(((uint16_least)AgingCounterDiff >= Dem_EvtGetAgingThreshold(EventId))
#if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)
		                                && ((uint16_least)TFSLCAgingCounterDiff >= Dem_EvtGetAgingThresholdForTFSLC(EventId))
#endif
		                    );

#if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT == FALSE)
    DEM_UNUSED_PARAM(TFSLCAgingCounterDiff);
#endif

	}

	if (IsAgingThresholdReached)
	{
		*StatusNew = *StatusNew | DEM_EVMEM_STSMASK_AGED;
	}

}

DEM_INLINE void Dem_EvMemSetAgingCounterOnEventFailed(Dem_EventIdType EventId, uint16_least LocId, uint16_least* StatusNew, uint16_least* WriteSts)
{

	*StatusNew = *StatusNew & (uint16_least)(~((uint16_least)DEM_EVMEM_STSMASK_AGED));
	if ((Dem_EvMemGetEventMemStatus(LocId) & DEM_EVMEM_STSMASK_TESTFAILED) == 0u)
	{
		if ((Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_COUNT_UP)) ||
				(Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_COUNT_DOWN)))
		{
			Dem_EvMemSetEventMemAgingCounter(LocId,0);
#if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)
			Dem_EvMemSetEventMemAgingCounterForTFSLC(LocId, 0);
#endif
			*WriteSts = *WriteSts | DEM_EVMEM_WRITEMASK_DATA;
		}
		if ((Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_AGINGCYC_STORE)) ||
				(Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_AGINGCYC_DIFF_UP)) ||
				(Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_AGINGCYC_DIFF_DOWN)))
		{
			Dem_EvMemSetEventMemAgingCounter(LocId,Dem_EvMemGetCurrentAgingCycleCounterInt(EventId));

#if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)
			Dem_EvMemSetEventMemAgingCounterForTFSLC(LocId, (uint16_least)(Dem_EvMemGetCurrentAgingCycleCounterInt(EventId)));
#endif
			*WriteSts = *WriteSts | DEM_EVMEM_WRITEMASK_DATA;
		}
	}

	if ((Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_COUNT_UP)) ||
			(Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_COUNT_DOWN)))
	{
		/* aging flags are only processed when the stored event is confirmed but not aged */
#if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)
	    if ((*StatusNew & (DEM_EVMEM_STSMASK_TESTFAILED_SLC | DEM_EVMEM_STSMASK_AGED)) == DEM_EVMEM_STSMASK_TESTFAILED_SLC)
#else
	    if ((*StatusNew & (DEM_EVMEM_STSMASK_CONFIRMED | DEM_EVMEM_STSMASK_AGED)) == DEM_EVMEM_STSMASK_CONFIRMED)
#endif
		{
			if (Dem_LibGetParamBool(DEM_CFG_EVMEM_TESTFAILED_TAC_SUPPORTED))
			{
				*StatusNew = *StatusNew | DEM_EVMEM_STSMASK_TESTFAILED_TAC;
			}
			if (Dem_LibGetParamBool(DEM_CFG_EVMEM_TESTCOMPLETE_TAC_SUPPORTED))
			{
				*StatusNew = *StatusNew | DEM_EVMEM_STSMASK_TESTCOMPLETE_TAC;
			}
		}
	}
}

DEM_INLINE void Dem_EvMemSetAgingCounterOnEventPassed(Dem_EventIdType EventId, uint16_least LocId, uint16_least *StatusNew, uint16_least* WriteSts)
{

	if ((Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_AGINGCYC_STORE)) ||
			(Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_AGINGCYC_DIFF_UP)) ||
			(Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_AGINGCYC_DIFF_DOWN)))
	{
		if ((Dem_EvMemGetEventMemStatus(LocId) & DEM_EVMEM_STSMASK_TESTFAILED) != 0u)
		{
			Dem_EvMemSetEventMemAgingCounter(LocId,(uint16_least)(Dem_EvMemGetCurrentAgingCycleCounterInt(EventId)));
#if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)
			Dem_EvMemSetEventMemAgingCounterForTFSLC(LocId, (uint16_least)(Dem_EvMemGetCurrentAgingCycleCounterInt(EventId)));
#endif
			*WriteSts = *WriteSts | DEM_EVMEM_WRITEMASK_DATA;
		}
	}

	if ((Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_COUNT_UP)) ||
			(Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_AGING_METHOD_COUNT_DOWN)))
	{
		/* aging flags are only processed when the stored event is confirmed but not aged */
#if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)
        if ((*StatusNew & (DEM_EVMEM_STSMASK_TESTFAILED_SLC | DEM_EVMEM_STSMASK_AGED)) == DEM_EVMEM_STSMASK_TESTFAILED_SLC)
#else
	    if ((*StatusNew & (DEM_EVMEM_STSMASK_CONFIRMED | DEM_EVMEM_STSMASK_AGED)) == DEM_EVMEM_STSMASK_CONFIRMED)
#endif
		{
			if (Dem_LibGetParamBool(DEM_CFG_EVMEM_TESTCOMPLETE_TAC_SUPPORTED))
			{
				*StatusNew = *StatusNew | DEM_EVMEM_STSMASK_TESTCOMPLETE_TAC;
			}
		}
	}
}

DEM_INLINE Dem_boolean_least Dem_EvMemIsAgingCalculationAllowed(uint16_least locationStatus)
{
    return ((locationStatus & (DEM_EVMEM_STSMASK_CONFIRMED
    #if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)
            | DEM_EVMEM_STSMASK_TESTFAILED_SLC
    #endif
    )) != 0u);
}

#endif
#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
*
* AR40.11.0.0; 1     14.12.2015 TVE5COB
*   CSCRM00989964
*
* AR40.11.0.0; 0     19.10.2015 TVE5COB
*   CSCRM00957961
*
* AR40.10.0.0; 1     14.07.2015 WUG3ABT
*   Checkout by wug3abt
*
* AR40.10.0.0; 0     17.06.2015 TVE5COB
*   CSCRM00783642
*
* AR40.9.0.0; 0     25.08.2014 GJ83ABT
*   CSCRM00617667
*
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
*
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
*
* AR40.7.0.0; 2     21.11.2013 GIN9COB
*   CSCRM00598921
*
* AR40.7.0.0; 1     19.11.2013 BRM2COB
*
*
* AR40.7.0.0; 0     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
*
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
