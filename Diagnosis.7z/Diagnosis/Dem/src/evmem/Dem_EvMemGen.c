/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_EvMemGen$
* $Variant___:AR40.10.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/

#include "Dem_EvMemGen.h"
#include "Dem_Main.h"

/* -------------------------------------------------
   service Dem_GetDTCByOccurrenceTime
   -------------------------------------------------
 */
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
#if ( DEM_CFG_EVMEMGENERIC_SUPPORTED != FALSE )
Dem_ReturnGetDTCByOccurrenceTimeType Dem_GetDTCByOccurrenceTime(Dem_DTCRequestType DTCRequest, Dem_DTCKindType DTCKind, uint32* DTC)
{
      Dem_DtcIdType DtcId;

      /* is DEM Initialized ?*/
      if (!Dem_OpMoIsInitialized())
      {
         DEM_DET(DEM_DET_APIID_GETDTCBYOCCURRENCETIME, DEM_E_UNINIT);
         return DEM_OCCURR_FAILED;
      }
      /* parameter check: DTCRequest */
      if ((DTCRequest != DEM_FIRST_FAILED_DTC) &&
            (DTCRequest != DEM_MOST_RECENT_FAILED_DTC) &&
            (DTCRequest != DEM_FIRST_DET_CONFIRMED_DTC) &&
            (DTCRequest != DEM_MOST_REC_DET_CONFIRMED_DTC))
      {
         DEM_DET(DEM_DET_APIID_GETDTCBYOCCURRENCETIME, DEM_E_PARAM_CONFIG);
         return DEM_OCCURR_FAILED;
      }

      /* parameter check: DTCKind */
      if (DTCKind != DEM_DTC_KIND_ALL_DTCS)
      {
         DEM_DET(DEM_DET_APIID_GETDTCBYOCCURRENCETIME, DEM_E_PARAM_CONFIG);
         return DEM_OCCURR_WRONG_DTCKIND;
      }
      /* get the stored DtcId matching the DTCRequest */
      DtcId = Dem_EvMemGenGetDtcIdByOccIndex(DTCRequest);

      /* Is DtcId valid ?*/
      if (!Dem_isDtcIdValid(DtcId))
      {   /* No DTC is stored */
         return DEM_OCCURR_FAILED;
      }

      /* get the DTC code */
      *DTC = (uint32)Dem_DtcGetCode(DtcId);
      return DEM_OCCURR_OK;
   }
#endif

/* -------------------------------------------------
   service Dem_GetEventMemoryOverflow
   -------------------------------------------------
 */
Std_ReturnType Dem_GetEventMemoryOverflow(Dem_DTCOriginType DTCOrigin, boolean* OverflowIndication)
{

   if (Dem_LibGetParamBool(DEM_CFG_EVMEMGENERIC_SUPPORTED))
   {

      /* is DEM Initialized ?*/
      if (!Dem_OpMoIsInitialized())
      {
         DEM_DET(DEM_DET_APIID_GETEVENTMEMORYOVERFLOW, DEM_E_UNINIT);
         return E_NOT_OK;
      }

      /* parameter check: DTCOrigin */
      if (!Dem_EvMemIsDtcOriginValid (DTCOrigin))
      {
         DEM_DET(DEM_DET_APIID_GETEVENTMEMORYOVERFLOW, DEM_E_PARAM_CONFIG);
         return E_NOT_OK;
      }

      /* get the stored overflow indicator matching the DTCOrigin */
      *OverflowIndication = Dem_EvMemGenIsOverflow(DTCOrigin);
      return E_OK;
   }
   else
   {
	   DEM_DET(DEM_DET_APIID_GETEVENTMEMORYOVERFLOW, DEM_E_WRONG_CONDITION);
	   return E_NOT_OK;
   }
}

Dem_boolean_least Dem_EvMemGenIsNvmImmediateStoragePending(Dem_boolean_least *anyFailed)
{
    Dem_NvmResultType nvmStatus;

    nvmStatus = Dem_NvmGetStatus (DEM_NVM_ID_DEM_GENERIC_NV_DATA);
    *anyFailed = (*anyFailed) || (nvmStatus == DEM_NVM_FAILED);
    return (
            (Dem_NvGenericIsImmediateStoragePending())
            || (nvmStatus == DEM_NVM_PENDING)
				);
}

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 0     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.9.0.0; 0     06.01.2015 VSA2COB
*   CSCRM00743974
* 
* AR40.8.0.0; 1     16.06.2014 BPE4COB
*   CSCRM00666829
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 3     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 2     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 1     11.11.2013 BPE4COB
*   CSCRM00583901: Cleanup dem_GetDTCByOccurenceTime
* 
* AR40.7.0.0; 0     19.08.2013 MER3KOR
*   CSCRM00287483
* 
* AR40.6.0.0; 2     18.04.2013 BRM2COB
*   CSCRM00503658 : Restructure DtcGroup storage
* 
* AR40.6.0.0; 1     17.04.2013 GJ83ABT
*   CSCRM00517299
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
