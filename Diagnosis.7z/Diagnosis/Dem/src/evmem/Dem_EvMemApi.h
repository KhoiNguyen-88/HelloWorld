/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_EvMemApi$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_EVMEMAPI_H
#define DEM_EVMEMAPI_H

#include "Dem_EvMemTypes.h"

/* ----------------------------------------------------------------------------
   Interface Functions
   ----------------------------------------------------------------------------
*/

typedef struct
{
  /* DEM API write */
  Dem_DtcIdType            DtcId;
  Dem_DTCOriginType        DTCOrigin;
  uint8                    ReqCounter;
  /* DEM Main write */
  uint8                    DemCounter;
  boolean                  IsValid;
  Dem_EvMemEventMemoryType EventMemory;
} Dem_EvMemDTCRecordType;

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"
extern Dem_EvMemDTCRecordType Dem_EvMemDTCRecord;
#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/* Read Events From EvMem */

typedef struct {
	uint16_least evMemId;
	uint16_least locIterator;
} Dem_ReadEventsFromMemoryType;

void Dem_EvMemApiMainFunction(void);


/* ----------------------------------------------------------------------------
   DEM API Functions
   ----------------------------------------------------------------------------
*/

/**
 * @ingroup DEM_H
 *
 * Dem233: Disables the event memory update of a specific DTC (only one at one time).
 * @param[in]	DTC				Selects the DTC in UDS format, for which DTC record update shall be disabled.
 * @param[in]	DTCOrigin		If the Dem supports more than one event memory, this parameter is used to select the source memory for which DTC record update shall be disabled.
 * @return		Dem_ReturnDisableDTCRecordUpdateType: Status of the operation to disable the event memory update of a specific DTC\n
 *
 * <b>Note:</b>\n
 * DEM is not locking any DTC record.\n
 * Parameters of this function are not used or checked.\n
 * Instead a copy of the DTC record is taken for further processing on when calling API functions like Dem_GetFreezeFrameDataByDTC!
 */

extern Dem_ReturnDisableDTCRecordUpdateType Dem_DisableDTCRecordUpdate(uint32 DTC, Dem_DTCOriginType DTCOrigin);


/**
 * @ingroup DEM_H
 *
 * Dem234: Enables the DTC record update
 * @return       E_OK = Operation was successfull \n
 *				 E_NOT_OK = Operation failed
 *
 * <b>Note:</b>\n
 */

extern Std_ReturnType Dem_EnableDTCRecordUpdate(void);


/**
 * @ingroup DEM_H
 *
 * Dem236: Gets freeze frame data by DTC. The function stores the data in the provided DestBuffer
 * @param[in]   	DTC				This is the DTC the freeze frame is assigned to.
 * @param[in]   	DTCKind			This parameter defines the requested DTC, either only OBD-relevant DTCs or all DTCs.
 * @param[in]   	DTCOrigin		If the Dem supports more than one event memory, this parameter is used to select.
 *                               the source memory the DTCs shall be read from.
 * @param[in]   	RecordNumber	This parameter is a unique identifier for a freeze frame record as defined in ISO 15031-5 and ISO 14229-1.
 *                               This record number is unique per DTC (relative addressing)
 *                               The value 0xFF is not allowed. The value 0x00 indicates the DTC-specific OBD freeze frame.\n
 * @param[out]  	DestBuffer 		This parameter contains a byte pointer that points to the buffer, to which the freeze frame data record shall be written to.\n
 *                               The format is: {RecordNumber, NumOfDIDs, DID[1], data[1], ..., DID[N], data[N]}
 * @param[in,out] BufSize			When the function is called this parameter contains the maximum number of data bytes that can be written to the buffer.\n
 *                               The function returns the actual number of written data bytes in this parameter
 * @return 	      Dem_ReturnGetFreezeFrameDataByDTCType: Status of the operation to retrieve freeze frame data by DTC\n
 *
 * <b>Note:</b>\n
 * DEM supports only DTCKind 'DEM_DTC_KIND_ALL_DTCS'.\n
 * In case of PENDING the caller needs to repeat the service with identical parameters.
 *
 * Reading Freeze Frames is done by creating a copy of the event memory.Hence Dem_DisableDTCRecordUpdate must be called
 * before Dem_GetFreezeFrameDataByDTC is used to query stored Freeze Frames.Calling Dem_EnableDTCRecordUpdate frees
 *  the event memory copy finally.
 */

extern Dem_ReturnGetFreezeFrameDataByDTCType Dem_GetFreezeFrameDataByDTC( uint32            DTC,
                                                                          Dem_DTCKindType   DTCKind,
                                                                          Dem_DTCOriginType DTCOrigin,
                                                                          uint8             RecordNumber,
                                                                          uint8*            DestBuffer,
                                                                          uint16*           BufSize
                                                                        );


/**
 * @ingroup DEM_H
 *
 * Dem238: Gets the size of freeze frame data by DTC.
 * @param[in]   DTC					   This is the DTC the freeze frame is assigned to.
 * @param[in]   DTCKind				   This parameter defines the requested DTC, either only OBD-relevant DTCs or all DTCs
 * @param[in]   DTCOrigin			   If the Dem supports more than one event memory, this parameter is used to select
 *                                  the source memory the DTCs shall be read from.
 * @param[in]   RecordNumber		   This parameter is a unique identifier for a freeze frame record as defined in ISO 15031-5 and ISO 14229-1.\n
 *                                  This record number is unique per DTC (relative addressing).\n
 *                                  The value 0xFF is explicitly allowed to request the overall size.
 * @param[out]  SizeOfFreezeFrame	Number of bytes in the requested freeze frame record.
 * @return 	    Dem_ReturnGetSizeOfFreezeFrameByDTCType : Status of the operation to retrieve the size of freeze frame data.\n
 *
 * <b>Note:</b>\n
 * DEM supports only DTCKind 'DEM_DTC_KIND_ALL_DTCS'.\n
 * In case of PENDING the caller needs to repeat the service with identical parameters.
 */


extern Dem_ReturnGetSizeOfFreezeFrameByDTCType Dem_GetSizeOfFreezeFrameByDTC( uint32              DTC,
                                                                              Dem_DTCKindType     DTCKind,
                                                                              Dem_DTCOriginType   DTCOrigin,
                                                                              uint8               RecordNumber,
                                                                              uint16*             SizeOfFreezeFrame
                                                                            );
/**
 * @ingroup DEM_H
 *
 * Dem239: Gets extended data by DTC. The function stores the data in the provided DestBuffer.
 * @param[in]   	DTC					   This is the DTC the 'Extended Data Record' is assigned to.
 * @param[in]  	DTCKind				   This parameter defines the requested DTC, either only OBD-relevant DTCs or all DTCs.
 * @param[in]   	DTCOrigin			   If the Dem supports more than one event memory, this parameter is used to select
 *                                     the source memory the DTCs shall be read from.
 * @param[in]   	ExtendedDataNumber	Identification/Number of requested extended data record.
 *                                     The values 0xFE and 0xFF are not allowed. Valid values are from 0x01 to 0xEF.
 * @param[out]  	DestBuffer			   This parameter contains a byte pointer that points to the buffer, to which the extended data record shall be written.\n
 *                                     The format is raw hexadecimal values and contains no header-information.
 * @param[in,out]	BufSize				   When the function is called this parameter contains the maximum number of data bytes that can be written to the buffer.\n
 *                                     The function returns the actual number of written data bytes in this parameter.
 * @return 	    Dem_ReturnGetExtendedDataRecordByDTCType : Status of the operation to retrieve extended data by DTC \n
 *
 * <b>Note:</b>\n
 * DEM supports only DTCKind 'DEM_DTC_KIND_ALL_DTCS'.\n
 * In case of PENDING the caller needs to repeat the service with identical parameters.
 *
 * Reading Extended Data is done by creating a copy of the event memory.Hence  Dem_DisableDTCRecordUpdate must be called
 *  before Dem_GetExtendedDataRecordByDTC is used to query stored Extended Data Records.Calling Dem_EnableDTCRecordUpdate
 *   frees the event memory copy finally.
 */

extern Dem_ReturnGetExtendedDataRecordByDTCType Dem_GetExtendedDataRecordByDTC( uint32              DTC,
                                                                                Dem_DTCKindType     DTCKind,
                                                                                Dem_DTCOriginType   DTCOrigin,
                                                                                uint8               ExtendedDataNumber,
                                                                                uint8*              DestBuffer,
                                                                                uint16*             BufSize
                                                                              );




/**
 * @ingroup DEM_H
 *
 * Dem240: Gets the size of extended data by DTC.
 * @param[in]   DTC							   This is the DTC the 'Extended Data Record' is assigned to.
 * @param[in]   DTCKind						   This parameter defines the requested DTC, either only OBD-relevant DTCs or all DTCs
 * @param[in]   DTCOrigin					   If the Dem supports more than one event memory, this parameter is used to select
 *                                        the source memory the DTCs shall be read from.
 * @param[in]   ExtendedDataNumber			Identification/Number of requested extended data record. Valid values are from 0x01 to 0xEF.
 * @param[out]  SizeOfExtendedDataRecord	Pointer to Size of the requested data record.
 * @return 	    Dem_ReturnGetSizeOfExtendedDataRecordByDTCType : Status of the operation to retrieve the size of extended data. \n
 *
 * <b>Note:</b>\n
 * DEM supports only DTCKind 'DEM_DTC_KIND_ALL_DTCS'.\n
 * In case of PENDING the caller needs to repeat the service with identical parameters.
 */


extern Dem_ReturnGetSizeOfExtendedDataRecordByDTCType Dem_GetSizeOfExtendedDataRecordByDTC( uint32             DTC,
                                                                                            Dem_DTCKindType    DTCKind,
                                                                                            Dem_DTCOriginType  DTCOrigin,
                                                                                            uint8              ExtendedDataNumber,
                                                                                            uint16*            SizeOfExtendedDataRecord
                                                                                          );



/**
 * @ingroup DEM_H
 *
 * Dem209: Sets a freeze frame record filter.
 * @param[in]  DTCFormat  Defines the output-format of the requested DTC values for the sub-sequent API calls.
 * @param[out]  NumberOfFilteredRecords	Number of freeze frame records currently stored in the event memory.
 * @return 	    Dem_ReturnSetFilterType: Status of the operation to (re-)set a freeze frame record filter \n
 *
 * <b>Note:</b>\n
 * DEM supports only DTCKind 'DEM_DTC_KIND_ALL_DTCS'.\n
 * In case of PENDING the caller needs to repeat the service with identical parameters.\n
 * This service is only allowed if the DCM task and the DEM task do not preempt each other
 */

 extern Dem_ReturnSetFilterType Dem_SetFreezeFrameRecordFilter( Dem_DTCFormatType DTCFormat, uint16* NumberOfFilteredRecords );


 /**
 * @ingroup DEM_H
 *
 * Dem215: Gets the current DTC and its associated snapshot record numbers from the Dem.
 * @param[out]  DTC	             Receives the DTC value returned by the function.
 *                                If the return value of the function is other than DEM_FILTERED_OK this parameter does not contain valid data.
 * @param[out]  RecordNumber	    Freeze frame record number of the reported DTC (relative addressing).
 *                                If the return value of the function is other than DEM_FILTERED_OK this parameter does not contain valid data.
 * @return 	    Dem_ReturnGetNextFilteredDTCType: Status of the operation to retrieve the next filtered DTC and freeze frame record number \n
 *
 * <b>Note:</b>\n
 * DEM supports only DTCKind 'DEM_DTC_KIND_ALL_DTCS'.\n
 * In case of PENDING the caller needs to repeat the service with identical parameters.\n
 * This service is only allowed if the DCM task and the DEM task do not preempt each other
 */

 extern Dem_ReturnGetNextFilteredDTCType Dem_GetNextFilteredRecord( uint32*  DTC,
                                                                    uint8*   RecordNumber );

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/* ----------------------------------------------------------------------------
   Inline Functions
   ----------------------------------------------------------------------------
*/

DEM_INLINE Dem_boolean_least Dem_EvMemIsDtcKindValid (Dem_DTCKindType DTCKind)
{
    return (DTCKind == DEM_DTC_KIND_ALL_DTCS);
}


DEM_INLINE Dem_boolean_least Dem_EvMemIsDtcOriginValid (Dem_DTCOriginType  DTCOrigin)
{
    return (
               (DTCOrigin == DEM_DTC_ORIGIN_PRIMARY_MEMORY)
#if DEM_CFG_MAX_NUMBER_EVENT_ENTRY_SECONDARY > 0
            || (DTCOrigin == DEM_DTC_ORIGIN_SECONDARY_MEMORY)
#endif
#if (DEM_CFG_MAX_NUMBER_EVENT_ENTRY_MIRROR > 0) || DEM_CFG_EVMEM_SHADOW_MEMORY_SUPPORTED
            || (DTCOrigin == DEM_DTC_ORIGIN_MIRROR_MEMORY)
#endif
           );
}


/**
 * @ingroup DEM_EXT_H
 *
 * Used to return the status of reading events from event memory (\ref Dem_ReadEventsFromMemory/ \ref Dem_GetNextEventFromMemory).\n
 * \n
 * DEM_READEVENT_OK\n
 * DEM_READEVENT_NO_MATCHING\n
 * DEM_READEVENT_WRONG_ORIGIN
 */
typedef uint8 Dem_ReadEventType;
#define DEM_READEVENT_OK                     0x00
#define DEM_READEVENT_NO_MATCHING_ELEMENT    0x01
#define DEM_READEVENT_WRONG_ORIGIN           0x02

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
/**
* @ingroup DEM_EXT_H
*
* Start reading the eventIds from the event memory.
* @param[in]  ReadEventsFromMemory 	State Read event and event related information from memory
* @param[in]  origin	             Specify the event memory which shall be read (see \ref Dem_DTCOriginType).
* @return 	    \ref Dem_ReadEventType: Basically returns, whether a valid origin was requested \n
* @see Dem_GetNextEventFromMemory
*/
Dem_ReadEventType Dem_ReadEventsFromMemory (Dem_ReadEventsFromMemoryType* ReadEventsFromMemoryState, Dem_DTCOriginType origin);

/**
* @ingroup DEM_EXT_H
*
* Read eventids and Location Ids from event memory after read was started with \ref Dem_ReadEventsFromMemory.
* Additional Hint: in concurrently running systems, the eventID returned by this interface may later on already be removed from event memory (e.g. due to displacement or event combination).
* @param[in]   ReadEventsFromMemory 	State Read event and event related information from memory
* @param[out]  EventId           The next found eventId is stored in the variable, but only if the return value is DEM_READEVENT_OK.
* @param[out]  LocId             The Location Id to read further event related information [e.g. Occurence Counter]
* @return 	    Dem_ReadEventType: Returns, whether reading was successful or no event was found (NO_MATCHING_ELEMENT).\n
*/
Dem_ReadEventType Dem_GetNextEventFromMemory (Dem_ReadEventsFromMemoryType* ReadEventsFromMemoryState, Dem_EventIdType* EventId, uint16* LocId);

#if(DEM_CFG_TRIGGER_TO_STORE_NVM_SUPPORTED)
void Dem_EvMemTriggerStoreToNvm(void);

void Dem_EvMemHandleTriggerStorageToNvm(void);
#endif

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     06.01.2016 BPE4COB
*   CSCRM00976006
* 
* AR40.8.0.0; 4     16.07.2014 BRM2COB
*   CSCRM00688243
* 
* AR40.8.0.0; 3     16.06.2014 BPE4COB
*   CSCRM00666829
* 
* AR40.8.0.0; 2     15.04.2014 BRM2COB
*   
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 5     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 4     19.11.2013 BRM2COB
*   
* 
* AR40.7.0.0; 3     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 2     24.10.2013 GJ83ABT
*   CSCRM00467090
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
