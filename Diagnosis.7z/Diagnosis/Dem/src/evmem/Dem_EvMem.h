/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_EvMem$
* $Variant___:AR40.11.0.1$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_EVMEM_H
#define DEM_EVMEM_H


#include "Dem_Types.h"
#include "Dem_Cfg_EnvMain.h"
#include "Dem_OperationCycle.h"

#include "Dem_EvMemTypes.h"
#include "Dem_EvMemBase.h"

#include "Dem_EvMemApi.h"
#include "Dem_EvMemAging.h"
#if (DEM_CFG_EVMEM_AGING_METHOD == DEM_CFG_EVMEM_AGING_METHOD_USER)
#include "Dem_PrjEvMemAging.h"
#endif


typedef struct {
	uint8 evMemId;
	boolean originSupported;
} Dem_EvMemMapOrigin2IdType;

#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
DEM_ARRAY_DECLARE_CONST(Dem_EvMemMapOrigin2IdType, Dem_EvMemMapOrigin2Id, 5);
#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"


DEM_INLINE boolean Dem_EvMemIsOriginSupported (Dem_DTCOriginType origin)
{
	return Dem_EvMemMapOrigin2Id[origin].originSupported;
}

DEM_INLINE uint8 Dem_EvMemGetEvMemIdFromOrigin (Dem_DTCOriginType origin)
{
	return Dem_EvMemMapOrigin2Id[origin].evMemId;
}


/* ----------------------------------------------------------------------------
   Interface Functions
   ----------------------------------------------------------------------------
*/
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
void          Dem_EvMemInit(void);
void          Dem_EvMemInitCausality(void);

void          Dem_EvMemClearEvent(Dem_EventIdType EventId, uint16_least MemId);
void          Dem_EvMemEraseEventMemory(uint16_least MemId);

void          Dem_EvMemSetEventPassed(Dem_EventIdType EventId, uint16_least MemId, const uint8 *EnvData);
void          Dem_EvMemSetEventFailed(Dem_EventIdType EventId, uint16_least MemId, const uint8 *EnvData);
void          Dem_EvMemSetEventUnRobust(Dem_EventIdType EventId, uint16_least MemId, const uint8 *EnvData);
void          Dem_EvMemStartOperationCycle(Dem_OperationCycleList operationCycleList, uint16_least MemId);

uint16_least  Dem_EvMemGetEventMemoryLocIdOfDtcWithVisibility(Dem_DtcIdType DtcId, uint16_least MemId, Dem_boolean_least ShadowEntriesVisible);
uint16_least  Dem_EvMemGetEventMemoryStatusOfDtc(Dem_DtcIdType DtcId, uint16_least MemId);
uint16_least  Dem_EvMemGetEventMemoryLocIdOfEvent (Dem_EventIdType EventId, uint16_least MemId);
uint16_least  Dem_EvMemGetEventMemoryStatusOfEvent(Dem_EventIdType EventId, uint16_least MemId);

#if DEM_CFG_EVMEM_SHADOW_MEMORY_SUPPORTED
void          Dem_EvMemClearShadowMemory(Dem_EventIdType EventId, uint16_least MemId);
uint16_least  Dem_EvMemGetShadowMemoryLocIdOfDtc(Dem_DtcIdType DtcId, uint16_least MemId);
#endif

uint16_least  Dem_EvMemGetMemoryLocIdOfDtcAndOriginWithVisibility(Dem_DtcIdType DtcId, Dem_DTCOriginType DTCOrigin, Dem_boolean_least ShadowEntriesVisible);


Dem_NvmIdType     Dem_EvMemGetNvmIdFromLocId(uint16_least LocId);
void              Dem_EvMemStorageMainFunction(void);
Dem_boolean_least Dem_EvMemIsNvmImmediateStoragePending(Dem_boolean_least *anyFailed);

/**
 * @ingroup DEM_EXT_H
 *
 * Interface to lock the event memory.
 * @param [in] Lock: describes whether the event memory is locked or unlocked
 * @return E_OK: Accessing any of the functions is possible
 * @return E_NOT_OK: Only read and clear functions are accessible. Accessing other functions are not possible since the memory is locked for any insertion of events.
 */
Std_ReturnType Dem_LockEventMemory (boolean Lock);
void              Dem_EvMemShutdown(void);
#if (DEM_CFG_READDEM_MAX_FDC_DURING_CURRENT_CYCLE_SUPPORTED	|| DEM_CFG_READDEM_MAX_FDC_SINCE_LAST_CLEAR_SUPPORTED)
void 			Dem_EvMemFdcUpdate(void);
#else
DEM_INLINE void Dem_EvMemFdcUpdate(void) {}
#endif
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"
extern boolean Dem_EvMemIsLocked;
#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"
/* ----------------------------------------------------------------------------
   Inline
   ----------------------------------------------------------------------------
*/

DEM_INLINE void Dem_EvMemMainFunction(void)
{
#if(DEM_CFG_TRIGGER_TO_STORE_NVM_SUPPORTED)
    Dem_EvMemHandleTriggerStorageToNvm();
#endif

    Dem_EvMemApiMainFunction();
    Dem_EvMemFdcUpdate();
    Dem_EvMemStorageMainFunction();
    #if (DEM_CFG_EVMEM_PROJECT_EXTENSION)
    {
        Dem_EvMemProjectExtensionMain();
    }
    #endif
}


DEM_INLINE void Dem_EvMemSetEventFailedAllMem(Dem_EventIdType EventId, const uint8 *EnvData)
{
   if (Dem_EvtIsDestPrimaryMemory(EventId))
   {
      Dem_EvMemSetEventFailed(EventId,DEM_CFG_EVMEM_MEMID_PRIMARY,EnvData);
   }
#if DEM_CFG_MAX_NUMBER_EVENT_ENTRY_SECONDARY > 0
   if (Dem_EvtIsDestSecondaryMemory(EventId))
   {
      Dem_EvMemSetEventFailed(EventId,DEM_CFG_EVMEM_MEMID_SECONDARY,EnvData);
   }
#endif
}


DEM_INLINE void Dem_EvMemSetEventPassedAllMem(Dem_EventIdType EventId, const uint8 *EnvData)
{
   if (Dem_EvtIsDestPrimaryMemory(EventId))
   {
      Dem_EvMemSetEventPassed(EventId,DEM_CFG_EVMEM_MEMID_PRIMARY,EnvData);
   }
#if DEM_CFG_MAX_NUMBER_EVENT_ENTRY_SECONDARY > 0
   if (Dem_EvtIsDestSecondaryMemory(EventId))
   {
      Dem_EvMemSetEventPassed(EventId,DEM_CFG_EVMEM_MEMID_SECONDARY,EnvData);
   }
#endif
}


DEM_INLINE void Dem_EvMemSetEventUnRobustAllMem(Dem_EventIdType EventId, const uint8 *EnvData)
{
   if (Dem_EvtIsDestPrimaryMemory(EventId))
   {
      Dem_EvMemSetEventUnRobust(EventId,DEM_CFG_EVMEM_MEMID_PRIMARY,EnvData);
   }
#if DEM_CFG_MAX_NUMBER_EVENT_ENTRY_SECONDARY > 0
   if (Dem_EvtIsDestSecondaryMemory(EventId))
   {
      Dem_EvMemSetEventUnRobust(EventId,DEM_CFG_EVMEM_MEMID_SECONDARY,EnvData);
   }
#endif
}

DEM_INLINE void Dem_EvMemStartOperationCycleAllMem(Dem_OperationCycleList operationCycleList)
{
    Dem_EvMemStartOperationCycle(operationCycleList, DEM_CFG_EVMEM_MEMID_PRIMARY);
#if DEM_CFG_MAX_NUMBER_EVENT_ENTRY_SECONDARY > 0
    Dem_EvMemStartOperationCycle(operationCycleList, DEM_CFG_EVMEM_MEMID_SECONDARY);
#endif
}


DEM_INLINE void Dem_EvMemClearEventAndOrigin(Dem_EventIdType EventId, Dem_DTCOriginType DTCOrigin)
{
   if (DTCOrigin == DEM_DTC_ORIGIN_PRIMARY_MEMORY)
   {
       Dem_EvMemClearEvent(EventId, DEM_CFG_EVMEM_MEMID_PRIMARY);
   }

#if DEM_CFG_MAX_NUMBER_EVENT_ENTRY_SECONDARY > 0
   if (DTCOrigin == DEM_DTC_ORIGIN_SECONDARY_MEMORY)
   {
       Dem_EvMemClearEvent(EventId, DEM_CFG_EVMEM_MEMID_SECONDARY);
   }
#endif

#if (DEM_CFG_MAX_NUMBER_EVENT_ENTRY_MIRROR > 0)
   if (DTCOrigin == DEM_DTC_ORIGIN_MIRROR_MEMORY)
   {
       Dem_EvMemClearEvent(EventId, DEM_CFG_EVMEM_MEMID_MIRROR);
   }
#elif DEM_CFG_EVMEM_SHADOW_MEMORY_SUPPORTED
   if (DTCOrigin == DEM_DTC_ORIGIN_MIRROR_MEMORY)
   {
	   Dem_EvMemClearShadowMemory(EventId, DEM_CFG_EVMEM_MEMID_SHADOW);
   }
#endif

}

DEM_INLINE uint16_least  Dem_EvMemGetEventMemoryStatusOfDtcAndOrigin(Dem_DtcIdType DtcId, Dem_DTCOriginType DTCOrigin)
{

   if (DTCOrigin == DEM_DTC_ORIGIN_PRIMARY_MEMORY)
   {
       return Dem_EvMemGetEventMemoryStatusOfDtc(DtcId, DEM_CFG_EVMEM_MEMID_PRIMARY);
   }

#if DEM_CFG_MAX_NUMBER_EVENT_ENTRY_SECONDARY > 0
   if (DTCOrigin == DEM_DTC_ORIGIN_SECONDARY_MEMORY)
   {
	   return Dem_EvMemGetEventMemoryStatusOfDtc(DtcId, DEM_CFG_EVMEM_MEMID_SECONDARY);
   }
#endif

#if (DEM_CFG_MAX_NUMBER_EVENT_ENTRY_MIRROR > 0)
   if (DTCOrigin == DEM_DTC_ORIGIN_MIRROR_MEMORY)
   {
	   return Dem_EvMemGetEventMemoryStatusOfDtc(DtcId, DEM_CFG_EVMEM_MEMID_MIRROR);
   }
#elif DEM_CFG_EVMEM_SHADOW_MEMORY_SUPPORTED
   /* not supported for shadow memory */
#endif

   /* should never occur */
   return 0;

}

DEM_INLINE uint16_least  Dem_EvMemGetEventMemoryStatusOfEventAndOrigin(Dem_EventIdType EventId, Dem_DTCOriginType DTCOrigin)
{
   if (DTCOrigin == DEM_DTC_ORIGIN_PRIMARY_MEMORY)
   {
       return  Dem_EvMemGetEventMemoryStatusOfEvent(EventId, DEM_CFG_EVMEM_MEMID_PRIMARY);
   }

#if DEM_CFG_MAX_NUMBER_EVENT_ENTRY_SECONDARY > 0
   if (DTCOrigin == DEM_DTC_ORIGIN_SECONDARY_MEMORY)
   {
	   return  Dem_EvMemGetEventMemoryStatusOfEvent(EventId, DEM_CFG_EVMEM_MEMID_SECONDARY);
   }
#endif

#if (DEM_CFG_MAX_NUMBER_EVENT_ENTRY_MIRROR > 0)
   if (DTCOrigin == DEM_DTC_ORIGIN_MIRROR_MEMORY)
   {
	   return  Dem_EvMemGetEventMemoryStatusOfEvent(EventId, DEM_CFG_EVMEM_MEMID_MIRROR);
   }
#elif DEM_CFG_EVMEM_SHADOW_MEMORY_SUPPORTED
   /* not supported for shadow memory */
#endif

   /* should never occur */
   return 0;

}
DEM_INLINE uint16_least Dem_EvMemGetLocationOfEventFromEventMemory(Dem_EventIdType EventId)
{

	if(Dem_EvtIsDestPrimaryMemory(EventId))
	{
		return (Dem_EvMemGetEventMemoryLocIdOfEvent(EventId, DEM_CFG_EVMEM_MEMID_PRIMARY));
	}

#if DEM_CFG_MAX_NUMBER_EVENT_ENTRY_SECONDARY > 0
	if(Dem_EvtIsDestSecondaryMemory(EventId))
	{
		return (Dem_EvMemGetEventMemoryLocIdOfEvent(EventId, DEM_CFG_EVMEM_MEMID_SECONDARY));
	}
#endif

#if (DEM_CFG_MAX_NUMBER_EVENT_ENTRY_MIRROR > 0)
	if(Dem_EvtIsDestMirrorMemory(EventId))
	{
		return Dem_EvMemGetEventMemoryLocIdOfEvent(EventId, DEM_CFG_EVMEM_MEMID_MIRROR);
	}
#elif DEM_CFG_EVMEM_SHADOW_MEMORY_SUPPORTED
	return Dem_EvMemGetEventMemoryLocIdOfEvent(EventId, DEM_CFG_EVMEM_MEMID_SHADOW);
#endif

	return DEM_EVMEM_INVALID_LOCID;
}
/**
 * @ingroup DEM_EXT_H
 *
 * Interface to get the lock
 * @returns
 * TRUE: Event Memory is locked
 * FALSE: Event Memory is unlocked
 */
DEM_INLINE boolean Dem_GetEvMemLock(void)
{
	return Dem_EvMemIsLocked;
}
DEM_INLINE uint16_least Dem_EvMemGetMemoryLocIdOfDtcAndOrigin(Dem_DtcIdType DtcId, Dem_DTCOriginType DTCOrigin)
{
	/* do not report deleted DTCs */
	return Dem_EvMemGetMemoryLocIdOfDtcAndOriginWithVisibility(DtcId,DTCOrigin,FALSE);
}
DEM_INLINE uint16_least Dem_EvMemGetEventMemoryLocIdOfDtc(Dem_DtcIdType DtcId, uint16_least MemId)
{
	/* do not report deleted DTCs */
    return Dem_EvMemGetEventMemoryLocIdOfDtcWithVisibility(DtcId,MemId,FALSE);
}



#endif
/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.1; 0     03.02.2016 CLH2SI
*   CSCRM01036799
* 
* AR40.11.0.0; 2     14.12.2015 TVE5COB
*   CSCRM00989964
* 
* AR40.11.0.0; 1     19.10.2015 CLH2SI
*   CSCRM00977094
* 
* AR40.11.0.0; 0     17.09.2015 UDKOEGEL
*   CSCRM00960004
* 
* AR40.10.0.0; 0     06.07.2015 VSA2COB
*   CSCRM00830308
* 
* AR40.9.0.0; 1     18.11.2014 LIB8FE
*   CSCRM00737017
* 
* AR40.9.0.0; 0     18.11.2014 TVE5COB
*   CSCRM00737328
* 
* AR40.8.0.0; 8     18.07.2014 VSA2COB
*   CSCRM00635984
* 
* AR40.8.0.0; 7     16.06.2014 BPE4COB
*   CSCRM00666829
* 
* AR40.8.0.0; 6     20.03.2014 CLH2SI
*   CSCRM00633913
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
