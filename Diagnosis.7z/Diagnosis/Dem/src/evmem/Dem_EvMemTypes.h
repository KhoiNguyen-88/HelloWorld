/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_EvMemTypes$
* $Variant___:AR40.11.0.0$
* $Revision__:2$
**********************************************************************************************************************
</BASDKey>*/


/* ----------------------------------------------------------------------------
   Include Protection
   ----------------------------------------------------------------------------
*/
#ifndef DEM_EVMEMTYPES_H
#define DEM_EVMEMTYPES_H

#include "Dem_Types.h"
#include "Dem_Cfg_EvMem.h"
#include "Dem_Cfg_EnvMain.h"
/* FC_VariationPoint_START */
#include "Dem_Cfg_ObdMain.h"
/* FC_VariationPoint_END */
#include "Dem_Cfg_EnvDataElement.h"
#if (DEM_CFG_EVMEM_PROJECT_EXTENSION)
#include "Dem_PrjEvmemProjectExtension.h"
#endif


/* ----------------------------------------------------------------------------
   Defines
   ----------------------------------------------------------------------------
*/

/* max TimeId */
#define DEM_EVMEM_MAX_TIMEID                        0xFFFFFFFFuL
/* invalid LocId */
#define DEM_EVMEM_INVALID_LOCID                     0xFFFFu
/* invalid MemId */
#define DEM_EVMEM_INVALID_MEMID                     0xFFFFu

/* ISO 14229 - like status bits */
#define DEM_EVMEM_STSMASK_TESTFAILED                0x0001u
#define DEM_EVMEM_STSMASK_TESTFAILED_TFC            0x0002u
#define DEM_EVMEM_STSMASK_PENDING                   0x0004u
#define DEM_EVMEM_STSMASK_CONFIRMED                 0x0008u
#define DEM_EVMEM_STSMASK_PENDING_NFC               0x0010u
#define DEM_EVMEM_STSMASK_TESTCOMPLETE_TFC          0x0020u
#define DEM_EVMEM_STSMASK_TESTFAILED_SLC            0x0040u
#define DEM_EVMEM_STSMASK_DELETED                   0x0080u

/* aging status bits */
#define DEM_EVMEM_STSMASK_TESTFAILED_TAC            0x0100u
#define DEM_EVMEM_STSMASK_TESTCOMPLETE_TAC          0x0200u
#define DEM_EVMEM_STSMASK_AGED                      0x0400u
#define DEM_EVMEM_STSMASK_PENDING_CONFIRMED         0x0800u
#define DEM_EVMEM_STSMASK_STORED                    0x1000u



/* storage priorities */
#define DEM_EVMEM_STORAGE_PRIO_UNDEF                0u
#define DEM_EVMEM_STORAGE_PRIO_DELETED              1u
#define DEM_EVMEM_STORAGE_PRIO_EMPTY                2u
#define DEM_EVMEM_STORAGE_PRIO_STORED               3u

#define DEM_EVMEM_PRIO_OFFSET                       255u

/* write status */
#define DEM_EVMEM_WRITEMASK_NO                      0x0000u
#define DEM_EVMEM_WRITEMASK_DATA                    0x0001u
#define DEM_EVMEM_WRITEMASK_EVENTDATA               0x0002u
#define DEM_EVMEM_WRITEMASK_CLEAR                   0x0004u
#define DEM_EVMEM_WRITEMASK_OCCCOUNTER              0x0008u

/* storage state */
#define DEM_EVMEM_STORAGESTATE_WRITE_IDLE           0x0000u
#define DEM_EVMEM_STORAGESTATE_WRITE_SHUTDOWN       0x0001u
#define DEM_EVMEM_STORAGESTATE_WRITE_IMMEDIATE      0x0002u

/* ----------------------------------------------------------------------------
   Typedef
   ----------------------------------------------------------------------------
*/

#if DEM_CFG_EVMEM_OCCURRENCE_COUNTER_MAX <= 0xFF
   typedef uint8    Dem_EvMemOccurrenceCounterType;
#elif DEM_CFG_EVMEM_OCCURRENCE_COUNTER_MAX <= 0xFFFF
   typedef uint16   Dem_EvMemOccurrenceCounterType;
#else
#error Occurrence Counter Type must be 8 or 16-Bit
#endif


#if DEM_CFG_EVMEM_AGING_COUNTER_MAX <= 0xFF
   typedef uint8    Dem_EvMemAgingCounterType;
#elif DEM_CFG_EVMEM_AGING_COUNTER_MAX <= 0xFFFF
   typedef uint16   Dem_EvMemAgingCounterType;
#else
#error Aging Counter Type must be 8 or 16-Bit
#endif


#if (DEM_CFG_EVMEM_DEBUG_BITFIELDS)
/* structure supports INTEL-format only */
typedef struct
{
   unsigned int TestFailed       :1;
   unsigned int TestFailedTFC    :1;
   unsigned int Pending          :1;
   unsigned int Confirmed        :1;
   unsigned int PendingNFC       :1;
   unsigned int TestCompleteTFC  :1;
   unsigned int TestFailedSLC    :1;
   unsigned int Deleted          :1;
   unsigned int TestFailedTAC    :1;
   unsigned int TestCompleteTAC  :1;
   unsigned int Aged             :1;
   unsigned int PendingConfirmed :1;
   unsigned int Stored           :1;
}  Dem_EvMemStatusBitFieldType;

#endif

typedef union
{
  struct
  {
      uint16       Status;
      uint16       EventId;
  } Data;
#if (DEM_CFG_EVMEM_DEBUG_BITFIELDS)
  Dem_EvMemStatusBitFieldType  StatusBits;
#endif
}  Dem_EvMemHdrType;


typedef struct
{
   Dem_EvMemHdrType                          Hdr;

#if (DEM_CFG_EVMEM_MIRROR_MEMORY_DTC_STATUS_STORED)
	uint8                                     DTCStatus;
#endif
#if (DEM_CFG_READDEM_CYCLES_SINCE_FIRST_FAILED_SUPPORTED)
	uint8 									CyclesSinceFirstFailed;
#endif

#if (DEM_CFG_READDEM_CYCLES_SINCE_LAST_FAILED_SUPPORTED)
	uint8 									CyclesSinceLastFailed;
#endif

#if (DEM_CFG_READDEM_CYCLES_SINCE_LAST_FAILED_EXCLUDING_TNC_SUPPORTED)
	uint8 									CyclesSinceLastFailedExcludingTNC;
#endif

#if (DEM_CFG_READDEM_FAILED_CYCLES_SUPPORTED)
	uint8									FailedCycles;
#endif

	uint8                                     Data[DEM_CFG_ENVMINSIZE_OF_MULTIPLE_RAWENVDATA];
#if (DEM_CFG_EVMEM_FAILURE_COUNTER_SUPPORTED)
   uint8                                     FailureCounter;
#endif
#if (DEM_CFG_EVMEM_FREEZE_FRAME_SUPPORTED)
   uint8                                     FreezeFrameCounter;
#endif
#if (DEM_CFG_READDEM_MAX_FDC_DURING_CURRENT_CYCLE_SUPPORTED)
    sint8                                   MaxFdcDuringCurrentCycle;
#endif
#if (DEM_CFG_READDEM_MAX_FDC_SINCE_LAST_CLEAR_SUPPORTED)
    sint8                                   MaxFdcSinceLastClear;
#endif
/* FC_VariationPoint_START */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
   uint8                                     ObdMilCounter;
#endif
/* FC_VariationPoint_END */
#if (DEM_CFG_EVMEM_AGING_COUNTER_SUPPORTED)
   Dem_EvMemAgingCounterType                 AgingCounter;
#endif
#if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)
   Dem_EvMemAgingCounterType                 AgingCounterForTFSLC;
#endif
#if (DEM_CFG_EVMEM_OCCURRENCE_COUNTER_SUPPORTED)
   Dem_EvMemOccurrenceCounterType            OccurrenceCounter;
#endif
#if (DEM_CFG_EVMEM_EXTENDED_DATA_SUPPORTED)
   Dem_TriggerType                           Trigger;
#endif

   uint32                                    TimeId;
/* FC_VariationPoint_START */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
   uint32                                    ObdFFTimeId;
#endif
/* FC_VariationPoint_END */

#if (DEM_CFG_EVMEM_PROJECT_EXTENSION)
   Dem_EvMemProjectExtensionType             ProjectExtension;
#endif

}  Dem_EvMemEventMemoryType;


typedef struct {
   uint8             state;
} Dem_EvMemStorageType;


/* ----------------------------------------------------------------------------
   Include Protection
   ----------------------------------------------------------------------------
*/
#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 2     19.10.2015 TVE5COB
*   CSCRM00957961
* 
* AR40.11.0.0; 1     19.10.2015 CLH2SI
*   CSCRM00977094
* 
* AR40.11.0.0; 0     17.09.2015 UDKOEGEL
*   CSCRM00960004
* 
* AR40.10.0.0; 1     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 0     17.06.2015 TVE5COB
*   CSCRM00783642
* 
* AR40.8.0.0; 8     18.07.2014 VSA2COB
*   CSCRM00635984
* 
* AR40.8.0.0; 7     17.06.2014 VSA2COB
*   CSCRM00659749
* 
* AR40.8.0.0; 6     16.06.2014 GJ83ABT
*   CSCRM00615634, CSCRM00671513
* 
* AR40.8.0.0; 5     10.06.2014 UDKOEGEL
*   CSCRM00639545
* 
* AR40.8.0.0; 4     15.05.2014 VSA2COB
*   CSCRM00662943
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
