/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_EvMemGenTypes$
* $Variant___:AR40.10.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_EVMEMGENTYPES_H
#define DEM_EVMEMGENTYPES_H

#include "Dem_Types.h"
#include "Dem_Cfg_EvMem.h"

/* ----------------------------------------------------------------------------
   config
   ----------------------------------------------------------------------------
 */
#define DEM_EVMEMGEN_DTCIDS_BY_OCCURRENCE_TIME_ARRAYSIZE     5u
#define DEM_EVMEMGEN_OVERFLOW_ARRAYSIZE                      5u

/* ----------------------------------------------------------------------------
   sanity checks of ARRAY-Length
   ----------------------------------------------------------------------------
 */

#if  DEM_DTC_ORIGIN_PRIMARY_MEMORY >= DEM_EVMEMGEN_OVERFLOW_ARRAYSIZE
#error "Declarations of DTC-Origins does not match the array size of the Overflow Flag Array"
#endif
#if  DEM_DTC_ORIGIN_MIRROR_MEMORY >= DEM_EVMEMGEN_OVERFLOW_ARRAYSIZE
#error "Declarations of DTC-Origins does not match the array size of the Overflow Flag Array"
#endif
#if  DEM_DTC_ORIGIN_PERMANENT_MEMORY >= DEM_EVMEMGEN_OVERFLOW_ARRAYSIZE
#error "Declarations of DTC-Origins does not match the array size of the Overflow Flag Array"
#endif
#if  DEM_DTC_ORIGIN_SECONDARY_MEMORY >= DEM_EVMEMGEN_OVERFLOW_ARRAYSIZE
#error "Declarations of DTC-Origins does not match the array size of the Overflow Flag Array"
#endif

#if  DEM_FIRST_FAILED_DTC >= DEM_EVMEMGEN_DTCIDS_BY_OCCURRENCE_TIME_ARRAYSIZE
#error "Declarations of DTC-Requests does not match the array size of the DTC Occurrence Array"
#endif
#if  DEM_MOST_RECENT_FAILED_DTC >= DEM_EVMEMGEN_DTCIDS_BY_OCCURRENCE_TIME_ARRAYSIZE
#error "Declarations of DTC-Requests does not match the array size of the DTC Occurrence Array"
#endif
#if  DEM_FIRST_DET_CONFIRMED_DTC >= DEM_EVMEMGEN_DTCIDS_BY_OCCURRENCE_TIME_ARRAYSIZE
#error "Declarations of DTC-Requests does not match the array size of the DTC Occurrence Array"
#endif
#if  DEM_MOST_REC_DET_CONFIRMED_DTC >= DEM_EVMEMGEN_DTCIDS_BY_OCCURRENCE_TIME_ARRAYSIZE
#error "Declarations of DTC-Requests does not match the array size of the DTC Occurrence Array"
#endif

#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 0     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     10.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 0     22.10.2013 AMN2KOR
*   CSCRM00547887
* 
* AR40.6.0.0; 0     21.03.2013 UDKOEGEL
*   CSCRM00388895
*   [DEM] Implement API service Dem_GetEventMemoryOverflow and 
*   Dem_GetDTCByOccurrenceTime
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
