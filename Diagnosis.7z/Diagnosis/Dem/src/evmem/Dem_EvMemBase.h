/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_EvMemBase$
* $Variant___:AR40.11.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_EVMEMBASE_H
#define DEM_EVMEMBASE_H

#include "Dem_Helpers.h"
#include "Dem_Events.h"
#include "Dem_ISO14229Byte.h"
#include "Dem_OperationCycle.h"
#include "Dem_Nvm.h"
#include "Dem_EvMemTypes.h"
#include "Dem_EnvTrigger.h"
#include "Dem_Cfg_EnvDataElement.h"
#include "Dem_Deb.h"
#include "Dem_EvBuffEvent.h"
#include "Dem_Lib.h"



typedef uint8 Dem_EvMemActionType;
#define DEM_EVMEM_ACTIONTYPE_CONFIRMATION   1
#define DEM_EVMEM_ACTIONTYPE_DISPLACEMENT   2
#define DEM_EVMEM_ACTIONTYPE_AGING          3
#define DEM_EVMEM_ACTIONTYPE_NONE           4
#define DEM_EVMEM_ACTIONTYPE_SETPENDING     5
#define DEM_EVMEM_ACTIONTYPE_RESETPENDING   6
#define DEM_EVMEM_ACTIONTYPE_IMMEDIATEAGING 7
#define DEM_EVMEM_ACTIONTYPE_AGINGOFCONFIRMED   8




/* ----------------------------------------------------------------------------
   Functions
   ----------------------------------------------------------------------------
*/
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
uint32       Dem_EvMemGetNewEventMemoryTimeId(uint16_least MemId);
void         Dem_EvMemCopyToMirrorMemory(uint16_least LocId);
void         Dem_EvMemForceClearEventMemoryLocation(uint16_least LocId, uint16_least WriteSts, Dem_EvMemActionType actionType);
uint16_least Dem_EvMemGetEventMemoryStorageLocation (Dem_EventIdType EventId, Dem_EvBuffEventType EventType, uint16_least MemId, Dem_boolean_least isDisplacementSupported, uint16_least displacementStrategy);
uint16_least Dem_EvMemGetMirrorMemoryStorageLocation(Dem_EventIdType EventId, uint16_least MemId, Dem_boolean_least isDisplacementSupported, uint16_least displacementStrategy);

#if (DEM_CFG_EVMEM_MEMORY_DISPLACEMENT_STRATEGY == DEM_CFG_EVMEM_DISPLACEMENT_STRATEGY_CUST) || (DEM_CFG_EVMEM_MIRROR_DISPLACEMENT_STRATEGY == DEM_CFG_EVMEM_DISPLACEMENT_STRATEGY_CUST)
uint16       Dem_EvMemGetEventMemoryDisplacementLocationCust(Dem_EventIdType EventId, Dem_EvBuffEventType EventType, uint16 MemId);
#endif

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"



/* ----------------------------------------------------------------------------
   Macros
   ----------------------------------------------------------------------------
*/

#define DEM_EVMEM_CLEAROBJ(obj)             DEM_MEMSET(&(obj),0,DEM_SIZEOF_VAR(obj))

#define DEM_EVMEM_BOOL2DEC(b)               ( (b) ? 1u : 0u )

#define DEM_EVMEM_USEVAR(var)               (void)(var)

/* ----------------------------------------------------------------------------
   Data
   ----------------------------------------------------------------------------
*/
#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
DEM_ARRAY_DECLARE_CONST(Dem_NvmIdType,      Dem_EvMemNvmId,       DEM_CFG_MAX_NUMBER_EVENT_ENTRY_ALL);
#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"
DEM_ARRAY_DECLARE(Dem_EvMemStorageType,     Dem_EvMemStorage,     DEM_CFG_MAX_NUMBER_EVENT_ENTRY_ALL);
#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"
DEM_ARRAY_DECLARE(Dem_EvMemEventMemoryType, Dem_EvMemEventMemory, DEM_CFG_MAX_NUMBER_EVENT_ENTRY_ALL);
#define DEM_STOP_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
DEM_ARRAY_DECLARE_CONST(uint16_least,       Dem_EvMemLocIdList,   DEM_CFG_EVMEM_MAX_MEMS+1u);
#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"


/* ----------------------------------------------------------------------------
   Inline
   ----------------------------------------------------------------------------
*/

DEM_INLINE Dem_boolean_least Dem_EvMemIsMemIdValid(uint16_least MemId)
{
    return (Dem_boolean_least)(MemId < DEM_CFG_EVMEM_MAX_MEMS);
}

/* ----------------------------------------------------------------------------
   Event Memory Data
   ----------------------------------------------------------------------------
*/
DEM_INLINE Dem_boolean_least Dem_EvMemIsEventMemLocIdValid(uint16_least LocId)
{
    return (Dem_boolean_least)(LocId < DEM_CFG_MAX_NUMBER_EVENT_ENTRY_ALL);
}

/* --- Status --- */
DEM_INLINE uint16_least Dem_EvMemGetEventMemStatusByPtr(const Dem_EvMemEventMemoryType *EventMemory)
{
    return EventMemory->Hdr.Data.Status;
}

DEM_INLINE uint16_least Dem_EvMemGetEventMemStatus(uint16_least LocId)
{
    return Dem_EvMemGetEventMemStatusByPtr(&Dem_EvMemEventMemory[LocId]);
}


DEM_INLINE void Dem_EvMemSetEventMemStatus(uint16_least LocId, uint16_least Status)
{
    Dem_EvMemEventMemory[LocId].Hdr.Data.Status = (uint16)Status;
}


/* --- EventId --- */
DEM_INLINE Dem_EventIdType Dem_EvMemGetEventMemEventIdByPtr(const Dem_EvMemEventMemoryType *EventMemory)
{
    return EventMemory->Hdr.Data.EventId;
}

DEM_INLINE Dem_EventIdType Dem_EvMemGetEventMemEventId(uint16_least LocId)
{
    return Dem_EvMemGetEventMemEventIdByPtr(&Dem_EvMemEventMemory[LocId]);
}


DEM_INLINE void Dem_EvMemSetEventMemEventId(uint16_least LocId, Dem_EventIdType EventId)
{
    Dem_EvMemEventMemory[LocId].Hdr.Data.EventId = (uint16)EventId;
}


/* --- TimeId --- */
DEM_INLINE uint32 Dem_EvMemGetEventMemTimeIdByPtr(const Dem_EvMemEventMemoryType *EventMemory)
{
    return EventMemory->TimeId;
}

DEM_INLINE uint32 Dem_EvMemGetEventMemTimeId(uint16_least LocId)
{
    return Dem_EvMemGetEventMemTimeIdByPtr(&Dem_EvMemEventMemory[LocId]);
}


DEM_INLINE void Dem_EvMemSetEventMemTimeId(uint16_least LocId, uint32 TimeId)
{
    Dem_EvMemEventMemory[LocId].TimeId = TimeId;
}


/* --- DTC Status --- */
DEM_INLINE uint8 Dem_EvMemGetEventMemDtcStatusByPtr(const Dem_EvMemEventMemoryType *EventMemory)
{
    DEM_EVMEM_USEVAR(EventMemory);

#if (DEM_CFG_EVMEM_MIRROR_MEMORY_DTC_STATUS_STORED)
    return EventMemory->DTCStatus;
#else
    return 0;
#endif
}

DEM_INLINE uint8 Dem_EvMemGetEventMemDtcStatus(uint16_least LocId)
{
    return Dem_EvMemGetEventMemDtcStatusByPtr(&Dem_EvMemEventMemory[LocId]);
}


DEM_INLINE void Dem_EvMemSetEventMemDtcStatus(uint16_least LocId, uint8 DtcStatus)
{
    DEM_EVMEM_USEVAR(LocId);
    DEM_EVMEM_USEVAR(DtcStatus);

#if (DEM_CFG_EVMEM_MIRROR_MEMORY_DTC_STATUS_STORED)
    Dem_EvMemEventMemory[LocId].DTCStatus = DtcStatus;
#endif
}

/* --- FailureCounter --- */
DEM_INLINE uint8_least Dem_EvMemGetEventMemFailureCounterByPtr(const Dem_EvMemEventMemoryType *EventMemory)
{
    DEM_EVMEM_USEVAR(EventMemory);

#if (DEM_CFG_EVMEM_FAILURE_COUNTER_SUPPORTED)
    return EventMemory->FailureCounter;
#else
    return 0;
#endif
}

DEM_INLINE uint8_least Dem_EvMemGetEventMemFailureCounter(uint16_least LocId)
{
    return Dem_EvMemGetEventMemFailureCounterByPtr(&Dem_EvMemEventMemory[LocId]);
}


DEM_INLINE void Dem_EvMemSetEventMemFailureCounter(uint16_least LocId, uint16_least FailureCounter)
{
    DEM_EVMEM_USEVAR(LocId);
    DEM_EVMEM_USEVAR(FailureCounter);

#if (DEM_CFG_EVMEM_FAILURE_COUNTER_SUPPORTED)
    Dem_EvMemEventMemory[LocId].FailureCounter = (uint8) FailureCounter;
#endif
}

/* --- OccurrenceCounter --- */
DEM_INLINE uint16_least Dem_EvMemGetEventMemOccurrenceCounterByPtr(const Dem_EvMemEventMemoryType *EventMemory)
{
    DEM_EVMEM_USEVAR(EventMemory);

#if (DEM_CFG_EVMEM_OCCURRENCE_COUNTER_SUPPORTED)
    return (uint16_least)EventMemory->OccurrenceCounter;
#else
    return 0;
#endif
}

DEM_INLINE uint16_least Dem_EvMemGetEventMemOccurrenceCounter(uint16_least LocId)
{
    return Dem_EvMemGetEventMemOccurrenceCounterByPtr(&Dem_EvMemEventMemory[LocId]);
}


DEM_INLINE void Dem_EvMemSetEventMemOccurrenceCounter(uint16_least LocId, uint16_least OccurrenceCounter)
{
    DEM_EVMEM_USEVAR(LocId);
    DEM_EVMEM_USEVAR(OccurrenceCounter);

#if (DEM_CFG_EVMEM_OCCURRENCE_COUNTER_SUPPORTED)
    Dem_EvMemEventMemory[LocId].OccurrenceCounter = (Dem_EvMemOccurrenceCounterType) OccurrenceCounter;
#endif
}

/* --- AgingCounter --- */
DEM_INLINE uint16_least Dem_EvMemGetEventMemAgingCounterByPtr(const Dem_EvMemEventMemoryType *EventMemory)
{
   DEM_EVMEM_USEVAR(EventMemory);

#if (DEM_CFG_EVMEM_AGING_COUNTER_SUPPORTED)
      return (uint16_least)EventMemory->AgingCounter;
#else
    return 0;
#endif
}

DEM_INLINE uint16_least Dem_EvMemGetEventMemAgingCounter(uint16_least LocId)
{
   return Dem_EvMemGetEventMemAgingCounterByPtr(&Dem_EvMemEventMemory[LocId]);

}

DEM_INLINE void Dem_EvMemSetEventMemAgingCounter(uint16_least LocId, uint16_least AgingCounter)
{
    DEM_EVMEM_USEVAR(LocId);
    DEM_EVMEM_USEVAR(AgingCounter);

#if (DEM_CFG_EVMEM_AGING_COUNTER_SUPPORTED)
    Dem_EvMemEventMemory[LocId].AgingCounter = (Dem_EvMemAgingCounterType) AgingCounter;
#endif
}

/* --- AgingCounterForTFSLC --- */
DEM_INLINE uint16_least Dem_EvMemGetEventMemAgingCounterForTFSLCByPtr(const Dem_EvMemEventMemoryType *EventMemory)
{
   DEM_EVMEM_USEVAR(EventMemory);

#if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)
      return (uint16_least)EventMemory->AgingCounterForTFSLC;
#else
    return 0;
#endif
}

DEM_INLINE uint16_least Dem_EvMemGetEventMemAgingCounterForTFSLC(uint16_least LocId)
{
   return Dem_EvMemGetEventMemAgingCounterForTFSLCByPtr(&Dem_EvMemEventMemory[LocId]);

}

DEM_INLINE void Dem_EvMemSetEventMemAgingCounterForTFSLC(uint16_least LocId, uint16_least AgingCounterForTFSLC)
{
    DEM_EVMEM_USEVAR(LocId);
    DEM_EVMEM_USEVAR(AgingCounterForTFSLC);

#if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)
    Dem_EvMemEventMemory[LocId].AgingCounterForTFSLC = (Dem_EvMemAgingCounterType) AgingCounterForTFSLC;
#endif
}

/* --- Debouncer-Info: MaxFdcCurrentCycle / MaxFdcSinceLastClear --- */

/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is depending on compiler switch setting */
DEM_INLINE void Dem_EvMemSetMaxFdcDuringCurrentCycleByPtr(Dem_EvMemEventMemoryType *EventMemory, sint8 fdc)
{
    DEM_EVMEM_USEVAR(EventMemory);
    DEM_EVMEM_USEVAR(fdc);

#if (DEM_CFG_READDEM_MAX_FDC_DURING_CURRENT_CYCLE_SUPPORTED)
	EventMemory->MaxFdcDuringCurrentCycle = fdc;
#endif
}

/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is depending on compiler switch setting */
DEM_INLINE void Dem_EvMemSetMaxFdcSinceLastClearByPtr(Dem_EvMemEventMemoryType *EventMemory, sint8 fdc)
{
    DEM_EVMEM_USEVAR(EventMemory);
    DEM_EVMEM_USEVAR(fdc);

#if (DEM_CFG_READDEM_MAX_FDC_SINCE_LAST_CLEAR_SUPPORTED)
	EventMemory->MaxFdcSinceLastClear = fdc;
#endif
}


DEM_INLINE sint8 Dem_EvMemGetMaxFdcDuringCurrentCycleByPtr(const Dem_EvMemEventMemoryType *EventMemory)
{
    DEM_EVMEM_USEVAR(EventMemory);

#if (DEM_CFG_READDEM_MAX_FDC_DURING_CURRENT_CYCLE_SUPPORTED)
	return EventMemory->MaxFdcDuringCurrentCycle;
#else
	return 0;
#endif
}

DEM_INLINE sint8 Dem_EvMemGetMaxFdcSinceLastClearByPtr(const Dem_EvMemEventMemoryType *EventMemory)
{
    DEM_EVMEM_USEVAR(EventMemory);

#if (DEM_CFG_READDEM_MAX_FDC_SINCE_LAST_CLEAR_SUPPORTED)
	return EventMemory->MaxFdcSinceLastClear;
#else
   	return 0;
#endif
}

DEM_INLINE void Dem_EvMemSetMaxFdcDuringCurrentCycle(uint16_least LocId, sint8 fdc)
{
	Dem_EvMemSetMaxFdcDuringCurrentCycleByPtr(&(Dem_EvMemEventMemory[LocId]), fdc);
}

DEM_INLINE void Dem_EvMemSetMaxFdcSinceLastClear(uint16_least LocId, sint8 fdc)
{
	Dem_EvMemSetMaxFdcSinceLastClearByPtr(&(Dem_EvMemEventMemory[LocId]), fdc);
}


DEM_INLINE sint8 Dem_EvMemGetMaxFdcDuringCurrentCycle(uint16_least LocId)
{
    return Dem_EvMemGetMaxFdcDuringCurrentCycleByPtr (&(Dem_EvMemEventMemory[LocId]));
}

DEM_INLINE sint8 Dem_EvMemGetMaxFdcSinceLastClear(uint16_least LocId)
{
	return Dem_EvMemGetMaxFdcSinceLastClearByPtr (&(Dem_EvMemEventMemory[LocId]));
}



/* --- Cycle-Info: CyclesSinceFirstFailed / CyclesSinceLastFailed  / FailedCycles --- */
DEM_INLINE uint8 Dem_EvMemGetCyclesSinceFirstFailedByPtr(const Dem_EvMemEventMemoryType *EventMemory)
{
#if (DEM_CFG_READDEM_CYCLES_SINCE_FIRST_FAILED_SUPPORTED)
	return EventMemory->CyclesSinceFirstFailed;
#else
	DEM_UNUSED_PARAM(EventMemory);
   	return 0;
#endif
}

DEM_INLINE uint8 Dem_EvMemGetCyclesSinceLastFailedByPtr(const Dem_EvMemEventMemoryType *EventMemory)
{
#if (DEM_CFG_READDEM_CYCLES_SINCE_LAST_FAILED_SUPPORTED)
	return EventMemory->CyclesSinceLastFailed;
#else
	DEM_UNUSED_PARAM(EventMemory);
	return 0;
#endif
}

DEM_INLINE uint8 Dem_EvMemGetCyclesSinceLastFailedExcludingTNCByPtr(const Dem_EvMemEventMemoryType *EventMemory)
{
#if (DEM_CFG_READDEM_CYCLES_SINCE_LAST_FAILED_EXCLUDING_TNC_SUPPORTED)
   	return EventMemory->CyclesSinceLastFailedExcludingTNC;
#else
	DEM_UNUSED_PARAM(EventMemory);
	return 0;
#endif
}

DEM_INLINE uint8 Dem_EvMemGetFailedCyclesByPtr(const Dem_EvMemEventMemoryType *EventMemory)
{
#if (DEM_CFG_READDEM_FAILED_CYCLES_SUPPORTED)
	return EventMemory->FailedCycles;
#else
	DEM_UNUSED_PARAM(EventMemory);
	return 0;
#endif
}

DEM_INLINE void Dem_EvMemIncCyclesSinceFirstFailed(uint16_least LocId)
{
#if (DEM_CFG_READDEM_CYCLES_SINCE_FIRST_FAILED_SUPPORTED)
	if(Dem_EvMemEventMemory[LocId].CyclesSinceFirstFailed != 255)
	{
		Dem_EvMemEventMemory[LocId].CyclesSinceFirstFailed++;
	}
#else
	DEM_UNUSED_PARAM(LocId);
#endif
}

DEM_INLINE void Dem_EvMemIncCyclesSinceLastFailed(uint16_least LocId)
{
#if (DEM_CFG_READDEM_CYCLES_SINCE_LAST_FAILED_SUPPORTED)
	if(Dem_EvMemEventMemory[LocId].CyclesSinceLastFailed != 255)
	{
		Dem_EvMemEventMemory[LocId].CyclesSinceLastFailed++;
	}
#else
	DEM_UNUSED_PARAM(LocId);
#endif
}

DEM_INLINE void Dem_EvMemIncCyclesSinceLastFailedExcludingTNC(uint16_least LocId)
{
#if (DEM_CFG_READDEM_CYCLES_SINCE_LAST_FAILED_EXCLUDING_TNC_SUPPORTED)
	if(Dem_EvMemEventMemory[LocId].CyclesSinceLastFailedExcludingTNC != 255)
	{
		Dem_EvMemEventMemory[LocId].CyclesSinceLastFailedExcludingTNC++;
	}
#else
	DEM_UNUSED_PARAM(LocId);
#endif
}

DEM_INLINE void Dem_EvMemIncFailedCycles(uint16_least LocId)
{
#if (DEM_CFG_READDEM_FAILED_CYCLES_SUPPORTED)
	if(Dem_EvMemEventMemory[LocId].FailedCycles != 255)
	{
		Dem_EvMemEventMemory[LocId].FailedCycles++;
	}
#else
	DEM_UNUSED_PARAM(LocId);
#endif
}

DEM_INLINE void Dem_EvMemResetCyclesSinceLastFailed(uint16_least LocId)
{
#if (DEM_CFG_READDEM_CYCLES_SINCE_LAST_FAILED_SUPPORTED)
	Dem_EvMemEventMemory[LocId].CyclesSinceLastFailed = 0;
#else
	DEM_UNUSED_PARAM(LocId);
#endif
}

DEM_INLINE void Dem_EvMemResetCyclesSinceLastFailedExcludingTNC(uint16_least LocId)
{
#if (DEM_CFG_READDEM_CYCLES_SINCE_LAST_FAILED_EXCLUDING_TNC_SUPPORTED)
   	Dem_EvMemEventMemory[LocId].CyclesSinceLastFailedExcludingTNC = 0;
#else
	DEM_UNUSED_PARAM(LocId);
#endif
}

/* --- FreezeFrameCounter --- */
DEM_INLINE uint16_least Dem_EvMemGetEventMemFreezeFrameCounterByPtr(const Dem_EvMemEventMemoryType *EventMemory)
{
   DEM_EVMEM_USEVAR(EventMemory);

#if (DEM_CFG_EVMEM_FREEZE_FRAME_SUPPORTED)
   return (uint16_least)EventMemory->FreezeFrameCounter;
#else
   return 0;
#endif

}

DEM_INLINE uint16_least Dem_EvMemGetEventMemFreezeFrameCounter(uint16_least LocId)
{
   return Dem_EvMemGetEventMemFreezeFrameCounterByPtr(&Dem_EvMemEventMemory[LocId]);
}



DEM_INLINE void Dem_EvMemSetEventMemLocFreezeFrameCounter(uint16_least LocId, uint16_least FreezeFrameCounter)
{
   DEM_EVMEM_USEVAR(LocId);
   DEM_EVMEM_USEVAR(FreezeFrameCounter);

#if (DEM_CFG_EVMEM_FREEZE_FRAME_SUPPORTED)
   Dem_EvMemEventMemory[LocId].FreezeFrameCounter = (uint8)FreezeFrameCounter;
#endif
}


/* --- Extended Data Trigger --- */
DEM_INLINE Dem_TriggerType Dem_EvMemGetEventMemTriggerByPtr(const Dem_EvMemEventMemoryType *EventMemory)
{
   DEM_EVMEM_USEVAR(EventMemory);

#if (DEM_CFG_EVMEM_EXTENDED_DATA_SUPPORTED)
   return EventMemory->Trigger;
#else
   return 0;
#endif

}

DEM_INLINE Dem_TriggerType Dem_EvMemGetEventMemTrigger(uint16_least LocId)
{
   return Dem_EvMemGetEventMemTriggerByPtr(&Dem_EvMemEventMemory[LocId]);
}

DEM_INLINE void Dem_EvMemSetEventMemTrigger(uint16_least LocId, Dem_TriggerType Trigger)
{
   DEM_EVMEM_USEVAR(LocId);
   DEM_EVMEM_USEVAR(Trigger);

#if (DEM_CFG_EVMEM_EXTENDED_DATA_SUPPORTED)
   Dem_EvMemEventMemory[LocId].Trigger = Trigger;
#endif
}

/* --- Data --- */
/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is used to get address of element data and to fill the data block */
DEM_INLINE uint8 *Dem_EvMemGetEventMemDataByPtr(Dem_EvMemEventMemoryType *EventMemory)
{
   return EventMemory->Data;
}

DEM_INLINE uint8 *Dem_EvMemGetEventMemData(uint16_least LocId)
{
   return Dem_EvMemGetEventMemDataByPtr(&Dem_EvMemEventMemory[LocId]);
}

DEM_INLINE Dem_EvMemEventMemoryType *Dem_EvMemGetEventMemLocation(uint16_least LocId)
{
   return (&Dem_EvMemEventMemory[LocId]);
}

DEM_INLINE uint16 Dem_EvMemGetEventMemDataSize(void)
{
   return DEM_SIZEOF_VAR(Dem_EvMemEventMemory[0].Data);
}

/* ----------------------------------------------------------------------------
   Event Memory Status
   ----------------------------------------------------------------------------
*/
/* the bits DEM_EVMEM_STSMASK_STORED and DEM_EVMEM_STSMASK_DELETED shall not be set at the same time */

DEM_INLINE Dem_boolean_least Dem_EvMemIsTestFailedSLC(uint16_least Status)
{
   return (Dem_boolean_least)((Status & (DEM_EVMEM_STSMASK_TESTFAILED_SLC | DEM_EVMEM_STSMASK_STORED)) == (DEM_EVMEM_STSMASK_TESTFAILED_SLC | DEM_EVMEM_STSMASK_STORED));
}

DEM_INLINE Dem_boolean_least Dem_EvMemIsStored(uint16_least Status)
{
   return (Dem_boolean_least)((Status & (DEM_EVMEM_STSMASK_STORED | DEM_EVMEM_STSMASK_DELETED)) == DEM_EVMEM_STSMASK_STORED);
}

DEM_INLINE Dem_boolean_least Dem_EvMemIsEmpty(uint16_least Status)
{
   return (Dem_boolean_least)((Status & (DEM_EVMEM_STSMASK_STORED | DEM_EVMEM_STSMASK_DELETED)) == 0u);
}

DEM_INLINE Dem_boolean_least Dem_EvMemIsDeleted(uint16_least Status)
{
   DEM_EVMEM_USEVAR(Status);

#if DEM_CFG_EVMEM_SHADOW_ENTRIES_SUPPORTED
   return (Dem_boolean_least)((Status & DEM_EVMEM_STSMASK_DELETED) != 0u);
#else
   return FALSE;
#endif
}
DEM_INLINE uint16_least Dem_EvMemSetToEmpty(void)
{
	return 0u;
}

DEM_INLINE uint16_least Dem_EvMemSetToDelete(uint16_least Status)
{
	DEM_EVMEM_USEVAR(Status);

#if DEM_CFG_EVMEM_SHADOW_ENTRIES_SUPPORTED
	return (Status | DEM_EVMEM_STSMASK_DELETED) & (~DEM_EVMEM_STSMASK_STORED);
#else
    return Dem_EvMemSetToEmpty();
#endif
}

DEM_INLINE Dem_boolean_least Dem_EvMemGetShadowVisibility(void)
{
	return DEM_CFG_EVMEM_SHADOW_ENTRIES_VISIBLE;
}

DEM_INLINE Dem_boolean_least Dem_EvMemIsVisible(uint16_least Status, Dem_boolean_least ShadowEntriesVisible)
{
	return (Dem_boolean_least)( ( Dem_EvMemIsStored(Status)) ||
			                    (!Dem_EvMemIsEmpty (Status) && Dem_EvMemGetShadowVisibility() && ShadowEntriesVisible));
}

/* ----------------------------------------------------------------------------
   Event Memory Iterators
   ----------------------------------------------------------------------------
*/


DEM_INLINE uint16_least Dem_EvMemGetEventMemStartLocId(uint16_least MemId)
{

	DEM_EVMEM_USEVAR(MemId);

#if (DEM_CFG_EVMEM_MAX_MEMS == 1)
	return 0;
#else
	return Dem_EvMemLocIdList[MemId];
#endif
}

DEM_INLINE uint16_least Dem_EvMemGetEventMemEndLocId(uint16_least MemId)
{
	DEM_EVMEM_USEVAR(MemId);

#if (DEM_CFG_EVMEM_MAX_MEMS == 1)
	return DEM_CFG_MAX_NUMBER_EVENT_ENTRY_PRIMARY;
#else
	return Dem_EvMemLocIdList[MemId+1u];
#endif
}


DEM_INLINE void Dem_EvMemEventMemoryLocIteratorNew (uint16_least *LocId, uint16_least MemId)
{
    *LocId = Dem_EvMemGetEventMemStartLocId(MemId);
}


DEM_INLINE Dem_boolean_least Dem_EvMemEventMemoryLocIteratorIsValid (const uint16_least *LocId, uint16_least MemId)
{
    return (Dem_boolean_least)(*LocId < Dem_EvMemGetEventMemEndLocId(MemId));
}


DEM_INLINE void Dem_EvMemEventMemoryLocIteratorNext (uint16_least *LocId, uint16_least MemId)
{
    DEM_EVMEM_USEVAR(MemId);
    (*LocId)++;
}

DEM_INLINE void Dem_EvMemEventMemoryLocIteratorInvalidate (uint16_least *LocId, uint16_least MemId)
{
    *LocId = Dem_EvMemGetEventMemEndLocId(MemId);
}


DEM_INLINE void Dem_EvMemEventMemoryIteratorNew(uint16_least *MemId)
{
	*MemId = 0;
}

DEM_INLINE Dem_boolean_least Dem_EvMemEventMemoryIteratorIsValid(const uint16_least *MemId)
{
	return (Dem_boolean_least) (*MemId < DEM_CFG_EVMEM_MAX_MEMS);
}

DEM_INLINE void Dem_EvMemEventMemoryIteratorNext(uint16_least *MemId)
{
	(*MemId)++;
}

DEM_INLINE void Dem_EvMemEventMemoryAllLocIteratorNew (uint16_least *LocId)
{
    *LocId = 0;
}

DEM_INLINE Dem_boolean_least Dem_EvMemEventMemoryAllLocIteratorIsValid (const uint16_least *LocId)
{
    return (Dem_boolean_least)(*LocId < DEM_CFG_MAX_NUMBER_EVENT_ENTRY_ALL);
}

DEM_INLINE void Dem_EvMemEventMemoryAllLocIteratorNext (uint16_least *LocId)
{
    (*LocId)++;
}

DEM_INLINE Dem_boolean_least Dem_EvMemIsOriginPrimary (uint16_least LocId)
{
   return (Dem_boolean_least) (LocId < DEM_CFG_MAX_NUMBER_EVENT_ENTRY_PRIMARY);
}

DEM_INLINE Dem_boolean_least Dem_EvMemIsOriginSecondary (uint16_least LocId)
{
   return (Dem_boolean_least) ((LocId >=  DEM_CFG_MAX_NUMBER_EVENT_ENTRY_PRIMARY) &&
                               (LocId <  (DEM_CFG_MAX_NUMBER_EVENT_ENTRY_PRIMARY + DEM_CFG_MAX_NUMBER_EVENT_ENTRY_SECONDARY)));
}

DEM_INLINE Dem_boolean_least Dem_EvMemIsOriginMirror (uint16_least LocId)
{
   return (Dem_boolean_least) ((LocId >=  (DEM_CFG_MAX_NUMBER_EVENT_ENTRY_PRIMARY + DEM_CFG_MAX_NUMBER_EVENT_ENTRY_SECONDARY)) &&
                               (LocId <    DEM_CFG_MAX_NUMBER_EVENT_ENTRY_ALL));
}

/* ----------------------------------------------------------------------------
   Storage State
   ----------------------------------------------------------------------------
*/

DEM_INLINE void Dem_EvMemSetStorageStateImmediate(uint16_least LocId)
{
	Dem_EvMemStorage[LocId].state = DEM_EVMEM_STORAGESTATE_WRITE_IMMEDIATE;
}


DEM_INLINE void Dem_EvMemSetStorageStateShutdown(uint16_least LocId)
{
    Dem_EvMemStorage[LocId].state = DEM_EVMEM_STORAGESTATE_WRITE_SHUTDOWN;
}

DEM_INLINE void Dem_EvMemResetStorageState(uint16_least LocId)
{
	Dem_EvMemStorage[LocId].state = DEM_EVMEM_STORAGESTATE_WRITE_IDLE;
}

DEM_INLINE Dem_boolean_least Dem_EvMemIsStorageStateImmediate(uint16_least LocId)
{
	return (Dem_boolean_least)(Dem_EvMemStorage[LocId].state == DEM_EVMEM_STORAGESTATE_WRITE_IMMEDIATE);
}

DEM_INLINE Dem_boolean_least Dem_EvMemIsStorageStateShutdown(uint16_least LocId)
{
	return (Dem_boolean_least)(Dem_EvMemStorage[LocId].state == DEM_EVMEM_STORAGESTATE_WRITE_SHUTDOWN);
}

DEM_INLINE Dem_boolean_least Dem_EvMemIsStorageStateIdle(uint16_least LocId)
{
	return (Dem_boolean_least)(Dem_EvMemStorage[LocId].state == DEM_EVMEM_STORAGESTATE_WRITE_IDLE);
}


/* ----------------------------------------------------------------------------
   Helper
   ----------------------------------------------------------------------------
*/

DEM_INLINE Dem_boolean_least Dem_EvMemIsEdgeTrigger(uint16_least StatusOld, uint16_least StatusNew, uint16_least Trigger)
{
	return (Dem_boolean_least) (((StatusOld ^ StatusNew) & Trigger) != 0u);
}

DEM_INLINE uint16_least Dem_EvMemGetEventMemId(uint16_least LocId)
{
	uint16_least MemId;

	for (Dem_EvMemEventMemoryIteratorNew     (&MemId);
		 Dem_EvMemEventMemoryIteratorIsValid (&MemId);
		 Dem_EvMemEventMemoryIteratorNext    (&MemId))
	{
		if (LocId < Dem_EvMemGetEventMemEndLocId (MemId))
		{
			return MemId;
		}
	}
	/* should only be reached in case of an invalid LocId */
	DEM_ASSERT(FALSE,DEM_DET_APIID_DEM_EVMEMGETEVENTMEMID,0);
	return DEM_EVMEM_INVALID_MEMID;

}

/* ----------------------------------------------------------------------------
   Functions
   ----------------------------------------------------------------------------
*/

DEM_INLINE Dem_boolean_least Dem_EvMemIsDisplaceEventMemoryLocAllowed(Dem_EventIdType NewEventId, uint16_least LocId)
{
   DEM_EVMEM_USEVAR(NewEventId);
   DEM_EVMEM_USEVAR(LocId);

   return TRUE;
}


DEM_INLINE Dem_boolean_least Dem_EvMemIsEventFailedAllowed(Dem_EventIdType EventId, uint16_least MemId)
{
   DEM_EVMEM_USEVAR(EventId);
   DEM_EVMEM_USEVAR(MemId);

   return(TRUE);
}


DEM_INLINE Dem_boolean_least Dem_EvMemIsEventPassedAllowed(Dem_EventIdType EventId, uint16_least MemId)
{
   DEM_EVMEM_USEVAR(EventId);
   DEM_EVMEM_USEVAR(MemId);

   return(TRUE);
}


DEM_INLINE Dem_boolean_least Dem_EvMemIsEventUnRobustAllowed(Dem_EventIdType EventId, uint16_least MemId)
{
   DEM_EVMEM_USEVAR(EventId);
   DEM_EVMEM_USEVAR(MemId);

   return(TRUE);
}

DEM_INLINE Dem_boolean_least Dem_EvMemIsEventMemoryDisplacementSupported(uint16_least MemId)
{
   DEM_EVMEM_USEVAR(MemId);

   return (Dem_boolean_least)(Dem_LibGetParamBool(DEM_CFG_EVMEM_DISPLACEMENT_SUPPORTED));
}


DEM_INLINE Dem_boolean_least Dem_EvMemIsTriggerOccurrenceCounter(Dem_EventIdType EventId, uint16_least MemId, uint16_least StatusOld, uint16_least StatusNew)
{
	DEM_EVMEM_USEVAR(EventId);
	DEM_EVMEM_USEVAR(MemId);

	/* occurrence counter is triggered if */
	/* 1. TestFailed changes from 0 to 1 */
	/* 2. static flags defined by DEM_CFG_EVMEM_OCCCOUNTER_TRIGGER_STSMASK are set */
	return Dem_EvMemIsEdgeTrigger (StatusOld, StatusNew, DEM_EVMEM_STSMASK_TESTFAILED) && ((StatusNew & DEM_CFG_EVMEM_OCCCOUNTER_TRIGGER_STSMASK) == DEM_CFG_EVMEM_OCCCOUNTER_TRIGGER_STSMASK);
}

DEM_INLINE Dem_TriggerType Dem_EvMemGetTriggerOnFailed(uint16_least StatusOld, uint16_least StatusNew)
{
	Dem_TriggerType Trigger;
	Trigger = DEM_TRIGGER_NONE;
	if (Dem_EvMemIsEdgeTrigger (StatusOld, StatusNew, DEM_EVMEM_STSMASK_TESTFAILED))
	{
		Dem_EnvSetTrigger(&Trigger, DEM_TRIGGER_ON_TEST_FAILED);
	}
	if (Dem_EvMemIsEdgeTrigger (StatusOld, StatusNew, DEM_EVMEM_STSMASK_PENDING))
	{
		Dem_EnvSetTrigger(&Trigger, DEM_TRIGGER_ON_PENDING);
	}
	if (Dem_EvMemIsEdgeTrigger (StatusOld, StatusNew, DEM_EVMEM_STSMASK_CONFIRMED))
	{
		Dem_EnvSetTrigger(&Trigger, DEM_TRIGGER_ON_CONFIRMED);
	}

	return Trigger;
}


DEM_INLINE Dem_TriggerType Dem_EvMemGetTriggerOnPassed(uint16_least StatusOld, uint16_least StatusNew)
{
	Dem_TriggerType Trigger;
	Trigger = DEM_TRIGGER_NONE;
	if (Dem_EvMemIsEdgeTrigger (StatusOld, StatusNew, DEM_EVMEM_STSMASK_TESTFAILED))
	{
		Dem_EnvSetTrigger(&Trigger, DEM_TRIGGER_ON_PASSED);
	}
	return Trigger;
}


DEM_INLINE Dem_boolean_least Dem_EvMemIsTriggerFreezeFrame(Dem_EventIdType EventId, uint16_least MemId, uint16_least StatusOld, uint16_least StatusNew)
{
   DEM_EVMEM_USEVAR(EventId);
   DEM_EVMEM_USEVAR(MemId);

   return Dem_EvMemIsEdgeTrigger(StatusOld, StatusNew, DEM_CFG_EVMEM_FREEZE_FRAME_TRIGGER_STSMASK);
}


/* ----------------------------------------------------------------------------
   Mirror Memory
   ----------------------------------------------------------------------------
*/
#if (DEM_CFG_EVMEM_MIRROR_MEMORY_SUPPORTED)


DEM_INLINE Dem_boolean_least Dem_EvMemIsTriggerMirrorOnFailed(Dem_EventIdType EventId, uint16_least MemId, uint16_least StatusOld, uint16_least StatusNew)
{
   DEM_EVMEM_USEVAR(EventId);
   DEM_EVMEM_USEVAR(MemId);

   return (Dem_boolean_least)(Dem_EvMemIsEdgeTrigger(StatusOld, StatusNew, DEM_EVMEM_STSMASK_TESTFAILED));
}


DEM_INLINE Dem_boolean_least Dem_EvMemIsTriggerMirrorOnClear(Dem_EventIdType EventId, uint16_least LocId, uint16_least StatusOld, uint16_least StatusNew)
{
   DEM_EVMEM_USEVAR(EventId);
   DEM_EVMEM_USEVAR(LocId);
   DEM_EVMEM_USEVAR(StatusOld);
   DEM_EVMEM_USEVAR(StatusNew);

   return (Dem_boolean_least)((StatusOld & DEM_EVMEM_STSMASK_CONFIRMED) != 0u);
}

#endif


/* ----------------------------------------------------------------------------
   NV-RAM Optimizations
   ----------------------------------------------------------------------------
*/

DEM_INLINE uint16_least Dem_EvMemGetRamStsMask(void)
{
   return DEM_CFG_EVMEM_RAM_STSMASK;
}

/* ----------------------------------------------------------------------------
   Helper Functions
   ----------------------------------------------------------------------------
*/

DEM_INLINE Dem_boolean_least Dem_EvMemIsEqualEvent(Dem_EventIdType EventId1, Dem_EventIdType EventId2)
{
   if (Dem_LibGetParamUI8(DEM_CFG_EVMEM_EVENTCOMBINATION) == Dem_LibGetParamUI8(DEM_CFG_EVMEM_EVENTCOMBINATION_TYPE1))
   {
        return (Dem_boolean_least)(Dem_DtcIdFromEventId(EventId1) == Dem_DtcIdFromEventId(EventId2));
   }
   else
   {
        return (Dem_boolean_least)(EventId1 == EventId2);
   }
}


DEM_INLINE Dem_boolean_least Dem_EvMemIsNvStatusChanged(Dem_EventIdType EventId, uint16_least StatusOld, uint16_least StatusNew)
{
   DEM_EVMEM_USEVAR(EventId);

   return (Dem_boolean_least)(Dem_EvMemIsEdgeTrigger(StatusOld, StatusNew, ~Dem_EvMemGetRamStsMask()));
}


/* ----------------------------------------------------------------------------
   Sanity Check
   ----------------------------------------------------------------------------
*/

#if (DEM_EVMEM_STSMASK_CONFIRMED != (1u << DEM_ISO14229_CONFIRMEDDTC))
   #error incompatible definition of ISO14229 status bit 'confirmedDtc'
#endif
#if (DEM_EVMEM_STSMASK_PENDING != (1u << DEM_ISO14229_PENDINGDTC))
   #error incompatible definition of ISO14229 status bit 'pendingDtc'
#endif


/* ----------------------------------------------------------------------------
   Include Protection
   ----------------------------------------------------------------------------
*/
#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 1     19.10.2015 TVE5COB
*   CSCRM00957961
* 
* AR40.11.0.0; 0     17.09.2015 UDKOEGEL
*   CSCRM00960004
* 
* AR40.10.0.0; 6     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 5     09.07.2015 RPV5COB
*   CSCRM00791814
* 
* AR40.10.0.0; 4     06.07.2015 VSA2COB
*   CSCRM00830308
* 
* AR40.10.0.0; 3     17.06.2015 TVE5COB
*   CSCRM00783642
* 
* AR40.10.0.0; 2     15.06.2015 UDKOEGEL
*   CSCRM00707801
* 
* AR40.10.0.0; 1     12.05.2015 CLH2SI
*   CSCRM00789099
* 
* AR40.10.0.0; 0     17.03.2015 TVE5COB
*   CSCRM00789300
* 
* AR40.9.0.0; 2     06.01.2015 GJ83ABT
*   CSCRM00751490
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
