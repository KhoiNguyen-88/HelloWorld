/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_EnvFFRecNumeration$
* $Variant___:AR40.8.0.0$
* $Revision__:2$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_ENVFFRECNUMERATION_H
#define DEM_ENVFFRECNUMERATION_H


#include "Dem_Types.h"
#include "Dem_Cfg_EnvFFRecNumeration.h"
#include "Dem_Events.h"


#if (DEM_CFG_FFRECNUM == DEM_CFG_FFRECNUM_CALCULATED)


DEM_INLINE Dem_boolean_least Dem_EnvIsFFRecNumValid(Dem_EventIdType EventId, uint8 RecNumber)
{
	return ((RecNumber > 0) && (RecNumber <= Dem_EvtGetMaxNumberOfFreezeFrames(EventId)));
}

DEM_INLINE uint8 Dem_EnvGetIndexFromFFRecNum(Dem_EventIdType EventId, uint8 RecNumber)
{
	DEM_UNUSED_PARAM(EventId);
	return (RecNumber - 1);
}


DEM_INLINE uint8 Dem_EnvGetFFRecNumFromIndex(Dem_EventIdType EventId, uint8 idx)
{
	DEM_UNUSED_PARAM(EventId);
	return (idx + 1);
}


#else

#define DEM_ENV_FFRECNUM_INDEX_INVALID   0xFF

#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
extern const uint8 Dem_Cfg_EnvFFRecNumConf[DEM_CFG_FFRECCLASS_NUMBEROF_FFRECCLASSES][DEM_CFG_FFRECCLASS_MAXNUMBEROF_FFFRECNUMS];
#if DEM_CFG_FFRECCLASS_NUMBEROF_FFRECCLASSES > 1
DEM_ARRAY_DECLARE_CONST(uint8, Dem_Cfg_EnvEventId2FrecNumClass, DEM_EVENTID_ARRAYLENGTH);
#endif
#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
uint8 Dem_EnvGetIndexOfFFRecConf(Dem_EventIdType EventId, uint8 RecNumber);
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


DEM_INLINE uint8 Dem_EnvGetFFRecNumClassIndex (Dem_EventIdType EventId)
{
#if DEM_CFG_FFRECCLASS_NUMBEROF_FFRECCLASSES > 1
	return Dem_Cfg_EnvEventId2FrecNumClass[EventId];
#else
	return 0;
#endif
}

DEM_INLINE Dem_boolean_least Dem_EnvIsFFRecNumValid(Dem_EventIdType EventId, uint8 RecNumber)
{
	uint8 RecNumberIndex;

	RecNumberIndex = Dem_EnvGetIndexOfFFRecConf(EventId,RecNumber);
	return (Dem_boolean_least)((RecNumber > 0) && (RecNumberIndex != DEM_ENV_FFRECNUM_INDEX_INVALID));
}

DEM_INLINE uint8 Dem_EnvGetIndexFromFFRecNum(Dem_EventIdType EventId, uint8 RecNumber)
{
	uint8 RecNumberIndex;

	RecNumberIndex = Dem_EnvGetIndexOfFFRecConf(EventId,RecNumber);
	DEM_ASSERT(RecNumberIndex != DEM_ENV_FFRECNUM_INDEX_INVALID,DEM_DET_APIID_ENVGETINDEXFROMFFRECNUM,0x0);
    return RecNumberIndex;
}


DEM_INLINE uint8 Dem_EnvGetFFRecNumFromIndex(Dem_EventIdType EventId, uint8 idx)
{
   DEM_ASSERT(idx < Dem_EvtGetMaxNumberOfFreezeFrames(EventId),DEM_DET_APIID_ENVGETFFRECNUMFROMINDEX,0x0);
   return Dem_Cfg_EnvFFRecNumConf [Dem_EnvGetFFRecNumClassIndex(EventId)][idx];
}

#endif
#endif
/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.8.0.0; 2     20.03.2014 CLH2SI
*   CSCRM00633913
* 
* AR40.8.0.0; 1     10.03.2014 VSA2COB
*   CSCRM00619537_ComassoChanges
* 
* AR40.8.0.0; 0     20.01.2014 UDKOEGEL
*   CSCRM00338832
* 
* AR40.7.0.0; 3     19.11.2013 BRM2COB
*   
* 
* AR40.7.0.0; 2     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 1     22.10.2013 AMN2KOR
*   CSCRM00547887
* 
* AR40.7.0.0; 0     21.08.2013 AMN2KOR
*   CSCRM00552368: [Int-Dem] Misc
* 
* AR40.5.0.0; 0     30.11.2012 KAN1COB
*   See: check in comment ofCOMP: DEM40.5_2012-11;5
* 
* AR40.4.0.0; 1     27.06.2012 BRM2COB
*   GIT to eASEE 27-06
* 
* AR40.4.0.0; 0     14.02.2012 CLH2SI
*   GIT-SYNC: a0008d733d3a94fa3e0a3e39260972344e821bef
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
