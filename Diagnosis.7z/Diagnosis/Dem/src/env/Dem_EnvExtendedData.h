/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_EnvExtendedData$
* $Variant___:AR40.8.0.0$
* $Revision__:3$
**********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_ENVEXTENDEDDATA_H
#define DEM_ENVEXTENDEDDATA_H

#include "Dem_Types.h"
#include "Dem_EnvExtendedDataRec.h"
#include "Dem_Cfg_EnvExtendedData.h"
#include "Dem_Cfg_Main.h"
#include "Dem_InternalEnvData.h"

typedef struct
{
	uint16 extDataRecIndex;
	uint16 rawByteSize;
} Dem_EnvExtData;
#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
extern const uint8 Dem_Cfg_EnvExtData2ExtDataRec[];
extern const Dem_EnvExtData Dem_Cfg_EnvExtData[DEM_CFG_ENVEXTDATA_ARRAYLENGTH];
#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

DEM_INLINE void Dem_EnvEDCapture(uint8 extDataId, uint8* buffer, uint16 size, const Dem_InternalEnvData* internalEnvData)
{
	uint16_least i;
	const uint8* end = &buffer[size];

	for (i = Dem_Cfg_EnvExtData[extDataId - 1].extDataRecIndex; i < Dem_Cfg_EnvExtData[extDataId].extDataRecIndex; i++)
	{
		Dem_EnvEDRCapture (Dem_Cfg_EnvExtData2ExtDataRec[i], &buffer, end, internalEnvData);
	}

#if (DEM_CFG_BUILDTARGET==DEM_CFG_BUILDTARGET_DEMTESTSUITE)
	DEM_MEMSET(&buffer,0xFF,end-buffer);
#endif
}

DEM_INLINE uint16 Dem_EnvEDGetRawByteSize(uint8 extDataId)
{
	return Dem_Cfg_EnvExtData[extDataId].rawByteSize;
}

DEM_INLINE void Dem_EnvEDCopyRaw(uint8 extDataId, uint8* dest, uint16 bufsize, const uint8* src, Dem_EnvTriggerParamType* triggerParam)
{
	uint16_least i;
	const uint8* end = dest + bufsize;

	for (i = Dem_Cfg_EnvExtData[extDataId - 1].extDataRecIndex; i < Dem_Cfg_EnvExtData[extDataId].extDataRecIndex; i++)
	{
		Dem_EnvEDRCopyRaw (Dem_Cfg_EnvExtData2ExtDataRec[i], &dest, end, &src, triggerParam);
	}
}

DEM_INLINE Dem_ReturnGetExtendedDataRecordByDTCType Dem_EnvEDRetrieveExtendedData(uint8 extDataId,
		uint8* dest,
		uint16* bufsize,
		const uint8* src,
		const Dem_InternalEnvData* internalEnvData)
{
	uint8* writepos = dest;
	uint8* end = dest + *bufsize;
	uint16_least i;

	for (i = Dem_Cfg_EnvExtData[extDataId - 1].extDataRecIndex; i < Dem_Cfg_EnvExtData[extDataId].extDataRecIndex; i++)
	{
		if (!Dem_EnvEDRRetrieve (Dem_Cfg_EnvExtData2ExtDataRec[i], &writepos, end, &src, internalEnvData))
		{
			return DEM_RECORD_WRONG_BUFFERSIZE;
		}
	}

	*bufsize = (uint16)(writepos - dest); /* current writing position - starting writing position */
	return DEM_RECORD_OK;
}

DEM_INLINE Dem_boolean_least Dem_EnvEDIsRecordNumberValid(uint8 extDataId, uint8 RecordNumber, Dem_TriggerType* trigger)
{
	uint16_least i;

	for (i = Dem_Cfg_EnvExtData[extDataId - 1].extDataRecIndex; i < Dem_Cfg_EnvExtData[extDataId].extDataRecIndex; i++)
	{
		if (Dem_EnvEDRGetRecordNumber (Dem_Cfg_EnvExtData2ExtDataRec[i]) == RecordNumber)
		{
			*trigger = Dem_EnvEDRGetRecordTrigger(Dem_Cfg_EnvExtData2ExtDataRec[i]);
			return TRUE;
		}
	}

	return FALSE;
}

DEM_INLINE Dem_ReturnGetExtendedDataRecordByDTCType Dem_EnvEDRetrieveExtendedDataRecord(uint8 extDataId,
		uint8 RecordNumber,
		uint8* dest,
		uint16* bufsize,
		const uint8* src,
		const Dem_InternalEnvData* internalEnvData)
{
	uint8* writepos = dest;
	uint8* end = dest + *bufsize;
	uint16_least i;

	for (i = Dem_Cfg_EnvExtData[extDataId - 1].extDataRecIndex; i < Dem_Cfg_EnvExtData[extDataId].extDataRecIndex; i++)
	{
		if (Dem_EnvEDRGetRecordNumber (Dem_Cfg_EnvExtData2ExtDataRec[i]) == RecordNumber)
		{
			if (!Dem_EnvEDRRetrieve (Dem_Cfg_EnvExtData2ExtDataRec[i], &writepos, end, &src, internalEnvData))
			{
				return DEM_RECORD_WRONG_BUFFERSIZE;
			}
			*bufsize = (uint16)(writepos - dest); /* current writing position - starting writing position */
			return DEM_RECORD_OK;
		}
		else
		{
			Dem_EnvEDRSkipSrc (Dem_Cfg_EnvExtData2ExtDataRec[i], &src);
		}
	}

	return DEM_RECORD_WRONG_NUMBER;
}

DEM_INLINE Dem_ReturnGetSizeOfExtendedDataRecordByDTCType Dem_EnvEDGetSizeOfEDR(uint8 extDataId,
		uint8 RecordNumber,
		uint16* size)
{
	uint16_least i;

	for (i = Dem_Cfg_EnvExtData[extDataId - 1].extDataRecIndex; i < Dem_Cfg_EnvExtData[extDataId].extDataRecIndex; i++)
	{
		if (Dem_EnvEDRGetRecordNumber (Dem_Cfg_EnvExtData2ExtDataRec[i]) == RecordNumber)
		{
			*size = (uint16)Dem_EnvEDRGetSize (Dem_Cfg_EnvExtData2ExtDataRec[i]);
			return DEM_GET_SIZEOFEDRBYDTC_OK;
		}
	}

	return DEM_GET_SIZEOFEDRBYDTC_W_RNUM;
}

#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.8.0.0; 3     16.07.2014 BRM2COB
*   CSCRM00688243
* 
* AR40.8.0.0; 2     07.04.2014 UDKOEGEL
*   CSCRM00594823
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 5     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 4     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 3     22.10.2013 AMN2KOR
*   CSCRM00547887
* 
* AR40.7.0.0; 2     08.08.2013 CLH2SI
*   CSCRM00532300
* 
* AR40.7.0.0; 1     24.07.2013 UDKOEGEL
*   CSCRM00545593: [Dem] removal of string.h
* 
* AR40.7.0.0; 0     24.07.2013 UDKOEGEL
*   CSCRM00545593: [Dem] removal of string.h
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
