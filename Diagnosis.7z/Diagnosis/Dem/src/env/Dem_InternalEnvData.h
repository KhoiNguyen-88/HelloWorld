/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_InternalEnvData$
* $Variant___:AR40.8.0.0$
* $Revision__:3$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_INTERNALENVDATA_H
#define DEM_INTERNALENVDATA_H


#include "Dem_Types.h"
#include "Dem_EvMemTypes.h"


typedef struct
{
	uint8 size;
	Dem_EventIdType eventId;
#if (DEM_CFG_DEBUGDATA != DEM_CFG_DEBUGDATA_OFF)
	Dem_DebugDataType debug0;
	Dem_DebugDataType debug1;
#endif
	Dem_EvMemEventMemoryType *evMemLocation;
} Dem_InternalEnvData;


#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.8.0.0; 3     15.05.2014 VSA2COB
*   CSCRM00662943
* 
* AR40.8.0.0; 2     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 1     10.03.2014 VSA2COB
*   CSCRM00619537_ComassoChanges
* 
* AR40.8.0.0; 0     13.02.2014 WUG3ABT
*   CSCRM00562030
* 
* AR40.4.0.0; 0     05.07.2012 BRM2COB
*   Version updated to AR40.4.0.0
* 
* AR40.4_2012-03; 2     30.06.2012 BRM2COB
*   Below versions moved to eASEE 
*   CSCRM00398920
*   CSCRM00427251
*   Commit:af8594c73c28251e2e2967be1f0cd3cd4d0e4511
*   Commit:1e189ae755ab7ae6be4b5673f630bd0db2448641
*   Commit:80b2451eac43605f43bfe401403cfef9cee46f24
*   Commit:88578f6740b1812feb8d1b19fd544f50bb78dc9d
*   Commit:ecdca94d8823fdd40ebb98b556457bf6a01814c1
* 
* AR40.4_2012-03; 1     27.06.2012 BRM2COB
*   GIT to eASEE 27-06
* 
* AR40.4_2012-03; 0     30.03.2012 CLH2SI
*   sync with GIT f91183928845e8f3f5b36ec7348093d0465d3965
*   * CSCRM00370898: Support internal env data
*   * CSCRM00389366: [DEM] Implement Disturbance
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
