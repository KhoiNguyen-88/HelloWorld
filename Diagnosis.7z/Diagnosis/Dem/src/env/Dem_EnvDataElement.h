/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_EnvDataElement$
* $Variant___:AR40.10.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_ENVDATAELEMENT_H
#define DEM_ENVDATAELEMENT_H

#include "Dem_Types.h"
#include "Dem_Cfg_EnvDataElement.h"
#include "Dem_InternalEnvData.h"


typedef Std_ReturnType (*Dem_ReadExtCSDataElementFnc)(uint8* Buffer);
typedef Std_ReturnType (*Dem_ReadInternalDataElementFnc)(uint8* Buffer, const Dem_InternalEnvData* internalData);


typedef struct
{
#if (DEM_CFG_ENV_DATAELEMENTS_EXTCS_AVAILABILITY == STD_ON)
   Dem_ReadExtCSDataElementFnc ReadExtCSFnc;
#endif
#if (DEM_CFG_ENV_DATAELEMENTS_INTERN_AVAILABILITY == STD_ON)
    Dem_ReadInternalDataElementFnc ReadInternalFnc;
#endif
    uint8 Size;
	boolean captureOnRetrieve;
} Dem_EnvDataElement;


#if (DEM_CFG_ENV_DATAELEMENTS_EXTCS_AVAILABILITY == STD_ON)
#define DEM_ENV_DATAELEMENTS_EXTCS_INIT(VAL)   (VAL),
#else
#define DEM_ENV_DATAELEMENTS_EXTCS_INIT(VAL)
#endif

#if (DEM_CFG_ENV_DATAELEMENTS_INTERN_AVAILABILITY == STD_ON)
#define DEM_ENV_DATAELEMENTS_INTERN_INIT(VAL)   (VAL),
#else
#define DEM_ENV_DATAELEMENTS_INTERN_INIT(VAL)
#endif

#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
extern const Dem_EnvDataElement Dem_Cfg_EnvDataElement[DEM_CFG_ENV_DATAELEMENTS_ARRAYLENGTH];
#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

DEM_INLINE void Dem_EnvInsertPadding(uint8* const* start, uint8 size)
{
	DEM_MEMSET(*start,0xFF,size);
}

DEM_INLINE void Dem_EnvDACapture(uint8 dataElementId, uint8** start, const uint8* end, const Dem_InternalEnvData* internalEnvData)
{
	Std_ReturnType result = E_NOT_OK;
	DEM_ASSERT((*start + Dem_Cfg_EnvDataElement[dataElementId].Size) <= end,DEM_DET_APIID_ENVDACAPTURE, 0);

	if (!Dem_Cfg_EnvDataElement[dataElementId].captureOnRetrieve)
	{
		#if (DEM_CFG_ENV_DATAELEMENTS_EXTCS_AVAILABILITY == STD_ON)
		if (Dem_Cfg_EnvDataElement[dataElementId].ReadExtCSFnc != NULL_PTR)
		{
			result = (Dem_Cfg_EnvDataElement[dataElementId].ReadExtCSFnc)(*start);
		}
		#endif

		#if (DEM_CFG_ENV_DATAELEMENTS_INTERN_AVAILABILITY == STD_ON)
		if (Dem_Cfg_EnvDataElement[dataElementId].ReadInternalFnc != NULL_PTR)
		{
			result = (Dem_Cfg_EnvDataElement[dataElementId].ReadInternalFnc)(*start, internalEnvData);
		}
		#endif

		if (result != E_OK)
		{
			Dem_EnvInsertPadding (start, Dem_Cfg_EnvDataElement[dataElementId].Size);
			DEM_DET(DEM_DET_APIID_ENVDACAPTURE, DEM_E_NODATAAVAILABLE);
		}
	}
	else
	{
		Dem_EnvInsertPadding (start, Dem_Cfg_EnvDataElement[dataElementId].Size);
	}

	*start += Dem_Cfg_EnvDataElement[dataElementId].Size;
}

DEM_INLINE void Dem_EnvDACopy(uint8 dataElementId, uint8** start, const uint8* end, const uint8** src)
{
	DEM_ASSERT((*start + Dem_Cfg_EnvDataElement[dataElementId].Size) <= end, DEM_DET_APIID_ENVDAUPDATE, 0);

	DEM_MEMCPY(*start, *src, Dem_Cfg_EnvDataElement[dataElementId].Size);
	*start += Dem_Cfg_EnvDataElement[dataElementId].Size;
	*src += Dem_Cfg_EnvDataElement[dataElementId].Size;
}

DEM_INLINE void Dem_EnvDASkip(uint8 dataElementId, uint8** start, const uint8* end, const uint8** src)
{
	DEM_ASSERT((*start + Dem_Cfg_EnvDataElement[dataElementId].Size) <= end, DEM_DET_APIID_ENVDASKIP, 0);

	*start += Dem_Cfg_EnvDataElement[dataElementId].Size;
	*src += Dem_Cfg_EnvDataElement[dataElementId].Size;
}

/* copies DataElement data from input stream to output stream. if capture on retrieve
 is configured, the data is captured and directly written to output stream */
DEM_INLINE Dem_boolean_least Dem_EnvDARetrieve(uint8 dataElementId,
		uint8** start,
		const uint8* end,
		const uint8** src,
		const Dem_InternalEnvData* internalEnvData)
{
	Std_ReturnType result = E_NOT_OK;

	if ((*start + Dem_Cfg_EnvDataElement[dataElementId].Size )> end)
	{
		return FALSE;
	}

	if (Dem_Cfg_EnvDataElement[dataElementId].captureOnRetrieve)
	{
#if (DEM_CFG_ENV_DATAELEMENTS_EXTCS_AVAILABILITY == STD_ON)
		if (Dem_Cfg_EnvDataElement[dataElementId].ReadExtCSFnc != NULL_PTR)
		{
			result = (Dem_Cfg_EnvDataElement[dataElementId].ReadExtCSFnc)(*start);
		}
#endif

#if (DEM_CFG_ENV_DATAELEMENTS_INTERN_AVAILABILITY == STD_ON)
		if (Dem_Cfg_EnvDataElement[dataElementId].ReadInternalFnc != NULL_PTR)
		{
			result = (Dem_Cfg_EnvDataElement[dataElementId].ReadInternalFnc)(*start, internalEnvData);
		}
#endif

		if (result != E_OK)
		{
			Dem_EnvInsertPadding (start, Dem_Cfg_EnvDataElement[dataElementId].Size);
			DEM_DET(DEM_DET_APIID_ENVDARETRIEVE, DEM_E_NODATAAVAILABLE);
		}
	}
	else
	{
	    DEM_MEMCPY(*start, *src, Dem_Cfg_EnvDataElement[dataElementId].Size);
	}
	*start += Dem_Cfg_EnvDataElement[dataElementId].Size;
	*src += Dem_Cfg_EnvDataElement[dataElementId].Size;
	return TRUE;
}

DEM_INLINE uint8 Dem_EnvDAGetSizeOf(uint8 dataElementId)
{
	return Dem_Cfg_EnvDataElement[dataElementId].Size;
}
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
#if (DEM_CFG_READDEM_DEBUG0_SUPPORTED)
Std_ReturnType Dem_ReadDebug0(uint8* Buffer, const Dem_InternalEnvData* internalData);
#endif

#if (DEM_CFG_READDEM_DEBUG1_SUPPORTED)
Std_ReturnType Dem_ReadDebug1(uint8* Buffer, const Dem_InternalEnvData* internalData);
#endif

Std_ReturnType Dem_ReadEventStatusByte( uint8* buffer, const Dem_InternalEnvData* internalData );

#if (DEM_CFG_READDEM_AGINGCTR_SUPPORTED)
Std_ReturnType Dem_ReadAgingCtr(uint8* Buffer, const Dem_InternalEnvData* internalData);
#endif

#if (DEM_CFG_READDEM_OCCCTR_SUPPORTED)
Std_ReturnType Dem_ReadOccCtr(uint8* Buffer, const Dem_InternalEnvData* internalData);
#endif

#if (DEM_CFG_READDEM_SIGNIFICANCE_SUPPORTED)
Std_ReturnType Dem_ReadSignificance(uint8* Buffer, const Dem_InternalEnvData* internalData);
#endif

#if (DEM_CFG_READDEM_OVFLIND_SUPPORTED)
Std_ReturnType Dem_ReadOvflInd(uint8* Buffer, const Dem_InternalEnvData* internalData);
#endif

#if (DEM_CFG_READDEM_CURRENT_FDC_SUPPORTED)
Std_ReturnType Dem_ReadCurrentFDC(uint8* Buffer, const Dem_InternalEnvData* internalData);
#endif

#if (DEM_CFG_READDEM_MAX_FDC_DURING_CURRENT_CYCLE_SUPPORTED)
Std_ReturnType Dem_ReadMaxFdcDuringCurrentCycle(uint8* Buffer, const Dem_InternalEnvData* internalData);
#endif

#if (DEM_CFG_READDEM_MAX_FDC_SINCE_LAST_CLEAR_SUPPORTED)
Std_ReturnType Dem_ReadMaxFdcSinceLastClear(uint8* Buffer, const Dem_InternalEnvData* internalData);
#endif

#if (DEM_CFG_READDEM_CYCLES_SINCE_FIRST_FAILED_SUPPORTED)
Std_ReturnType Dem_ReadCyclesSinceFirstFailed(uint8* Buffer, const Dem_InternalEnvData* internalData);
#endif

#if (DEM_CFG_READDEM_CYCLES_SINCE_LAST_FAILED_SUPPORTED)
Std_ReturnType Dem_ReadCyclesSinceLastFailed(uint8* Buffer, const Dem_InternalEnvData* internalData);
#endif

#if (DEM_CFG_READDEM_CYCLES_SINCE_LAST_FAILED_EXCLUDING_TNC_SUPPORTED)
Std_ReturnType Dem_ReadCyclesSinceLastFailedExcludingTNC(uint8* Buffer, const Dem_InternalEnvData* internalData);
#endif

#if (DEM_CFG_READDEM_FAILED_CYCLES_SUPPORTED)
Std_ReturnType Dem_ReadFailedCycles(uint8* Buffer, const Dem_InternalEnvData* internalData);
#endif

#if (DEM_CFG_READDEM_EVENT_ID_SUPPORTED)
Std_ReturnType Dem_ReadEventId(uint8* Buffer, const Dem_InternalEnvData* internalData);
#endif

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
#endif
/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 1     14.05.2015 TVE5COB
*   CSCRM00862564
* 
* AR40.10.0.0; 0     23.04.2015 TVE5COB
*   CSCRM00788723
* 
* AR40.8.0.0; 7     16.07.2014 BRM2COB
*   CSCRM00688243
* 
* AR40.8.0.0; 6     17.06.2014 VSA2COB
*   CSCRM00659749
* 
* AR40.8.0.0; 5     13.06.2014 WUG3ABT
*   CSCRM00673682
* 
* AR40.8.0.0; 4     14.04.2014 WUG3ABT
*   CSCRM00625933
* 
* AR40.8.0.0; 3     07.04.2014 UDKOEGEL
*   CSCRM00594823
* 
* AR40.8.0.0; 2     10.03.2014 VSA2COB
*   CSCRM00619537_ComassoChanges
* 
* AR40.8.0.0; 1     27.02.2014 WUG3ABT
*   CSCRM00588123
* 
* AR40.8.0.0; 0     20.02.2014 CLH2SI
*   CSCRM00594825
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
