/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_EnvMain$
* $Variant___:AR40.8.0.0$
* $Revision__:4$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_ENVMAIN_H
#define DEM_ENVMAIN_H


#include "Dem_Mapping.h"
#include "Dem_Cfg_EnvMain.h"
#include "Dem_Cfg_DistMem.h"
#include "Dem_EnvExtendedData.h"
#include "Dem_EnvFreezeFrame.h"
#include "Dem_EnvFFRecNumeration.h"



/* Dem-internal functions for capture, copy and update */

typedef struct
{
	uint8 extDataId;
	uint8 freezeFrameId;
} Dem_EnvDataMap;
#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
extern const Dem_EnvDataMap Dem_Cfg_EnvEventId2EnvData[DEM_EVENTID_ARRAYLENGTH];
#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

DEM_INLINE Dem_boolean_least Dem_EnvHasExtendedData(Dem_EventIdType EventId)
{
	return (Dem_Cfg_EnvEventId2EnvData[EventId].extDataId != 0);
}
DEM_INLINE Dem_boolean_least Dem_EnvHasFreezeFrame(Dem_EventIdType EventId)
{
	return (Dem_Cfg_EnvEventId2EnvData[EventId].freezeFrameId != 0);
}

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

void Dem_EnvCaptureED (Dem_EventIdType EventId, uint8* dest, uint16 destSize DEM_DEBUGDATA_PARAM(Dem_DebugDataType debug0, Dem_DebugDataType debug1));

#if(DEM_CFG_DISTURBANCE_MEMORY == DEM_CFG_DISTURBANCE_MEMORY_ON)
void Dem_EnvCaptureForDisturbanceMemory(Dem_EventIdType EventId, uint8* dest, uint16 destSize  DEM_DEBUGDATA_PARAM(Dem_DebugDataType debug0, Dem_DebugDataType debug1));
#endif

void Dem_EnvCaptureFF (Dem_EventIdType EventId, uint8* dest, uint16 destSize DEM_DEBUGDATA_PARAM(Dem_DebugDataType debug0, Dem_DebugDataType debug1));
void Dem_EnvCopyRawFF (Dem_EventIdType EventId, uint8* dest, uint16 destSize, uint8 ffIndex, const uint8* src);
void Dem_EnvCopyRawED (Dem_EventIdType EventId, uint8* dest, uint16 destSize, const uint8* src, Dem_EnvTriggerParamType* triggerParam);


/* Support functions for DCM-querries: Dem_GetExtendedDataRecordByDTC, Dem_GetFreezeFrameDataByDTC */

Dem_boolean_least Dem_EnvIsEDRNumberValid(Dem_EventIdType EventId, uint8 RecordNumber, Dem_TriggerType* trigger);
Dem_ReturnGetExtendedDataRecordByDTCType Dem_EnvRetrieveEDR(Dem_EventIdType EventId, uint8 RecordNumber, uint8* dest, uint16* destSize, const uint8* src, Dem_EvMemEventMemoryType *evMemLocation); /* according Figure 49 */
Dem_ReturnGetFreezeFrameDataByDTCType Dem_EnvRetrieveFF(Dem_EventIdType EventId, uint8* dest, uint16* destSize, uint8 ffIndex, const uint8* src, Dem_EvMemEventMemoryType *evMemLocation); /* according Figure 48 */

Dem_ReturnGetSizeOfExtendedDataRecordByDTCType Dem_EnvGetSizeOfEDR(Dem_EventIdType EventId, uint8 RecordNumber, uint16* size); /* according Figure 49 */
Dem_ReturnGetSizeOfExtendedDataRecordByDTCType Dem_EnvGetSizeOfED(Dem_EventIdType EventId, uint16* size);
Dem_ReturnGetSizeOfFreezeFrameByDTCType Dem_EnvGetSizeOfFF(Dem_EventIdType EventId, uint16* size); /* according Figure 48 */


/* Support functions for DLT: Dem_GetEventExtendedDataRecord, Dem_GetEventFreezeFrameData */

Std_ReturnType Dem_EnvRetrieveRawED(Dem_EventIdType EventId, uint8* dest, uint16* destSize, const uint8* src, Dem_EvMemEventMemoryType *evMemLocation);
Dem_boolean_least Dem_EnvRetrieveRawEDR(Dem_EventIdType EventId, uint8 RecordNumber, uint8* dest, uint16* destSize, const uint8* src, Dem_EvMemEventMemoryType *evMemLocation);
Std_ReturnType Dem_EnvRetrieveRawFF(Dem_EventIdType EventId, uint8* dest, uint16* destSize, uint8 ffIndex, const uint8* src, Dem_EvMemEventMemoryType *evMemLocation);
Dem_boolean_least Dem_EnvRetrieveRawDid(Dem_EventIdType EventId, uint8* dest, uint16* destSize, uint8 ffIndex, uint16 did, const uint8* src, Dem_EvMemEventMemoryType *evMemLocation);

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.8.0.0; 4     18.04.2014 NAL2KOR
*   CSCRM00370778
* 
* AR40.8.0.0; 3     07.04.2014 UDKOEGEL
*   CSCRM00594823
* 
* AR40.8.0.0; 2     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 1     10.03.2014 VSA2COB
*   CSCRM00619537_ComassoChanges
* 
* AR40.8.0.0; 0     20.02.2014 CLH2SI
*   CSCRM00594825
* 
* AR40.7.0.0; 4     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 3     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 2     22.10.2013 AMN2KOR
*   CSCRM00547887
* 
* AR40.7.0.0; 1     16.09.2013 BRM2COB
*   CSCRM00554250 : Updated Dem_EnvMain.c and .h files.
* 
* AR40.7.0.0; 0     16.09.2013 BRM2COB
*   
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
