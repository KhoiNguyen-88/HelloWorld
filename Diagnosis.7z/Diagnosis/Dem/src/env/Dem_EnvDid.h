/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_EnvDid$
* $Variant___:AR40.10.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_ENVDID_H
#define DEM_ENVDID_H


#include "Dem_Types.h"
#include "Dem_Array.h"
#include "Dem_EnvDataElement.h"
#include "Dem_Cfg_EnvDid.h"


typedef struct
{
	uint16 dataElementIndex;
	uint16 identifier;
} Dem_EnvDid;
#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
extern const uint8 Dem_Cfg_EnvDid2DataElement[];
DEM_ARRAY_DECLARE_CONST(Dem_EnvDid, Dem_Cfg_EnvDid, DEM_CFG_ENVDID_ARRAYLENGTH);
#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

DEM_INLINE void Dem_EnvDIDCapture(uint8 didId, uint8** start, const uint8* end, const Dem_InternalEnvData *internalEnvData)
{
	uint16_least i;
	for (i = Dem_Cfg_EnvDid[didId - 1].dataElementIndex;
		 i < Dem_Cfg_EnvDid[didId].dataElementIndex;
		 i++)
	{
		Dem_EnvDACapture(Dem_Cfg_EnvDid2DataElement[i], start, end, internalEnvData);
	}
}


/* copies all dataelements of DID from input stream to output stream */

/* MISRA RULE 16.7 VIOLATION: parameter src not made const, as it is modified in subfunction */
DEM_INLINE Dem_boolean_least Dem_EnvDIDRetrieveRaw(uint8 didId, uint8** start, const uint8* end, const uint8** src, const Dem_InternalEnvData* internalEnvData)
{
	uint16_least i;

	for (i = Dem_Cfg_EnvDid[didId - 1].dataElementIndex;
		 i < Dem_Cfg_EnvDid[didId].dataElementIndex;
		 i++)
	{
		if (!Dem_EnvDARetrieve(Dem_Cfg_EnvDid2DataElement[i], start, end, src, internalEnvData))
		{
			return FALSE;
		}
	}
	return TRUE;
}


/* MISRA RULE 16.7 VIOLATION: parameter src not made const, as it is modified in subfunction */
DEM_INLINE Dem_boolean_least Dem_EnvDIDRetrieve(uint8 didId, uint8** start, const uint8* end, const uint8** src, const Dem_InternalEnvData* internalEnvData)
{
	if ((end - *start) < 2)
	{
		return FALSE;
	}
	**start = (uint8) ((Dem_Cfg_EnvDid[didId].identifier / 256u) & 0xFFu);
	(*start)++;
	**start = (uint8)((Dem_Cfg_EnvDid[didId].identifier) & 0xFFu);
	(*start)++;

	return Dem_EnvDIDRetrieveRaw(didId, start, end, src, internalEnvData);
}


/* if identifier matches selected DID (didId), the data of the DID didId is returned. Otherwise
   the DID data is skipped in the inputstream (readpointer is increased by current DID size). */

DEM_INLINE Dem_boolean_least Dem_EnvDIDRetrieveSpecificDid (uint8 didId, uint16 identifier, uint8** start, const uint8* end, const uint8** src, const Dem_InternalEnvData* internalEnvData)
{
	uint16_least i;

	if (Dem_Cfg_EnvDid[didId].identifier == identifier)
	{
		for (i = Dem_Cfg_EnvDid[didId - 1].dataElementIndex;
			 i < Dem_Cfg_EnvDid[didId].dataElementIndex;
			 i++)
		{
			if (!Dem_EnvDARetrieve(Dem_Cfg_EnvDid2DataElement[i], start, end, src, internalEnvData))
			{
				return FALSE;
			}
		}
		return TRUE;
	}
	else
	{
		for (i = Dem_Cfg_EnvDid[didId - 1].dataElementIndex;
			 i < Dem_Cfg_EnvDid[didId].dataElementIndex;
			 i++)
		{
			*src += Dem_EnvDAGetSizeOf(Dem_Cfg_EnvDid2DataElement[i]);
		}
	}

	return FALSE;
}


DEM_INLINE uint16 Dem_EnvDIDGetSize(uint8 didId)
{
	uint16_least i;
	uint16 byteSize = 2;

	for (i = Dem_Cfg_EnvDid[didId - 1].dataElementIndex;
		 i < Dem_Cfg_EnvDid[didId].dataElementIndex;
		 i++)
	{
		byteSize += Dem_EnvDAGetSizeOf(Dem_Cfg_EnvDid2DataElement[i]);
	}
	return byteSize;
}

#endif
/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 0     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 8     12.12.2013 GET1COB
*   CSCRM00597621
* 
* AR40.7.0.0; 7     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 6     19.11.2013 BRM2COB
*   
* 
* AR40.7.0.0; 5     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 4     22.10.2013 AMN2KOR
*   CSCRM00547887
* 
* AR40.7.0.0; 3     21.10.2013 CLH2SI
*   CSCRM00585471
* 
* AR40.7.0.0; 2     08.08.2013 CLH2SI
*   CSCRM00532300
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
