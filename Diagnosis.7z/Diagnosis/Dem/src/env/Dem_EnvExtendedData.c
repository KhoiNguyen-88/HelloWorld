/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_EnvExtendedData$
* $Variant___:AR40.8.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/



#include "Dem_Cfg_EnvExtendedData.h"
#include "Dem_Cfg_EnvExtendedDataRec.h"
#include "Dem_EnvExtendedData.h"

#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
const uint8 Dem_Cfg_EnvExtData2ExtDataRec[] = DEM_CFG_ENVEXTDATA2EXTDATAREC;

const Dem_EnvExtData Dem_Cfg_EnvExtData[DEM_CFG_ENVEXTDATA_ARRAYLENGTH] = DEM_CFG_ENVEXTDATA;
#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 2     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 1     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 0     22.10.2013 AMN2KOR
*   CSCRM00547887
* 
* AR40.4.0.0; 1     27.06.2012 BRM2COB
*   GIT to eASEE 27-06
* 
* AR40.4.0.0; 0     14.02.2012 CLH2SI
*   GIT-SYNC: a0008d733d3a94fa3e0a3e39260972344e821bef
* 
* AR40.0.0.1; 1     12.12.2011 ALA2ABT
*   Git Commit:b21a116571d3e20441afe258ab336b12b1970d77
*   
* 
* AR40.0.0.1; 0     18.08.2011 CLH2SI
*   initial Rev based on Git-Rev:
*   e1ad93e3ec82d69d1a37032dd0fd856e9b21099e
*   
*   Requests:
*   CSCRM00293299
*   CSCRM00320676
*   CSCRM00320616
*   CSCRM00320579
*   CSCRM00320488
*   CSCRM00320415
*   CSCRM00318395
*   CSCRM00316439
*   CSCRM00316437
*   CSCRM00312185
*   CSCRM00312176
*   CSCRM00312173
*   CSCRM00312166
*   CSCRM00312162
*   CSCRM00312159
*   CSCRM00333624
*   
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
