/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************
* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_EnvTrigger$
* $Variant___:AR40.8.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_ENVTRIGGER_H
#define DEM_ENVTRIGGER_H


typedef struct
{
	/* In Parameter */
	Dem_TriggerType currentTrigger;
	Dem_TriggerType storedTrigger;
	/* Out Parameter */
	Dem_TriggerType matchingTrigger;
} Dem_EnvTriggerParamType;


DEM_INLINE void Dem_EnvSetTrigger(Dem_TriggerType* trigger, Dem_TriggerType trigger2set)
{
	*trigger = (*trigger) | trigger2set;
}

DEM_INLINE Dem_boolean_least Dem_EnvIsAnyTriggerSet(Dem_TriggerType trigger2test)
{
	return (Dem_boolean_least)(trigger2test != 0);
}

DEM_INLINE Dem_boolean_least Dem_EnvIsTriggerSet(Dem_TriggerType trigger, Dem_TriggerType trigger2test)
{
	return Dem_EnvIsAnyTriggerSet(trigger & trigger2test);
}



#endif /* DEM_ENVTRIGGER_H */

/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.8.0.0; 0     07.04.2014 UDKOEGEL
*   CSCRM00594823
* 
* $
**********************************************************************************************************************
</BASDKey>*/
