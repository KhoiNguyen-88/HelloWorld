/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_EnvDataElement$
* $Variant___:AR40.11.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/

#include "Std_Types.h"
#include "Dem_Cfg.h"
#include "Dem_Cfg_EnvDataElement.h"
#include "Dem_EnvDataElement.h"
#include "Dem_Events.h"
#include "Dem_EvMem.h"
#include "Dem_EvMemGen.h"
#include "Dem_Cfg_ExtPrototypes.h"
#include "Rte_Dem.h"
#include "Dem_Protected.h"

/* FC_VariationPoint_START */
#include "Dem_Cfg_Bfm.h"
#include "Dem_BfmCounter.h"
#include "Dem_BfmEvent.h"
/* FC_VariationPoint_END */

#include "Dem_PrjEnvDataElement.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
#if (DEM_CFG_DEBUGDATA != DEM_CFG_DEBUGDATA_OFF)
#if (DEM_CFG_READDEM_DEBUG0_SUPPORTED)
Std_ReturnType Dem_ReadDebug0(uint8* Buffer, const Dem_InternalEnvData* internalData)
{
    Dem_BigEndian_WriteValue2Buffer(Buffer, internalData->debug0, DEM_SIZEOF_TYPE(Dem_DebugDataType));
	return E_OK;
}
#endif

#if (DEM_CFG_READDEM_DEBUG1_SUPPORTED)
Std_ReturnType Dem_ReadDebug1(uint8* Buffer, const Dem_InternalEnvData* internalData)
{
    Dem_BigEndian_WriteValue2Buffer(Buffer, internalData->debug1, DEM_SIZEOF_TYPE(Dem_DebugDataType));
	return E_OK;
}
#endif
#endif

Std_ReturnType Dem_ReadEventStatusByte( uint8* buffer, const Dem_InternalEnvData* internalData )
{
	Std_ReturnType retVal = E_NOT_OK;
	Dem_EventStatusExtendedType eventStatus = 0;

	if( Dem_GetEventStatus( internalData->eventId, &eventStatus ) == E_OK )
	{
		*buffer = (uint8)eventStatus;
		retVal = E_OK;
	}

	return retVal;
}


#if (DEM_CFG_READDEM_AGINGCTR_SUPPORTED)
Std_ReturnType Dem_ReadAgingCtr(uint8* Buffer, const Dem_InternalEnvData* internalData)
{
	if (internalData->evMemLocation != NULL_PTR)
	{
		*Buffer = (uint8) Dem_EvMemGetEventMemAgingCounterScaled (internalData->evMemLocation);
	}
	else
	{
		*Buffer = 0;
	}
	return E_OK;
}
#endif

#if (DEM_CFG_READDEM_OCCCTR_SUPPORTED)
Std_ReturnType Dem_ReadOccCtr(uint8* Buffer, const Dem_InternalEnvData* internalData)
{
	if (internalData->evMemLocation != NULL_PTR)
	{
		*Buffer = (uint8)Dem_EvMemGetEventMemOccurrenceCounterByPtr(internalData->evMemLocation);
	}
	else
	{
		*Buffer = 0;
	}
	return E_OK;
}
#endif

#if (DEM_CFG_READDEM_OVFLIND_SUPPORTED)
Std_ReturnType Dem_ReadOvflInd(uint8* Buffer, const Dem_InternalEnvData* internalData)
{
	DEM_UNUSED_PARAM(internalData);
	/* Overflow Indicator supported for PRIMARY Memory */
	*Buffer = DEM_BOOL2BIT( Dem_EvMemGenIsOverflow(DEM_DTC_ORIGIN_PRIMARY_MEMORY) );
	return E_OK;
}
#endif

#if (DEM_CFG_READDEM_SIGNIFICANCE_SUPPORTED)
Std_ReturnType Dem_ReadSignificance(uint8* Buffer, const Dem_InternalEnvData* internalData)
{
	*Buffer = Dem_EvtIsSignificanceFault(internalData->eventId);
	return E_OK;
}
#endif


#if (DEM_CFG_READDEM_CURRENT_FDC_SUPPORTED)
Std_ReturnType Dem_ReadCurrentFDC(uint8* Buffer, const Dem_InternalEnvData* internalData)
{
    *Buffer = (uint8)Dem_DtcFaultDetectionRetrieve(Dem_DtcIdFromEventId(internalData->eventId));
	return E_OK;
}
#endif

#if (DEM_CFG_READDEM_MAX_FDC_DURING_CURRENT_CYCLE_SUPPORTED)
Std_ReturnType Dem_ReadMaxFdcDuringCurrentCycle(uint8* Buffer, const Dem_InternalEnvData* internalData)
{
	if (internalData->evMemLocation != NULL_PTR)
	{
		*Buffer = (uint8)Dem_EvMemGetMaxFdcDuringCurrentCycleByPtr(internalData->evMemLocation);
	}
	else
	{
		*Buffer = 0;
	}
	return E_OK;
}
#endif

#if (DEM_CFG_READDEM_MAX_FDC_SINCE_LAST_CLEAR_SUPPORTED)
Std_ReturnType Dem_ReadMaxFdcSinceLastClear(uint8* Buffer, const Dem_InternalEnvData* internalData)
{
	if (internalData->evMemLocation != NULL_PTR)
	{
		*Buffer = (uint8)Dem_EvMemGetMaxFdcSinceLastClearByPtr(internalData->evMemLocation);
	}
	else
	{
		*Buffer = 0;
	}
	return E_OK;
}
#endif

#if (DEM_CFG_READDEM_CYCLES_SINCE_FIRST_FAILED_SUPPORTED)
Std_ReturnType Dem_ReadCyclesSinceFirstFailed(uint8* Buffer, const Dem_InternalEnvData* internalData)
{
	if (internalData->evMemLocation != NULL_PTR)
	{
		*Buffer = Dem_EvMemGetCyclesSinceFirstFailedByPtr(internalData->evMemLocation);
	}
	else
	{
		*Buffer = 0;
	}
	return E_OK;
}
#endif

#if (DEM_CFG_READDEM_CYCLES_SINCE_LAST_FAILED_SUPPORTED)
Std_ReturnType Dem_ReadCyclesSinceLastFailed(uint8* Buffer, const Dem_InternalEnvData* internalData)
{
	if (internalData->evMemLocation != NULL_PTR)
	{
		*Buffer = Dem_EvMemGetCyclesSinceLastFailedByPtr(internalData->evMemLocation);
	}
	else
	{
		*Buffer = 0;
	}
	return E_OK;
}
#endif

#if (DEM_CFG_READDEM_CYCLES_SINCE_LAST_FAILED_EXCLUDING_TNC_SUPPORTED)
Std_ReturnType Dem_ReadCyclesSinceLastFailedExcludingTNC(uint8* Buffer, const Dem_InternalEnvData* internalData)
{
	if (internalData->evMemLocation != NULL_PTR)
	{
		*Buffer = Dem_EvMemGetCyclesSinceLastFailedExcludingTNCByPtr(internalData->evMemLocation);
	}
	else
	{
		*Buffer = 0;
	}
	return E_OK;
}
#endif

#if (DEM_CFG_READDEM_FAILED_CYCLES_SUPPORTED)
Std_ReturnType Dem_ReadFailedCycles(uint8* Buffer, const Dem_InternalEnvData* internalData)
{
	if (internalData->evMemLocation != NULL_PTR)
	{
		*Buffer = Dem_EvMemGetFailedCyclesByPtr(internalData->evMemLocation);
	}
	else
	{
		*Buffer = 0;
	}
	return E_OK;
}
#endif

#if (DEM_CFG_READDEM_EVENT_ID_SUPPORTED)
Std_ReturnType Dem_ReadEventId(uint8* Buffer, const Dem_InternalEnvData* internalData)
{
    Dem_BigEndian_WriteValue2Buffer(Buffer, internalData->eventId, DEM_SIZEOF_TYPE( Dem_EventIdType ));
    return E_OK;
}
#endif

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
const Dem_EnvDataElement Dem_Cfg_EnvDataElement[DEM_CFG_ENV_DATAELEMENTS_ARRAYLENGTH] = DEM_CFG_ENV_DATAELEMENTS;
#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 1     07.01.2016 TVE5COB
*   CSCRM01017790
* 
* AR40.11.0.0; 0     17.09.2015 UDKOEGEL
*   CSCRM00960004
* 
* AR40.10.0.0; 4     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 3     09.07.2015 SUH4COB
*   CSCRM00788888
* 
* AR40.10.0.0; 2     14.05.2015 TVE5COB
*   CSCRM00862564
* 
* AR40.10.0.0; 1     12.05.2015 CLH2SI
*   CSCRM00789099
* 
* AR40.10.0.0; 0     23.04.2015 TVE5COB
*   CSCRM00788723
* 
* AR40.9.0.0; 0     20.08.2014 VSA2COB
*   CSCRM00698491
* 
* AR40.8.0.0; 6     17.06.2014 VSA2COB
*   CSCRM00659749
* 
* AR40.8.0.0; 5     13.06.2014 WUG3ABT
*   CSCRM00673682
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
