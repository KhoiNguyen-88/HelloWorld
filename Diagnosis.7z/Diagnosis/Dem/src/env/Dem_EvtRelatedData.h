/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:H$
 * $Name______:Dem_EvtRelatedData$
 * $Variant___:AR40.10.0.0$
 * $Revision__:0$
 **********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_EVTRELATEDDATA_H
#define DEM_EVTRELATEDDATA_H

#include "Dem_EnvMain.h"
#include "Dem_EvMemBase.h"
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/**
 * @ingroup DEM_H
 *
 * Gets the data of all extended data records of an event.
 *
 * @param [in] EventId     : Identification of an event by assigned EventId
 * @param [out] DestBuffer : This parameter contains a byte pointer that points to the buffer, to which the extended data shall be
 *                           written to. The format is raw hexadecimal values and contains no header-information.
 * @param [in/out] BufSize : When the function is called this parameter contains the maximum
 *                           number of data bytes that can be written to the buffer.
 *                           The function returns the actual number of written data bytes in this
 *                           parameter.
 *
 * @return  E_OK = Operation was successful, E_NOT_OK: Operation failed.
 */
Std_ReturnType Dem_DltGetAllExtendedDataRecords(Dem_EventIdType EventId, uint8* DestBuffer, uint16* BufSize);

/**
 * @ingroup DEM_H
 *
 * Gets the data of an most recent freeze frame record by event.
 *
 * @param [in] EventId     : Identification of an event by assigned EventId
 * @param [out] DestBuffer : This parameter contains a byte pointer that points to the buffer, to which the extended data shall be
 *                           written to. The format is raw hexadecimal values and contains no header-information.
 * @param [in/out] BufSize : When the function is called this parameter contains the maximum
 *                           number of data bytes that can be written to the buffer.
 *                           The function returns the actual number of written data bytes in this
 *                           parameter.
 *
 * @return  E_OK = Operation was successful, E_NOT_OK: Operation failed.
 */

Std_ReturnType Dem_DltGetMostRecentFreezeFrameRecordData(Dem_EventIdType EventId, uint8* DestBuffer, uint16* BufSize);

/**
 * @ingroup DEM_H
 *
 * Gets the data of an extended data record by event.
 *
 * @param [in] EventId     : Identification of an event by assigned EventId
 *
 * @param [in]RecordNumber : Identification of requested Extended data record. Valid values are between 0x01 and 0xEF as defined in ISO14229-1.
 *							 0xFF means data of all extended data records are returned.
 *
 * @param [out] DestBuffer : This parameter contains a byte pointer that points to the buffer, to which the extended data shall be
 *                           written to. The format is raw hexadecimal values and contains no header-information.
 *
 * @param [in/out] BufSize : When the function is called this parameter contains the maximum
 *                           number of data bytes that can be written to the buffer.
 *                           The function returns the actual number of written data bytes in this
 *                           parameter.
 *
 * @return  			   : E_OK = Operation was successful,
 * 							 E_NOT_OK = Operation failed.
 *
 */

Std_ReturnType Dem_GetEventExtendedDataRecord(
		Dem_EventIdType EventId,
		uint8 RecordNumber,
		uint8* DestBuffer,
		uint8* BufSize
);

Std_ReturnType Dem_GetEventExtendedDataRecordForRTE(
        Dem_EventIdType EventId,
        uint8 RecordNumber,
        uint8* DestBuffer
);

/**
 * @ingroup DEM_H
 *
 * Gets the data of a freeze frame record by event.
 *
 * @param [in] EventId            : Identification of an event by assigned EventId
 *
 * @param [in] RecordNumber	      : This parameter is a unique identifier for a freeze frame record as defined in ISO15031-5 and ISO14229-1.
 *							        0xFF means most recent freeze frame record is returned.
 *
 * @param [in] ReportTotalRecord  :	This parameter is obsolete and shall be set to FALSE. This function requests a single PID/DID.
 *
 * @param [in] DataId	          : This parameter specifies the PID (ISO15031-5) or data identifier (ISO14229-1) that shall be copied to the destination buffer.
 *									If ReportTotalRecord is TRUE, the value of DataId is ignored.
 *
 * @param [out] DestBuffer  	  : This parameter contains a byte pointer that points to the buffer, to which the freeze frame data shall be
 *                                  written to. The format is raw hexadecimal values and contains no header-information.
 *
 * @param [in/out] BufSize        : When the function is called this parameter contains the maximum
 *                            		number of data bytes that can be written to the buffer.
 *                            		The function returns the actual number of written data bytes in this
 *                            		parameter.
 *
 * @return        				  : E_OK = Operation was successful,
 *                                  E_NOT_OK = Operation failed.
 *
 */

Std_ReturnType Dem_GetEventFreezeFrameData(
		Dem_EventIdType EventId,
		uint8 RecordNumber,
		boolean ReportTotalRecord,
		uint16 DataId,
		uint8* DestBuffer,
		uint8* BufSize
);

Std_ReturnType Dem_GetEventFreezeFrameDataForRTE(
        Dem_EventIdType EventId,
        uint8 RecordNumber,
        boolean ReportTotalRecord,
        uint16 DataId,
        Dem_MaxDataValueType DestBuffer
);

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif

/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.10.0.0; 0     24.03.2015 LIB8FE
 *   CSCRM00743164
 * 
 * AR40.8.0.0; 0     18.04.2014 NAL2KOR
 *   CSCRM00370778
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
