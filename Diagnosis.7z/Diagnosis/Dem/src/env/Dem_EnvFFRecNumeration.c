/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_EnvFFRecNumeration$
* $Variant___:AR40.8.0.0$
* $Revision__:2$
**********************************************************************************************************************
</BASDKey>*/


#include "Dem_EnvFFRecNumeration.h"

#if (DEM_CFG_FFRECNUM == DEM_CFG_FFRECNUM_CONFIGURED)

#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
const uint8 Dem_Cfg_EnvFFRecNumConf[DEM_CFG_FFRECCLASS_NUMBEROF_FFRECCLASSES][DEM_CFG_FFRECCLASS_MAXNUMBEROF_FFFRECNUMS] = DEM_CFG_FFRECNUMCLASSES;
#if DEM_CFG_FFRECCLASS_NUMBEROF_FFRECCLASSES > 1
DEM_ARRAY_DEFINE_CONST(uint8, Dem_Cfg_EnvEventId2FrecNumClass, DEM_EVENTID_ARRAYLENGTH, DEM_CFG_ENVEVENTID2FFRECNUMCLASS);
#endif
#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

uint8 Dem_EnvGetIndexOfFFRecConf(Dem_EventIdType EventId, uint8 RecNumber)
{
	uint8 idx;

	DEM_ASSERT(Dem_EvtGetMaxNumberOfFreezeFrames(EventId) <= DEM_CFG_FFRECCLASS_MAXNUMBEROF_FFFRECNUMS,DEM_DET_APIID_ENVGETINDEXOFCONFFFREC,0x0);
	for (idx = 0; idx < Dem_EvtGetMaxNumberOfFreezeFrames(EventId); idx++)
	{
		if (Dem_Cfg_EnvFFRecNumConf [Dem_EnvGetFFRecNumClassIndex(EventId)][idx] == RecNumber)
		{
			return idx;
		}
	}
	return DEM_ENV_FFRECNUM_INDEX_INVALID;
}

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.8.0.0; 2     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 1     10.03.2014 VSA2COB
*   CSCRM00619537_ComassoChanges
* 
* AR40.8.0.0; 0     20.01.2014 UDKOEGEL
*   CSCRM00338832
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
