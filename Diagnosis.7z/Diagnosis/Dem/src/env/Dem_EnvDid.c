/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_EnvDid$
* $Variant___:AR40.8.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/

#include "Dem_Cfg_EnvDid.h"
#include "Dem_Cfg_EnvDataElement.h"
#include "Dem_EnvDid.h"

#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
const uint8 Dem_Cfg_EnvDid2DataElement[] = DEM_CFG_ENVDID2DATAELEMENT;
DEM_ARRAY_DEFINE_CONST(Dem_EnvDid, Dem_Cfg_EnvDid, DEM_CFG_ENVDID_ARRAYLENGTH, DEM_CFG_ENVDID);
#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 3     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 2     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 1     22.10.2013 AMN2KOR
*   CSCRM00547887
* 
* AR40.7.0.0; 0     08.08.2013 CLH2SI
*   CSCRM00532300
* 
* AR40.5.0.0; 1     10.07.2013 CLH2SI
*   - update NVM handling of statusbyte/distmem/generivNVData
*   - include delivery notes
*   (CSCRM00544420,  CSCRM00526766)
* 
* AR40.5.0.0; 0     30.11.2012 KAN1COB
*   See: check in comment ofCOMP: DEM40.5_2012-11;5
* 
* AR40.4.0.0; 1     27.06.2012 BRM2COB
*   GIT to eASEE 27-06
* 
* AR40.4.0.0; 0     14.02.2012 CLH2SI
*   GIT-SYNC: a0008d733d3a94fa3e0a3e39260972344e821bef
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
