/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:C$
 * $Name______:Dem_EvtRelatedData$
 * $Variant___:AR40.10.0.0$
 * $Revision__:2$
 **********************************************************************************************************************
</BASDKey>*/

#include "Dem_EvtRelatedData.h"
#include "Dem_EvMem.h"
#include "Dem_ObdMain.h"


#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

Std_ReturnType Dem_DltGetAllExtendedDataRecords(Dem_EventIdType EventId, uint8* DestBuffer, uint16* BufSize)
{

	uint16_least LocId;
	Std_ReturnType returnValue = E_NOT_OK;

	if (!Dem_isEventIdValid(EventId))
	{
		return E_NOT_OK;
	}

	LocId = Dem_EvMemGetLocationOfEventFromEventMemory(EventId);

	if (Dem_EvMemIsEventMemLocIdValid (LocId))
	{
		returnValue = Dem_EnvRetrieveRawED(EventId, DestBuffer, BufSize, Dem_EvMemGetEventMemData(LocId), Dem_EvMemGetEventMemLocation(LocId));
	}
	else
	{
		return E_NOT_OK;
	}

	return returnValue;
}

Std_ReturnType Dem_DltGetMostRecentFreezeFrameRecordData(Dem_EventIdType EventId, uint8* DestBuffer, uint16* BufSize)
{

	uint16_least LocId;
	uint16_least ffIndex;
	Std_ReturnType returnValue = E_NOT_OK;

	if (!Dem_isEventIdValid(EventId))
	{
		return E_NOT_OK;
	}

	LocId = Dem_EvMemGetLocationOfEventFromEventMemory(EventId);

	if (Dem_EvMemIsEventMemLocIdValid (LocId))
	{

		ffIndex = Dem_EvMemGetEventMemFreezeFrameCounter(LocId);

		if (ffIndex < 1u)
		{
			return E_NOT_OK;
		}
		returnValue = Dem_EnvRetrieveRawFF(EventId, DestBuffer, BufSize, (uint8)(ffIndex - 1u), Dem_EvMemGetEventMemData(LocId), Dem_EvMemGetEventMemLocation(LocId));
	}
	else
	{
		returnValue = E_NOT_OK;
	}
	return returnValue;
}

Std_ReturnType Dem_GetEventExtendedDataRecord(
		Dem_EventIdType EventId,
		uint8 RecordNumber,
		uint8* DestBuffer,
		uint8* BufSize
)
{
#if( DEM_CFG_EVMEM_EXTENDED_DATA_SUPPORTED != FALSE )
	Std_ReturnType returnValue = E_NOT_OK;
	Dem_TriggerType Trigger;
	uint16_least LocId;
	uint16 BufSize_u16;

	if (!Dem_isEventIdValid(EventId))
	{
		return E_NOT_OK;
	}

	if (!Dem_EnvIsEDRNumberValid (EventId, RecordNumber, &Trigger))
	{
		return E_NOT_OK;
	}

	LocId = Dem_EvMemGetLocationOfEventFromEventMemory(EventId);

	if (Dem_EvMemIsEventMemLocIdValid (LocId))
	{

		if (!Dem_EnvIsTriggerSet(Dem_EvMemGetEventMemTrigger(LocId), Trigger))
		{
			return E_NOT_OK;
		}

     BufSize_u16 = *BufSize ;

		if( Dem_EnvRetrieveRawEDR(EventId, RecordNumber, DestBuffer,&BufSize_u16, Dem_EvMemGetEventMemData(LocId), Dem_EvMemGetEventMemLocation(LocId)) == FALSE )
		{
			returnValue = E_NOT_OK;
		}
		else
		{
		    *BufSize = (uint8)BufSize_u16;
		    returnValue = E_OK;
		}

	}
	else
	{
		/* Nothing to do here , E_NOT_OK returned at the end of the function */
	}

	return returnValue;

#else
	DEM_UNUSED_PARAM(EventId);
	DEM_UNUSED_PARAM(RecordNumber);
	DEM_UNUSED_PARAM(DestBuffer);
	DEM_UNUSED_PARAM(BufSize);
	return E_NOT_OK;
#endif
}

Std_ReturnType Dem_GetEventExtendedDataRecordForRTE(
        Dem_EventIdType EventId,
        uint8 RecordNumber,
        uint8* DestBuffer
)
{
    uint8 bufSize = DEM_SIZEOF_TYPE(Dem_MaxDataValueType);
    return Dem_GetEventExtendedDataRecord(EventId, RecordNumber, DestBuffer, &bufSize);
}

Std_ReturnType Dem_GetEventFreezeFrameData(
		Dem_EventIdType EventId,
		uint8 RecordNumber,
		boolean ReportTotalRecord,
		uint16 DataId,
		uint8* DestBuffer,
		uint8* BufSize
)
{
#if ( DEM_CFG_EVMEM_FREEZE_FRAME_SUPPORTED != FALSE )
	Std_ReturnType returnValue = E_NOT_OK;
	uint16_least LocId;
	uint16_least ffIndex = 0xFFFF;
	uint16 BufSize_u16;

	if (!Dem_isEventIdValid(EventId))
	{
		return E_NOT_OK;
	}

   if (  (!Dem_EnvIsFFRecNumValid(EventId,RecordNumber)) && (RecordNumber != 0xFF)
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
         && (RecordNumber != 0x00)
#endif
         )
   {
      return E_NOT_OK;
   }

	LocId = Dem_EvMemGetLocationOfEventFromEventMemory(EventId);

	if (Dem_EvMemIsEventMemLocIdValid (LocId))
	{
		if(RecordNumber == 0xFF)
		{
			ffIndex = Dem_EvMemGetEventMemFreezeFrameCounter(LocId);

			if(ffIndex > 0u)
			{
				ffIndex--;
			}
			else
			{
				return E_NOT_OK;
			}
		}
      else if (RecordNumber == 0x00)
      {
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
         /* Read PID value from OBD Freeze frame,in case of RecordNumber =0.*/
         if ((DataId & 0xFF00) == 0xF400)
         {
            returnValue = Dem_ObdRetrievePidData((uint8)(DataId & 0xFF), DestBuffer, BufSize, LocId);
         }
         else
         {
            /*Return Negative response in case of wrong input parameter*/
            returnValue = E_NOT_OK;
         }
#else
         /* Non OBD -> freeze frame record 0 does not exist */
         return E_NOT_OK;
#endif
      }
		else
		{
			ffIndex = Dem_EnvGetIndexFromFFRecNum(EventId,RecordNumber);
		}

		if(ReportTotalRecord)
		{
			DEM_DET(DEM_DET_APIID_GETEVENTFREEZEFRAMEDATA, 0);
			return E_NOT_OK;
		}
		else
		{
			if( ffIndex < Dem_EvtGetMaxNumberOfFreezeFrames(EventId))
			{
				BufSize_u16 = *BufSize ;
				if( Dem_EnvRetrieveRawDid(EventId, DestBuffer, &BufSize_u16, (uint8)(ffIndex), DataId, Dem_EvMemGetEventMemData(LocId), Dem_EvMemGetEventMemLocation(LocId)) == FALSE )
				{
					returnValue = E_NOT_OK;
				}
				else
				{
					*BufSize = (uint8)BufSize_u16;
					returnValue = E_OK;
				}
			}
			else
			{
                /* Nothing to do here , E_NOT_OK returned at the end of the function */
			}
		}
	}
	else
	{
           /* Nothing to do here , E_NOT_OK returned at the end of the function */
	}

	return returnValue;

#else
	DEM_UNUSED_PARAM(EventId);
	DEM_UNUSED_PARAM(RecordNumber);
	DEM_UNUSED_PARAM(ReportTotalRecord);
	DEM_UNUSED_PARAM(DataId);
	DEM_UNUSED_PARAM(DestBuffer);
	DEM_UNUSED_PARAM(BufSize);
	return E_NOT_OK;
#endif
}

Std_ReturnType Dem_GetEventFreezeFrameDataForRTE(
        Dem_EventIdType EventId,
        uint8 RecordNumber,
        boolean ReportTotalRecord,
        uint16 DataId,
        Dem_MaxDataValueType DestBuffer
)
{
    uint8 bufSize = DEM_SIZEOF_TYPE(Dem_MaxDataValueType);
    return Dem_GetEventFreezeFrameData(EventId, RecordNumber, ReportTotalRecord, DataId, DestBuffer, &bufSize);
}

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.10.0.0; 2     14.07.2015 WUG3ABT
 *   Checkout by wug3abt
 * 
 * AR40.10.0.0; 1     12.05.2015 CLH2SI
 *   CSCRM00789099
 * 
 * AR40.10.0.0; 0     24.03.2015 LIB8FE
 *   CSCRM00743164
 * 
 * AR40.8.0.0; 2     16.06.2014 GJ83ABT
 *   CSCRM00615634, CSCRM00671513
 * 
 * AR40.8.0.0; 1     19.05.2014 GJ83ABT
 *   CSCRM00615636, CSCRM00591553
 * 
 * AR40.8.0.0; 0     18.04.2014 NAL2KOR
 *   CSCRM00370778
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
