/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:H$
 * $Name______:Dem_EvBuffEvent$
 * $Variant___:AR40.10.0.0$
 * $Revision__:2$
 **********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_EVBUFFEVENT_H
#define DEM_EVBUFFEVENT_H


#include "Dem_Cfg_EvBuff.h"
#include "Dem_Types.h"
#include "Dem_Mapping.h"
#include "Dem_Events.h"
#include "Dem_EnvMain.h"


#define Dem_EvBuffEventType uint8
#define C_EVENTTYPE_NOEVENT                        0u
#define C_EVENTTYPE_SET                            1u
#define C_EVENTTYPE_SET_RESET                      2u
#define C_EVENTTYPE_RESET                          3u
#define C_EVENTTYPE_SET_RECONFIRMED                4u
#define C_EVENTTYPE_SET_WAITINGFORMONITORING       5u
#define C_EVENTTYPE_PRESTORE                       6u
#define C_EVENTTYPE_UNROBUST                       7u


#define DEM_CFG_EVBUFF_STORES_ENVDATA_ON		STD_ON
#define DEM_CFG_EVBUFF_STORES_ENVDATA_OFF		STD_OFF
#if ((DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON) || (DEM_CFG_FFPRESTORAGESUPPORT == DEM_CFG_FFPRESTORAGESUPPORT_ON))
#define DEM_CFG_EVBUFF_STORES_ENVDATA		DEM_CFG_EVBUFF_STORES_ENVDATA_ON
#else
#define DEM_CFG_EVBUFF_STORES_ENVDATA		DEM_CFG_EVBUFF_STORES_ENVDATA_OFF
#endif

typedef struct {
    Dem_EvBuffEventType eventType;

#if (DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON)
    uint8 counter;
#endif
#if (DEM_CFG_EVBUFF_STORES_ENVDATA == DEM_CFG_EVBUFF_STORES_ENVDATA_ON)
    uint8 envData[DEM_CFG_ENVMINSIZE_OF_RAWENVDATA];
#endif

    Dem_EventIdType eventId;

#if (DEM_CFG_DEBUGDATA != DEM_CFG_DEBUGDATA_OFF)
    Dem_DebugDataType debug0;          /* debug data0   */
    Dem_DebugDataType debug1;          /* debug data1   */
#endif
} Dem_EvBuffEvent;


#if (DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON)
DEM_INLINE Dem_NodeIdType Dem_FailureEvent__getNodeId (const Dem_EvBuffEvent *fe)
{
    return Dem_NodeIdFromEventId(fe->eventId);
}
#endif

/* MISRA RULE 16.7 VIOLATION: parameter evBuff not made const, as it is modified in subfunction */
DEM_INLINE void Dem_EvBuffSetCounter (Dem_EvBuffEvent *evBuff, uint8 value)
{
#if (DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON)
    evBuff->counter = value;
#else
    DEM_UNUSED_PARAM(evBuff);
    DEM_UNUSED_PARAM(value);
#endif
}

DEM_INLINE uint8 Dem_EvBuffGetCounter (const Dem_EvBuffEvent *evBuff)
{
#if (DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON)
    return evBuff->counter;
#else
    DEM_UNUSED_PARAM(evBuff);
    return 0;
#endif
}

#endif
/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.10.0.0; 2     14.07.2015 WUG3ABT
 *   Checkout by wug3abt
 * 
 * AR40.10.0.0; 1     10.07.2015 CLH2SI
 *   CSCRM00938605
 * 
 * AR40.10.0.0; 0     16.04.2015 CLH2SI
 *   CSCRM00764027
 * 
 * AR40.9.0.0; 0     15.10.2014 GJ83ABT
 *   CSCRM00719089, CSCRM00650337, CSCRM00625552, CSCRM00434933
 * 
 * AR40.8.0.0; 3     16.07.2014 BRM2COB
 *   CSCRM00688243
 * 
 * AR40.8.0.0; 2     15.05.2014 VSA2COB
 *   CSCRM00662943
 * 
 * AR40.8.0.0; 1     20.03.2014 CLH2SI
 *   CSCRM00633913
 * 
 * AR40.8.0.0; 0     11.03.2014 VSA2COB
 *   CSCRM00619537_Comassochanges
 * 
 * AR40.7.0.0; 2     19.11.2013 CLH2SI
 *   CSCRM00578067
 * 
 * AR40.7.0.0; 1     22.10.2013 AMN2KOR
 *   CSCRM00547887
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
