/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_EvBuffDistributor$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_EVBUFFDISTRIBUTOR_H
#define DEM_EVBUFFDISTRIBUTOR_H

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
void Dem_EvBuffDistributorMainFunction(void);
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     01.10.2015 TVE5COB
*   CSCRM00976841
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 1     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 0     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.5.0.0; 0     30.11.2012 KAN1COB
*   See: check in comment ofCOMP: DEM40.5_2012-11;5
* 
* AR40.4.0.0; 0     05.07.2012 BRM2COB
*   Version updated to AR40.4.0.0
* 
* AR40.0.0.1; 1     27.06.2012 BRM2COB
*   GIT to eASEE 27-06
* 
* AR40.0.0.1; 0     18.08.2011 CLH2SI
*   initial Rev based on Git-Rev:
*   e1ad93e3ec82d69d1a37032dd0fd856e9b21099e
*   
*   Requests:
*   CSCRM00293299
*   CSCRM00320676
*   CSCRM00320616
*   CSCRM00320579
*   CSCRM00320488
*   CSCRM00320415
*   CSCRM00318395
*   CSCRM00316439
*   CSCRM00316437
*   CSCRM00312185
*   CSCRM00312176
*   CSCRM00312173
*   CSCRM00312166
*   CSCRM00312162
*   CSCRM00312159
*   CSCRM00333624
*   
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
