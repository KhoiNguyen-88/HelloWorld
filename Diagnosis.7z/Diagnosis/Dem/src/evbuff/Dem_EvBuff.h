/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:H$
 * $Name______:Dem_EvBuff$
 * $Variant___:AR40.11.0.0$
 * $Revision__:0$
 **********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_EVBUFF_H
#define DEM_EVBUFF_H


#include "Dem_Cfg_EvBuff.h"
#include "Dem_Cfg_Nodes.h"
#include "Dem_EvBuffEvent.h"
#include "Dem_Types.h"
#include "Dem_Mapping.h"
#include "Dem_Events.h"

typedef struct
{
    uint16 OverflowCounter;
    uint16 OverflowCounterSet;
    Dem_EvBuffEvent  Locations[DEM_CFG_EVBUFF_SIZE];
} Dem_EvtBufferState;


/************************************
 * DEM-internal interfaces
 ************************************/
#define DEM_START_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"
extern Dem_EvtBufferState Dem_EvtBuffer;
#define DEM_STOP_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

#if (DEM_CFG_FFPRESTORAGE_NONVOLATILE == DEM_CFG_FFPRESTORAGE_NONVOLATILE_ON)
#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
DEM_ARRAY_DECLARE_CONST(Dem_NvmIdType, Dem_PreStoredFFNvmId, DEM_CFG_PRESTORED_FF_SIZE);
#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
#endif

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


void Dem_EvBuffRemoveAllPrestored (void);

void Dem_EvBuffMainFunction(void);


#if (DEM_CFG_FFPRESTORAGESUPPORT == DEM_CFG_FFPRESTORAGESUPPORT_ON)
void Dem_PreStoredFFInitCheckNvM(void);
void Dem_PreStoredFFShutdown(void);
#endif
#if (DEM_CFG_FFPRESTORAGE_NONVOLATILE_IMMEDIATE == DEM_CFG_FFPRESTORAGE_NONVOLATILE_IMMEDIATE_ON)
void Dem_PreStoredFFTriggerStoreToNvM(void);
#endif


Dem_boolean_least Dem_EvBuffInsert (Dem_EvBuffEventType eventType,
        Dem_EventIdType eventId
        DEM_DEBUGDATA_PARAM(Dem_DebugDataType debug0,Dem_DebugDataType debug1));

const Dem_EvBuffEvent* Dem_EvBuffGetEvent (uint32* locationIndex);

void Dem_EvBuffRemoveEvent (uint32 locationIndex);
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


#if (DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON)
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
uint8_least Dem_EvBuffClearSequentialFailures (Dem_EventIdType EventId, Dem_NodeIdType nodeID, uint8 counterInit);
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
#else

DEM_INLINE uint8_least Dem_EvBuffClearSequentialFailures (Dem_EventIdType EventId, Dem_NodeIdType nodeID, uint8 counterInit) {
    DEM_UNUSED_PARAM(EventId);
    DEM_UNUSED_PARAM(nodeID);
    DEM_UNUSED_PARAM(counterInit);
    return 0;
}

#endif



#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
void Dem_EvBuffClear (Dem_EventIdType EventId);
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"



/************************************
 * PUBLIC interfaces
 ************************************/


#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
Dem_boolean_least Dem_EvBuffIsEventPending (Dem_EventIdType EventId);
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
DEM_INLINE Dem_boolean_least Dem_EvBuffIsAnyEventPending (void)
{
    return Dem_EvBuffIsEventPending (DEM_EVENTID_INVALID);
}

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
/**
 * @ingroup DEM_EXT_H
 *
 * Dem188: Stores a prestored freeze frame of a specific event along with the debug information.
 *
 * @param[in]  EventId          Identification of Event by ID.
 *             debug0           First envData information
 *             debug1           Second envData inforation
 * @return  E_OK = storing of prestored freezeframe was succssful \n
 *          E_NOT_OK = storing of prestored freezeframe was not successful
 *
 * @see Dem_PrestoreFreezeFrame is the corresponding AUTOSAR function.
 */
Std_ReturnType  Dem_PrestoreFreezeFrameWithEnvData( Dem_EventIdType EventId ,Dem_DebugDataType debug0 ,Dem_DebugDataType debug1 );
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


#endif
/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.11.0.0; 0     01.10.2015 TVE5COB
 *   CSCRM00976841
 * 
 * AR40.10.0.0; 2     09.07.2015 RPV5COB
 *   CSCRM00791814
 * 
 * AR40.10.0.0; 1     06.07.2015 VSA2COB
 *   CSCRM00830308
 * 
 * AR40.10.0.0; 0     17.06.2015 LIB8FE
 *   CSCRM00764040
 * 
 * AR40.9.0.0; 1     23.12.2014 BPE4COB
 *   CSCRM00715627
 * 
 * AR40.9.0.0; 0     15.10.2014 GJ83ABT
 *   CSCRM00719089, CSCRM00650337, CSCRM00625552, CSCRM00434933
 * 
 * AR40.8.0.0; 2     16.07.2014 BRM2COB
 *   CSCRM00688243
 * 
 * AR40.8.0.0; 1     15.05.2014 VSA2COB
 *   CSCRM00662943
 * 
 * AR40.8.0.0; 0     11.03.2014 VSA2COB
 *   CSCRM00619537_Comassochanges
 * 
 * AR40.7.0.0; 5     21.11.2013 GIN9COB
 *   CSCRM00598921
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
