/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_EvBuffDistributor$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#include "Dem_EvBuff.h"
#include "Dem_DTCStateManager.h"
#include "Dem_EvBuffDistributor.h"
#include "Dem_Clear.h"
/* FC_VariationPoint_START */
#include "Dem_Bfm.h"
#include "Dem_BfmBuffer.h"
/* FC_VariationPoint_END */

#define DEM_START_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"
static boolean Dem_isDistributionRunning = FALSE;
#define DEM_STOP_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"


DEM_INLINE void Dem_EvBuffDistributorCallReceivers (const Dem_EvBuffEvent* fe)
{
   Dem_DtcStateManagerReport (fe);
}
#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"
static Dem_EvBuffEvent tmpEvBuffLocation;
#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
/**
 * Get all failure events from SFB and distribute them
 */
void Dem_EvBuffDistributorMainFunction(void)
{
	Dem_boolean_least performDistribution = FALSE;
	uint32 idx;
	const Dem_EvBuffEvent* fEvent;

	/* do not distibute events while clear is in progress to avoid data inconsistency (e.g. evmem entry without testfailed) */
	if( Dem_ClearIsInPgrogress() )
	{
		return;
	}
	/* FC_VariationPoint_START */
	#if( DEM_BFM_ENABLED == DEM_BFM_ON )
	if( Dem_BfmDeleteAllIsInProgress() )
	{
		return;
	}
	#endif
	/* FC_VariationPoint_END */


	DEM_ENTERLOCK_MON_BEFORE_INIT();
	if (!Dem_isDistributionRunning) {
		performDistribution = TRUE;
		Dem_isDistributionRunning = TRUE;
	}
	DEM_EXITLOCK_MON_BEFORE_INIT();

	while (performDistribution)
	{
		DEM_ENTERLOCK_MON_BEFORE_INIT();
		/* getting next event from evBuff and isDistributionRunning must be
		 * atomic action, to ensure correct processing in case of concurrent
		 * call to DistributorProcess (on flush).
		 */
		fEvent = Dem_EvBuffGetEvent(&idx);

		if (fEvent == NULL_PTR)
		{
			performDistribution = FALSE;
			Dem_isDistributionRunning = FALSE;
		}
		else
		{
			DEM_MEMCPY(&tmpEvBuffLocation, fEvent, DEM_SIZEOF_VAR(tmpEvBuffLocation));
			/* FC_VariationPoint_START */
			#if( DEM_BFM_ENABLED == DEM_BFM_ON )
			Dem_BfmEnvCopyToTempBuffer((uint8)idx);
			#endif
			/* FC_VariationPoint_END */
			Dem_EvBuffRemoveEvent(idx);
		}
		DEM_EXITLOCK_MON_BEFORE_INIT();

		if (performDistribution)
		{
			Dem_EvBuffDistributorCallReceivers(&tmpEvBuffLocation);

			/* FC_VariationPoint_START */
			#if( DEM_BFM_ENABLED == DEM_BFM_ON )
			Dem_BfmEnvRetrieveBFM();
			#endif
			/* FC_VariationPoint_END */
		}
	}
/* FC_VariationPoint_START */
/* TODO: check robustness
   fEvent = UnrobustnessEventBuffer__getEvent (&idx);
   while (fEvent != NULL_PTR)
   {
      Dem_EvBuffDistributorCallReceivers(fEvent);

      UnrobustnessEventBuffer__removeEvent (idx);
      fEvent = UnrobustnessEventBuffer__getEvent (&idx);
   }
*/
/* FC_VariationPoint_END */
}


#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     01.10.2015 TVE5COB
*   CSCRM00976841
* 
* AR40.10.0.0; 1     12.05.2015 CLH2SI
*   CSCRM00789099
* 
* AR40.10.0.0; 0     17.03.2015 TVE5COB
*   CSCRM00789300
* 
* AR40.8.0.0; 1     11.04.2014 WUG3ABT
*   CSCRM00625933
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 6     21.11.2013 AMN2KOR
*   CSCRM00591723
* 
* AR40.7.0.0; 5     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 4     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 3     21.08.2013 AMN2KOR
*   CSCRM00552368: [Int-Dem] Misc
* 
* AR40.7.0.0; 2     08.08.2013 CLH2SI
*   CSCRM00532300
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
