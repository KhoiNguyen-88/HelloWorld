/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_DTCStateManager$
* $Variant___:AR40.8.0.0$
* $Revision__:2$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_DTCSTATEMANAGER_H
#define DEM_DTCSTATEMANAGER_H


#include "Dem_EvBuff.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

void Dem_DtcStateManagerReport (const Dem_EvBuffEvent* fe);
void Dem_DtcStateManagerMainFunction(void);
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
/*
void DTCStateManager__reInitAllDTCs (void);
void DTCStateManager__reInitDTC (Dem_DtcIdType dtcID);
*/



#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.8.0.0; 2     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 1     18.03.2014 NAL2KOR
*   CSCRM00633565_EventSuppression
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 1     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 0     19.11.2013 BRM2COB
*   
* 
* AR40.5.0.0; 1     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.5.0.0; 0     30.11.2012 KAN1COB
*   See: check in comment ofCOMP: DEM40.5_2012-11;5
* 
* AR40.4.0.0; 1     27.06.2012 BRM2COB
*   GIT to eASEE 27-06
* 
* AR40.4.0.0; 0     14.02.2012 CLH2SI
*   GIT-SYNC: a0008d733d3a94fa3e0a3e39260972344e821bef
* 
* AR40.0.0.1; 1     12.12.2011 ALA2ABT
*   Git Commit:b21a116571d3e20441afe258ab336b12b1970d77
*   
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
