/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_DTCGroup$
* $Variant___:AR40.10.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_DTCGROUP_H
#define DEM_DTCGROUP_H


#include "Dem_Types.h"
#include "Dem_Array.h"
#include "Dem_Cfg_DTCs.h"
#include "Dem_Cfg_DtcId.h"
/* FC_VariationPoint_START */
#include "Dem_Cfg_ObdMain.h"
/* FC_VariationPoint_END */
#include "Dem_Clear.h"


#define DEM_DTCGROUPS_INIT(CODE) \
{   (CODE) \
}

typedef struct {

	Dem_DTCGroupType dtcGroupCode;
} Dem_DtcGroupParam;
#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
DEM_ARRAY_DECLARE_CONST(Dem_DtcGroupParam, Dem_AllDTCGroupsParam, DEM_DTCGROUPID_ARRAYLENGTH);
#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

Dem_DTCGroupIdType Dem_DtcGroupIdFromDtcGroupCode (Dem_DTCGroupType dtcGrpCode);
void Dem_DtcsClearDtcInGroup(uint8 GroupId, Dem_DTCOriginType DTCOrigin, Dem_ClearHandlerType *ClearHandler);
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
/*********************Disable && Enable DTC************************************************************************/

DEM_INLINE Dem_DTCGroupType Dem_DtcGroupGetCode (Dem_DTCGroupIdType dtcGroupId)
{
	return Dem_AllDTCGroupsParam[dtcGroupId].dtcGroupCode;
}


/**
 * @ingroup DEM_H
 *
 * Dem243: Enables the DTC setting for a DTC group.
 * @param[in]  DTCGroup  Defines the group of DTC that shall be enabled to store in event memory.
 * @param[in]  DTCKind  This parameter defines the requested DTC, either only OBD-relevant DTCs or all DTCs
 * @return  DEM_CONTROL_DTC_SETTING_OK: DTC setting control successful
 *          DEM_CONTROL_DTC_SETTING_N_OK: DTC setting control not successful
 *          DEM_CONTROL_DTC_WRONG_DTCGROUP: DTC setting control not successful because group of DTC was wrong
 */
Dem_ReturnControlDTCSettingType Dem_EnableDTCSetting (Dem_DTCGroupType DTCGroup, Dem_DTCKindType DTCKind);

/**
 * @ingroup DEM_H
 *
 * Dem242: Disables the DTC setting for a DTC group.
 * @param[in]  DTCGroup  Defines the group of DTC that shall be disabled to store in event memory.
 * @param[in]  DTCKind  This parameter defines the requested DTC, either only OBD-relevant DTCs or all DTCs
 * @return  DEM_CONTROL_DTC_SETTING_OK: DTC setting control successful
 *          DEM_CONTROL_DTC_SETTING_N_OK: DTC setting control not successful
 *          DEM_CONTROL_DTC_WRONG_DTCGROUP: DTC setting control not successful because group of DTC was wrong
 */
Dem_ReturnControlDTCSettingType Dem_DisableDTCSetting (Dem_DTCGroupType DTCGroup, Dem_DTCKindType DTCKind);


#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 0     06.07.2015 VSA2COB
*   CSCRM00830308
* 
* AR40.9.0.0; 0     22.08.2014 CLH2SI
*   CSCRM00688436
* 
* AR40.8.0.0; 1     16.06.2014 GJ83ABT
*   CSCRM00615634, CSCRM00671513
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 4     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 3     19.11.2013 BRM2COB
*   
* 
* AR40.7.0.0; 2     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 1     22.10.2013 AMN2KOR
*   CSCRM00547887
* 
* AR40.7.0.0; 0     08.08.2013 CLH2SI
*   CSCRM00532300
* 
* AR40.6.0.0; 5     10.07.2013 CLH2SI
*   - update NVM handling of statusbyte/distmem/generivNVData
*   - include delivery notes
*   (CSCRM00544420,  CSCRM00526766)
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
