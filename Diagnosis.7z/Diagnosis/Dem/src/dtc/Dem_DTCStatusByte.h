/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_DTCStatusByte$
* $Variant___:AR40.10.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_DTCSTATUSBYTE_H
#define DEM_DTCSTATUSBYTE_H


#include "Dem_Cfg_DTCs.h"
#include "Dem_Mapping.h"
#include "Dem_EvBuff.h"
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

uint8 Dem_DtcStatusByteRetrieve (Dem_DtcIdType dtcId);
uint8 Dem_DtcStatusByteRetrieveWithOrigin (Dem_DtcIdType dtcId, Dem_DTCOriginType DtcOrigin, boolean* DtcStatusIsValid);
void Dem_ClearDTCsEvents(Dem_EventIdType EventId, Dem_DTCOriginType DTCOrigin, Dem_ClearHandlerType *ClearHandler);
void Dem_ClearAllDTCs(Dem_DTCOriginType DTCOrigin, Dem_ClearHandlerType *ClearHandler);
void Dem_ClearSingleDTC(Dem_DtcIdType dtcId, Dem_DTCOriginType DTCOrigin, Dem_ClearHandlerType *ClearHandler);
boolean Dem_IsPendingClearEvent(Dem_EventIdType EventId);



/**
 * @ingroup DEM_H
 *
 * Dem198: Gets the DTC of an event.
 * @param[in]  DTC  For this DTC its status is requested
 * @param[in]  DTCKind  This parameter defines the requested DTC, either only
 *                      OBD-relevant DTCs or all DTCs
 * @param[in]  DTCOrigin  If the Dem supports more than one event memory this parameter
 *                        is used to select the source memory the DTCs shall be read from.
 * @param[out]  DTCStatus  This parameter receives the status information of the requested
 *                         DTC. If the return value of the function call is other than
 *                         DEM_STATUS_OK this parameter does not contain valid data.
 *                         0x00...0xFF match DTCStatusMask as defined in ISO14229-1.
 * @return  Status of the operation of type Dem_ReturnGetStatusOfDTCType.\n
 */
Dem_ReturnGetStatusOfDTCType Dem_GetStatusOfDTC( uint32 DTC, Dem_DTCKindType DTCKind, Dem_DTCOriginType DTCOrigin, uint8* DTCStatus);
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 0     06.07.2015 VSA2COB
*   CSCRM00830308
* 
* AR40.8.0.0; 2     10.06.2014 UDKOEGEL
*   CSCRM00639545
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 3     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 2     19.11.2013 BRM2COB
*   
* 
* AR40.7.0.0; 1     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 0     22.10.2013 AMN2KOR
*   CSCRM00547887
* 
* AR40.5.0.0; 1     02.11.2012 CRA1COB
*   GiT to eASEE
* 
* AR40.5.0.0; 0     17.09.2012 CRA1COB
*   gittoeASEE
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
