/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:H$
 * $Name______:Dem_DTCs$
 * $Variant___:AR40.10.0.0$
 * $Revision__:6$
 **********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_DTCS_H
#define DEM_DTCS_H



#include "Dem_Types.h"
#include "Dem_Array.h"
#include "Dem_BitArray.h"
#include "Dem_Bits8.h"
#include "Dem_Cfg_DtcId.h"
#include "Dem_Cfg_DTCs.h"
/* FC_VariationPoint_START */
#include "Dem_Cfg_ObdMain.h"
/* FC_VariationPoint_END */
#include "Dem_Mapping.h"
#include "Dem_ISO14229Byte.h"
#include "Dem_Events.h"
#include "Dem_DTCStatusByte.h"

#include "Dem_DTCFilter.h"
#include "Dem_Helpers.h"
#include "Dem_EvMem.h"

#define DEM_DTC_SETTING_ENABLED     FALSE
#define DEM_DTC_SETTING_DISABLED    TRUE


typedef struct {
	Dem_DtcStateType state;
} Dem_DtcState;

/******************************************************************************/



#define DEM_DTCS_NVSTORAGE_BP    2u
#define DEM_DTCS_ALTERNATIVEDTC_FLAG_BP    3u

#define DEM_DTCS_SEVERITYMASK    0xE0u
#define DEM_DTCS_KINDMASK        0x03u
#define DEM_DTCS_NVSTORAGEMASK   ((uint8)(1u<<DEM_DTCS_NVSTORAGE_BP))
#define DEM_DTCS_ALTERNATIVEDTC_FLAG   ((uint8)(1u<<DEM_DTCS_ALTERNATIVEDTC_FLAG_BP))



#define DEM_DTCS_INIT8(KIND, SEVERITY, NVSTORAGE, FUNC_UNIT, INDEXOF_ALTERNATIVE_DTCID) \
{   ((KIND) & (DEM_DTCS_KINDMASK))|((SEVERITY) & (DEM_DTCS_SEVERITYMASK)) | ((uint8)(((NVSTORAGE) & (0x01u)) << DEM_DTCS_NVSTORAGE_BP)) | ((uint8)((DEM_BOOL2BIT(INDEXOF_ALTERNATIVE_DTCID) & (0x01u)) << DEM_DTCS_ALTERNATIVEDTC_FLAG_BP)) \
    ,(FUNC_UNIT) \
}

/* FC_VariationPoint_START */
#if (DEM_CFG_OBD == DEM_CFG_OBD_ON) && (DEM_CFG_OBD_DTC_CONFIG != DEM_CFG_OBD_DTC_CONFIG_OFF)
#define DEM_DTCS_INIT16(OBDCODE) \
{   (OBDCODE) \
}
#endif
/* FC_VariationPoint_END */

#define DEM_DTCS_INIT32(CODE) \
{   (CODE) \
}



typedef struct {
   uint8 kind_severity_storage;
   uint8 Functional_Unit;
} Dem_DtcParam8;

/* FC_VariationPoint_START */
#if (DEM_CFG_OBD == DEM_CFG_OBD_ON) && (DEM_CFG_OBD_DTC_CONFIG != DEM_CFG_OBD_DTC_CONFIG_OFF)
typedef struct {
   uint16 ObdCode;
} Dem_DtcParam16;
#endif
/* FC_VariationPoint_END */

typedef struct {
   Dem_DtcCodeType code;
} Dem_DtcParam32;

typedef struct {
    Dem_DtcCodeType AltDtccode;
    Dem_DtcCodeType Dtccode;
}Dem_DtcAltParam;

/******************************************************************************/
#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

    DEM_ARRAY_DECLARE(Dem_DtcState, Dem_AllDTCsState, DEM_DTCID_ARRAYLENGTH);

#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"

    #if(DEM_CFG_ALTERNATIVEDTC == DEM_CFG_ALTERNATIVEDTC_ON)
    extern boolean Dem_AlternativeDTCEnabled;
    #endif

#define DEM_STOP_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

    DEM_ARRAY_DECLARE_CONST(Dem_DtcParam8, Dem_AllDTCsParam8, DEM_DTCID_ARRAYLENGTH);
    /* FC_VariationPoint_START */
    #if (DEM_CFG_OBD == DEM_CFG_OBD_ON) && (DEM_CFG_OBD_DTC_CONFIG != DEM_CFG_OBD_DTC_CONFIG_OFF)
    DEM_ARRAY_DECLARE_CONST(Dem_DtcParam16, Dem_AllDTCsParam16, DEM_DTCID_ARRAYLENGTH);
    #endif
    /* FC_VariationPoint_END */
    DEM_ARRAY_DECLARE_CONST(Dem_DtcParam32, Dem_AllDTCsParam32, DEM_DTCID_ARRAYLENGTH);
    #if (DEM_CFG_ALTERNATIVEDTC == DEM_CFG_ALTERNATIVEDTC_ON)
    DEM_ARRAY_DECLARE_CONST(Dem_DtcAltParam, Dem_AllAlternativeDTCsParam, DEM_ALTERNATIVE_DTCCODE_ARRAYLENGTH);
    #endif

#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
/******************************************************************************/

/*-- REPORTING STATE ---------------------------------------------------------*/

DEM_INLINE void Dem_DtcSetPassedWasReported (Dem_DtcIdType dtcId, Dem_boolean_least setBit)
{
	DEM_DTCSTATE_OVERWRITEBIT (&Dem_AllDTCsState[dtcId].state, DEM_DTC_BP_STATE_PASSEDWASREPORTED, setBit);
}


DEM_INLINE Dem_boolean_least Dem_DtcWasPassedReported (Dem_DtcIdType dtcId)
{
	return DEM_DTCSTATE_ISBITSET (Dem_AllDTCsState[dtcId].state, DEM_DTC_BP_STATE_PASSEDWASREPORTED);
}
/********DTC SUPPRESION************************************************************/
#if ((DEM_CFG_SUPPRESSION == DEM_DTC_SUPPRESSION) || (DEM_CFG_SUPPRESSION == DEM_EVENT_AND_DTC_SUPPRESSION))
DEM_INLINE void Dem_DtcSuppressionApply (Dem_DtcIdType dtcId, Dem_boolean_least setBit)
{
	DEM_ENTERLOCK_MON();
	DEM_DTCSTATE_OVERWRITEBIT (&Dem_AllDTCsState[dtcId].state, DEM_DTC_BP_STATE_SUPPRESSED, setBit);
	DEM_EXITLOCK_MON();
}
#endif

#if ((DEM_CFG_SUPPRESSION == DEM_DTC_SUPPRESSION) || (DEM_CFG_SUPPRESSION == DEM_EVENT_AND_DTC_SUPPRESSION))
DEM_INLINE Dem_boolean_least Dem_IsEventMemoryEntryExistForDTC (Dem_DtcIdType dtcId)
{
	uint8 DtcStatusByte = Dem_DtcStatusByteRetrieve(dtcId);

	/**
	 * Checking, whether TestFailed or TestFailedSLC bit is set
	 * (To make sure that corresponding DTC already processed and available in Event memory)
	 */
	if(Dem_ISO14229ByteIsTestFailed(DtcStatusByte) || Dem_ISO14229ByteIsTestFailedSLC(DtcStatusByte))
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}
#endif

DEM_INLINE Dem_boolean_least Dem_DtcIsSuppressed (Dem_DtcIdType dtcId)
{
#if ((DEM_CFG_SUPPRESSION == DEM_DTC_SUPPRESSION) || (DEM_CFG_SUPPRESSION == DEM_EVENT_AND_DTC_SUPPRESSION))
	return DEM_DTCSTATE_ISBITSET (Dem_AllDTCsState[dtcId].state, DEM_DTC_BP_STATE_SUPPRESSED);
#else
	DEM_UNUSED_PARAM(dtcId);
	return FALSE;
#endif
}

/***********************************************************************************/

/*-- AVAILABILITY ------------------------------------------------------------*/

#if (DEM_CFG_DTCAVAILABILITY != DEM_CFG_DTCAVAILABILITY_OFF)
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
Dem_boolean_least Dem_DtcAreEventsAssigned (Dem_DtcIdType dtcId);
void Dem_DtcAutoConfAvailability(void);
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
DEM_INLINE void Dem_DtcSetAvailable (Dem_DtcIdType dtcId, Dem_boolean_least setBit)
{
	DEM_ENTERLOCK_MON();
	DEM_DTCSTATE_OVERWRITEBIT (&Dem_AllDTCsState[dtcId].state, DEM_DTC_BP_STATE_UNAVAILABLE, !setBit);
	DEM_EXITLOCK_MON();
}

#else

DEM_INLINE void Dem_DtcAutoConfAvailability(void) {}

#endif


DEM_INLINE Dem_boolean_least Dem_DtcIsAvailable (Dem_DtcIdType dtcId)
{
#if (DEM_CFG_DTCAVAILABILITY != DEM_CFG_DTCAVAILABILITY_OFF)
	return !DEM_DTCSTATE_ISBITSET (Dem_AllDTCsState[dtcId].state, DEM_DTC_BP_STATE_UNAVAILABLE);
#else
	return TRUE;
#endif
}

DEM_INLINE Dem_boolean_least Dem_DtcIsSupported (Dem_DtcIdType dtcID)
{
	return (Dem_isDtcIdValid(dtcID)
#if((DEM_CFG_SUPPRESSION == DEM_DTC_SUPPRESSION) || (DEM_CFG_SUPPRESSION == DEM_EVENT_AND_DTC_SUPPRESSION))
			&& (!Dem_DtcIsSuppressed(dtcID))
#endif
#if(DEM_CFG_DTCAVAILABILITY == DEM_CFG_DTCAVAILABILITY_ONANDAFFECTVALIDITY)
			&& (Dem_DtcIsAvailable(dtcID))
#endif
	);
}

/******************* Alternative DTC Enabled ***********************************/
#if (DEM_CFG_ALTERNATIVEDTC == DEM_CFG_ALTERNATIVEDTC_ON)
DEM_INLINE Dem_boolean_least Dem_DtcHasAlternativeDTCConfigured (Dem_DtcIdType dtcId)
{
   return (Dem_boolean_least)((Dem_AllDTCsParam8[dtcId].kind_severity_storage & DEM_DTCS_ALTERNATIVEDTC_FLAG) != 0u);
}
#endif
/******************************************************************************/

/*-- DTC CODE ----------------------------------------------------------------*/
DEM_INLINE Dem_DtcCodeType Dem_DtcGetCode (Dem_DtcIdType dtcId)
{
#if (DEM_CFG_ALTERNATIVEDTC == DEM_CFG_ALTERNATIVEDTC_ON)
    if(Dem_DtcHasAlternativeDTCConfigured(dtcId))
    {
        if (Dem_AlternativeDTCEnabled)
        {
            return Dem_AllAlternativeDTCsParam[Dem_AllDTCsParam32[dtcId].code].AltDtccode;
        }
        else
        {
            return Dem_AllAlternativeDTCsParam[Dem_AllDTCsParam32[dtcId].code].Dtccode;
        }
    }
    else
#endif
    {
        return Dem_AllDTCsParam32[dtcId].code;
    }
}


/* FC_VariationPoint_START */
#if (DEM_CFG_OBD == DEM_CFG_OBD_ON) && (DEM_CFG_OBD_DTC_CONFIG != DEM_CFG_OBD_DTC_CONFIG_OFF)

DEM_INLINE Dem_DtcCodeType Dem_DtcGetOBDCode (Dem_DtcIdType dtcId)
{
    return Dem_AllDTCsParam16[dtcId].ObdCode;
}

#endif
/* FC_VariationPoint_END */



Dem_DtcIdType Dem_DtcIdFromDtcCode (Dem_DtcCodeType dtcCode);

DEM_INLINE Dem_DTCKindType Dem_DtcGetKind (Dem_DtcIdType dtcId)
{
    return Dem_AllDTCsParam8[dtcId].kind_severity_storage & DEM_DTCS_KINDMASK;
}

DEM_INLINE Dem_DTCSeverityType Dem_DtcGetSeverity (Dem_DtcIdType dtcId)
{
    return ((Dem_DTCSeverityType)(Dem_AllDTCsParam8[dtcId].kind_severity_storage & DEM_DTCS_SEVERITYMASK));
}
DEM_INLINE uint8 Dem_DtcGetFuncUnit (Dem_DtcIdType dtcId)
{
    return Dem_AllDTCsParam8[dtcId].Functional_Unit;
}

DEM_INLINE Dem_boolean_least Dem_DtcGetImmediateNvStorage (Dem_DtcIdType dtcId)
{
    return (Dem_boolean_least)((Dem_AllDTCsParam8[dtcId].kind_severity_storage & DEM_DTCS_NVSTORAGEMASK) != 0u);
}


DEM_INLINE Dem_boolean_least Dem_EventUsesOrigin (Dem_EventIdType eventId, Dem_DTCOriginType origin)
{
	if (   ((origin == DEM_DTC_ORIGIN_PRIMARY_MEMORY) && Dem_EvtIsDestPrimaryMemory(eventId))
			|| ((origin == DEM_DTC_ORIGIN_SECONDARY_MEMORY) && Dem_EvtIsDestSecondaryMemory(eventId))
			|| ((origin == DEM_DTC_ORIGIN_MIRROR_MEMORY) && Dem_EvtIsDestMirrorMemory(eventId))
/* FC_VariationPoint_START */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
			|| ((origin == DEM_DTC_ORIGIN_PERMANENT_MEMORY) && (Dem_DtcGetKind(Dem_DtcIdFromEventId(eventId)) == DEM_DTC_KIND_EMISSION_REL_DTCS))
#endif
/* FC_VariationPoint_END */
	)
	{
		return TRUE;
	}
	return FALSE;
}

DEM_INLINE Dem_boolean_least Dem_DtcUsesOrigin (Dem_DtcIdType dtcId, Dem_DTCOriginType origin)
{
    Dem_EventIdType eventId = Dem_DtcIdGetFirstEventId(dtcId);
    return Dem_EventUsesOrigin(eventId, origin);
}


/*************************Enable & DiableDTCGroup****************************************************/
void Dem_DtcSetDTCSetting (Dem_DtcIdType dtcId, Dem_boolean_least setBit);


DEM_INLINE Dem_boolean_least Dem_DtcIsDTCSettingEnabled(Dem_DtcIdType dtcId)
{
	return (!(DEM_DTCSTATE_ISBITSET (Dem_AllDTCsState[dtcId].state, DEM_DTC_BP_GROUP_DTCSETTING_DISABLED)));
}

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
/*************************CheckDTCSettingStatus****************************************************/

Dem_boolean_least Dem_IsEventEnabledByDtcSetting(Dem_EventIdType EventId);

DEM_INLINE Dem_boolean_least Dem_IsEventReportingEnabledByDtcSetting(Dem_EventIdType EventId)
{
#if (DEM_CFG_DTCSETTINGBLOCKSREPORTING)
    return Dem_IsEventEnabledByDtcSetting(EventId);
#else
    DEM_UNUSED_PARAM(EventId);
    return TRUE;
#endif
}

DEM_INLINE Dem_boolean_least Dem_IsEventStorageEnabledByDtcSetting(Dem_EventIdType EventId)
{
#if (DEM_CFG_DTCSETTINGBLOCKSREPORTING)
    DEM_UNUSED_PARAM(EventId);
    return TRUE;
#else
    return Dem_IsEventEnabledByDtcSetting(EventId);
#endif
}


/****************************************************************************************************/

sint8 Dem_DtcFaultDetectionRetrieve (Dem_DtcIdType dtcId);


/**
 * @ingroup DEM_H
 *
 * Gets the Fault detection counter of the specified dtcCode.
 * @param[in]  dtcCode - defines the mapping DtcCode from which a DTC Id shall be retrieved.
 * @param[out] FaultDetectionCounter - theFault Detection Counter for the specified dtcCode.
 * @return  E_OK:When valid dtcCode is passed and also when the pointer argument is not a null pointer\n
 *          E_NOT_OK:When either an invalid dtcCode is passed or when the pointer argument is a null pointer
 */
Std_ReturnType Dem_GetDtcFaultDetectionCounter(Dem_DtcCodeType dtcCode, sint8* FaultDetectionCounter);


/**
 * @ingroup DEM_H
 *
 * Dem230: Gets the supported DTC formats of the ECU. The supported formats
 *         are configured via DemTypeOfDTCSupported.
 * @return Returns the configured DTC translation format. A combination of
 *         different DTC formats is not possible.
 *
 * @note  The only supported DTC translation format is currently ISO14229-1
 */
Dem_DTCTranslationFormatType Dem_GetTranslationType(void);


/**
 * @ingroup DEM_H
 *
 * Dem213: Gets the DTC Status availability mask.
 * @param[out]  DTCStatusMask   The value DTCStatusMask indicates the supported DTC
 *                              status bits from the Dem. All supported information
 *                              is indicated by setting the corresponding status bit
 *                              to 1. See ISO14229-1.
 * @return  E_OK: get of DTC status mask was successful\n
 *          E_NOT_OK: get of DTC status mask failed
 */
Std_ReturnType Dem_GetDTCStatusAvailabilityMask(uint8* DTCStatusMask);


/**
 * @ingroup DEM_H
 *
 * Dem232: Gets the severity of the requested DTC.
 * @param[in]  DTC  The Severity assigned to this DTC should be returned.
 * @param[out]  DTCSeverity  This parameter contains the DTCSeverityMask according to ISO14229-1.
 * @return  Status of the operation of type Dem_ReturnGetSeverityOfDTCType.
 */
Dem_ReturnGetSeverityOfDTCType Dem_GetSeverityOfDTC(uint32 DTC, Dem_DTCSeverityType* DTCSeverity);


/**
 * @ingroup DEM_H
 *
 * Dem594: Gets the functional unit of the requested DTC.
 * @param[in]  DTC  Diagnostic Trouble Code.
 * @param[out]  DTCFunctionalUnit  Functional unit value of this DTC.
 * @return  Status of the operation of type Dem_ReturnGetFunctionalUnitOfDTCType.
 */
Dem_ReturnGetFunctionalUnitOfDTCType Dem_GetFunctionalUnitOfDTC (uint32 DTC, uint8* DTCFunctionalUnit);


/**
 * @ingroup DEM_EXT_H
 *
 * Function to Enable Alternative DtcCode during startup.
 */
#if (DEM_CFG_ALTERNATIVEDTC == DEM_CFG_ALTERNATIVEDTC_ON)
void Dem_SwitchToAlternativeDtc(void);
#endif
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif
/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.10.0.0; 6     14.07.2015 WUG3ABT
 *   Checkout by wug3abt
 * 
 * AR40.10.0.0; 5     10.07.2015 CLH2SI
 *   CSCRM00938605
 * 
 * AR40.10.0.0; 4     06.07.2015 VSA2COB
 *   CSCRM00830308
 * 
 * AR40.10.0.0; 3     01.07.2015 CLH2SI
 *   CSCRM00649773
 * 
 * AR40.10.0.0; 2     17.06.2015 VSA2COB
 *   CSCRM00880343
 * 
 * AR40.10.0.0; 1     04.06.2015 MVA2COB
 *   CSCRM00777583
 * 
 * AR40.10.0.0; 0     16.04.2015 CLH2SI
 *   CSCRM00764027
 * 
 * AR40.9.0.0; 3     12.11.2014 CLH2SI
 *   CSCRM00735646
 * 
 * AR40.9.0.0; 2     15.10.2014 GJ83ABT
 *   CSCRM00719089, CSCRM00650337, CSCRM00625552, CSCRM00434933
 * 
 * AR40.9.0.0; 1     22.08.2014 CLH2SI
 *   CSCRM00688436
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
