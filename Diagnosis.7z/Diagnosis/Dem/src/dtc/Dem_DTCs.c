/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_DTCs$
* $Variant___:AR40.11.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/


#include "Dem_DTCs.h"
#include "Dem_Deb.h"
#include "Dem_Events.h"
#include "Dem_EventStatus.h"
#include "Dem_Nvm.h"
#include "Dem_Mapping.h"
#include "Rte_Dem.h"
#include "Dem_Protected.h"
/* FC_VariationPoint_START */
#include "Dem_ObdMain.h"
/* FC_VariationPoint_END */
#include "Dem_DTCGroup.h"
#include "Dem_Cfg_ExtPrototypes.h"


#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

    DEM_ARRAY_DEFINE(Dem_DtcState, Dem_AllDTCsState, DEM_DTCID_ARRAYLENGTH);

#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"

    #if (DEM_CFG_ALTERNATIVEDTC == DEM_CFG_ALTERNATIVEDTC_ON)
    boolean Dem_AlternativeDTCEnabled = FALSE;
    #endif

#define DEM_STOP_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

    DEM_ARRAY_DEFINE_CONST(Dem_DtcParam8, Dem_AllDTCsParam8, DEM_DTCID_ARRAYLENGTH, DEM_CFG_DTCPARAMS8);
    /* FC_VariationPoint_START */
    #if (DEM_CFG_OBD == DEM_CFG_OBD_ON) && (DEM_CFG_OBD_DTC_CONFIG != DEM_CFG_OBD_DTC_CONFIG_OFF)
    DEM_ARRAY_DEFINE_CONST(Dem_DtcParam16, Dem_AllDTCsParam16, DEM_DTCID_ARRAYLENGTH, DEM_CFG_DTCPARAMS16);
    #endif
    /* FC_VariationPoint_END */
    DEM_ARRAY_DEFINE_CONST(Dem_DtcParam32, Dem_AllDTCsParam32, DEM_DTCID_ARRAYLENGTH, DEM_CFG_DTCPARAMS32);
    #if (DEM_CFG_ALTERNATIVEDTC == DEM_CFG_ALTERNATIVEDTC_ON)
    DEM_ARRAY_DEFINE_CONST(Dem_DtcAltParam, Dem_AllAlternativeDTCsParam, DEM_ALTERNATIVE_DTCCODE_ARRAYLENGTH, DEM_CFG_ALTERNATIVE_DTCPARAMS);
    #endif

#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

/*-- AVAILABILITY ------------------------------------------------------------*/
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#if (DEM_CFG_ALTERNATIVEDTC == DEM_CFG_ALTERNATIVEDTC_ON)
void Dem_SwitchToAlternativeDtc(void)
{
	Dem_AlternativeDTCEnabled = TRUE;
}
#endif

#if (DEM_CFG_DTCAVAILABILITY != DEM_CFG_DTCAVAILABILITY_OFF)

Dem_boolean_least Dem_DtcAreEventsAssigned (Dem_DtcIdType dtcId)
{
   Dem_EventIdListIterator eventIt;

   for (Dem_EventIdListIteratorNewFromDtcId(&eventIt, dtcId);
        Dem_EventIdListIteratorIsValid(&eventIt);
        Dem_EventIdListIteratorNext(&eventIt))
   {
      if (Dem_EvtIsConsidered4DTCStatus(Dem_EventIdListIteratorCurrent(&eventIt)))
      {
         return TRUE;
      }
   }
   return  FALSE;
}

void Dem_DtcAutoConfAvailability(void)
{
   Dem_boolean_least hasMons;
   Dem_DtcIdIterator dtcId;
   Dem_DtcIdIteratorNew(&dtcId);

   while (Dem_DtcIdIteratorIsValid(&dtcId))
   {
      hasMons = Dem_DtcAreEventsAssigned ((Dem_DtcIdType)dtcId);
      Dem_DtcSetAvailable ((Dem_DtcIdType)dtcId, hasMons);
      Dem_DtcIdIteratorNext(&dtcId);
   }
}

#endif

/*************************CheckDTCSettingStatus****************************************************/

Dem_boolean_least Dem_IsEventEnabledByDtcSetting(Dem_EventIdType EventId)
{
    if (Dem_EventIdIsDtcAssigned(EventId))
    {
        if(!Dem_DtcIsDTCSettingEnabled(Dem_DtcIdFromEventId(EventId)))
        {
#if(DEM_DTC_DTCSETTING_CALLBACK_SUPPORTED == DEM_DTC_DTCSETTING_CALLBACK_SUPPORTED_ON)
            //invoke the global config callback to get the DTC Disable status
            if(DEM_DTC_CALLBACK_FUNCTION_DISABLE_DTCSETTING_ALLOWED(EventId))
#endif
            {
                return FALSE;
            }
        }
    }
    return TRUE;
}



/*-- DTC CODE ----------------------------------------------------------------*/

Dem_DtcIdType Dem_DtcIdFromDtcCode (Dem_DtcCodeType dtcCode)
{
	Dem_DtcIdIterator dtcId;

	for (Dem_DtcIdIteratorNew(&dtcId);
			Dem_DtcIdIteratorIsValid(&dtcId);
			Dem_DtcIdIteratorNext(&dtcId))
	{
		if (Dem_DtcGetCode(Dem_DtcIdIteratorCurrent(&dtcId)) == dtcCode)
		{
			return Dem_DtcIdIteratorCurrent(&dtcId);
		}
	}
	return DEM_DTCID_INVALID;
}

/*-- PUBLIC INTERFACES -------------------------------------------------------*/

Std_ReturnType Dem_GetDTCOfEvent(Dem_EventIdType EventId, Dem_DTCFormatType DTCFormat, uint32* DTCOfEvent)
{
   Dem_DtcIdType dtcId;

   if (!Dem_isEventIdValid(EventId))
   {
	   return E_NOT_OK;
   }

   if(Dem_EvtIsSuppressed(EventId))
   {
	   return E_NOT_OK;
   }

   if (!Dem_EventIdIsDtcAssigned(EventId))
   {
      return DEM_E_NO_DTC_AVAILABLE;
   }

   dtcId = Dem_DtcIdFromEventId(EventId);

   if (DTCFormat == DEM_DTC_FORMAT_UDS)
   {
      *DTCOfEvent = Dem_DtcGetCode(dtcId);
      return E_OK;
   }
   else if (DTCFormat == DEM_DTC_FORMAT_OBD)
   {
/* FC_VariationPoint_START */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
      *DTCOfEvent = Dem_ObdDtcGetCode(dtcId);
      return E_OK;
#else
/* FC_VariationPoint_END */
      return E_NOT_OK;
/* FC_VariationPoint_START */
#endif
/* FC_VariationPoint_END */
   }
   else
   {
      return E_NOT_OK;
   }
}


Dem_DTCTranslationFormatType Dem_GetTranslationType(void)
{
   return DEM_CFG_DTC_TRANSLATION_TYPE;
}


Std_ReturnType Dem_GetDTCStatusAvailabilityMask(uint8* DTCStatusMask)
{
   *DTCStatusMask = DEM_CFG_DTCSTATUS_AVAILABILITYMASK;
   return E_OK;
}


Dem_ReturnGetSeverityOfDTCType Dem_GetSeverityOfDTC(uint32 DTC, Dem_DTCSeverityType* DTCSeverity)
{
   Dem_DtcIdType dtcId = Dem_DtcIdFromDtcCode(DTC);

   if (!Dem_DtcIsSupported(dtcId))
   {
      return DEM_GET_SEVERITYOFDTC_WRONG_DTC;
   }

   *DTCSeverity = Dem_DtcGetSeverity(dtcId);
   return DEM_GET_SEVERITYOFDTC_OK;
/* FC_VariationPoint_START */
   /* TODO: is it necessary to return DEM_GET_SEVERITYOFDTC_NOSEVERITY? */
/* FC_VariationPoint_END */
}


Dem_ReturnGetFunctionalUnitOfDTCType Dem_GetFunctionalUnitOfDTC (uint32 DTC, uint8* DTCFunctionalUnit)
{
   Dem_DtcIdType dtcId = Dem_DtcIdFromDtcCode(DTC);

   if (!Dem_DtcIsSupported(dtcId))
   {
      return DEM_GET_FUNCTIONALUNITOFDTC_WRONG_DTC;
   }

   *DTCFunctionalUnit = Dem_DtcGetFuncUnit(dtcId);
   return DEM_GET_FUNCTIONALUNITOFDTC_OK;
}

Std_ReturnType Dem_SetDTCSuppression (uint32 DTC, Dem_DTCFormatType DTCFormat, boolean SuppressionStatus)
{
#if ((DEM_CFG_SUPPRESSION == DEM_DTC_SUPPRESSION) || (DEM_CFG_SUPPRESSION == DEM_EVENT_AND_DTC_SUPPRESSION))

	Dem_DtcIdType dtcId = Dem_DtcIdFromDtcCode(DTC);

   if (DTCFormat == DEM_DTC_FORMAT_UDS)
   {
      dtcId = Dem_DtcIdFromDtcCode(DTC);
   }
   else /* DEM_DTC_FORMAT_OBD */
   {
      /* not implemented, DEM specification not clear eg: regarding handling of readiness */
	  return E_NOT_OK;
   }

	/**
	 * Dem588: The API Dem_SetDTCSuppression shall reject the request and return E_NOT_OK,
	 * if the event memory entry exists already.
	 */
	if ((!Dem_isDtcIdValid(dtcId)) || (Dem_IsEventMemoryEntryExistForDTC(dtcId)))
	{
		return E_NOT_OK;
	}
	else
	{
		Dem_DtcSuppressionApply(dtcId, SuppressionStatus);
		return E_OK;
	}
#else
	DEM_UNUSED_PARAM(DTC);
	DEM_UNUSED_PARAM(DTCFormat);
	DEM_UNUSED_PARAM(SuppressionStatus);
	return E_NOT_OK;
#endif
}




/***************************************************/
/* DtcLevel Fault Detection Counter */
/***************************************************/

sint8 Dem_DtcFaultDetectionRetrieve (Dem_DtcIdType dtcId)
{
	Dem_EventIdListIterator eventIt;
	Dem_EventIdType eventId;
	sint8 faultDetectionCtrVal=0;
	sint8 maxFaultDetectionCtrVal = -128;

	if ((Dem_DtcIsAvailable(dtcId)) && (!Dem_DtcIsSuppressed(dtcId)))
	{
		for (Dem_EventIdListIteratorNewFromDtcId(&eventIt, dtcId);
				Dem_EventIdListIteratorIsValid(&eventIt);
				Dem_EventIdListIteratorNext(&eventIt))
		{
			eventId = Dem_EventIdListIteratorCurrent(&eventIt);
			if (Dem_GetFaultDetectionCounter(eventId, &faultDetectionCtrVal) != E_OK)
			{
			    faultDetectionCtrVal = 0;
			}
			DEM_A_MAX_AB(maxFaultDetectionCtrVal, faultDetectionCtrVal);
		}
	}
	return maxFaultDetectionCtrVal;
}
/***************************************************/
/* DtcFault Detection Counter based on dtcCode */
/***************************************************/

Std_ReturnType Dem_GetDtcFaultDetectionCounter(Dem_DtcCodeType dtcCode, sint8* FaultDetectionCounter)
{
    Dem_DtcIdType dtcId;

    if( FaultDetectionCounter != NULL_PTR )
    {
        dtcId = Dem_DtcIdFromDtcCode(dtcCode);

        if( Dem_isDtcIdValid(dtcId) )
        {
            *FaultDetectionCounter = Dem_DtcFaultDetectionRetrieve(dtcId);
            return E_OK;
        }
    }

    return E_NOT_OK;
}



void Dem_DtcSetDTCSetting (Dem_DtcIdType dtcId, Dem_boolean_least setBit)
{
    Dem_EventIdListIterator eventIt;

    DEM_ENTERLOCK_MON();
    DEM_DTCSTATE_OVERWRITEBIT (&Dem_AllDTCsState[dtcId].state, DEM_DTC_BP_GROUP_DTCSETTING_DISABLED, setBit);

    if (!setBit)
    {
        for (Dem_EventIdListIteratorNewFromDtcId(&eventIt, dtcId);
                Dem_EventIdListIteratorIsValid(&eventIt);
                Dem_EventIdListIteratorNext(&eventIt))
        {
            Dem_EvtSt_HandleDTCSettingOn(Dem_EventIdListIteratorCurrent(&eventIt));
        }
    }

    DEM_EXITLOCK_MON();
}


#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 1     07.01.2016 TVE5COB
*   CSCRM01017790
* 
* AR40.11.0.0; 0     17.09.2015 UDKOEGEL
*   CSCRM00960004
* 
* AR40.10.0.0; 3     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 2     10.07.2015 CLH2SI
*   CSCRM00938605
* 
* AR40.10.0.0; 1     01.07.2015 CLH2SI
*   CSCRM00649773
* 
* AR40.10.0.0; 0     17.06.2015 VSA2COB
*   CSCRM00880343
* 
* AR40.9.0.0; 2     15.10.2014 GJ83ABT
*   CSCRM00719089, CSCRM00650337, CSCRM00625552, CSCRM00434933
* 
* AR40.9.0.0; 1     22.08.2014 CLH2SI
*   CSCRM00688436
* 
* AR40.9.0.0; 0     18.08.2014 BPE4COB
*   CSCRM00672665
* 
* AR40.8.0.0; 3     16.06.2014 GJ83ABT
*   CSCRM00615634, CSCRM00671513
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
