/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:C$
 * $Name______:Dem_DTCStateManager$
 * $Variant___:AR40.10.0.0$
 * $Revision__:2$
 **********************************************************************************************************************
</BASDKey>*/


#include "Dem_DTCs.h"
#include "Dem_DTCStatusByte.h"
#include "Dem_EvBuff.h"
#include "Dem_EvMem.h"
#include "Dem_DTCStateManager.h"
#include "Dem_EventStatus.h"
#include "Dem_ObdMain.h"



#define DEM_DTCSTATEMANGER_DTCS_PER_CYCLE   (((DEM_DTCID_ARRAYLENGTH) / 20u) +1u)




DEM_INLINE  Dem_boolean_least Dem_DtcIsFaulty (Dem_DtcIdType dtcId)
{
    Dem_EventIdListIterator it;

    for (Dem_EventIdListIteratorNewFromDtcId(&it, dtcId);
            Dem_EventIdListIteratorIsValid(&it);
            Dem_EventIdListIteratorNext(&it))
    {
        if (Dem_EvtIsCausal(Dem_EventIdListIteratorCurrent(&it)))
        {
            return TRUE;
        }
    }

    return FALSE;
}


#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
void Dem_DtcStateManagerReport (const Dem_EvBuffEvent* fe)
{
    Dem_DtcIdType dtcID;

#if (DEM_CFG_EVBUFF_STORES_ENVDATA == DEM_CFG_EVBUFF_STORES_ENVDATA_OFF)
    uint8 envData[DEM_CFG_ENVMINSIZE_OF_RAWENVDATA];
#else
    const uint8 *envData;
    envData = (fe->envData);
#endif

    dtcID = Dem_DtcIdFromEventId(fe->eventId);

    if (Dem_isDtcIdValid(dtcID)) // && Dem_IsEventStorageEnabledByDtcSetting(fe->eventId)) probably avoid storage in case of DTCSettingDisabled and DTCSetting does NOT block systemreaction
    {
#if (DEM_CFG_EVBUFF_STORES_ENVDATA == DEM_CFG_EVBUFF_STORES_ENVDATA_OFF)
        Dem_EnvCaptureED(fe->eventId, envData, DEM_CFG_ENVMINSIZE_OF_RAWENVDATA DEM_DEBUGDATA_PARAM(fe->debug0,fe->debug1));
        Dem_EnvCaptureFF(fe->eventId, envData, DEM_CFG_ENVMINSIZE_OF_RAWENVDATA DEM_DEBUGDATA_PARAM(fe->debug0,fe->debug1));
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
        Dem_ObdFFCaptureFF(fe->eventId, envData, DEM_CFG_ENVMINSIZE_OF_RAWENVDATA DEM_DEBUGDATA_PARAM(fe->debug0,fe->debug1));
#endif
#endif
        if (   (fe->eventType == C_EVENTTYPE_SET)
                || (fe->eventType == C_EVENTTYPE_SET_RESET)
#if (DEM_CFG_DTCSTOREWAITINGFORMONITORING == DEM_CFG_DTCSTOREWAITINGFORMONITORING_ON)
                || (fe->eventType == C_EVENTTYPE_SET_WAITINGFORMONITORING)
#endif
        )
        {

            Dem_EvMemSetEventFailedAllMem(fe->eventId, envData);
        }

        if (   (fe->eventType == C_EVENTTYPE_RESET)
                || (fe->eventType == C_EVENTTYPE_SET_RESET)
        )
        {
            if (   !Dem_DtcIsFaulty(Dem_DtcIdFromEventId(fe->eventId))
                    || (DEM_CFG_EVCOMB != DEM_CFG_EVCOMB_TYPE1)
            )
            {
                Dem_EvMemSetEventPassedAllMem(fe->eventId, envData);
            }
        }

        if (fe->eventType == C_EVENTTYPE_UNROBUST)
        {
            Dem_EvMemSetEventUnRobustAllMem(fe->eventId, envData);
        }
    }
}




void Dem_DtcStateManagerMainFunction(void)
{
    Dem_boolean_least NONE_Failed = TRUE;
    Dem_boolean_least ALL_TestComplete = TRUE;

    Dem_EventIdListIterator eventIt;
    Dem_EventIdType eventId;

    static Dem_DtcIdIterator dtcIt = DEM_DTCIDITERATOR_NEW();
    uint32_least i;

    uint8 tempEnvBuffer[DEM_CFG_ENVMINSIZE_OF_RAWENVDATA];

    for (i = 0; i<DEM_DTCSTATEMANGER_DTCS_PER_CYCLE; i++)
    {
        if (Dem_DtcWasPassedReported(Dem_DtcIdIteratorCurrent(&dtcIt)))
        {
            DEM_ENTERLOCK_MON();
            Dem_DtcSetPassedWasReported (Dem_DtcIdIteratorCurrent(&dtcIt), FALSE);
            DEM_EXITLOCK_MON();

            for (Dem_EventIdListIteratorNewFromDtcId (&eventIt, Dem_DtcIdIteratorCurrent(&dtcIt));
                    Dem_EventIdListIteratorIsValid (&eventIt);
                    Dem_EventIdListIteratorNext (&eventIt))
            {
                eventId = Dem_EventIdListIteratorCurrent (&eventIt);
                if (!Dem_EvtIsSuppressed(eventId))
                {
                    NONE_Failed      = NONE_Failed  && (!Dem_EvtSt_GetTestFailed(eventId));
                    ALL_TestComplete = ALL_TestComplete &&  (Dem_EvtSt_GetTestCompleteTOC(eventId));

                    if (!(NONE_Failed && ALL_TestComplete))
                    {
                        return;
                    }
                }
            }

            eventId = Dem_DtcIdGetFirstEventId(Dem_DtcIdIteratorCurrent(&dtcIt));
            Dem_EnvCaptureED(eventId, tempEnvBuffer, DEM_CFG_ENVMINSIZE_OF_RAWENVDATA DEM_DEBUGDATA_PARAM(0,0));
            Dem_EnvCaptureFF(eventId, tempEnvBuffer, DEM_CFG_ENVMINSIZE_OF_RAWENVDATA DEM_DEBUGDATA_PARAM(0,0));
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
            Dem_ObdFFCaptureFF(eventId, tempEnvBuffer, DEM_CFG_ENVMINSIZE_OF_RAWENVDATA DEM_DEBUGDATA_PARAM(0,0));
#endif
         if(Dem_IsEventStorageEnabledByDtcSetting (eventId))
         {
             Dem_EvMemSetEventPassedAllMem(eventId, tempEnvBuffer);
         }
      }

        Dem_DtcIdIteratorNext(&dtcIt);
        if (!Dem_DtcIdIteratorIsValid(&dtcIt))
        {
            Dem_DtcIdIteratorNew(&dtcIt);
            break;
        }
    }
}
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


/*
void DTCStateManager__reInitAllDTCs (void)
{
   DEM_ENTERLOCK_MON();

   Dem_BitArrayClearAll (DEM_BITARRAY_ADDRESS(DTCStateManager__failureStateReported2FM), DEM_DTCID_ARRAYLENGTH);

   DEM_EXITLOCK_MON();
}


void DTCStateManager__reInitDTC (DTCID dtcID)
{
   Dem_BitArrayClearBit (DEM_BITARRAY_ADDRESS(DTCStateManager__failureStateReported2FM), dtcID);
}
 */

/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.10.0.0; 2     14.07.2015 WUG3ABT
 *   Checkout by wug3abt
 * 
 * AR40.10.0.0; 1     01.07.2015 TVE5COB
 *   CSCRM00825249
 * 
 * AR40.10.0.0; 0     16.04.2015 CLH2SI
 *   CSCRM00764027
 * 
 * AR40.9.0.0; 1     15.10.2014 GJ83ABT
 *   CSCRM00719089, CSCRM00650337, CSCRM00625552, CSCRM00434933
 * 
 * AR40.9.0.0; 0     22.08.2014 CLH2SI
 *   CSCRM00688436
 * 
 * AR40.8.0.0; 5     18.07.2014 VSA2COB
 *   CSCRM00635984
 * 
 * AR40.8.0.0; 4     16.07.2014 BRM2COB
 *   CSCRM00688243
 * 
 * AR40.8.0.0; 3     17.04.2014 CLH2SI
 *   CSCRM00649098
 * 
 * AR40.8.0.0; 2     12.04.2014 BRM2COB
 *   CSCRM00645692
 * 
 * AR40.8.0.0; 1     18.03.2014 NAL2KOR
 *   CSCRM00633565_EventSuppression
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
