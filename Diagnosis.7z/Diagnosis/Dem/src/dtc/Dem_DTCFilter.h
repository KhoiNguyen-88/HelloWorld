/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_DTCFilter$
* $Variant___:AR40.10.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_DTCFILTER_H
#define DEM_DTCFILTER_H


#include "Dem_Types.h"
#include "Dem_DTCs.h"
#include "Dem_DTCStatusByte.h"

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"
    DEM_BITARRAY_DECLARE  (Dem_DTCFilterMatching,DEM_DTCID_ARRAYLENGTH);
#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

void Dem_DtcFilterInit(void);

void Dem_DTCFilterMainFunction(void);


/**
 * @ingroup DEM_H
 *
 * Dem208: The function Dem_SetDTCFilter (refer to chapter 8.3.4.1.1) shall set the filter mask
 *         attributes to be used for the sub-sequent calls of @ref Dem_GetNumberOfFilteredDTC,
 *         @ref Dem_GetNextFilteredDTC, @ref Dem_GetNextFilteredDTCAndFDC, as well as
 *         @ref Dem_GetNextFilteredDTCAndSeverity.
 *
 * @param[in]  DTCStatusMask  According ISO14229-1 StatusOfDTC Values:\n
 *                            0x00: Report all supported DTCs\n
 *                            0x01...0xFF: Match DTCStatusMask as defined in ISO14229-1
 * @param[in]  DTCKind  Defines the functional group of DTCs to be reported
 *                      (e.g. all DTC, OBD-relevant DTC)
 * @param[in]  DTCFormat  Defines the output-format of the requested DTC values for the sub-sequent API calls.
 * @param[in]  DTCOrigin  If the Dem supports more than one event memory this parameter
 *                        is used to select the source memory the DTCs shall be read from.
 * @param[in]  FilterWithSeverity  This flag defines whether severity information (ref. to
 *                                 parameter below) shall be used for filtering. This is to
 *                                 allow for coexistence of DTCs with and without severity information.
 * @param[in]  DTCSeverityMask  This parameter contains the DTCSeverityMask according to ISO14229-1
 *                              (see for example Service 0x19, subfunction 0x08)
 * @param[in]  FilterForFaultDetectionCounter  This flag defines whether the fault detection counter
 *                                             information shall be used for filtering. This is to
 *                                             allow for coexistence of DTCs with and without fault
 *                                             detection counter information. If fault detection counter
 *                                             information is filter criteria, only those DTCs with a
 *                                             fault detection counter value between 1 and 0x7E shall
 *                                             be reported. Remark: If the event does not use the
 *                                             debouncing inside Dem, then the Dem must request this
 *                                             information via GetFaultDetectionCounter.
 * @return  Status of the operation to (re-)set a DTC filter.
 */

Dem_ReturnSetFilterType Dem_SetDTCFilter (uint8 DTCStatusMask,
                                          Dem_DTCKindType DTCKind,
                                          Dem_DTCFormatType DTCFormat,
                                          Dem_DTCOriginType DTCOrigin,
                                          Dem_FilterWithSeverityType FilterWithSeverity,
                                          Dem_DTCSeverityType DTCSeverityMask,
                                          Dem_FilterForFDCType FilterForFaultDetectionCounter);


/**
 * @ingroup DEM_H
 *
 * Dem215: Gets the next filtered DTC.
 *
 * @param[out]  DTC  Receives the DTC value returned by the function. If the return value of the
 *                   function is other than DEM_FILTERED_OK this parameter does not contain valid data.
 * @param[out]  DTCStatus  This parameter receives the status information of the requested DTC. It
 *                         follows the format as defined in ISO14229-1 If the return value of the function
 *                         call is other than DEM_FILTERED_OK this parameter does not contain valid data.
 * @return  Status of the operation to retrieve a DTC from the Dem.
 * @see Dem_SetDTCFilter
 */
Dem_ReturnGetNextFilteredDTCType Dem_GetNextFilteredDTC(uint32* DTC, uint8* DTCStatus);


/**
 * @ingroup DEM_H
 *
 * Dem281: Gets the current DTC and its Severity from the Dem.
 *
 * @param[out]  DTC  Receives the DTC value returned by the function. If the return value of the function
 *                   is other than DEM_FILTERED_OK this parameter does not contain valid data.
 * @param[out]  DTCStatus  Receives the status value returned by the function. If the return value
 *                         of the function is other than DEM_FILTERED_OK this parameter does not
 *                         contain valid data.
 * @param[out]  Dem_DTCSeverityType  Receives the severity value returned by the function. If the
 *                                   return value of the function is other than DEM_FILTERED_OK this
 *                                   parameter does not contain valid data.
 * @param[out]  DTCFunctionalUnit  Receives the functional unit value returned by the function. If
 *                                 the return value of the function is other than DEM_FILTERED_OK
 *                                 this parameter does not contain valid data.
 * @return  Status of the operation to retrieve a DTC from the Dem.
 * @see Dem_SetDTCFilter
 */
Dem_ReturnGetNextFilteredDTCType Dem_GetNextFilteredDTCAndSeverity (uint32* DTC, uint8* DTCStatus, Dem_DTCSeverityType* DTCSeverity, uint8* DTCFunctionalUnit);

/**
 * @ingroup DEM_H
 *
 * Dem214: Gets the number of a filtered DTC.
 *
 * @param[out]  NumberOfFilteredDTC  The number of DTCs matching the defined status mask.
 * @return  Status of the operation to retrieve a number of DTC from the Dem.
 */
Dem_ReturnGetNumberOfFilteredDTCType Dem_GetNumberOfFilteredDTC(uint16* NumberOfFilteredDTC);

/**
 * @ingroup DEM_H
 *
 * Dem227: Gets the current DTC and its associated Fault Detection Counter (FDC) from the Dem. The interface has an
 *         asynchronous behavior, because the FDC might be received asynchronously from a SW-C, too.
 *
 * @param[out]  DTC : Receives the DTC value returned by the function. If the return value of the function is
 *                    other than DEM_FILTERED_OK this parameter does not contain valid data.
 * @param[out]  DTCFaultDetectionCounter : This parameter receives the Fault Detection Counter information of the
 *                    requested DTC. If the return value of the function call is other than DEM_FILTERED_OK this
 *                    parameter does not contain valid data.
 * @return  Dem_ReturnGetNextFilteredDTCType : Status of the operation to retrieve a DTC from the Dem.
 */
Dem_ReturnGetNextFilteredDTCType Dem_GetNextFilteredDTCAndFDC (uint32* DTC, sint8* DTCFaultDetectionCounter);
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 1     10.07.2015 CLH2SI
*   CSCRM00938605
* 
* AR40.10.0.0; 0     04.07.2015 BPE4COB
*   CSCRM00835665
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 1     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 0     19.11.2013 BRM2COB
*   
* 
* AR40.5.0.0; 5     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.5.0.0; 4     07.01.2013 KAN1COB
*   Git transfer - >c7b60f6605db2476a382daf05b17f6c7f088f2d2
*   Fix- Obd Drv cycle and warmup cyce not configured in operationcycles
*   * CSCRM00479194 - [INT-Dem] pending review findings from CSCRM00434163
*   CSCRM00483492 - [INT-Dem] Fix findings -Vendor Specific parameters optional
*   CSCRM00479560 - [INT-DEM] Issue from PAC_DevDiagnosis November build
*   CSCRM00479557 - [INT-DEM] Remove compilation warnings
*   CSCRM00484190 - [INT-Dem] Fix Medium/Strong review findings
*   CSCRM00484194 - [INT-Dem] Fix Medium/Strong review findings
*   CSCRM00480461 : Fix Reviewfindings : 
*   Review12_636_COMP_Dem_AR40_5_2012-10_3.xls
*   CSCRM00482583: OBD: Fix review findings
*   Changes during code analysis of Defect CSCRM00467070 (DemClearDTCBehavior)
*   QAC-warning
*   
*   CSCRM00479820 - [INT-FIM] Fix review findings
*   CSCRM00479857 - [INT - FIM] remove BCT errors and warnings shown in 
*   problemes log
* 
* AR40.5.0.0; 3     30.11.2012 KAN1COB
*   See: check in comment ofCOMP: DEM40.5_2012-11;5
* 
* AR40.5.0.0; 2     02.11.2012 CRA1COB
*   GiT to eASEE
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
