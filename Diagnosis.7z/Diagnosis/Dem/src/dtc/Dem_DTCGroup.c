/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_DTCGroup$
* $Variant___:AR40.10.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/

#include "Dem_DTCGroup.h"
#include "Dem_DTCs.h"
#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
DEM_ARRAY_DEFINE_CONST(Dem_DtcGroupParam, Dem_AllDTCGroupsParam, DEM_DTCGROUPID_ARRAYLENGTH, DEM_CFG_DTCGROUPPARAMS);
#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
/*-- DTC GROUP CODE-------------------------------------------------------------*/


DEM_INLINE void Dem_DtcGroupApplyDTCSetting(Dem_DTCGroupType DTCGroup, uint8 groupId, boolean newDtcSettingState)
{

	Dem_DtcIdListIterator dtcIt;

	if(DTCGroup != DEM_DTC_GROUP_EMISSION_REL_DTCS)
	{
		for (Dem_DtcIdListIteratorNewFromDtcGroup(&dtcIt, groupId);
				Dem_DtcIdListIteratorIsValid(&dtcIt);
				Dem_DtcIdListIteratorNext(&dtcIt))
		{
			Dem_DtcSetDTCSetting(Dem_DtcIdListIteratorCurrent(&dtcIt), newDtcSettingState);
		}
	}
	else
	{
		Dem_DtcIdIterator dtcId = DEM_DTCIDITERATOR_NEW();
		/*
		 * looping through all DTCs and if DTCKind configured as DEM_DTC_KIND_EMISSION_REL_DTCS(OBD-relevant DTCs) shall be enabled or disabled.
		 * DTCgroup iterator function shall not be considered here because zeroth index is considered as INVALID
		 * and DEM_DTC_GROUP_EMISSION_REL_DTCS(0x000000) is not from configuration.
		 */
		for (Dem_DtcIdIteratorNew(&dtcId); Dem_DtcIdIteratorIsValid(&dtcId);Dem_DtcIdIteratorNext(&dtcId))
		{
			if(Dem_DtcGetKind(Dem_DtcIdIteratorCurrent(&dtcId)) == DEM_DTC_KIND_EMISSION_REL_DTCS)
			{
				Dem_DtcSetDTCSetting(Dem_DtcIdIteratorCurrent(&dtcId), newDtcSettingState);
			}
		}
	}
}
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
Dem_DTCGroupIdType Dem_DtcGroupIdFromDtcGroupCode (Dem_DTCGroupType dtcGrpCode)
{
   Dem_DtcGroupIdIterator dtcGroupId;

   for (Dem_DtcGroupIdIteratorNew(&dtcGroupId);
        Dem_DtcGroupIdIteratorIsValid(&dtcGroupId);
        Dem_DtcGroupIdIteratorNext(&dtcGroupId))
   {
      if (Dem_DtcGroupGetCode(Dem_DtcGroupIdIteratorCurrent(&dtcGroupId)) == dtcGrpCode)
      {
         return Dem_DtcGroupIdIteratorCurrent(&dtcGroupId);
      }
   }
   return DEM_DTCGROUPID_INVALID;
}

Dem_ReturnControlDTCSettingType Dem_EnableDTCSetting (Dem_DTCGroupType DTCGroup, Dem_DTCKindType DTCKind)
{

	Dem_DTCGroupIdType DtcGroupId = Dem_DtcGroupIdFromDtcGroupCode(DTCGroup);
	DEM_UNUSED_PARAM(DTCKind);

	/* Validate the DTCGroupcode when OBD project is enabled or Disabled */
	if(DTCGroup != DEM_DTC_GROUP_EMISSION_REL_DTCS)
	{
		if(!Dem_DtcGroupIdIsValid(DtcGroupId))
		{
			return DEM_CONTROL_DTC_WRONG_DTCGROUP;
		}
	}

/* FC_VariationPoint_START */
#if(DEM_CFG_OBD == DEM_CFG_OBD_OFF)
/* FC_VariationPoint_END */
	{
		if(DTCGroup == DEM_DTC_GROUP_EMISSION_REL_DTCS)
		{
			return DEM_CONTROL_DTC_WRONG_DTCGROUP;
		}
	}
/* FC_VariationPoint_START */
#endif
/* FC_VariationPoint_END */

	Dem_DtcGroupApplyDTCSetting(DTCGroup, DtcGroupId, DEM_DTC_SETTING_ENABLED);

	return DEM_CONTROL_DTC_SETTING_OK;
}

Dem_ReturnControlDTCSettingType Dem_DisableDTCSetting (Dem_DTCGroupType DTCGroup, Dem_DTCKindType DTCKind)
{


	Dem_DTCGroupIdType DtcGroupId = Dem_DtcGroupIdFromDtcGroupCode(DTCGroup);
	DEM_UNUSED_PARAM(DTCKind);

	/* Validate the DTCGroupcode when OBD project is enabled or Disabled */
	if(DTCGroup != DEM_DTC_GROUP_EMISSION_REL_DTCS)
	{
		if(!Dem_DtcGroupIdIsValid(DtcGroupId))
		{
			return DEM_CONTROL_DTC_WRONG_DTCGROUP;
		}
	}

/* FC_VariationPoint_START */
#if(DEM_CFG_OBD == DEM_CFG_OBD_OFF)
/* FC_VariationPoint_END */
	{
		if(DTCGroup == DEM_DTC_GROUP_EMISSION_REL_DTCS)
		{
			return DEM_CONTROL_DTC_WRONG_DTCGROUP;
		}
	}
/* FC_VariationPoint_START */
#endif
/* FC_VariationPoint_END */

	Dem_DtcGroupApplyDTCSetting(DTCGroup, DtcGroupId, DEM_DTC_SETTING_DISABLED);

	return DEM_CONTROL_DTC_SETTING_OK;
}


void Dem_DtcsClearDtcInGroup(uint8 GroupId, Dem_DTCOriginType DTCOrigin, Dem_ClearHandlerType *ClearHandler)
{
    Dem_DtcIdType dtcId;

    /* Check whether the Clear is requested newly */
    if (ClearHandler->IsNewClearRequest)
    {
        Dem_DtcIdListIteratorNewFromDtcGroup(&(ClearHandler->DtcIt), GroupId);
    }

    while (Dem_DtcIdListIteratorIsValid(&(ClearHandler->DtcIt)))
    {
        dtcId = Dem_DtcIdListIteratorCurrent(&(ClearHandler->DtcIt));
        Dem_ClearSingleDTC(dtcId, DTCOrigin, ClearHandler);
        /* Check whether the number of events processed reached the Max limit */
        if (ClearHandler->IsClearInterrupted)
        {
            return;
        }
        Dem_DtcIdListIteratorNext(&(ClearHandler->DtcIt));
    }
}
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 0     06.07.2015 VSA2COB
*   CSCRM00830308
* 
* AR40.9.0.0; 1     06.01.2015 GJ83ABT
*   CSCRM00751490
* 
* AR40.9.0.0; 0     30.12.2014 TVE5COB
*   CSCRM00758414
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 3     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 2     19.11.2013 BRM2COB
*   
* 
* AR40.7.0.0; 1     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 0     08.08.2013 CLH2SI
*   CSCRM00532300
* 
* AR40.6.0.0; 7     10.07.2013 CLH2SI
*   - update NVM handling of statusbyte/distmem/generivNVData
*   - include delivery notes
*   (CSCRM00544420,  CSCRM00526766)
* 
* AR40.6.0.0; 6     23.05.2013 BRM2COB
*   CSCRM00516256
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
