/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_DTCFilter$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/



#include "Dem_Cfg_DTCs.h"
#include "Dem_DTCFilter.h"
#include "Dem_BitArray.h"
/* FC_VariationPoint_START */
#include "Dem_ObdMain.h"
/* FC_VariationPoint_END */


typedef struct
{
   boolean isNewFilterCriteria;
   uint8 DTCStatusMask;
   Dem_DTCKindType DTCKind;
   Dem_DTCFormatType DTCFormat;
   Dem_DTCOriginType DTCOrigin;
   Dem_FilterWithSeverityType FilterWithSeverity;
   Dem_DTCSeverityType DTCSeverityMask;
   Dem_FilterForFDCType FilterForFaultDetectionCounter;
   uint16 numberOfMatchingDTCs;
   Dem_DtcIdIterator searchIt, retrieveIt;
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
   uint16_least EvMemLocIt;
   Dem_ObdPdtcMemIterator ObdPdtcLocIt;
#endif
} Dem_DTCFilterState;

typedef struct
{
	/* state machine */
	volatile boolean start;
	volatile boolean exec;
	/* output parameter */
	volatile uint8   DTCStatus;
	/* input parameter */
	volatile Dem_DTCOriginType DTCOrigin;
	volatile Dem_DtcIdType DtcId;
} Dem_DTCFilterSyncState;

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"
	DEM_BITARRAY_DEFINE(Dem_DTCFilterMatching,DEM_DTCID_ARRAYLENGTH);
	static Dem_DTCFilterState Dem_DTCFilter;
	#if DEM_CFG_EVMEM_MIRROR_MEMORY_DTC_STATUS_STORED
	static Dem_DTCFilterSyncState Dem_DTCFilterSync;
	#endif
#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"



#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/* called in DCM task context */
DEM_INLINE void Dem_DtcFilterSyncInit(void)
{
#if DEM_CFG_EVMEM_MIRROR_MEMORY_DTC_STATUS_STORED

	Dem_DTCFilterSync.start  = TRUE;
#endif
}


DEM_INLINE boolean Dem_DtcFilterSyncGetDtcStatusByte (Dem_DtcIdType dtcId, Dem_DTCOriginType DTCOrigin, uint8* DTCStatus)
{
	DEM_UNUSED_PARAM(DTCOrigin);

#if DEM_CFG_EVMEM_MIRROR_MEMORY_DTC_STATUS_STORED
	/* Sync currently is only necessary to retrieve the stored DTC status in MIRROR Memory */
	if (DTCOrigin == DEM_DTC_ORIGIN_MIRROR_MEMORY)
	{
		/* sync job is running: just wait till results are available */
		if (Dem_DTCFilterSync.exec)
		{
			return FALSE;
		}
		/* start/init a new sync job */
		if (Dem_DTCFilterSync.start)
		{
			Dem_DTCFilterSync.DtcId = dtcId;
			Dem_DTCFilterSync.DTCOrigin = DTCOrigin;
			Dem_DTCFilterSync.start = FALSE;
			Dem_DTCFilterSync.exec = TRUE;
			return FALSE;
		}
		/* take the results of a finished sync job*/
		*DTCStatus = Dem_DTCFilterSync.DTCStatus;
		Dem_DTCFilterSync.start = TRUE;
		return TRUE;
	}
#endif

	/* retrieve of current DTC status */
	*DTCStatus = Dem_DtcStatusByteRetrieve(dtcId);
	return TRUE;
}

/* called in DEM task context */
DEM_INLINE void Dem_DtcFilterSyncCyclic(void)
{
#if DEM_CFG_EVMEM_MIRROR_MEMORY_DTC_STATUS_STORED
	if (Dem_DTCFilterSync.exec)
	{
		boolean DtcStatusIsValid;

		/* this is the sync action */
		Dem_DTCFilterSync.DTCStatus = Dem_DtcStatusByteRetrieveWithOrigin(Dem_DTCFilterSync.DtcId, Dem_DTCFilterSync.DTCOrigin, &DtcStatusIsValid);
		Dem_DTCFilterSync.exec = FALSE;
	}
#endif
}

void Dem_DtcFilterInit(void)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    Dem_EvMemEventMemoryLocIteratorInvalidate(&Dem_DTCFilter.EvMemLocIt, DEM_CFG_EVMEM_MEMID_PRIMARY);
    Dem_ObdPdtcMemLocIteratorInvalidate(&Dem_DTCFilter.ObdPdtcLocIt);
#endif
    Dem_DtcIdIteratorInvalidate(&Dem_DTCFilter.searchIt);
    Dem_DtcIdIteratorInvalidate(&Dem_DTCFilter.retrieveIt);
    Dem_DTCFilter.isNewFilterCriteria = TRUE;
}

Dem_ReturnSetFilterType Dem_SetDTCFilter (uint8 DTCStatusMask,
                                          Dem_DTCKindType DTCKind,
                                          Dem_DTCFormatType DTCFormat,
                                          Dem_DTCOriginType DTCOrigin,
                                          Dem_FilterWithSeverityType FilterWithSeverity,
                                          Dem_DTCSeverityType DTCSeverityMask,
                                          Dem_FilterForFDCType FilterForFaultDetectionCounter)
{
   /* not clear when to return DEM_WRONG_FILTER: all function parameters must be valid, as specified in AR-spec for each data-type */

    /* Call the FilterInit to reinit the iterators as it will be more robust when a running filter operation is interrupted by a new call to setDTCFilter */
    Dem_DtcFilterInit();

    if (DTCFormat == DEM_DTC_FORMAT_OBD)
    {
        /* FC_VariationPoint_START */
#if (DEM_CFG_OBD == DEM_CFG_OBD_OFF)
        /* FC_VariationPoint_END */
        return DEM_WRONG_FILTER;

        /* FC_VariationPoint_START */
#else
        if(DTCOrigin == DEM_DTC_ORIGIN_PRIMARY_MEMORY)
        {
            Dem_EvMemEventMemoryLocIteratorNew(&Dem_DTCFilter.EvMemLocIt,DEM_CFG_EVMEM_MEMID_PRIMARY);
        }
        else if(DTCOrigin == DEM_DTC_ORIGIN_PERMANENT_MEMORY)
        {
            Dem_ObdPdtcMemLocIteratorNew(&Dem_DTCFilter.ObdPdtcLocIt);
        }
        else
        {
            //To avoid MISRA
        }
#endif
        /* FC_VariationPoint_END */
    }
    else
    {
        Dem_DtcIdIteratorNew(&Dem_DTCFilter.searchIt);
        Dem_DtcIdIteratorNew(&Dem_DTCFilter.retrieveIt);

        Dem_BitArrayClearAll(Dem_DTCFilterMatching, DEM_DTCID_ARRAYLENGTH);
    }

   DEM_ENTERLOCK_DCM();

   Dem_DTCFilter.DTCStatusMask = (uint8)(DTCStatusMask & DEM_CFG_DTCSTATUS_AVAILABILITYMASK);
   Dem_DTCFilter.DTCKind = DTCKind;
   Dem_DTCFilter.DTCFormat = DTCFormat;
   Dem_DTCFilter.DTCOrigin = DTCOrigin;
   Dem_DTCFilter.FilterWithSeverity = FilterWithSeverity;
   Dem_DTCFilter.DTCSeverityMask = DTCSeverityMask;
   Dem_DTCFilter.FilterForFaultDetectionCounter = FilterForFaultDetectionCounter;

   Dem_DTCFilter.numberOfMatchingDTCs = 0;

   Dem_DtcFilterSyncInit();

   DEM_EXITLOCK_DCM();

   return DEM_FILTER_ACCEPTED;
}


static Dem_boolean_least Dem_DTCFilterMatches (Dem_DtcIdType dtcId)
{
   Dem_boolean_least matches = TRUE;
   sint8 FaultDetectionCounter;
   uint8 DtcStatus;
   boolean DtcStatusIsValid;

   if (Dem_DTCFilter.DTCStatusMask != 0)
   {
	  DtcStatus = Dem_DtcStatusByteRetrieveWithOrigin (dtcId, Dem_DTCFilter.DTCOrigin, &DtcStatusIsValid);
	  matches = matches && ((Dem_DTCFilter.DTCStatusMask & (DtcStatus & DEM_CFG_DTCSTATUS_AVAILABILITYMASK)) != 0u);
   }

   if (Dem_DTCFilter.DTCKind != DEM_DTC_KIND_ALL_DTCS)
   {
      matches = matches && (Dem_DtcGetKind(dtcId) == Dem_DTCFilter.DTCKind);
   }

   if (!Dem_DtcUsesOrigin(dtcId, Dem_DTCFilter.DTCOrigin))
   {
      matches = FALSE;
   }

   if (Dem_DTCFilter.FilterWithSeverity == DEM_FILTER_WITH_SEVERITY_YES)
   {
      matches = matches && ((Dem_DtcGetSeverity(dtcId) & Dem_DTCFilter.DTCSeverityMask) != 0);
   }

   if(Dem_DTCFilter.FilterForFaultDetectionCounter == DEM_FILTER_FOR_FDC_YES)
   {
	   FaultDetectionCounter = Dem_DtcFaultDetectionRetrieve(dtcId);
	   matches = matches && ((FaultDetectionCounter > 0) && (FaultDetectionCounter < 127));
   }

/* FC_VariationPoint_START */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
   if (Dem_DTCFilter.DTCOrigin == DEM_DTC_ORIGIN_PERMANENT_MEMORY)
   {
      matches = matches && Dem_ObdPdtcMemIsPdtcServ0A(dtcId);
   }
#endif
/* FC_VariationPoint_END */

   return matches;
}



void Dem_DTCFilterMainFunction(void)
{
   const sint32 epc = (sint32)DEM_DTC_FILTER_NUMBER_OF_EVENTS_PER_CYCLE; //to avoid MISRA warnings
   sint32 i = epc;
   Dem_DtcIdType dtcId;
   Dem_boolean_least matches;
   sint32 numberOfEvents;

   DEM_ENTERLOCK_DCM();
   Dem_DTCFilter.isNewFilterCriteria = FALSE;
   DEM_EXITLOCK_DCM();

   Dem_DtcFilterSyncCyclic();

   if (Dem_DtcIdIteratorIsValid(&Dem_DTCFilter.searchIt))
   {
       while (i>0)
       {
           /* check filter-rules for current dtcId */
           dtcId = Dem_DtcIdIteratorCurrent(&Dem_DTCFilter.searchIt);

           if (!Dem_isDtcIdValid(dtcId))
           {
               return;
           }

           if ((Dem_DtcIsAvailable(dtcId)) && (!Dem_DtcIsSuppressed(dtcId)))
           {
               numberOfEvents = (sint32)Dem_DtcIdGetNumberOfEvents(dtcId);
               /* only execute if number of events of current DTC does not exceed the total number of events allowed in this cycle or it is the first DTC in this cycle */
               if ((numberOfEvents > i) && (i != epc))
               {
                   break;
               }
               i = i - numberOfEvents;
               matches = Dem_DTCFilterMatches(dtcId);
           }
           else
           {
               i = i - 1;
               matches = FALSE;
           }


           DEM_ENTERLOCK_DCM();
           if (!Dem_DTCFilter.isNewFilterCriteria)
           {
               if (matches)
               {
                   Dem_BitArraySetBit(Dem_DTCFilterMatching, dtcId);
                   Dem_DTCFilter.numberOfMatchingDTCs++;
               }

               /* advance iterator to next dtcId */
               Dem_DtcIdIteratorNext(&Dem_DTCFilter.searchIt);
           }
           else
           {
               i = 0;
           }
           DEM_EXITLOCK_DCM();

       }
   }
}



static Dem_ReturnGetNextFilteredDTCType Dem_GetNextFilteredDTCID (Dem_DtcIdType* dtcId, uint32* DTC, uint8* DTCStatus)
{
    uint16_least i = DEM_DTC_FILTER_RETRIEVE_NUMBER_OF_DTCS;

    while (i>0u)
    {
        if (!Dem_DtcIdIteratorIsValid(&Dem_DTCFilter.retrieveIt))
        {
            return DEM_FILTERED_NO_MATCHING_DTC;
        }

        if (Dem_DTCFilter.retrieveIt == Dem_DTCFilter.searchIt)
        {
            return DEM_FILTERED_PENDING;
        }

        *dtcId = Dem_DtcIdIteratorCurrent(&Dem_DTCFilter.retrieveIt);

        if (Dem_BitArrayIsBitSet(Dem_DTCFilterMatching, *dtcId))
        {
            if (DTCStatus != NULL_PTR)
            {
                if (!Dem_DtcFilterSyncGetDtcStatusByte(*dtcId, Dem_DTCFilter.DTCOrigin, DTCStatus))
                {
                    return DEM_FILTERED_PENDING;
                }
                *DTCStatus = (uint8)(*DTCStatus & DEM_CFG_DTCSTATUS_AVAILABILITYMASK);
            }

            *DTC = Dem_DtcGetCode(*dtcId);

            Dem_DtcIdIteratorNext(&Dem_DTCFilter.retrieveIt);
            return DEM_FILTERED_OK;
        }
        i--;
        Dem_DtcIdIteratorNext(&Dem_DTCFilter.retrieveIt);
    }
    return DEM_FILTERED_PENDING;
}

#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
DEM_INLINE Dem_ReturnGetNextFilteredDTCType Dem_GetDtcAndDtcStatus(Dem_DtcIdType dtcId, uint32* DTC, uint8* DTCStatus)
{
    *DTC = Dem_ObdDtcGetCode(dtcId);

    *DTCStatus = Dem_DtcStatusByteRetrieve(dtcId);

    *DTCStatus = (uint8)(*DTCStatus & DEM_CFG_DTCSTATUS_AVAILABILITYMASK);

    Dem_DTCFilter.numberOfMatchingDTCs++;

    return DEM_FILTERED_OK;
}
#endif


Dem_ReturnGetNextFilteredDTCType Dem_GetNextFilteredDTC(uint32* DTC, uint8* DTCStatus)
{
    Dem_DtcIdType dtcId;

    /* FC_VariationPoint_START */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    uint16_least currentEvMemLoc;
    uint16_least PdtcLocId;
#endif
    /* FC_VariationPoint_END */

    if (Dem_DtcIdIteratorIsValid(&Dem_DTCFilter.retrieveIt))
    {
        return Dem_GetNextFilteredDTCID (&dtcId, DTC, DTCStatus);
    }

    /* FC_VariationPoint_START */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    //If the DTC origin is PRIMARY
    if(Dem_EvMemEventMemoryLocIteratorIsValid(&Dem_DTCFilter.EvMemLocIt, DEM_CFG_EVMEM_MEMID_PRIMARY))
    {
        //For filtering OBD services loop through Event Memory locationand set the matching DTC fot this particular DTC
        while(Dem_EvMemEventMemoryLocIteratorIsValid(&Dem_DTCFilter.EvMemLocIt, DEM_CFG_EVMEM_MEMID_PRIMARY))
        {
            currentEvMemLoc = Dem_DTCFilter.EvMemLocIt;

            //Iterate to the next location
            Dem_EvMemEventMemoryLocIteratorNext(&Dem_DTCFilter.EvMemLocIt, DEM_CFG_EVMEM_MEMID_PRIMARY);

            //check if the EvMem loc is not empty
            if (Dem_EvMemIsStored (Dem_EvMemGetEventMemStatus (currentEvMemLoc)))
            {
                //Get the Dtc id for this particular location
                dtcId = Dem_DtcIdFromEventId(Dem_EvMemGetEventMemEventId(currentEvMemLoc));

                if(Dem_isDtcIdValid(dtcId))
                {
                    //Check if the filter matches
                    if (Dem_DTCFilterMatches(dtcId))
                    {
                        //Get the DTC and DTC status and return DEM_FILTERED_OK
                        return Dem_GetDtcAndDtcStatus(dtcId, DTC, DTCStatus);
                    }
                }
            }
        }
    }

    //If the DTC origin is PERMANENT
    if(Dem_ObdPdtcMemLocIteratorIsValid(&Dem_DTCFilter.ObdPdtcLocIt))
    {
        //loop through the iterator
        while(Dem_ObdPdtcMemLocIteratorIsValid(&Dem_DTCFilter.ObdPdtcLocIt))
        {
            PdtcLocId = Dem_ObdPdtcMemLocIteratorCurrent(&Dem_DTCFilter.ObdPdtcLocIt);

            //Iterate to the next Loc
            Dem_ObdPdtcMemLocIteratorNext(&Dem_DTCFilter.ObdPdtcLocIt);

            if(Dem_ObdPdtcMemLocIsNotEmpty (PdtcLocId))
            {
                if (Dem_ObdPdtcMemLocIsEventVisibleServ0A(PdtcLocId))
                {
                    //This portion can be optimised with the above call
                    dtcId = Dem_DtcIdFromEventId(Dem_ObdPdtcMemGetEventId(PdtcLocId));

                    //Get the DTC and DTC status and return DEM_FILTERED_OK
                    return Dem_GetDtcAndDtcStatus(dtcId, DTC, DTCStatus);
                }
            }
        }
    }
#endif
    /* FC_VariationPoint_END */

    //If OBD is configured and none of the DTCs are matching.
    return DEM_FILTERED_NO_MATCHING_DTC;
}

Dem_ReturnGetNextFilteredDTCType Dem_GetNextFilteredDTCAndFDC(uint32* DTC, sint8* DTCFaultDetectionCounter)
{
	Dem_DtcIdType dtcId;
	Dem_ReturnGetNextFilteredDTCType retVal;

	DEM_ASSERT(((DTC != NULL_PTR) && (DTCFaultDetectionCounter != NULL_PTR)),DEM_DET_APIID_GETNEXTFILTEREDDTCANDFDC, DEM_E_PARAM_ADDRESS);

	retVal = Dem_GetNextFilteredDTCID (&dtcId, DTC, NULL_PTR);
	if (retVal == DEM_FILTERED_OK)
	{
		*DTCFaultDetectionCounter = Dem_DtcFaultDetectionRetrieve(dtcId);
	}
	return retVal;
}


Dem_ReturnGetNextFilteredDTCType Dem_GetNextFilteredDTCAndSeverity (uint32* DTC, uint8* DTCStatus, Dem_DTCSeverityType* DTCSeverity, uint8* DTCFunctionalUnit)
{
	Dem_DtcIdType dtcId;
	Dem_ReturnGetNextFilteredDTCType retVal;

	retVal = Dem_GetNextFilteredDTCID (&dtcId, DTC, DTCStatus);
	if (retVal == DEM_FILTERED_OK)
	{
		*DTCSeverity = Dem_DtcGetSeverity(dtcId);
		*DTCFunctionalUnit = Dem_DtcGetFuncUnit(dtcId);
	}
	return retVal;
}



Dem_ReturnGetNumberOfFilteredDTCType Dem_GetNumberOfFilteredDTC(uint16* NumberOfFilteredDTC)
{
   if (Dem_DtcIdIteratorIsValid(&Dem_DTCFilter.searchIt))
   {
      return DEM_NUMBER_PENDING;
   }

   *NumberOfFilteredDTC = Dem_DTCFilter.numberOfMatchingDTCs;
   return DEM_NUMBER_OK;
}
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     16.10.2015 VSA2COB
*   Checkout by vsa2cob
* 
* AR40.10.0.0; 3     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 2     10.07.2015 CLH2SI
*   CSCRM00938605
* 
* AR40.10.0.0; 1     04.07.2015 BPE4COB
*   CSCRM00835665
* 
* AR40.10.0.0; 0     17.06.2015 BPE4COB
*   CSCRM00835665
* 
* AR40.9.0.0; 1     09.01.2015 CLH2SI
*   CSCRM00769241
* 
* AR40.9.0.0; 0     21.11.2014 CLH2SI
*   CSCRM00712155
* 
* AR40.8.0.0; 5     16.07.2014 BRM2COB
*   CSCRM00688243
* 
* AR40.8.0.0; 4     16.06.2014 GJ83ABT
*   CSCRM00615634, CSCRM00671513
* 
* AR40.8.0.0; 3     10.06.2014 UDKOEGEL
*   CSCRM00639545
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
