#ifndef DEM_BFMUTILS_H
#define DEM_BFMUTILS_H

#include "Dem_Cfg_Bfm.h"
#if( DEM_BFM_ENABLED == DEM_BFM_ON )

#define BFM_ENTER_LOCK_EXTERNAL_NVM_READ_NONEST() do{}while(0)
#define BFM_EXIT_LOCK_EXTERNAL_NVM_READ_NONEST() do{}while(0)

#define BFM_ENTER_LOCK_EXTERNAL_READ_NONEST() do{}while(0)
#define BFM_EXIT_LOCK_EXTERNAL_READ_NONEST() do{}while(0)

#define BFM_ENTER_LOCK_EXTERNAL_READ_DIRECT_NESTED()	do{}while(0)
#define BFM_EXIT_LOCK_EXTERNAL_READ_DIRECT_NESTED()	do{}while(0)

#endif //DEM_BFM_ENABLED
#endif
