/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2013. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************
* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_Bfm$
* $Variant___:AR40.10.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/
#ifndef DEM_BFM_H
#define DEM_BFM_H

#include "Dem_Cfg_Bfm.h"
#if( DEM_BFM_ENABLED == DEM_BFM_ON )


#include "Dem_BfmCounter.h"
#include "Dem_BfmRecord.h"


#define DEM_START_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"

extern Dem_BfmConfigDataType const * Dem_BfmConfigParam_pcs;

#define DEM_STOP_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"


#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/**
 * \defgroup DEM_BFM_H DEM - Bosch Failure Memory interface
 * This interface provides functionality to handle the BFM.
 * To use this interface include the header <b>dem.h</b>
 */

void Dem_BfmPreInit( Dem_BfmConfigDataType const * demBfmConfigPointer );
void Dem_BfmInit(void);
void Dem_BfmInitCheckNvM(void);
void Dem_BfmShutdown(void);
void Dem_BfmMainFunction(void);


/** * @ingroup DEM_BFM_H
 * Trigger a delete operation. Function returns immediately also delete operation is executed asynchroeously.
 * Use Dem_BfmDeleteAllCheck() to check the status.
 * @return  DEM_BFM_RET_OK: order accepted
 */
Dem_BfmReturnType Dem_BfmDeleteAllTrigger(void);

/** * @ingroup DEM_BFM_H
 * Check the status of the delete operation that has been initiated by Dem_BfmDeleteAllTrigger().
 * You can pass against which status should be checked: check if order has been accepted, check if RAM has been zeroed, check if management data has been updatedin NvM
 * @param [in]  checkStatus  can be [DEM_BFM_CHECK_RequestAccepted,DEM_BFM_CHECK_MemoryDeleted,DEM_BFM_CHECK_MangementDataWrittenToNvm]
 * @return  DEM_BFM_RET_OK: delete operation has reached the status requested\n
 *          DEM_BFM_RET_PENDING: delete operation has not yet reached the status requested\n
 *          DEM_BFM_RET_NOK: no delete operation has been triggered or unsupported checkStatus was used
 */
Dem_BfmReturnType Dem_BfmDeleteAllCheck( Dem_BfmDeleteAllCheckStatus checkStatus );
boolean Dem_BfmDeleteAllIsInProgress(void);

/** * @ingroup DEM_BFM_H
 * Trigger to read one BFM record from NvM.
 * Only one read operation can be handled at a time.
 * @param [in]  location  location of the BFM record, should be aquired by using the interfaces Dem_BfmRecordGetFirst(), Dem_BfmRecordGetNext() or Dem_BfmRecordFind()
 * @param [out] buffer  pointer to a BFM record, where the content of NvM can be stored in
 * @return  DEM_BFM_RET_PENDING: request has been accepted, result is pending\n
 *          DEM_BFM_RET_BUSY: currently busy with another read operation\n
 *          DEM_BFM_RET_OUT_OF_RANGE: the location is not within the limits\n
 *          DEM_BFM_RET_NULL_PTR: pointer to buffer is not valid\n
 *          DEM_BFM_RET_NOK: something went wrong
 */
Dem_BfmReturnType Dem_BfmReadRecordFromNvMTrigger( Dem_BfmLocationDataType location, Dem_BfmRecord *buffer );

/** * @ingroup DEM_BFM_H
 * Check the status of the read operation that has been initiated by Dem_BfmReadRecordFromNvMTrigger().
 * You need to pass the location, that we can be sure you are checking the right read operation.
 * @param [in]  location  the same location as used for Dem_BfmReadRecordFromNvMTrigger()
 * @return  DEM_BFM_RET_OK: the read NvM operation has completed, content of BFM record buffer can now be used\n
 *          DEM_BFM_RET_PENDING: the read NvM operation is not yet finished\n
 *          DEM_BFM_RET_NOT_FOUND: there is no read NvM operation established for the passed location\n
 *          DEM_BFM_RET_NOK: something went wrong
 */
Dem_BfmReturnType Dem_BfmReadRecordFromNvMCheck( Dem_BfmLocationDataType location );

/** * @ingroup DEM_BFM_H
 * Trigger to read one BFM record from RAM.
 * Only one read operation can be handled at a time.
 * @param [in]  location  location of the BFM record, should be aquired by using the interfaces Dem_BfmRecordGetFirst(), Dem_BfmRecordGetNext() or Dem_BfmRecordFind()
 * @param [out] buffer  pointer to a BFM record, where the content of RAM can be stored in
 * @return  DEM_BFM_RET_PENDING: request has been accepted, result is pending\n
 *          DEM_BFM_RET_BUSY: currently busy with another read operation\n
 *          DEM_BFM_RET_OUT_OF_RANGE: the location is not within the limits\n
 *          DEM_BFM_RET_NULL_PTR: pointer to buffer is not valid\n
 *          DEM_BFM_RET_NOK: something went wrong
 */
Dem_BfmReturnType Dem_BfmReadRecordFromRAMTrigger( Dem_BfmLocationDataType location, Dem_BfmRecord *buffer );

/** * @ingroup DEM_BFM_H
 * Check the status of the read operation that has been initiated by Dem_BfmReadRecordFromRAMTrigger().
 * You need to pass the location, that we can be sure you are checking the right read operation.
 * @param [in]  location  the same location as used for Dem_BfmReadRecordFromRAMTrigger()
 * @return  DEM_BFM_RET_OK: the read RAM operation has completed, content of BFM record buffer can now be used\n
 *          DEM_BFM_RET_PENDING: the read RAM operation is not yet finished\n
 *          DEM_BFM_RET_NOT_FOUND: there is no read RAM operation established for the passed location\n
 *          DEM_BFM_RET_NOK: something went wrong
 */
Dem_BfmReturnType Dem_BfmReadRecordFromRAMCheck( Dem_BfmLocationDataType location );

/** * @ingroup DEM_BFM_H
 * Try to read one BFM record directly from RAM.
 * The read operation can only be granted if currecntly no other process is using the location you want to read.
 * The access to the BFM record is interrupt protected and can block the system for a longer time. So the preferred solution should be to use Dem_BfmReadRecordFromRAMTrigger/Check instead.
 * @param [in]  location  location of the BFM record, should be aquired by using the interfaces Dem_BfmRecordGetFirst(), Dem_BfmRecordGetNext() or Dem_BfmRecordFind()
 * @param [out] buffer  pointer to a BFM record, where the content of RAM can be stored in
 * @return  DEM_BFM_RET_OK: the content was read/copied successfully\n
 *          DEM_BFM_RET_BUSY: the location is crrently in use by another process\n
 *          DEM_BFM_RET_OUT_OF_RANGE: the location is not within the limits\n
 *          DEM_BFM_RET_NULL_PTR: pointer to buffer is not valid\n
 *          DEM_BFM_RET_NOK: something went wrong
 */
Dem_BfmReturnType Dem_BfmReadRecordFromRAMDirect( Dem_BfmLocationDataType location, Dem_BfmRecord *buffer );

/** * @ingroup DEM_BFM_H
 * Temporary lock all BFM records against changes.
 * Temporary means that the entries are only locked as long as the ECU had not power off reset, or until the get unlocked.
 * If a lock and a unlock request arrive at the same time, than locking has the higher priority.
 * @return  DEM_BFM_RET_OK: the BFM records are going to be locked temporary
 */
Dem_BfmReturnType Dem_BfmLockAllRecordsTemporary(void);

/** * @ingroup DEM_BFM_H
 * Unlock all temporary locked BFM records.
 * If a lock and a unlock request arrive at the same time, than locking has the higher priority.
 * @return  DEM_BFM_RET_OK: the BFM records are going to be unlocked again
 */
Dem_BfmReturnType Dem_BfmUnlockAllRecordsTemporary(void);

/** * @ingroup DEM_BFM_H
 * Permanently lock all BFM records against changes.
 * Permanently means that the entries are locked over several ECU power off cycles, or until they get unlocked.
 * If a lock and a unlock request arrive at the same time, than locking has the higher priority.
 * @return  DEM_BFM_RET_OK: the BFM records are going to be locked permanently
 */
Dem_BfmReturnType Dem_BfmLockAllRecordsPermanently(void);

/** * @ingroup DEM_BFM_H
 * Unlock all permanently locked BFM records.
 * If a lock and a unlock request arrive at the same time, than locking has the higher priority.
 * @return  DEM_BFM_RET_OK: the BFM records are going to be unlocked again
 */
Dem_BfmReturnType Dem_BfmUnlockAllRecordsPermanently(void);

/** * @ingroup DEM_BFM_H
 * Trigger storing BFM counter and BFM management data to NvM. The request will be processed in the next BFM main loop. BFM records are handled separately
 * @return  DEM_BFM_RET_OK: order accepted
 */
Dem_BfmReturnType Dem_BfmTriggerStoreToNvm(void);

#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
/** * @ingroup DEM_BFM_H
 * Trigger to read one BFM extended data record from RAM.
 * Only one read operation can be handled at a time.
 * @param [in]  location  location of the extended data record, should be acquired by using the Dem_BfmRecordFind()
 * @param [out] buffer  Pointer to a buffer where an extended debug record can be copied to.
 * @return  DEM_BFM_RET_PENDING: request has been accepted, result is pending\n
 *          DEM_BFM_RET_BUSY: currently busy with another read operation\n
 *          DEM_BFM_RET_OUT_OF_RANGE: the location is not within the limits\n
 *          DEM_BFM_RET_NULL_PTR: pointer to buffer is not valid\n
 *          DEM_BFM_RET_NOK: something went wrong
 */
Dem_BfmReturnType Dem_BfmReadExtendedDebugDataFromRAMTrigger( Dem_BfmLocationDataType location, Dem_BfmExtendedDebugDataRecord *buffer );


/** * @ingroup DEM_BFM_H
 * Check the status of the Extended data record read operation that has been initiated by Dem_BfmReadRecordFromRAMTrigger().
 * You need to pass the location, that we can be sure you are checking the right read operation.
 * @param [in]  location  the same location as used for Dem_BfmReadRecordFromRAMTrigger()
 * @return  DEM_BFM_RET_OK: the read RAM operation has completed, content of BFM record buffer can now be used\n
 *          DEM_BFM_RET_PENDING: the read RAM operation is not yet finished\n
 *          DEM_BFM_RET_NOT_FOUND: there is no read RAM operation established for the passed location\n
 *          DEM_BFM_RET_NOK: something went wrong
 */
Dem_BfmReturnType Dem_BfmReadExtendedDebugDataFromRAMCheck( Dem_BfmLocationDataType location);

/** * @ingroup DEM_BFM_H
 * Try to read one BFM record directly from RAM.
 * The read operation can only be granted if currently no other process is using the location you want to read.
 * The access to the BFM record is interrupt protected and can block the system for a longer time. So the preferred solution should be to use Dem_BfmReadRecordFromRAMTrigger/Check instead.
 * @param [in]  location  location of the BFM record, should be acquired by using the interfaces Dem_BfmRecordGetFirst(), Dem_BfmRecordGetNext() or Dem_BfmRecordFind()
 * @param [out] buffer  pointer to a BFM record, where the content of RAM can be stored in
 * @return  DEM_BFM_RET_OK: the content was read/copied successfully\n
 *          DEM_BFM_RET_BUSY: the location is currently in use by another process\n
 *          DEM_BFM_RET_OUT_OF_RANGE: the location is not within the limits\n
 *          DEM_BFM_RET_NULL_PTR: pointer to buffer is not valid\n
 *          DEM_BFM_RET_NOK: something went wrong
 */
Dem_BfmReturnType Dem_BfmReadExtendedDebugDataFromRAMDirect( Dem_BfmLocationDataType location, Dem_BfmExtendedDebugDataRecord *buffer );
#endif

#ifdef DEM_TESTSUITE
atomic_ui8 DemTest_BfmGetStateNvmWrite();
atomic_ui8 DemTest_BfmGetStateNvmRead();
atomic_ui8 DemTest_BfmGetStateRamRead();
atomic_ui8 DemTest_BfmGetStateNvmWriteManagementData();
atomic_ui8 DemTest_BfmGetStateNvmWriteCounter();
#endif

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif //DEM_BFM_ENABLED
#endif
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 1     24.06.2015 WUG3ABT
*   CSCRM00896357
* 
* AR40.10.0.0; 0     13.05.2015 WUG3ABT
*   CSCRM00857327
* 
* AR40.9.0.0; 1     14.10.2014 VSA2COB
*   CSCRM00554989
* 
* AR40.9.0.0; 0     25.08.2014 BPE4COB
*   CSCRM00641522
* 
* AR40.8.0.0; 4     18.04.2014 BPE4COB
*   CSCRM00581953
* 
* AR40.8.0.0; 3     17.04.2014 WUG3ABT
*   CSCRM00653602
* 
* AR40.8.0.0; 2     11.04.2014 WUG3ABT
*   CSCRM00625933
* 
* AR40.8.0.0; 1     07.04.2014 WUG3ABT
*   CSCRM00621339
* 
* AR40.8.0.0; 0     27.02.2014 WUG3ABT
*   CSCRM00588123
* 
* AR40.7.0.0; 3     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* $
**********************************************************************************************************************
</BASDKey>*/
