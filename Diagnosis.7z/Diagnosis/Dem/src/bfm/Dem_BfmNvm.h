/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2013. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************
* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_BfmNvm$
* $Variant___:AR40.10.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/
#ifndef DEM_BFMNVM_H
#define DEM_BFMNVM_H

#include "Dem_Cfg_Bfm.h"
#if( DEM_BFM_ENABLED == DEM_BFM_ON )

#include "Dem_BfmRecord.h"
#include "Dem_BfmCounter.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
Dem_BfmReturnType Dem_BfmNvmWriteRecord( Dem_BfmLocationDataType location, void *record );
Dem_BfmReturnType Dem_BfmNvmWriteCounter( Dem_BfmCounterNvm *counter );
Dem_BfmReturnType Dem_BfmNvmWriteManagementData( Dem_BfmRecordManagementDataNvm *managementData );

Dem_BfmReturnType Dem_BfmNvmReadRecord( Dem_BfmLocationDataType location, Dem_BfmRecord *record );
Dem_BfmReturnType Dem_BfmNvmReadCounter( Dem_BfmCounterNvm *counter );
Dem_BfmReturnType Dem_BfmNvmReadManagementData( Dem_BfmRecordManagementDataNvm *managementData );

Dem_BfmReturnType Dem_BfmNvmGetStatusRecord( Dem_BfmLocationDataType location );
Dem_BfmReturnType Dem_BfmNvmGetStatusCounter(void);
Dem_BfmReturnType Dem_BfmNvmGetStatusManagementData(void);

Dem_BfmReturnType Dem_BfmNvmSetRamBlockStatusRecord( Dem_BfmLocationDataType location, boolean blockChanged );
Dem_BfmReturnType Dem_BfmNvmSetRamBlockStatusCounter( boolean blockChanged );
Dem_BfmReturnType Dem_BfmNvmSetRamBlockStatusManagementData( boolean blockChanged );

Dem_BfmReturnType Dem_BfmNvmEraseRecord( Dem_BfmLocationDataType location );
Dem_BfmReturnType Dem_BfmNvmEraseCounter(void);
Dem_BfmReturnType Dem_BfmNvmEraseManagementData(void);

Std_ReturnType Dem_BfmNvmWriteRamBlockToNvmCallback( void* NvmBufDest, Dem_BfmLocationDataType locSrc );
Std_ReturnType Dem_BfmNvmReadRamBlockFromNvmCallback( void* NvmBufSrc, Dem_BfmLocationDataType locDest );

#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
Std_ReturnType Dem_BfmNvmWriteExtDbgDataRamBlockToNvmCallback( void* NvmBufDest, Dem_BfmLocationDataType locSrc );
Std_ReturnType Dem_BfmNvmReadExtDbgDataRamBlockFromNvmCallback( void* NvmBufSrc, Dem_BfmLocationDataType locDest );

Dem_BfmReturnType Dem_BfmNvmGetStatusExtDbgDataRecord( Dem_BfmLocationDataType location );
Dem_BfmReturnType Dem_BfmNvmWriteExtDbgDataRecord( Dem_BfmLocationDataType location, void *record );
Dem_BfmReturnType Dem_BfmNvmSetRamBlockStatusExtDbgDataRecord( Dem_BfmLocationDataType location, boolean blockChanged );
#endif


#ifdef DEM_TESTSUITE
uint32 DemTest_BfmRecordGetBlockId( Dem_BfmLocationDataType location );
#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
uint32 DemTest_BfmExtDbgDataRecordGetBlockId( Dem_BfmLocationDataType location );
#endif
uint32 DemTest_BfmManagementDataGetBlockId();
uint32 DemTest_BfmCounterGetBlockId();
#endif



#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


#endif //DEM_BFM_ENABLED
#endif
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 0     24.06.2015 WUG3ABT
*   CSCRM00896357
* 
* AR40.9.0.0; 1     14.10.2014 VSA2COB
*   CSCRM00554989
* 
* AR40.9.0.0; 0     25.08.2014 BPE4COB
*   CSCRM00641522
* 
* AR40.8.0.0; 0     13.06.2014 WUG3ABT
*   CSCRM00610171
* 
* AR40.7.0.0; 2     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 1     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 0     22.10.2013 AMN2KOR
*   CSCRM00547887
* 
* AR40.6.0.0; 2     09.07.2013 WUG3ABT
*   CSCRM00533303:
*   remove workaround for Nvm read/write interfaces, use final solution
* 
* AR40.6.0.0; 1     08.07.2013 BRM2COB
*   CSCRM00541186 : Removal of MISRA warnings
* 
* AR40.6.0.0; 0     21.06.2013 WUG3ABT
*   
* 
* $
**********************************************************************************************************************
</BASDKey>*/
