/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2013. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************
* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_BfmCounter$
* $Variant___:AR40.10.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/
#ifndef DEM_BFMCOUNTER_H
#define DEM_BFMCOUNTER_H

#include "Dem_Cfg_Bfm.h"
#if( DEM_BFM_ENABLED == DEM_BFM_ON )

#include "Dem_InternalEnvData.h"
#include "Dem_Cfg_OperationCycle.h"


typedef struct
{
	Dem_BfmOperationCycleCounterType OperationCycleCounter;
	Dem_BfmAbsoluteOperatingTimeCounterType AbsoluteOperatingTimeCounter;
}
Dem_BfmCounterNvm;

typedef struct
{
	Dem_BfmRelativeOperatingTimeCounterType RelativeOperatingTimeCounter;
	Dem_BfmTimestampType TimestampCounter;
}
Dem_BfmCounterRam;



#define DEM_START_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

	//necessary to access the data directly through NvM configuration
	extern Dem_BfmCounterNvm Dem_BfmCounterValuesNvm;

#define DEM_STOP_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/** * @ingroup DEM_BFM_H
 * Get the current value of the operation cycle counter.
 * The operation cycle type that is responsible for triggering a counter increment has to be set through configuration parameter "DemBfmOperationCycleType".
 * @param [out]  operationCycles  pointer to a buffer that is filled with current value of the operation cycle counter
 * @return  DEM_BFM_RET_OK: operationCycles got set\n
 *          DEM_BFM_RET_NULL_PTR: operationCycles pointer is invalid\n
 *          DEM_BFM_RET_NOK: something went wrong
 */
Dem_BfmReturnType Dem_BfmCounterGetOperationCycle( Dem_BfmOperationCycleCounterType *operationCycles );

/** * @ingroup DEM_BFM_H
 * Get the current value of the absolute operating time counter.
 * The absolute operating time counter counts over all power cycles. The unit of the counter is one second.
 * @param [out]  operatingTime  pointer to a buffer that is filled with current value of the absolute operating time counter
 * @return  DEM_BFM_RET_OK: operatingTime got set\n
 *          DEM_BFM_RET_NULL_PTR: operatingTime pointer is invalid\n
 *          DEM_BFM_RET_NOK: something went wrong
 */
Dem_BfmReturnType Dem_BfmCounterGetAbsoluteOperatingTime( Dem_BfmAbsoluteOperatingTimeCounterType *operatingTime );

/** * @ingroup DEM_BFM_H
 * Get the current value of the relative operating time counter.
 * The relative operating time counter counts wihtin one power cycle. The unit of the counter is resolution of the Dem task, eg 1ms, 10ms or 20ms.
 * @param [out]  operatingTime  pointer to a buffer that is filled with current value of the relative operating time counter
 * @return  DEM_BFM_RET_OK: operatingTime got set\n
 *          DEM_BFM_RET_NULL_PTR: operatingTime pointer is invalid\n
 *          DEM_BFM_RET_NOK: something went wrong
 */
Dem_BfmReturnType Dem_BfmCounterGetRelativeOperatingTime( Dem_BfmRelativeOperatingTimeCounterType *operatingTime );

/** * @ingroup DEM_BFM_H
 * Get the unit/resolution of the of the relative operating time counter.
 * The unit of the counter is resolution of the Dem task in milli seconds, eg 1ms, 10ms or 20ms.
 * @param [out]  timebase  pointer to a buffer that is filled with current value of the resolution in ms
 * @return  DEM_BFM_RET_OK: timebase got set\n
 *          DEM_BFM_RET_NULL_PTR: timebase pointer is invalid\n
 *          DEM_BFM_RET_NOK: something went wrong
 */
Dem_BfmReturnType Dem_BfmCounterGetRelativeOperatingTimeTimebase( Dem_BfmRelativeOperatingTimeCounterTimebaseType *timebase );

/** * @ingroup DEM_BFM_H
 * Get the current value of the internal timestamp counter.
 * The timestamp is used to differentiate the age of the BFM records.
 * @param [out]  timestamp  pointer to a buffer that is filled with current value of the timestamp counter
 * @return  DEM_BFM_RET_OK: timestamp got set\n
 *          DEM_BFM_RET_NULL_PTR: timestamp pointer is invalid\n
 *          DEM_BFM_RET_NOK: something went wrong
 */
Dem_BfmReturnType Dem_BfmCounterGetTimestamp( Dem_BfmTimestampType *timestamp );



Std_ReturnType Dem_BfmWrapperGetOperationCycle( uint8* buffer, const Dem_InternalEnvData* internalData );
Std_ReturnType Dem_BfmWrapperGetAbsoluteOperatingTime( uint8* buffer, const Dem_InternalEnvData* internalData );
Std_ReturnType Dem_BfmWrapperGetRelativeOperatingTime( uint8* buffer, const Dem_InternalEnvData* internalData );
Std_ReturnType Dem_BfmWrapperGetTimestamp( uint8* buffer, const Dem_InternalEnvData* internalData );

void Dem_BfmCounterCalcTimestamp(void);
void Dem_BfmCounterCalcOperationCycle(void);
void Dem_BfmCounterAdvanceOperationCycle( Dem_OperationCycleList currentTriggers );

void Dem_BfmCounterMainFunction(void);
void Dem_BfmCounterInitCheckNvM(void);
void Dem_BfmCounterInit(void);
void Dem_BfmCounterShutdown(void);

boolean Dem_BfmCounterNeedsToBeSaved(void);
void Dem_BfmCounterSetNeedsToBeSaved( boolean needsTobeSaved );
void Dem_BfmCounterGetCounterDataNvm( Dem_BfmCounterNvm *counterDataNvm );

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif //DEM_BFM_ENABLED
#endif
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 1     09.07.2015 RPV5COB
*   CSCRM00791814
* 
* AR40.10.0.0; 0     13.05.2015 WUG3ABT
*   CSCRM00857327
* 
* AR40.9.0.0; 0     25.08.2014 BPE4COB
*   CSCRM00641522
* 
* AR40.8.0.0; 3     17.04.2014 WUG3ABT
*   CSCRM00653602
* 
* AR40.8.0.0; 2     27.02.2014 WUG3ABT
*   CSCRM00588123
* 
* AR40.8.0.0; 1     21.02.2014 BPE4COB
*   CSCRM00604620: BFM interrupt protection and mulitcore support
* 
* AR40.8.0.0; 0     13.02.2014 WUG3ABT
*   CSCRM00562030
* 
* AR40.7.0.0; 2     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 1     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 0     22.10.2013 AMN2KOR
*   CSCRM00547887
* 
* $
**********************************************************************************************************************
</BASDKey>*/
