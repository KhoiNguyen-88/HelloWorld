/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2013. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:C$
 * $Name______:Dem_BfmCounter$
 * $Variant___:AR40.10.0.0$
 * $Revision__:5$
 **********************************************************************************************************************
</BASDKey>*/

#include "Dem_BfmCounter.h"
#if( DEM_BFM_ENABLED == DEM_BFM_ON )

#include "Dem_Bfm.h"
#include "Dem_Cfg_ExtPrototypes.h"
#include "Dem_BfmRecord.h"
#include "Dem_BfmUtils.h"
#include "Dem_BfmNvm.h"


#define DEM_START_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"

	static Dem_BfmCounterRam mCountersRam = {0,0};
	static boolean mIsModified = FALSE;
	static uint16 mAbsolutCounterHelper = 0;
	static uint8 mNvmStoreMinuteCounterHelper = 0;

#define DEM_STOP_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

	Dem_BfmCounterNvm Dem_BfmCounterValuesNvm = {0,0};

#define DEM_STOP_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
//*****************************************************************************
Dem_BfmReturnType Dem_BfmCounterGetOperationCycle( Dem_BfmOperationCycleCounterType *operationCycles )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( operationCycles == NULL_PTR )
	{
		retVal = DEM_BFM_RET_NULL_PTR;
	}
	else
	{
		*operationCycles = Dem_BfmCounterValuesNvm.OperationCycleCounter;
		retVal = DEM_BFM_RET_OK;
	}

	return retVal;
}

Dem_BfmReturnType Dem_BfmCounterGetAbsoluteOperatingTime( Dem_BfmAbsoluteOperatingTimeCounterType *operatingTime )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( operatingTime == NULL_PTR )
	{
		retVal = DEM_BFM_RET_NULL_PTR;
	}
	else
	{
		*operatingTime = Dem_BfmCounterValuesNvm.AbsoluteOperatingTimeCounter;
		retVal = DEM_BFM_RET_OK;
	}

	return retVal;
}

Dem_BfmReturnType Dem_BfmCounterGetRelativeOperatingTime( Dem_BfmRelativeOperatingTimeCounterType *operatingTime )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( operatingTime == NULL_PTR )
	{
		retVal = DEM_BFM_RET_NULL_PTR;
	}
	else
	{
		*operatingTime = mCountersRam.RelativeOperatingTimeCounter;
		retVal = DEM_BFM_RET_OK;
	}

	return retVal;
}

Dem_BfmReturnType Dem_BfmCounterGetRelativeOperatingTimeTimebase( Dem_BfmRelativeOperatingTimeCounterTimebaseType *timebase )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( timebase == NULL_PTR )
	{
		retVal = DEM_BFM_RET_NULL_PTR;
	}
	else
	{
		*timebase = DEM_BFM_TASK;
		retVal = DEM_BFM_RET_OK;
	}

	return retVal;
}

Dem_BfmReturnType Dem_BfmCounterGetTimestamp( Dem_BfmTimestampType *timestamp )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( timestamp == NULL_PTR )
	{
		retVal = DEM_BFM_RET_NULL_PTR;
	}
	else
	{
		*timestamp = mCountersRam.TimestampCounter;
		retVal = DEM_BFM_RET_OK;
	}

	return retVal;
}


//*****************************************************************************
void Dem_BfmCounterAdvanceOperationCycle( Dem_OperationCycleList currentTriggers )
{
	Dem_OperationCycleList operationCycleBitmask = (Dem_OperationCycleList)(1u << DEM_BFM_OPERATION_CYCLE_TYPE);

	if( (currentTriggers & operationCycleBitmask) != 0 )
	{
		//call BFM counter increment
		Dem_BfmCounterCalcOperationCycle();
	}
}

void Dem_BfmCounterCalcOperationCycle(void)
{
	//overflow protection
	if( Dem_BfmCounterValuesNvm.OperationCycleCounter != DEM_BFM_OPERATIONCYCLECOUNTER_MAX )
	{
		Dem_BfmCounterValuesNvm.OperationCycleCounter++;
	}

	//mark as modified
	mIsModified = TRUE;
}

static void Dem_BfmCounterCalcAbsoluteOperatingTime(void)
{
	mAbsolutCounterHelper++;

	if( (mAbsolutCounterHelper%(1000/DEM_BFM_TASK))==0 ) //one second complete
	{
		mAbsolutCounterHelper = 0;

		if( Dem_BfmCounterValuesNvm.AbsoluteOperatingTimeCounter != DEM_BFM_ABSOPERATINGTIME_MAX )
		{
			Dem_BfmCounterValuesNvm.AbsoluteOperatingTimeCounter++;

			if( (Dem_BfmCounterValuesNvm.AbsoluteOperatingTimeCounter%60u)==0u ) //one minute complete
			{
				mNvmStoreMinuteCounterHelper++;
			}
		}
	}
}

static void Dem_BfmCounterCalcRelativeOperatingTime(void)
{
	if( mCountersRam.RelativeOperatingTimeCounter != DEM_BFM_RELOPERATINGTIME_MAX )
	{
		mCountersRam.RelativeOperatingTimeCounter++;
	}
}

void Dem_BfmCounterCalcTimestamp(void)
{
	if( mCountersRam.TimestampCounter != DEM_BFM_TIMESTAMP_MAX )
	{
		mCountersRam.TimestampCounter++;
	}
}


//*****************************************************************************
void Dem_BfmCounterInitCheckNvM(void)
{
	//for the case that NvM_ReadAll didn't work out in the beginning
	Dem_BfmReturnType retVal = Dem_BfmNvmGetStatusCounter();
	if( (retVal==DEM_BFM_RET_NOK) || (retVal==DEM_BFM_RET_UNSUPPORTED) || (retVal==DEM_BFM_RET_INVALIDATED) )
	{
		DEM_MEMSET( &Dem_BfmCounterValuesNvm, 0x00, DEM_SIZEOF_TYPE(Dem_BfmCounterNvm) );
	}
}

void Dem_BfmCounterInit(void)
{
	//read counter to max value of stored BFM records
	Dem_BfmRecordFindMaxTimestampAndLocation( &mCountersRam.TimestampCounter, NULL_PTR );
}

void Dem_BfmCounterShutdown(void)
{
	//let NvM write counters in writeAll
	(void)Dem_BfmNvmSetRamBlockStatusCounter( TRUE );
}

void Dem_BfmCounterMainFunction(void)
{
	Dem_BfmCounterCalcAbsoluteOperatingTime();
	Dem_BfmCounterCalcRelativeOperatingTime();

	//every 15min save to NVM
	if( mNvmStoreMinuteCounterHelper >= (Dem_BfmConfigParam_pcs->savingInterval))
	{
		mIsModified = TRUE;
	}
}


//*****************************************************************************
boolean Dem_BfmCounterNeedsToBeSaved(void)
{
	return (mIsModified );
}

void Dem_BfmCounterSetNeedsToBeSaved( boolean needsTobeSaved )
{
	mIsModified = needsTobeSaved;
}

void Dem_BfmCounterGetCounterDataNvm( Dem_BfmCounterNvm *counterDataNvm )
{
	if( counterDataNvm != NULL_PTR )
	{
		counterDataNvm->AbsoluteOperatingTimeCounter = Dem_BfmCounterValuesNvm.AbsoluteOperatingTimeCounter;
		counterDataNvm->OperationCycleCounter = Dem_BfmCounterValuesNvm.OperationCycleCounter;
		mNvmStoreMinuteCounterHelper = 0;
	}
}


//*****************************************************************************
Std_ReturnType Dem_BfmWrapperGetOperationCycle( uint8* buffer, const Dem_InternalEnvData* internalData )
{
	Std_ReturnType retVal = E_NOT_OK;
	uint8 calcSize = DEM_SIZEOF_TYPE( Dem_BfmOperationCycleCounterType );
	Dem_BfmOperationCycleCounterType temp;

	if( internalData->size < calcSize )
	{
		DEM_DET(DEM_DET_APIID_BFM,DEM_E_PARAM_LENGTH);
	}
	else if( buffer == NULL_PTR )
	{
		DEM_DET(DEM_DET_APIID_BFM,DEM_E_PARAM_ADDRESS);
	}
	else
	{
		temp = Dem_BfmCounterValuesNvm.OperationCycleCounter;
		DEM_MEMCPY( buffer, &temp, calcSize );
		retVal = E_OK;
	}

	return retVal;
}

Std_ReturnType Dem_BfmWrapperGetAbsoluteOperatingTime( uint8* buffer, const Dem_InternalEnvData* internalData )
{
	Std_ReturnType retVal = E_NOT_OK;
	uint8 calcSize = DEM_SIZEOF_TYPE( Dem_BfmAbsoluteOperatingTimeCounterType );
	Dem_BfmAbsoluteOperatingTimeCounterType temp;

	if( internalData->size < calcSize )
	{
		DEM_DET(DEM_DET_APIID_BFM,DEM_E_PARAM_LENGTH);
	}
	else if( buffer == NULL_PTR )
	{
		DEM_DET(DEM_DET_APIID_BFM,DEM_E_PARAM_ADDRESS);
	}
	else
	{
		temp = Dem_BfmCounterValuesNvm.AbsoluteOperatingTimeCounter;
		DEM_MEMCPY( buffer, &temp, calcSize );
		retVal = E_OK;
	}

	return retVal;
}

Std_ReturnType Dem_BfmWrapperGetRelativeOperatingTime( uint8* buffer, const Dem_InternalEnvData* internalData )
{
	Std_ReturnType retVal = E_NOT_OK;
	uint8 calcSize = DEM_SIZEOF_TYPE( Dem_BfmRelativeOperatingTimeCounterType );
	Dem_BfmRelativeOperatingTimeCounterType temp;

	if( internalData->size < calcSize )
	{
		DEM_DET(DEM_DET_APIID_BFM,DEM_E_PARAM_LENGTH);
	}
	else if( buffer == NULL_PTR )
	{
		DEM_DET(DEM_DET_APIID_BFM,DEM_E_PARAM_ADDRESS);
	}
	else
	{
		temp = mCountersRam.RelativeOperatingTimeCounter;
		DEM_MEMCPY( buffer, &temp, calcSize );
		retVal = E_OK;
	}

	return retVal;
}

Std_ReturnType Dem_BfmWrapperGetTimestamp( uint8* buffer, const Dem_InternalEnvData* internalData )
{
	Std_ReturnType retVal = E_NOT_OK;
	uint8 calcSize = DEM_SIZEOF_TYPE( Dem_BfmTimestampType );
	Dem_BfmTimestampType temp;

	if( internalData->size < calcSize )
	{
		DEM_DET(DEM_DET_APIID_BFM,DEM_E_PARAM_LENGTH);
	}
	else if( buffer == NULL_PTR )
	{
		DEM_DET(DEM_DET_APIID_BFM,DEM_E_PARAM_ADDRESS);
	}
	else
	{
		temp = mCountersRam.TimestampCounter;
		DEM_MEMCPY( buffer, &temp, calcSize );
		retVal = E_OK;
	}

	return retVal;
}

#if 0
Std_ReturnType Dem_BfmWrapperGetOccurrenceCounter( uint8* buffer, const Dem_InternalEnvData* internalData )
{
	Std_ReturnType retVal = E_NOT_OK;
	Dem_BfmOccurenceCounterType tempOcc;
	uint8 calcSize = DEM_SIZEOF_TYPE( Dem_BfmOccurenceCounterType );

	if( internalData->size < calcSize )
	{
		DEM_DET(DEM_DET_APIID_BFM,DEM_E_PARAM_LENGTH);
	}
	else if( buffer == NULL_PTR )
	{
		DEM_DET(DEM_DET_APIID_BFM,DEM_E_PARAM_ADDRESS);
	}
	else
	{
		DEM_MEMCPY( &tempOcc, buffer, calcSize );
		tempOcc++;
		DEM_MEMCPY( buffer, &tempOcc, calcSize );
		retVal = E_OK;
	}

	return retVal;
}
#endif

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif //DEM_BFM_ENABLED
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.10.0.0; 5     14.07.2015 WUG3ABT
 *   Checkout by wug3abt
 * 
 * AR40.10.0.0; 4     09.07.2015 RPV5COB
 *   CSCRM00791814
 * 
 * AR40.10.0.0; 3     24.06.2015 WUG3ABT
 *   CSCRM00896357
 * 
 * AR40.10.0.0; 2     13.05.2015 WUG3ABT
 *   CSCRM00857327
 * 
 * AR40.10.0.0; 1     12.05.2015 CLH2SI
 *   CSCRM00789099
 * 
 * AR40.10.0.0; 0     17.03.2015 TVE5COB
 *   CSCRM00789300
 * 
 * AR40.9.0.0; 0     14.10.2014 VSA2COB
 *   CSCRM00554989
 * 
 * AR40.8.0.0; 4     18.03.2014 BPE4COB
 *   CSCRM00633982: [Dem]Review fixes
 * 
 * AR40.8.0.0; 3     27.02.2014 WUG3ABT
 *   CSCRM00588123
 * 
 * AR40.8.0.0; 2     27.02.2014 WUG3ABT
 *   CSCRM00633871
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
