/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2013. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************
* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_BfmRecord$
* $Variant___:AR40.11.0.1$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/
#ifndef DEM_BFMRECORD_H
#define DEM_BFMRECORD_H

#include "Dem_Cfg_Bfm.h"
#if( DEM_BFM_ENABLED == DEM_BFM_ON )

#include "Dem_BfmBuffer.h"

#define DEM_BFM_INVALID_INDEX  0xFFu

#define DEM_BFM_ST_PERM_LOCK	0x01u
#define DEM_BFM_ST_PERM_DELETE	0x02u
#define DEM_BFM_ST_PERM_EMPTY	0x04u
//define 0x08
//0x10
#define DEM_BFM_ST_PERM_EXT_DELETE	0x20u
#define DEM_BFM_ST_PERM_EXT_EMPTY	0x40u
//0x80

#define DEM_BFM_ST_TEMP_LOCK		0x01u
#define DEM_BFM_ST_TEMP_MODIFY		0x02u
#define DEM_BFM_ST_TEMP_EXT_MODIFY	0x20u

/**
 * @ingroup DEM_BFM_H
 *
 * This type is used to hold a complete BFM record. The order here (sorted by name) does not represent the order in the real struct.
 */
typedef struct
{
	Dem_BfmPriorityType priority; /**< The priority of the record (event that is saved), used in replacement logic */
	Dem_BfmStatusAndQualificationBitType statusAndQualification; /**< Contains the type (FAILED,PASSED,UNROBUST) and the time (FIRST,MOST CURRENT) of the last update/setting */
	#if( DEM_BFM_OCCURRENCE_COUNTER == DEM_BFM_ON )
	Dem_BfmOccurenceCounterType occurrences; /**< optional: the occurence counter gets incremented whenver the BFM record is updated (depends on configuration) */
	#endif
	/* MISRA RULE 1.1 VIOLATION: This byte array has Array Length of Zero when BFM Custom Data Size is Configured Zero */
	uint8 customData[DEM_BFM_CUSTOM_DATA_SIZE]; /**< This byte array contains the configured custom data of the BFM record */
	Dem_EventIdType eventId; /**< The event that is saved in this record */
	Dem_BfmTimestampType age; /**< The age/timestamp of the record, used in replacement logic */
	#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
	Dem_BfmExtDbgDataRecordIndexType ExtDbgDataRecordIndex; /**<optional: the index of the extended data record gets saved */
	#endif
}
Dem_BfmRecord;

/**
 * @ingroup DEM_BFM_H
 *
 * This type is used to hold a complete BFM extended data record.
 */
#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
typedef struct
{
	uint8 ExtData[DEM_BFM_EXTENDED_DEBUG_DATA_ELEMENT_SIZE]; /**< This byte array contains the BFM extend debug data */
	uint8 BfmRecIndex; /**< The index of the BFM record which it belongs to */
}
Dem_BfmExtendedDebugDataRecord;
#endif

/**
 * @ingroup DEM_BFM_H
 *
 * This type is used to hold the complete BFM record/ ExtDbgDataRecord .
 */
typedef union
{
	Dem_BfmRecord BfmRecord; /**< The union always provides enough space to save the content of a BfmRecord */

	#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
	Dem_BfmExtendedDebugDataRecord BfmExtDbgDataRecord; /**< optional: the union can also provide space to save the content of a Dem_BfmExtendedDebugDataRecord */
	#endif
}Dem_BfmNvMBufferType;


typedef struct
{
	uint8 managementData[DEM_BFM_AMOUNT_RECORDS];
	Dem_EventIdType eventId[DEM_BFM_AMOUNT_RECORDS];
	Dem_BfmTimestampType age;
}
Dem_BfmRecordManagementDataNvm;

typedef struct
{
	uint8 managementData[DEM_BFM_AMOUNT_RECORDS];
}
Dem_BfmRecordManagementDataRam;

typedef struct
{
	uint8 bufferIndex;
	uint16 offset;
}
Dem_BfmCustomDataElement;

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

    extern Dem_BfmLocationDataType Dem_BfmCurrentlyUpdatingLocation;
    extern boolean Dem_BfmIsCurrentlyBusyWithUpdating;

    #if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
    extern boolean Dem_BfmExtDbgDataRecIsCurrentlyBusyWithUpdating;
    extern Dem_BfmLocationDataType Dem_BfmExtDbgDataCurrentlyUpdatingLocation;
    #endif

#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

    //necessary to access the data directly through NvM configuration
    extern Dem_BfmRecordManagementDataNvm Dem_BfmRecordManagementDataValuesNvm;

#define DEM_STOP_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

void Dem_BfmRecordInitCheckNvM(void);
void Dem_BfmRecordInit(void);
void Dem_BfmRecordShutdown(void);

void Dem_BfmInitCausality(void);


void Dem_BfmRecordUpdateCustomData( Dem_BfmLocationDataType location, const Dem_BfmBufferData *buffer );
void Dem_BfmRecordUpdate( Dem_BfmLocationDataType location, const Dem_BfmBufferData *buffer );
Dem_BfmReturnType Dem_BfmRecordFindSlotForUpdate( const Dem_BfmBufferData *buffer, Dem_BfmLocationDataType *location );

void Dem_BfmRecordFindMaxTimestampAndLocation( Dem_BfmTimestampType *timestamp, Dem_BfmLocationDataType *location );
Dem_BfmTimestampType Dem_BfmRecordGetTimestamp( Dem_BfmLocationDataType location );

Dem_EventIdType Dem_BfmRecordGetEventId( Dem_BfmLocationDataType location );

/** * @ingroup DEM_BFM_H
 * Get the first location of the BFM records.
 * Use Dem_BfmRecordGetFirst() and Dem_BfmRecordGetNext() to iterator through all BFM locations.
 * <b>Never</b> manipulate the location manually.
 * @param [out]  location  pointer to a buffer that is filled with location of the first BFM record
 * @return  DEM_BFM_RET_OK: location got set\n
 *          DEM_BFM_RET_NULL_PTR: location pointer is invalid\n
 *          DEM_BFM_RET_NOK: something went wrong
 */
Dem_BfmReturnType Dem_BfmRecordGetFirst( Dem_BfmLocationDataType *location );

/** * @ingroup DEM_BFM_H
 * Get the next location of the BFM records.
 * Use Dem_BfmRecordGetFirst() and Dem_BfmRecordGetNext() to iterator through all BFM locations.
 * <b>Never</b> manipulate the location manually.
 * @param [in,out]  location  pointer to a buffer that contains the last location and is filled with the next location of a BFM record
 * @return  DEM_BFM_RET_OK: location got updated\n
 *          DEM_BFM_RET_NULL_PTR: location pointer is invalid\n
 *          DEM_BFM_RET_NOK: end of iteration reached
 */
Dem_BfmReturnType Dem_BfmRecordGetNext( Dem_BfmLocationDataType *location );

/** * @ingroup DEM_BFM_H
 * Find the location that contains information for the passed eventId.
 * @param [in]  eventId  can be [DEM_BFM_CHECK_RequestAccepted,DEM_BFM_CHECK_MemoryDeleted,DEM_BFM_CHECK_MangementDataWrittenToNvm]
 * @param [out]  location  can be [DEM_BFM_CHECK_RequestAccepted,DEM_BFM_CHECK_MemoryDeleted,DEM_BFM_CHECK_MangementDataWrittenToNvm]
 * @return  DEM_BFM_RET_OK: a BFM record was found that contains the searched eventId, the location pointer got set\n
 *          DEM_BFM_RET_NULL_PTR: location pointer is invalid\n
 *          DEM_BFM_RET_OUT_OF_RANGE: eventId is invalid\n
 *          DEM_BFM_RET_NOT_FOUND: no BFM record currently conatains information about the eventId
 */
Dem_BfmReturnType Dem_BfmRecordFind( Dem_EventIdType eventId, Dem_BfmLocationDataType *location );

#if(DEM_ENABLE_BFM_DIRECT_ACCESS_INTERFACE == DEM_BFM_ON)
/** * @ingroup DEM_BFM_H
 * Get direct read access to a BFM record.
 * <b>Caution:</b> only use this function within the BFM task context, eg inside a callback function.
 * <b>The function is not interrupt protected!!!</b>
 * The interface needs to be enabled through configuration switch: DemEnableBfmDirectAccessInterface
 * @param [in]  location  the BFM record you want to have read access
 * @param [out]  bfmRecord  is set to point to a BFM record
 * @param [out]  isMarkedForDeletion  is the record marked for deletion (you will see content in the record that is invalid)
 * @param [out]  isEmpty  is the record emtpy
 * @param [out]  isModified  is the record modified (updated and not yet saved in NvM)
 * @param [out]  isLockedPerm  is the record locked permanently
 * @param [out]  isLockedTemp  is the record locked temporary
 * @return  DEM_BFM_RET_OK: all pointers got updated\n
 *          DEM_BFM_RET_NULL_PTR: some pointer is invalid\n
 *          DEM_BFM_RET_OUT_OF_RANGE: location is invalid\n
 *          DEM_BFM_RET_NOK: something went wrong
 */
Dem_BfmReturnType Dem_BfmRecordGetDirectReadAccess( Dem_BfmLocationDataType location, Dem_BfmRecord const **bfmRecord,
		boolean *isMarkedForDeletion, boolean *isEmpty, boolean *isModified, boolean *isLockedPerm, boolean *isLockedTemp );
#endif

void Dem_BfmRecordLockAllTemp(void);
void Dem_BfmRecordUnlockAllTemp(void);
boolean Dem_BfmRecordIsLockedTemp( Dem_BfmLocationDataType location );
void Dem_BfmRecordSetLockedTemp( Dem_BfmLocationDataType location );
void Dem_BfmRecordResetLockedTemp( Dem_BfmLocationDataType location );
void Dem_BfmRecordLockAllPerm(void);
void Dem_BfmRecordUnlockAllPerm(void);
boolean Dem_BfmRecordIsLockedPerm( Dem_BfmLocationDataType location );
void Dem_BfmRecordSetLockedPerm( Dem_BfmLocationDataType location );
void Dem_BfmRecordResetLockedPerm( Dem_BfmLocationDataType location );
boolean Dem_BfmRecordHandleAllowLockedModify( Dem_BfmLocationDataType location, Dem_EventIdType eventId );

void Dem_BfmRecordRead( Dem_BfmLocationDataType location, void *buffer );
void Dem_BfmRecordGetManagementDataNvm( Dem_BfmRecordManagementDataNvm *managementDataNvm );

#if( DEM_BFM_NVM_BYTE_SWAPPING == DEM_BFM_ON )
void Dem_BfmRecordSwapBytes( Dem_BfmRecord *pBfmRecDest, Dem_BfmRecord const *pBfmRecSrc );
void Dem_BfmRecordReadByteSwapped( Dem_BfmLocationDataType location, void *destination, boolean handleDelete );
void Dem_BfmRecordWriteByteSwapped( Dem_BfmLocationDataType location, void const *source );
#endif

void Dem_BfmRecordHandleDeletion( Dem_BfmLocationDataType location );
void Dem_BfmRecordMarkAllForDeletion(void);

boolean Dem_BfmRecordIsSomeMarkedForDeletion(void);
void Dem_BfmRecordResetDeletionCounter(void);
boolean Dem_BfmRecordIsMarkedForDeletion( Dem_BfmLocationDataType location );
void Dem_BfmRecordResetDeletionFlag( Dem_BfmLocationDataType location );
void Dem_BfmRecordSetDeletionFlag( Dem_BfmLocationDataType location );

boolean Dem_BfmRecordIsSomeModified(void);
boolean Dem_BfmRecordIsModified( Dem_BfmLocationDataType location );
void Dem_BfmRecordResetModified( Dem_BfmLocationDataType location );
void Dem_BfmRecordSetModified( Dem_BfmLocationDataType location );

boolean Dem_BfmRecordIsManagementDataModified(void);
void Dem_BfmRecordSetManagementDataModified( boolean isModified );
void Dem_BfmRecordSetManagementDataEventId( Dem_BfmLocationDataType location, Dem_EventIdType eventId );

boolean Dem_BfmRecordIsEmpty( Dem_BfmLocationDataType location );
void Dem_BfmRecordSetEmpty( Dem_BfmLocationDataType location );
void Dem_BfmRecordResetEmpty( Dem_BfmLocationDataType location );

void* Dem_BfmRecordGetAddress( Dem_BfmLocationDataType location );

void Dem_BfmConsistencyChkForManagementData(void);
void Dem_BfmConsistencyChkForBfmCounters(void);

#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)

uint8 Dem_BfmGetExtDbgDataRecordIndex(Dem_BfmLocationDataType location);
Dem_BfmReturnType Dem_BfmExtDbgDataRecordFindslotForUpdate(Dem_BfmLocationDataType location,Dem_BfmLocationDataType *locationEdd,const Dem_BfmBufferData *buffer );

void Dem_BfmExtDbgDataRecordRead(Dem_BfmLocationDataType location, void *buffer);
Dem_BfmLocationDataType Dem_BfmExtDbgDataGetBfmRecordIndex( Dem_BfmLocationDataType location );

void Dem_BfmExtSetBfmIndexToInvalid(Dem_BfmLocationDataType ExtRecIndex);
void* Dem_BfmExtDbgDataGetRecordAddress(Dem_BfmLocationDataType location);
void Dem_BfmExtDbgDataRecordEmptyRam(uint8 ExtRecIndex);

void Dem_BfmExtDbgDataRecordSetEmpty(Dem_BfmLocationDataType location);
boolean Dem_BfmExtDbgDataRecordIsEmpty(Dem_BfmLocationDataType location);
void Dem_BfmExtDbgDataRecordResetEmpty( Dem_BfmLocationDataType location );

void Dem_BfmExtDbgDataRecordUpdate(Dem_BfmLocationDataType location, Dem_BfmLocationDataType ExtRecLocation);

void Dem_BfmExtDbgDataRecordHandleDeletion( Dem_BfmLocationDataType location );

boolean Dem_BfmExtDbgDataRecordIsModified(Dem_BfmLocationDataType location);
void Dem_BfmExtDbgDataRecordResetModified(Dem_BfmLocationDataType location);
void Dem_BfmExtDbgDataRecordSetDeletionFlag( Dem_BfmLocationDataType location );
void Dem_BfmExtDbgRecordResetDeletionFlag( Dem_BfmLocationDataType location );
boolean Dem_BfmExtDbgDataRecordIsMarkedForDeletion(Dem_BfmLocationDataType location);
void Dem_BfmExtDbgDataRecordSetModified(Dem_BfmLocationDataType location);
void Dem_BfmSetExtDbgDataRecIndexToInvalid(Dem_BfmLocationDataType BfmRecordIndex);
#endif

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif //DEM_BFM_ENABLED
#endif
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.1; 0     03.02.2016 CLH2SI
*   CSCRM01036799
* 
* AR40.11.0.0; 0     16.10.2015 VSA2COB
*   Checkout by vsa2cob
* 
* AR40.10.0.0; 2     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 1     09.07.2015 RPV5COB
*   CSCRM00791814
* 
* AR40.10.0.0; 0     24.06.2015 WUG3ABT
*   CSCRM00896357
* 
* AR40.9.0.0; 4     06.01.2015 GJ83ABT
*   CSCRM00751490
* 
* AR40.9.0.0; 3     06.01.2015 TVE5COB
*   CSCRM00741126
* 
* AR40.9.0.0; 2     20.10.2014 BPE4COB
*   CSCRM00716141
* 
* AR40.9.0.0; 1     14.10.2014 VSA2COB
*   CSCRM00554989
* 
* AR40.9.0.0; 0     25.08.2014 BPE4COB
*   CSCRM00641522
* 
* $
**********************************************************************************************************************
</BASDKey>*/
