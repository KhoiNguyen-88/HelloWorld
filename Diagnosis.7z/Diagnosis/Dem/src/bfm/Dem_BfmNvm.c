/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2013. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************
* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_BfmNvm$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/
#include "Dem_BfmNvm.h"
#if( DEM_BFM_ENABLED == DEM_BFM_ON )

#include "Dem_Cfg_BfmNvm.h"
#include "NvM.h"

#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

    static const NvM_BlockIdType mBfmNvmRecords[DEM_BFM_FIX_ARRAY_SIZE(DEM_BFM_AMOUNT_NVM_RECORDS)] = {DEM_BFM_NVM_RECORDS};
    #if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
    static const NvM_BlockIdType mBfmExtNvmRecords[DEM_BFM_FIX_ARRAY_SIZE(DEM_BFM_AMOUNT_NVM_EXT_RECORDS)] = {DEM_BFM_EXT_NVM_RECORDS};
    #endif

#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

//*****************************************************************************
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
static Dem_BfmReturnType Dem_BfmNvmTranslateResult( NvM_RequestResultType result )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	switch( result )
	{
		case NVM_REQ_REDUNDANCY_FAILED: //only a info, but still does store non redundant
		case NVM_REQ_RESTORED_FROM_ROM: //read from rom worked, why is this not simply ok???
		case NVM_REQ_OK:
			retVal = DEM_BFM_RET_OK;
			break;

		case NVM_REQ_PENDING:
			retVal = DEM_BFM_RET_PENDING;
			break;

		case NVM_REQ_NOT_OK:
			retVal = DEM_BFM_RET_NOK;
			break;

		case NVM_REQ_NV_INVALIDATED:
		case NVM_REQ_INTEGRITY_FAILED:
			retVal = DEM_BFM_RET_INVALIDATED;
			break;

		case NVM_REQ_BLOCK_SKIPPED:
		case NVM_REQ_CANCELED:

		default:
			retVal = DEM_BFM_RET_UNSUPPORTED;
			break;
	}

	return retVal;
}



//*****************************************************************************
static Dem_BfmReturnType Dem_BfmNvmWrite(NvM_BlockIdType blockId, void *src)
{
    Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

    if( src == NULL_PTR )
    {
        retVal = DEM_BFM_RET_NULL_PTR;
    }
    else
    {
        if( NvM_WriteBlock(blockId, src) == E_OK )
        {
            retVal = DEM_BFM_RET_OK;
        }
    }

    return retVal;
}

Dem_BfmReturnType Dem_BfmNvmWriteRecord( Dem_BfmLocationDataType location, void *record )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( location>=DEM_BFM_AMOUNT_NVM_RECORDS )
	{
		retVal = DEM_BFM_RET_OUT_OF_RANGE;
	}
	else
	{
		retVal = Dem_BfmNvmWrite( mBfmNvmRecords[location], record );
	}

	return retVal;
}


Dem_BfmReturnType Dem_BfmNvmWriteCounter( Dem_BfmCounterNvm *counter )
{
	return Dem_BfmNvmWrite( DEM_NVM_ID_BFM_COUNTERS, counter );
}

Dem_BfmReturnType Dem_BfmNvmWriteManagementData( Dem_BfmRecordManagementDataNvm *managementData )
{
	return Dem_BfmNvmWrite( DEM_NVM_ID_BFM_MANAGEMENT_DATA, managementData );
}

#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
Dem_BfmReturnType Dem_BfmNvmWriteExtDbgDataRecord( Dem_BfmLocationDataType location, void *record )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( location>=DEM_BFM_AMOUNT_NVM_EXT_RECORDS )
	{
		retVal = DEM_BFM_RET_OUT_OF_RANGE;
	}
	else
	{
		retVal = Dem_BfmNvmWrite( mBfmExtNvmRecords[location], record );
	}

	return retVal;
}
#endif

//*****************************************************************************
static Dem_BfmReturnType Dem_BfmNvmRead(NvM_BlockIdType blockId, void *dest)
{
    Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

    if( dest == NULL_PTR )
    {
        retVal = DEM_BFM_RET_NULL_PTR;
    }
    else
    {
        if( NvM_ReadBlock(blockId, dest) == E_OK )
        {
            retVal = DEM_BFM_RET_OK;
        }
    }

    return retVal;
}

Dem_BfmReturnType Dem_BfmNvmReadRecord( Dem_BfmLocationDataType location, Dem_BfmRecord *record )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( location>=DEM_BFM_AMOUNT_NVM_RECORDS )
	{
		retVal = DEM_BFM_RET_OUT_OF_RANGE;
	}
	else
	{
		retVal = Dem_BfmNvmRead( mBfmNvmRecords[location], record );
	}

	return retVal;
}

Dem_BfmReturnType Dem_BfmNvmReadCounter( Dem_BfmCounterNvm *counter )
{
	return Dem_BfmNvmRead( DEM_NVM_ID_BFM_COUNTERS, counter );
}

Dem_BfmReturnType Dem_BfmNvmReadManagementData( Dem_BfmRecordManagementDataNvm *managementData )
{
	return Dem_BfmNvmRead( DEM_NVM_ID_BFM_MANAGEMENT_DATA, managementData );
}


//*****************************************************************************
static Dem_BfmReturnType Dem_BfmNvmGetStatus( NvM_BlockIdType blockId )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;
	NvM_RequestResultType result;

	if( NvM_GetErrorStatus( blockId, &result) == E_OK )
	{
		retVal = Dem_BfmNvmTranslateResult( result );
	}

	return retVal;
}

Dem_BfmReturnType Dem_BfmNvmGetStatusRecord( Dem_BfmLocationDataType location )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( location>=DEM_BFM_AMOUNT_NVM_RECORDS )
	{
		retVal = DEM_BFM_RET_OUT_OF_RANGE;
	}
	else
	{
		retVal = Dem_BfmNvmGetStatus( mBfmNvmRecords[location] );
	}

	return retVal;
}

#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
Dem_BfmReturnType Dem_BfmNvmGetStatusExtDbgDataRecord( Dem_BfmLocationDataType location )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( location>=DEM_BFM_AMOUNT_NVM_EXT_RECORDS )
	{
		retVal = DEM_BFM_RET_OUT_OF_RANGE;
	}
	else
	{
		retVal = Dem_BfmNvmGetStatus( mBfmExtNvmRecords[location] );
	}

	return retVal;
}
#endif

Dem_BfmReturnType Dem_BfmNvmGetStatusCounter(void)
{
	return Dem_BfmNvmGetStatus( DEM_NVM_ID_BFM_COUNTERS );
}

Dem_BfmReturnType Dem_BfmNvmGetStatusManagementData(void)
{
	return Dem_BfmNvmGetStatus( DEM_NVM_ID_BFM_MANAGEMENT_DATA );
}


//*****************************************************************************
static Dem_BfmReturnType Dem_BfmNvmSetRamBlockStatus( NvM_BlockIdType blockId, boolean blockChanged )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( NvM_SetRamBlockStatus( blockId, blockChanged ) == E_OK )
	{
		retVal = DEM_BFM_RET_OK;
	}

	return retVal;
}

Dem_BfmReturnType Dem_BfmNvmSetRamBlockStatusRecord( Dem_BfmLocationDataType location, boolean blockChanged )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( location>=DEM_BFM_AMOUNT_NVM_RECORDS )
	{
		retVal = DEM_BFM_RET_OUT_OF_RANGE;
	}
	else
	{
		retVal = Dem_BfmNvmSetRamBlockStatus( mBfmNvmRecords[location], blockChanged );
	}

	return retVal;
}

#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
Dem_BfmReturnType Dem_BfmNvmSetRamBlockStatusExtDbgDataRecord( Dem_BfmLocationDataType location, boolean blockChanged )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( location>=DEM_BFM_AMOUNT_NVM_EXT_RECORDS )
	{
		retVal = DEM_BFM_RET_OUT_OF_RANGE;
	}
	else
	{
		retVal = Dem_BfmNvmSetRamBlockStatus( mBfmExtNvmRecords[location], blockChanged );
	}

	return retVal;
}
#endif

Dem_BfmReturnType Dem_BfmNvmSetRamBlockStatusCounter( boolean blockChanged )
{
	return Dem_BfmNvmSetRamBlockStatus( DEM_NVM_ID_BFM_COUNTERS, blockChanged );
}

Dem_BfmReturnType Dem_BfmNvmSetRamBlockStatusManagementData( boolean blockChanged )
{
	return Dem_BfmNvmSetRamBlockStatus( DEM_NVM_ID_BFM_MANAGEMENT_DATA, blockChanged );
}


//*****************************************************************************
static Dem_BfmReturnType Dem_BfmNvmErase( NvM_BlockIdType blockId )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( NvM_EraseNvBlock( blockId ) == E_OK )
	{
		retVal = DEM_BFM_RET_OK;
	}

	return retVal;
}

Dem_BfmReturnType Dem_BfmNvmEraseRecord( Dem_BfmLocationDataType location )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( location>=DEM_BFM_AMOUNT_NVM_RECORDS )
	{
		retVal = DEM_BFM_RET_OUT_OF_RANGE;
	}
	else
	{
		retVal = Dem_BfmNvmErase( mBfmNvmRecords[location] );
	}

	return retVal;
}

Dem_BfmReturnType Dem_BfmNvmEraseCounter(void)
{
	return Dem_BfmNvmErase( DEM_NVM_ID_BFM_COUNTERS );
}

Dem_BfmReturnType Dem_BfmNvmEraseManagementData(void)
{
	return Dem_BfmNvmErase( DEM_NVM_ID_BFM_MANAGEMENT_DATA );
}

//*****************************************************************************
Std_ReturnType Dem_BfmNvmWriteRamBlockToNvmCallback( void* NvmBufDest, Dem_BfmLocationDataType locSrc )
{
	#if( DEM_BFM_NVM_BYTE_SWAPPING == DEM_BFM_ON )
	Dem_BfmRecordReadByteSwapped( locSrc, NvmBufDest, FALSE );
	#else
	DEM_MEMCPY( NvmBufDest, Dem_BfmRecordGetAddress(locSrc), DEM_SIZEOF_TYPE(Dem_BfmRecord) );
	#endif

	return E_OK;
}

/* MISRA RULE 16.7 VIOLATION: Interface is defined by AUTOSAR */
Std_ReturnType Dem_BfmNvmReadRamBlockFromNvmCallback( void* NvmBufSrc, Dem_BfmLocationDataType locDest )
{
	#if( DEM_BFM_NVM_BYTE_SWAPPING == DEM_BFM_ON )
	Dem_BfmRecordWriteByteSwapped( locDest, NvmBufSrc );
	#else
	DEM_MEMCPY( Dem_BfmRecordGetAddress(locDest), NvmBufSrc, DEM_SIZEOF_TYPE(Dem_BfmRecord) );
	#endif

	return E_OK;
}

//*****************************************************************************
#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
Std_ReturnType Dem_BfmNvmWriteExtDbgDataRamBlockToNvmCallback(void* NvmBufDest, Dem_BfmLocationDataType locSrc)
{
	DEM_MEMCPY( NvmBufDest, Dem_BfmExtDbgDataGetRecordAddress(locSrc), DEM_SIZEOF_TYPE(Dem_BfmExtendedDebugDataRecord) );

	return E_OK;
}

/* MISRA RULE 16.7 VIOLATION: Interface is defined by AUTOSAR */
Std_ReturnType Dem_BfmNvmReadExtDbgDataRamBlockFromNvmCallback(void* NvmBufSrc, Dem_BfmLocationDataType locDest)
{
	DEM_MEMCPY( Dem_BfmExtDbgDataGetRecordAddress(locDest), NvmBufSrc, DEM_SIZEOF_TYPE(Dem_BfmExtendedDebugDataRecord) );

	return E_OK;
}
#endif




//*****************************************************************************
#ifdef DEM_TESTSUITE
uint32 DemTest_BfmRecordGetBlockId( Dem_BfmLocationDataType location )
{
    return mBfmNvmRecords[location];
}

#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
uint32 DemTest_BfmExtDbgDataRecordGetBlockId( Dem_BfmLocationDataType location )
{
    return mBfmExtNvmRecords[location];
}
#endif

uint32 DemTest_BfmManagementDataGetBlockId()
{
    return DEM_NVM_ID_BFM_MANAGEMENT_DATA;
}

uint32 DemTest_BfmCounterGetBlockId()
{
    return DEM_NVM_ID_BFM_COUNTERS;
}
#endif


#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif //DEM_BFM_ENABLED
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     16.10.2015 VSA2COB
*   Checkout by vsa2cob
* 
* AR40.10.0.0; 4     10.07.2015 CLH2SI
*   CSCRM00938605
* 
* AR40.10.0.0; 3     24.06.2015 WUG3ABT
*   CSCRM00896357
* 
* AR40.10.0.0; 2     13.05.2015 WUG3ABT
*   CSCRM00857327
* 
* AR40.10.0.0; 1     12.05.2015 CLH2SI
*   CSCRM00789099
* 
* AR40.10.0.0; 0     17.03.2015 TVE5COB
*   CSCRM00789300
* 
* AR40.9.0.0; 1     14.10.2014 VSA2COB
*   CSCRM00554989
* 
* AR40.9.0.0; 0     25.08.2014 BPE4COB
*   CSCRM00641522
* 
* AR40.8.0.0; 0     13.06.2014 WUG3ABT
*   CSCRM00610171
* 
* AR40.7.0.0; 4     12.12.2013 GET1COB
*   CSCRM00597621
* 
* $
**********************************************************************************************************************
</BASDKey>*/
