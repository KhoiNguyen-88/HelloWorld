/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2013. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************
* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_PB_Bfm$
* $Variant___:AR40.9.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_PB_BFM_H
#define DEM_PB_BFM_H

/*
 ***************************************************************************************************
 * Includes
 ***************************************************************************************************
 */

#include "Dem_Cfg_Bfm.h"
#if (DEM_BFM_ENABLED == DEM_BFM_ON)

#include "Dem_BfmTypes.h"



#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

/* Dem_ConfigParam_cs global structure of type Dem_BfmConfigDataType */
extern const Dem_BfmConfigDataType Dem_BfmConfigParam_cs;

#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"


#endif

#endif

/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.9.0.0; 0     14.10.2014 VSA2COB
*   CSCRM00554989
* 
* $
**********************************************************************************************************************
</BASDKey>*/
