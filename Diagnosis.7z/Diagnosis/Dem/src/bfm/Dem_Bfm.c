/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2013. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:C$
 * $Name______:Dem_Bfm$
 * $Variant___:AR40.10.0.0$
 * $Revision__:4$
 **********************************************************************************************************************
</BASDKey>*/
#include "Dem_Bfm.h"
#if( DEM_BFM_ENABLED == DEM_BFM_ON )
#include "Dem_PB_Bfm.h"
#include "Dem_BfmUtils.h"
#include "Dem_BfmNvm.h"

#define BFM_STATE_IDLE 0
#define BFM_STATE_REQUESTED 1
#define BFM_STATE_EXECUTING 2
#define BFM_STATE_EXECUTING_EXTENDED_RECORD	3
#define BFM_STATE_FINISHED 4

#define BFM_DELETE_STATE_IDLE 0
#define BFM_DELETE_STATE_MARKED 1
#define BFM_DELETE_STATE_RAM_ZEROED 2
#define BFM_DELETE_STATE_NVM_STARTED 3
#define BFM_DELETE_STATE_NVM_FINISHED 4


#define DEM_START_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"

	Dem_BfmConfigDataType const * Dem_BfmConfigParam_pcs = NULL_PTR;

	//flags for external requests (need to be atomic)
	static atomic_b m_BfmRequestDeleteAll = FALSE;
	static atomic_b m_BfmRequestLockTemp = FALSE;
	static atomic_b m_BfmRequestLockPerm = FALSE;
	static atomic_b m_BfmRequestUnlockTemp = FALSE;
	static atomic_b m_BfmRequestUnlockPerm = FALSE;

	static atomic_ui8 m_BfmDeleteAll_State = BFM_DELETE_STATE_IDLE;

	//NvM write a record
	static atomic_ui8 m_BfmNvMWriteState = BFM_STATE_IDLE;
	static Dem_BfmLocationDataType m_BfmNvMWriteLocation = 0;

	//NvM read a record
	static atomic_ui8 m_BfmNvMReadState = BFM_STATE_IDLE;
	static Dem_BfmLocationDataType m_BfmNvMReadLocation = 0;
	static Dem_BfmRecord *m_BfmNvMReadTarget = NULL_PTR;
	static uint8 m_BfmNvMReadReleaseCounter = 0; //avoid lock if check function in never called
	static uint8 m_BfmNvMReadRequestLimitCounter = 0; //avoid lock if NvM block cannot be red
	static Dem_BfmReturnType m_BfmNvMReadReturnValue = DEM_BFM_RET_OK; //result from NvM read operation

	//RAM read a record
	static atomic_ui8 m_BfmRamReadState = BFM_STATE_IDLE;
	static Dem_BfmLocationDataType m_BfmRamReadLocation = 0;
	static Dem_BfmRecord *m_BfmRamReadTarget = NULL_PTR;
	static uint8 m_BfmRamReadReleaseCounter = 0; //avoid lock if check function in never called

	static atomic_ui8 m_BfmNvMWriteManagementState = BFM_STATE_IDLE;
	static atomic_ui8 m_BfmNvMWriteCountersState = BFM_STATE_IDLE;

	//where did last delete or modify operation stop
	static Dem_BfmLocationDataType lastDeleteLocation=0;
	static Dem_BfmLocationDataType lastModifyLocation=0;

	static boolean Dem_BfmModifyHandlingIsDoneInBFM = TRUE;
	static boolean Dem_BfmDeletionHandlingIsDoneInBFM = TRUE;

	//Nvm write trigger
	static atomic_b Dem_BfmTriggerFlag = FALSE;

	#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
	//RAM read a Extended data record
	static uint8 m_BfmRamExtDDReadReleaseCounter = 0;
	static atomic_ui8 m_BfmExtendedRamReadState = BFM_STATE_IDLE;
	static Dem_BfmLocationDataType m_BfmExtendedRamReadLocation = 0;
	static Dem_BfmExtendedDebugDataRecord *m_BfmExtendedRamReadTarget = NULL_PTR;
	#endif

#define DEM_STOP_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"


#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

	static Dem_BfmNvMBufferType m_BfmWriteRecordToNvMBuffer;

	static Dem_BfmRecord m_BfmReadRecordFromNvM;

	//NvM write management data
	static Dem_BfmRecordManagementDataNvm m_BfmWriteManagementDataToNvMBuffer;

	//NvM write counters
	static Dem_BfmCounterNvm m_BfmWriteCountersToNvMBuffer;

#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"


#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
//*****************************************************************************
static void Dem_BfmHandleDeleteAndLocking(void)
{
	if( m_BfmRequestDeleteAll )
	{
		Dem_BfmRecordMarkAllForDeletion();
		lastDeleteLocation = 0;

		m_BfmDeleteAll_State = BFM_DELETE_STATE_MARKED;
		m_BfmRequestDeleteAll = FALSE;
	}

	if( Dem_BfmRecordIsSomeMarkedForDeletion() )
	{
		uint8 i = (Dem_BfmConfigParam_pcs->recordDeletionsPerCycle);
		uint8 k = DEM_BFM_AMOUNT_RECORDS;
		boolean hopOn = TRUE;
		Dem_BfmLocationDataType startPos = lastDeleteLocation;
		#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
		uint8 j = DEM_BFM_EXTENDED_DEBUG_DATA_AMOUNT_RECORDS;
		boolean startHandlingMemory = Dem_BfmDeletionHandlingIsDoneInBFM;
		#endif

		do
		{
			if((i!=0) && (k!=0) && (Dem_BfmDeletionHandlingIsDoneInBFM) )
			{
				if( Dem_BfmRecordIsMarkedForDeletion(lastDeleteLocation) )
				{
					Dem_BfmRecordHandleDeletion( lastDeleteLocation );
					i--;
				}

				lastDeleteLocation++;
				if( lastDeleteLocation>=DEM_BFM_AMOUNT_RECORDS )
				{
					lastDeleteLocation = 0;
					#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
					Dem_BfmDeletionHandlingIsDoneInBFM = FALSE;
					#endif
				}

				k--;
			}

			#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
			if((i!=0) && (j!=0) && (!Dem_BfmDeletionHandlingIsDoneInBFM))
			{
				if( Dem_BfmExtDbgDataRecordIsMarkedForDeletion(lastDeleteLocation) )
				{
					Dem_BfmExtDbgDataRecordHandleDeletion( lastDeleteLocation );
					i--;
				}

				lastDeleteLocation++;
				if( lastDeleteLocation>=DEM_BFM_EXTENDED_DEBUG_DATA_AMOUNT_RECORDS )
				{
					lastDeleteLocation = 0;
					Dem_BfmDeletionHandlingIsDoneInBFM = TRUE;
				}

				j--;
			}
			#endif

			//Required to make a complete loop and not only covering half of the elements
			if((i==0) ||(( lastDeleteLocation == startPos )
			#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
				&& (Dem_BfmDeletionHandlingIsDoneInBFM == startHandlingMemory )
			#endif
			))
			{
				hopOn = FALSE;
			}

		}while(hopOn==TRUE);


		if( (k==0) && (i==(Dem_BfmConfigParam_pcs->recordDeletionsPerCycle))
		#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
				&& (j==0)
		#endif
		)
		{
			//error: nothing got deleted -> deletion counter is wrong -> reset counter to avoid additional loops
			Dem_BfmRecordResetDeletionCounter();
			Dem_BfmRecordSetManagementDataModified( TRUE );
			DEM_DET(DEM_DET_APIID_BFM,DEM_E_WRONG_CONDITION);
		}

		//only set flag if previous steps of delete request have been performed
		if( !Dem_BfmRecordIsSomeMarkedForDeletion() && (m_BfmDeleteAll_State==BFM_DELETE_STATE_MARKED) )
		{
			m_BfmDeleteAll_State = BFM_DELETE_STATE_RAM_ZEROED;
		}
	}
	else //do not handle external lock/unlock during delete
	{
		//if lock and unlock are set "simultaneously" than lock has the higher priority
		if( m_BfmRequestLockTemp )
		{
			Dem_BfmRecordLockAllTemp();
			m_BfmRequestLockTemp = FALSE;
			m_BfmRequestUnlockTemp = FALSE;
		}
		else if( m_BfmRequestUnlockTemp )
		{
			Dem_BfmRecordUnlockAllTemp();
			m_BfmRequestUnlockTemp = FALSE;
		}
		else
		{
			//To avoid Misra warning
		}

		//if lock and unlock are set "simultaneously" than lock has the higher priority
		if( m_BfmRequestLockPerm )
		{
			Dem_BfmRecordLockAllPerm();
			m_BfmRequestLockPerm = FALSE;
			m_BfmRequestUnlockPerm = FALSE;
		}
		else if( m_BfmRequestUnlockPerm )
		{
			Dem_BfmRecordUnlockAllPerm();
			m_BfmRequestUnlockPerm = FALSE;
		}
		else
		{
			//To avoid Misra warning
		}
	}
}

//*****************************************************************************
static void Dem_BfmHandleReadRam(void)
{
	atomic_ui8 state;

	#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
	atomic_ui8 ExtendedRecstate;
	#endif

	boolean Bfm_DetErrorflag = FALSE;

	BFM_ENTER_LOCK_EXTERNAL_READ_NONEST();
	state = m_BfmRamReadState;

	if( BFM_STATE_FINISHED == state )
	{
		m_BfmRamReadReleaseCounter++;

		//do not get stuck if a task never calls check()
		if( (Dem_BfmConfigParam_pcs->releaseCounterLimit) <= m_BfmRamReadReleaseCounter )
		{
			m_BfmRamReadState = BFM_STATE_IDLE;

			//Set the error flag
			Bfm_DetErrorflag = TRUE;
		}
	}

	#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)

	ExtendedRecstate = m_BfmExtendedRamReadState;

	if (BFM_STATE_FINISHED == ExtendedRecstate)
	{
		m_BfmRamExtDDReadReleaseCounter++;
		//do not get stuck if a task never calls check()
		if( (Dem_BfmConfigParam_pcs->releaseCounterLimit) <= m_BfmRamExtDDReadReleaseCounter )
		{
			m_BfmExtendedRamReadState = BFM_STATE_IDLE;

			//Set the error flag
			Bfm_DetErrorflag = TRUE;
		}

	}

	#endif

	BFM_EXIT_LOCK_EXTERNAL_READ_NONEST();

	if(Bfm_DetErrorflag)
	{
		DEM_DET(DEM_DET_APIID_BFM,DEM_E_OUTOFTIME);
	}

	if( BFM_STATE_REQUESTED == state )
	{
		Dem_BfmRecordRead( m_BfmRamReadLocation, m_BfmRamReadTarget );

		m_BfmRamReadState = BFM_STATE_FINISHED;

		m_BfmRamReadReleaseCounter = 0;
	}


	#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
	if(BFM_STATE_REQUESTED == ExtendedRecstate )
	{
		Dem_BfmExtDbgDataRecordRead( m_BfmExtendedRamReadLocation, m_BfmExtendedRamReadTarget );

		m_BfmExtendedRamReadState = BFM_STATE_FINISHED;

		m_BfmRamExtDDReadReleaseCounter = 0;
	}
	#endif

}

//*****************************************************************************
static void Dem_BfmHandleReadNvM(void)
{
    atomic_ui8 state;
    boolean Bfm_DetErrorFlag = FALSE;

    BFM_ENTER_LOCK_EXTERNAL_NVM_READ_NONEST();
    state = m_BfmNvMReadState;

    if( BFM_STATE_FINISHED == state )
    {
        m_BfmNvMReadReleaseCounter++;

        //do not get stuck if a task never calls check()
        if (m_BfmNvMReadReleaseCounter >= (Dem_BfmConfigParam_pcs->releaseCounterLimit))
        {
            m_BfmNvMReadState = BFM_STATE_IDLE;

            //set the Error flag
            Bfm_DetErrorFlag = TRUE;

        }
    }
    BFM_EXIT_LOCK_EXTERNAL_NVM_READ_NONEST();

    if( Bfm_DetErrorFlag )
    {
        DEM_DET(DEM_DET_APIID_BFM, DEM_E_OUTOFTIME);
    }

    if( BFM_STATE_REQUESTED == state )
    {
        if( Dem_BfmNvmReadRecord(m_BfmNvMReadLocation, &m_BfmReadRecordFromNvM) == DEM_BFM_RET_OK )
        {
            m_BfmNvMReadState = BFM_STATE_EXECUTING;
        }
        else //try several times
        {
            if (m_BfmNvMReadRequestLimitCounter >= (Dem_BfmConfigParam_pcs->nvmBlockAccessRetries))
            {
                m_BfmNvMReadReturnValue = DEM_BFM_RET_NOK;
                m_BfmNvMReadState = BFM_STATE_FINISHED;
                DEM_DET(DEM_DET_APIID_BFM, DEM_E_OUTOFTIME);
            }

            m_BfmNvMReadRequestLimitCounter++;
        }
    }
    else if( BFM_STATE_EXECUTING == state )
    {
        Dem_BfmReturnType result = Dem_BfmNvmGetStatusRecord(m_BfmNvMReadLocation);

        if( result == DEM_BFM_RET_PENDING ) //pending
        {
            //wait another cycle
        }
        else if (result == DEM_BFM_RET_OK) //ok
        {
            Dem_BfmRecordHandleDeletion(m_BfmNvMReadLocation);

            if (Dem_BfmRecordIsEmpty(m_BfmNvMReadLocation))
            {
                DEM_MEMSET(m_BfmNvMReadTarget, 0, DEM_SIZEOF_TYPE(Dem_BfmRecord));

                #if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
                m_BfmNvMReadTarget->ExtDbgDataRecordIndex = DEM_BFM_INVALID_INDEX;
                #endif
            }
            else
            {
                //copy to target / final destination
                DEM_MEMCPY(m_BfmNvMReadTarget, &m_BfmReadRecordFromNvM, DEM_SIZEOF_TYPE(Dem_BfmRecord));
            }

            m_BfmNvMReadReturnValue = DEM_BFM_RET_OK;
            m_BfmNvMReadState = BFM_STATE_FINISHED;
        }
        else if (result == DEM_BFM_RET_INVALIDATED)
        {
            m_BfmNvMReadReturnValue = DEM_BFM_RET_INVALIDATED;
            m_BfmNvMReadState = BFM_STATE_FINISHED;
        }
        else //error situation
        {
            m_BfmNvMReadReturnValue = DEM_BFM_RET_NOK;
            m_BfmNvMReadState = BFM_STATE_FINISHED;
            DEM_DET(DEM_DET_APIID_BFM, DEM_E_WRONG_CONDITION);
        }
    }
    else //BFM_STATE_IDLE
    {
        //nothing to do
    }
}

//*****************************************************************************
static void Dem_BfmHandleModifiedRecords(void)
{
    Dem_BfmReturnType result;

    if( BFM_STATE_EXECUTING == m_BfmNvMWriteState )
    {
        result = Dem_BfmNvmGetStatusRecord(m_BfmNvMWriteLocation);

        if( result != DEM_BFM_RET_PENDING ) //finished
        {
            m_BfmNvMWriteState = BFM_STATE_IDLE;
        }
        else //pending
        {
            //wait another cycle
        }
    }
    #if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
    else if( BFM_STATE_EXECUTING_EXTENDED_RECORD == m_BfmNvMWriteState )
    {
        result = Dem_BfmNvmGetStatusExtDbgDataRecord(m_BfmNvMWriteLocation);

        if( result != DEM_BFM_RET_PENDING )
        {
            m_BfmNvMWriteState = BFM_STATE_IDLE;
        }
        else //pending
        {
            //wait another cycle
        }
    }
    #endif
    else
    {

    }

    if( Dem_BfmRecordIsSomeModified() && (BFM_STATE_IDLE == m_BfmNvMWriteState) )
    {
        Dem_BfmLocationDataType startPos = lastModifyLocation;
        boolean hopOn = TRUE;

        #if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
        boolean startHandlingMemory = Dem_BfmModifyHandlingIsDoneInBFM;
        #endif

        do
        {
            //Check whether the Bfm Record is modified
            if( Dem_BfmModifyHandlingIsDoneInBFM && Dem_BfmRecordIsModified(lastModifyLocation) )
            {
                #if( DEM_BFM_NVM_BYTE_SWAPPING == DEM_BFM_ON )
                Dem_BfmRecordReadByteSwapped(lastModifyLocation, &m_BfmWriteRecordToNvMBuffer, TRUE);
                #else
                Dem_BfmRecordRead( lastModifyLocation, &m_BfmWriteRecordToNvMBuffer );
                #endif

                if( Dem_BfmNvmWriteRecord(lastModifyLocation, &m_BfmWriteRecordToNvMBuffer) == DEM_BFM_RET_OK )
                {
                    Dem_BfmRecordResetModified(lastModifyLocation);
                    m_BfmNvMWriteLocation = lastModifyLocation;
                    m_BfmNvMWriteState = BFM_STATE_EXECUTING;
                    hopOn = FALSE;
                }
            }

            #if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
            //Check whether the Bfm Extended debug data Record is modified
            if( !Dem_BfmModifyHandlingIsDoneInBFM && Dem_BfmExtDbgDataRecordIsModified(lastModifyLocation) )
            {
                Dem_BfmExtDbgDataRecordRead(lastModifyLocation, &m_BfmWriteRecordToNvMBuffer);

                if( Dem_BfmNvmWriteExtDbgDataRecord(lastModifyLocation, &m_BfmWriteRecordToNvMBuffer) == DEM_BFM_RET_OK )
                {
                    Dem_BfmExtDbgDataRecordResetModified(lastModifyLocation);
                    m_BfmNvMWriteLocation = lastModifyLocation;
                    m_BfmNvMWriteState = BFM_STATE_EXECUTING_EXTENDED_RECORD;
                    hopOn = FALSE;
                }
            }
            #endif

            lastModifyLocation++;
            if (Dem_BfmModifyHandlingIsDoneInBFM && (lastModifyLocation >= DEM_BFM_AMOUNT_RECORDS))
            {
                lastModifyLocation = 0;

                #if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
                Dem_BfmModifyHandlingIsDoneInBFM = FALSE;
                #endif
            }
            #if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
            else if( !Dem_BfmModifyHandlingIsDoneInBFM && (lastModifyLocation >= DEM_BFM_EXTENDED_DEBUG_DATA_AMOUNT_RECORDS) )
            {
                lastModifyLocation = 0;
                Dem_BfmModifyHandlingIsDoneInBFM = TRUE;
            }
            else
            {
                //To avoid misra
            }
            #endif

            //Required to make a complete loop and not only covering half of the elements
            if ((lastModifyLocation == startPos)
                    #if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
                    && (Dem_BfmModifyHandlingIsDoneInBFM == startHandlingMemory)
                    #endif
                    )
            {
                hopOn = FALSE;
            }
        }
		while (hopOn == TRUE);
    }
}

//*****************************************************************************
static void Dem_BfmHandleManagementData(void)
{
    if( Dem_BfmRecordIsManagementDataModified() && (BFM_STATE_IDLE == m_BfmNvMWriteManagementState) )
    {
        Dem_BfmRecordGetManagementDataNvm(&m_BfmWriteManagementDataToNvMBuffer);

        if( Dem_BfmNvmWriteManagementData(&m_BfmWriteManagementDataToNvMBuffer) == DEM_BFM_RET_OK )
        {
            Dem_BfmRecordSetManagementDataModified( FALSE);
            m_BfmNvMWriteManagementState = BFM_STATE_EXECUTING;

            //only set flag if previous steps of delete request have been performed
            if( m_BfmDeleteAll_State == BFM_DELETE_STATE_RAM_ZEROED )
            {
                m_BfmDeleteAll_State = BFM_DELETE_STATE_NVM_STARTED;
            }
        }
    }
    else if( BFM_STATE_EXECUTING == m_BfmNvMWriteManagementState )
    {
        Dem_BfmReturnType result = Dem_BfmNvmGetStatusManagementData();

        if( result != DEM_BFM_RET_PENDING ) //finished
        {
            m_BfmNvMWriteManagementState = BFM_STATE_IDLE;

            //only set flag if previous steps of delete request have been performed
            if (m_BfmDeleteAll_State == BFM_DELETE_STATE_NVM_STARTED)
            {
                m_BfmDeleteAll_State = BFM_DELETE_STATE_NVM_FINISHED;
            }
        }
        else //pending
        {
            //wait another cycle
        }
    }
    else
    {
        //To avoid Misra warning
    }
}

//*****************************************************************************
static void Dem_BfmHandleCounter(void)
{
    if( Dem_BfmCounterNeedsToBeSaved() && (BFM_STATE_IDLE == m_BfmNvMWriteCountersState) )
    {
        Dem_BfmCounterGetCounterDataNvm(&m_BfmWriteCountersToNvMBuffer);

        if( Dem_BfmNvmWriteCounter(&m_BfmWriteCountersToNvMBuffer) == DEM_BFM_RET_OK )
        {
            Dem_BfmCounterSetNeedsToBeSaved( FALSE);
            m_BfmNvMWriteCountersState = BFM_STATE_EXECUTING;
        }
    }
    else if( BFM_STATE_EXECUTING == m_BfmNvMWriteCountersState )
    {
        Dem_BfmReturnType result = Dem_BfmNvmGetStatusCounter();

        if( result != DEM_BFM_RET_PENDING ) //finished
        {
            m_BfmNvMWriteCountersState = BFM_STATE_IDLE;
        }
        else //pending
        {
            //wait another cycle
        }
    }
    else
    {
        // To avoid Misra Warning
    }
}

//*****************************************************************************
//Only the counter and the management data will be handled since explicit buffers are available for both
//But not for the records since because only one write operation shall be handled at a time as there is only one buffer available.
static void Dem_BfmHandleTriggerStoreToNvm(void)
{
	if(Dem_BfmTriggerFlag == TRUE)
	{
		Dem_BfmCounterSetNeedsToBeSaved(TRUE);
		Dem_BfmRecordSetManagementDataModified(TRUE);

		//Reset the flag
		Dem_BfmTriggerFlag = FALSE;
	}
}

//*****************************************************************************

void Dem_BfmPreInit( Dem_BfmConfigDataType const * demBfmConfigPointer )
{
	if( demBfmConfigPointer != NULL_PTR )
	{
		Dem_BfmConfigParam_pcs = demBfmConfigPointer;
	}
	else
	{
		//workaround for that projects that did not use config pointer until now don't have to change
		//get rid of this in future
		Dem_BfmConfigParam_pcs = &Dem_BfmConfigParam_cs;
	}
}

void Dem_BfmInitCheckNvM(void)
{
	Dem_BfmRecordInitCheckNvM();
	Dem_BfmCounterInitCheckNvM();
	Dem_BfmConsistencyChkForManagementData();
	Dem_BfmConsistencyChkForBfmCounters();
}

void Dem_BfmInit(void)
{
	Dem_BfmBufferInit();
	Dem_BfmRecordInit();
	Dem_BfmCounterInit();
}


void Dem_BfmShutdown(void)
{
	Dem_BfmCounterShutdown();
	Dem_BfmRecordShutdown();
}


void Dem_BfmMainFunction(void)
{
	Dem_BfmHandleTriggerStoreToNvm();

	//handle counters
	Dem_BfmCounterMainFunction();

	//delete, lock & unlock records
	Dem_BfmHandleDeleteAndLocking();

	//read from RAM
	Dem_BfmHandleReadRam();

	//read from NVM
	Dem_BfmHandleReadNvM();

	//write modified records to NVM
	Dem_BfmHandleModifiedRecords();

	//write management data to NVM
	Dem_BfmHandleManagementData();

	//write counters to NVM
	Dem_BfmHandleCounter();
}




//*****************************************************************************
Dem_BfmReturnType Dem_BfmDeleteAllTrigger(void)
{
	//atomic operation required, else interrupt lock needed
	m_BfmRequestDeleteAll = TRUE;
	return DEM_BFM_RET_OK;
}

Dem_BfmReturnType Dem_BfmDeleteAllCheck( Dem_BfmDeleteAllCheckStatus checkStatus )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( TRUE == m_BfmRequestDeleteAll )
	{
		retVal = DEM_BFM_RET_PENDING;
	}
	else
	{
		if( m_BfmDeleteAll_State > BFM_DELETE_STATE_IDLE )
		{
			retVal = DEM_BFM_RET_PENDING;

			switch( checkStatus )
			{
				case DEM_BFM_CHECK_RequestAccepted:
					{
						if( m_BfmDeleteAll_State >= BFM_DELETE_STATE_MARKED )
						{
							retVal = DEM_BFM_RET_OK;
						}
					}
					break;
				case DEM_BFM_CHECK_MemoryDeleted:
					{
						if(	 m_BfmDeleteAll_State >= BFM_DELETE_STATE_RAM_ZEROED )
						{
							retVal = DEM_BFM_RET_OK;
						}
					}
					break;
				case DEM_BFM_CHECK_MangementDataWrittenToNvm:
					{
						if(	 m_BfmDeleteAll_State >= BFM_DELETE_STATE_NVM_FINISHED )
						{
							retVal = DEM_BFM_RET_OK;
						}
					}
					break;
				default:
					{
						retVal = DEM_BFM_RET_NOK;
					}
					break;
			}
		}
	}

	return retVal;
}

boolean Dem_BfmDeleteAllIsInProgress(void)
{
	return m_BfmRequestDeleteAll;
}


//*****************************************************************************
Dem_BfmReturnType Dem_BfmReadRecordFromNvMTrigger( Dem_BfmLocationDataType location, Dem_BfmRecord *buffer )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( location>=DEM_BFM_AMOUNT_RECORDS )
	{
		retVal = DEM_BFM_RET_OUT_OF_RANGE;
	}
	else if( NULL_PTR == buffer )
	{
		retVal = DEM_BFM_RET_NULL_PTR;
	}
	else
	{
		BFM_ENTER_LOCK_EXTERNAL_NVM_READ_NONEST();
		if( BFM_STATE_IDLE == m_BfmNvMReadState )
		{
			m_BfmNvMReadLocation = location;
			m_BfmNvMReadTarget = buffer;
			m_BfmNvMReadState = BFM_STATE_REQUESTED;
			m_BfmNvMReadReleaseCounter = 0;
			m_BfmNvMReadRequestLimitCounter = 0;
			retVal = DEM_BFM_RET_PENDING;
		}
		else
		{
			retVal = DEM_BFM_RET_BUSY;
		}
		BFM_EXIT_LOCK_EXTERNAL_NVM_READ_NONEST();
	}

	return retVal;
}

Dem_BfmReturnType Dem_BfmReadRecordFromNvMCheck( Dem_BfmLocationDataType location )
{
	Dem_BfmReturnType retVal;
	atomic_ui8 state;

	BFM_ENTER_LOCK_EXTERNAL_NVM_READ_NONEST();
	state = m_BfmNvMReadState;

	if( location != m_BfmNvMReadLocation )
	{
		retVal = DEM_BFM_RET_NOT_FOUND;
	}
	else if( (BFM_STATE_REQUESTED == state) || (BFM_STATE_EXECUTING == state) )
	{
		retVal = DEM_BFM_RET_PENDING;
	}
	else if( BFM_STATE_FINISHED == state )
	{
		retVal = m_BfmNvMReadReturnValue;
		m_BfmNvMReadState = BFM_STATE_IDLE; //needs to be an atomic operation !!!
	}
	else
	{
		retVal = DEM_BFM_RET_NOK;
	}
	BFM_EXIT_LOCK_EXTERNAL_NVM_READ_NONEST();

	return retVal;
}

//*****************************************************************************
Dem_BfmReturnType Dem_BfmReadRecordFromRAMDirect( Dem_BfmLocationDataType location, Dem_BfmRecord *buffer )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( location>=DEM_BFM_AMOUNT_RECORDS )
	{
		retVal = DEM_BFM_RET_OUT_OF_RANGE;
	}
	else if( NULL_PTR == buffer )
	{
		retVal = DEM_BFM_RET_NULL_PTR;
	}
	else
	{
		BFM_ENTER_LOCK_EXTERNAL_READ_DIRECT_NESTED();

		if((Dem_BfmIsCurrentlyBusyWithUpdating)&&(Dem_BfmCurrentlyUpdatingLocation == location))
		{
			retVal = DEM_BFM_RET_BUSY;
		}
		else
		{
			Dem_BfmRecordRead(location,buffer);
			retVal = DEM_BFM_RET_OK;
		}

		BFM_EXIT_LOCK_EXTERNAL_READ_DIRECT_NESTED();

	}

	return retVal;
}

//*****************************************************************************
Dem_BfmReturnType Dem_BfmReadRecordFromRAMTrigger( Dem_BfmLocationDataType location, Dem_BfmRecord *buffer )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( location>=DEM_BFM_AMOUNT_RECORDS )
	{
		retVal = DEM_BFM_RET_OUT_OF_RANGE;
	}
	else if( NULL_PTR == buffer )
	{
		retVal = DEM_BFM_RET_NULL_PTR;
	}
	else
	{
		BFM_ENTER_LOCK_EXTERNAL_READ_NONEST();
		if( BFM_STATE_IDLE == m_BfmRamReadState )
		{
			m_BfmRamReadLocation = location;
			m_BfmRamReadTarget = buffer;
			m_BfmRamReadState = BFM_STATE_REQUESTED;
			retVal = DEM_BFM_RET_PENDING;
		}
		else
		{
			retVal = DEM_BFM_RET_BUSY;
		}
		BFM_EXIT_LOCK_EXTERNAL_READ_NONEST();
	}

	return retVal;
}

Dem_BfmReturnType Dem_BfmReadRecordFromRAMCheck( Dem_BfmLocationDataType location )
{
	Dem_BfmReturnType retVal;
	atomic_ui8 state;

	BFM_ENTER_LOCK_EXTERNAL_READ_NONEST();
	state = m_BfmRamReadState;

	if( location != m_BfmRamReadLocation )
	{
		retVal = DEM_BFM_RET_NOT_FOUND;
	}
	else if( BFM_STATE_REQUESTED == state )
	{
		retVal = DEM_BFM_RET_PENDING;
	}
	else if( BFM_STATE_FINISHED == state )
	{
		retVal = DEM_BFM_RET_OK;
		m_BfmRamReadState = BFM_STATE_IDLE; //needs to be an atomic operation !!!
	}
	else
	{
		retVal = DEM_BFM_RET_NOK;
	}
	BFM_EXIT_LOCK_EXTERNAL_READ_NONEST();

	return retVal;
}

//*****************************************************************************
Dem_BfmReturnType Dem_BfmLockAllRecordsTemporary(void)
{
	//atomic operation required, else interrupt lock needed
	m_BfmRequestLockTemp = TRUE;
	return DEM_BFM_RET_OK;
}

Dem_BfmReturnType Dem_BfmUnlockAllRecordsTemporary(void)
{
	//atomic operation required, else interrupt lock needed
	m_BfmRequestUnlockTemp = TRUE;
	return DEM_BFM_RET_OK;
}


//*****************************************************************************
Dem_BfmReturnType Dem_BfmLockAllRecordsPermanently(void)
{
	//atomic operation required, else interrupt lock needed
	m_BfmRequestLockPerm = TRUE;
	return DEM_BFM_RET_OK;
}

Dem_BfmReturnType Dem_BfmUnlockAllRecordsPermanently(void)
{
	//atomic operation required, else interrupt lock needed
	m_BfmRequestUnlockPerm = TRUE;
	return DEM_BFM_RET_OK;
}

//*****************************************************************************
Dem_BfmReturnType Dem_BfmTriggerStoreToNvm(void)
{
	//atomic operation required, else interrupt lock needed
	Dem_BfmTriggerFlag = TRUE;
	return DEM_BFM_RET_OK;
}


//*****************************************************************************
#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)

Dem_BfmReturnType Dem_BfmReadExtendedDebugDataFromRAMDirect( Dem_BfmLocationDataType location, Dem_BfmExtendedDebugDataRecord *buffer )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( location>=DEM_BFM_EXTENDED_DEBUG_DATA_AMOUNT_RECORDS )
	{
		retVal = DEM_BFM_RET_OUT_OF_RANGE;
	}
	else if( NULL_PTR == buffer )
	{
		retVal = DEM_BFM_RET_NULL_PTR;
	}
	else
	{
		BFM_ENTER_LOCK_EXTERNAL_READ_DIRECT_NESTED();

		if((Dem_BfmExtDbgDataRecIsCurrentlyBusyWithUpdating)&&(Dem_BfmExtDbgDataCurrentlyUpdatingLocation == location))
		{
			retVal = DEM_BFM_RET_BUSY;
		}
		else
		{
			Dem_BfmExtDbgDataRecordRead(location,buffer);
			retVal = DEM_BFM_RET_OK;
		}

		BFM_EXIT_LOCK_EXTERNAL_READ_DIRECT_NESTED();

	}

	return retVal;
}

//*****************************************************************************
Dem_BfmReturnType Dem_BfmReadExtendedDebugDataFromRAMTrigger( Dem_BfmLocationDataType location, Dem_BfmExtendedDebugDataRecord *buffer )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( location>=DEM_BFM_EXTENDED_DEBUG_DATA_AMOUNT_RECORDS )
	{
		retVal = DEM_BFM_RET_OUT_OF_RANGE;
	}
	else if( NULL_PTR == buffer )
	{
		retVal = DEM_BFM_RET_NULL_PTR;
	}
	else
	{
		BFM_ENTER_LOCK_EXTERNAL_READ_NONEST();
		if( BFM_STATE_IDLE == m_BfmExtendedRamReadState )
		{
			m_BfmExtendedRamReadLocation = location;
			m_BfmExtendedRamReadTarget = buffer;
			m_BfmExtendedRamReadState = BFM_STATE_REQUESTED;
			retVal = DEM_BFM_RET_PENDING;
		}
		else
		{
			retVal = DEM_BFM_RET_BUSY;
		}
		BFM_EXIT_LOCK_EXTERNAL_READ_NONEST();
	}

	return retVal;
}

//*****************************************************************************
Dem_BfmReturnType Dem_BfmReadExtendedDebugDataFromRAMCheck( Dem_BfmLocationDataType location )
{
	Dem_BfmReturnType retVal;
	atomic_ui8 state;

	BFM_ENTER_LOCK_EXTERNAL_READ_NONEST();
	state = m_BfmExtendedRamReadState;

	if( location != m_BfmExtendedRamReadLocation )
	{
		retVal = DEM_BFM_RET_NOT_FOUND;
	}
	else if( BFM_STATE_REQUESTED == state )
	{
		retVal = DEM_BFM_RET_PENDING;
	}
	else if( BFM_STATE_FINISHED == state )
	{
		retVal = DEM_BFM_RET_OK;
		m_BfmExtendedRamReadState = BFM_STATE_IDLE;
	}
	else
	{
		retVal = DEM_BFM_RET_NOK;
	}
	BFM_EXIT_LOCK_EXTERNAL_READ_NONEST();

	return retVal;
}

#endif


#ifdef DEM_TESTSUITE
atomic_ui8 DemTest_BfmGetStateNvmWrite()
{
    return m_BfmNvMWriteState;
}

atomic_ui8 DemTest_BfmGetStateNvmRead()
{
    return m_BfmNvMReadState;
}

atomic_ui8 DemTest_BfmGetStateRamRead()
{
    return m_BfmRamReadState;
}

atomic_ui8 DemTest_BfmGetStateNvmWriteManagementData()
{
    return m_BfmNvMWriteManagementState;
}

atomic_ui8 DemTest_BfmGetStateNvmWriteCounter()
{
    return m_BfmNvMWriteCountersState;
}
#endif

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


#endif //DEM_BFM_ENABLED
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.10.0.0; 4     14.07.2015 WUG3ABT
 *   Checkout by wug3abt
 * 
 * AR40.10.0.0; 3     24.06.2015 WUG3ABT
 *   CSCRM00896357
 * 
 * AR40.10.0.0; 2     13.05.2015 WUG3ABT
 *   CSCRM00857327
 * 
 * AR40.10.0.0; 1     12.05.2015 CLH2SI
 *   CSCRM00789099
 * 
 * AR40.10.0.0; 0     17.03.2015 TVE5COB
 *   CSCRM00789300
 * 
 * AR40.9.0.0; 3     20.10.2014 BPE4COB
 *   CSCRM00716141
 * 
 * AR40.9.0.0; 2     20.10.2014 WUG3ABT
 *   CSCRM00724657
 * 
 * AR40.9.0.0; 1     14.10.2014 VSA2COB
 *   CSCRM00554989
 * 
 * AR40.9.0.0; 0     25.08.2014 BPE4COB
 *   CSCRM00641522
 * 
 * AR40.8.0.0; 9     16.07.2014 BRM2COB
 *   CSCRM00688243
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
