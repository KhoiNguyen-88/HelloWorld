/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2013. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************
* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_BfmBuffer$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/
#ifndef DEM_BFMBUFFER_H
#define DEM_BFMBUFFER_H

#include "Dem_Cfg_Bfm.h"
#if( DEM_BFM_ENABLED == DEM_BFM_ON )

#include "Dem_BfmTypes.h"
#include "Dem_Cfg.h"
#include "Dem_Types.h"
#include "Dem_EvBuffEvent.h"




typedef struct
{
	uint8 buffer[DEM_BFM_FIX_ARRAY_SIZE(DEM_BFM_BUFFER_DATA_ELEMENTS_SIZE)];
	Dem_BfmStatusAndQualificationBitType qualification;
	Dem_EventIdType eventId;
	Dem_BfmTimestampType timestamp;
}
Dem_BfmBufferData;


typedef struct
{
	uint8 envDataElementIndex;
	uint16 offset;
}
Dem_BfmBufferConfiguration;


#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

void Dem_BfmBufferInit(void);
void Dem_BfmEnvCopyToTempBuffer( uint8 idx );
void Dem_BfmEnvRetrieveBFM(void);
void Dem_BfmEnvCaptureBFM( Dem_EventIdType eventId, Dem_EvBuffEventType eventType, uint8 idx    DEM_DEBUGDATA_PARAM(Dem_DebugDataType debug0, Dem_DebugDataType debug1) );
Dem_BfmReturnType Dem_BfmBufferCalcQualificationType( Dem_EvBuffEventType eventType, Dem_BfmStatusAndQualificationBitType *qualification );
void Dem_BfmBufferRead( const Dem_BfmBufferData *source, uint8 elementIdx, uint8 *target );
uint8 Dem_BfmBufferGetElementSize( uint8 idx );

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif //DEM_BFM_ENABLED
#endif
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     16.10.2015 VSA2COB
*   Checkout by vsa2cob
* 
* AR40.9.0.0; 1     06.01.2015 GJ83ABT
*   CSCRM00751490
* 
* AR40.9.0.0; 0     06.01.2015 TVE5COB
*   CSCRM00741126
* 
* AR40.8.0.0; 3     13.06.2014 WUG3ABT
*   CSCRM00610171
* 
* AR40.8.0.0; 2     15.05.2014 VSA2COB
*   CSCRM00662943
* 
* AR40.8.0.0; 1     27.02.2014 WUG3ABT
*   CSCRM00588123
* 
* AR40.8.0.0; 0     13.02.2014 WUG3ABT
*   CSCRM00562030
* 
* AR40.7.0.0; 2     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 1     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 0     22.10.2013 AMN2KOR
*   CSCRM00547887
* 
* $
**********************************************************************************************************************
</BASDKey>*/
