/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2013. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************
* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_BfmBuffer$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/
#include "Dem_BfmBuffer.h"
#if( DEM_BFM_ENABLED == DEM_BFM_ON )

#include "Dem_Cfg_ExtPrototypes.h"
#include "Dem_BfmCounter.h"
#include "Dem_BfmRecord.h"
#include "Dem_BfmEvent.h"
#include "Dem_Cfg_EventId.h"
#include "Dem_Cfg_EvBuff.h"
#include "Dem_Cfg_EnvDataElement.h"


#define DEM_BFM_BUFFER_ENTRIES DEM_CFG_EVBUFF_SIZE //shall have the size of Dem EvBuffer


#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

	static const Dem_BfmBufferConfiguration mBfmBufferConfiguration[DEM_BFM_FIX_ARRAY_SIZE(DEM_BFM_BUFFER_DATA_ELEMENTS_AMOUNT)] = { DEM_BFM_BUFFER_DATA_ELEMENTS_CONFIGURATION };

#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"


#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

	static Dem_BfmBufferData mBufferData[DEM_BFM_FIX_ARRAY_SIZE(DEM_BFM_BUFFER_ENTRIES)];
	static Dem_BfmBufferData mTempCopyBufferData;

#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"


#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
//*****************************************************************************
void Dem_BfmBufferInit(void)
{
	DEM_MEMSET( mBufferData, 0x00, DEM_SIZEOF_VAR(mBufferData) );
	DEM_MEMSET( &mTempCopyBufferData, 0x00, DEM_SIZEOF_TYPE(Dem_BfmBufferData) );

	#if( DEM_EVENTID_INVALID!=0 )
	{
		uint8 i;
		for( i=0; i<DEM_BFM_BUFFER_ENTRIES; i++ )
			mBufferData[i].eventId = DEM_EVENTID_INVALID;

		mTempCopyBufferData.eventId = DEM_EVENTID_INVALID;
	}
	#endif
}


//*****************************************************************************
static void Dem_BfmBufferPopulate( Dem_InternalEnvData *internalEnvData, uint8 idx )
{
	uint8 i;
	Dem_BfmBufferConfiguration const *bufConf;

	mBufferData[idx].eventId = internalEnvData->eventId;

	for( i=0; i<DEM_BFM_BUFFER_DATA_ELEMENTS_AMOUNT; i++ )
	{
		bufConf = &mBfmBufferConfiguration[i];
		internalEnvData->size = Dem_EnvDAGetSizeOf( bufConf->envDataElementIndex );

		if( Dem_Cfg_EnvDataElement[bufConf->envDataElementIndex].ReadExtCSFnc != NULL_PTR )
		{
			Dem_Cfg_EnvDataElement[bufConf->envDataElementIndex].ReadExtCSFnc( &mBufferData[idx].buffer[bufConf->offset] );
		}
		else if( Dem_Cfg_EnvDataElement[bufConf->envDataElementIndex].ReadInternalFnc != NULL_PTR )
		{
			Dem_Cfg_EnvDataElement[bufConf->envDataElementIndex].ReadInternalFnc( &mBufferData[idx].buffer[bufConf->offset], internalEnvData );
		}
		else
		{
			DEM_DET(DEM_DET_APIID_BFM_BUFFER,DEM_E_WRONG_CONDITION);
		}
	}
}


Dem_BfmReturnType Dem_BfmBufferCalcQualificationType( Dem_EvBuffEventType eventType, Dem_BfmStatusAndQualificationBitType *qualification )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( qualification == NULL_PTR )
	{
		retVal = DEM_BFM_RET_NULL_PTR;
	}
	else
	{
		switch( eventType )
		{
			case C_EVENTTYPE_SET:
			case C_EVENTTYPE_SET_WAITINGFORMONITORING:
				*qualification = DEM_BFM_STQU_FAILED;
				retVal = DEM_BFM_RET_OK;
				break;
			case C_EVENTTYPE_RESET:
				*qualification = DEM_BFM_STQU_HEALED;
				retVal = DEM_BFM_RET_OK;
				break;
			case C_EVENTTYPE_UNROBUST:
				*qualification = DEM_BFM_STQU_UNROBUST;
				retVal = DEM_BFM_RET_OK;
				break;
			default:
				retVal = DEM_BFM_RET_NOK;
				break;
		}
	}

	return retVal;
}

void Dem_BfmEnvCaptureBFM( Dem_EventIdType eventId, Dem_EvBuffEventType eventType, uint8 idx	DEM_DEBUGDATA_PARAM(Dem_DebugDataType debug0, Dem_DebugDataType debug1) )
{
	Dem_BfmStatusAndQualificationBitType calcQuali = 0;

	if( Dem_BfmBufferCalcQualificationType( eventType, &calcQuali ) == DEM_BFM_RET_OK )
	{
		Dem_InternalEnvData internalEnvData;

		internalEnvData.evMemLocation = NULL_PTR;
		internalEnvData.eventId = eventId;
		#if (DEM_CFG_DEBUGDATA != DEM_CFG_DEBUGDATA_OFF)
		internalEnvData.debug0 = debug0;
		internalEnvData.debug1 = debug1;
		#endif

		mBufferData[idx].eventId = eventId;
		mBufferData[idx].qualification = calcQuali;

		Dem_BfmBufferPopulate( &internalEnvData, idx );
	}
	else
	{
		mBufferData[idx].eventId = DEM_EVENTID_INVALID;
	}
}


void Dem_BfmEnvCopyToTempBuffer( uint8 idx )
{
	if( mBufferData[idx].eventId != DEM_EVENTID_INVALID )
	{
		DEM_MEMCPY( &mTempCopyBufferData, &mBufferData[idx], DEM_SIZEOF_TYPE(Dem_BfmBufferData) );
	}
}

void Dem_BfmEnvRetrieveBFM(void)
{
    if (mTempCopyBufferData.eventId != DEM_EVENTID_INVALID)
    {
        Dem_BfmLocationDataType location;
        #if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
        Dem_BfmLocationDataType locationEdd;
        #endif

        Dem_BfmCounterCalcTimestamp();
        (void)Dem_BfmCounterGetTimestamp(&mTempCopyBufferData.timestamp);

        if (Dem_BfmRecordFindSlotForUpdate(&mTempCopyBufferData, &location) == DEM_BFM_RET_OK)
        {
            Dem_BfmRecordUpdate(location, &mTempCopyBufferData);

            #if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
            if (Dem_BfmExtDbgDataRecordFindslotForUpdate(location, &locationEdd, &mTempCopyBufferData) == DEM_BFM_RET_OK)
            {
                Dem_BfmExtDbgDataRecordUpdate(location, locationEdd);
            }
            #endif
        }

        mTempCopyBufferData.eventId = DEM_EVENTID_INVALID;
    }
}


void Dem_BfmBufferRead( const Dem_BfmBufferData *source, uint8 elementIdx, uint8 *target )
{
	if( target!=NULL_PTR )
	{
		DEM_MEMCPY( target, &source->buffer[mBfmBufferConfiguration[elementIdx].offset], Dem_EnvDAGetSizeOf(mBfmBufferConfiguration[elementIdx].envDataElementIndex) );
	}
}

uint8 Dem_BfmBufferGetElementSize( uint8 idx )
{
	return Dem_EnvDAGetSizeOf( mBfmBufferConfiguration[ idx ].envDataElementIndex );
}



#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif //DEM_BFM_ENABLED
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     16.10.2015 VSA2COB
*   Checkout by vsa2cob
* 
* AR40.10.0.0; 4     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 3     10.07.2015 CLH2SI
*   CSCRM00938605
* 
* AR40.10.0.0; 2     12.05.2015 CLH2SI
*   CSCRM00789099
* 
* AR40.10.0.0; 1     16.04.2015 CLH2SI
*   CSCRM00764027
* 
* AR40.10.0.0; 0     17.03.2015 TVE5COB
*   CSCRM00789300
* 
* AR40.9.0.0; 2     12.11.2014 CLH2SI
*   CSCRM00735646
* 
* AR40.9.0.0; 1     14.10.2014 VSA2COB
*   CSCRM00554989
* 
* AR40.9.0.0; 0     25.08.2014 BPE4COB
*   CSCRM00641522
* 
* AR40.8.0.0; 3     13.06.2014 WUG3ABT
*   CSCRM00610171
* 
* $
**********************************************************************************************************************
</BASDKey>*/
