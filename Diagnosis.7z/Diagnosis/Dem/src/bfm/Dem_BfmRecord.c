/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2013. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:C$
 * $Name______:Dem_BfmRecord$
 * $Variant___:AR40.11.0.1$
 * $Revision__:0$
 **********************************************************************************************************************
</BASDKey>*/
#include "Dem_BfmRecord.h"
#if( DEM_BFM_ENABLED == DEM_BFM_ON )

#include "Dem_Bfm.h"
#include "Dem_Cfg_ExtPrototypes.h"
#include "Dem_BfmCounter.h"
#include "Dem_BfmEvent.h"
#include "Dem_Cfg_EventId.h"
#include "Dem_BfmNvm.h"
#include "Dem_BfmUtils.h"
#include "Dem_Lib.h"
#include "Dem_EventStatus.h"
#include "Rte_Dem.h"

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

	static Dem_BfmRecordManagementDataRam Dem_BfmRecordManagementDataValuesRam;
	static boolean m_BfmRecordIsManagmentDataModified;
	static Dem_BfmLocationDataType m_BfmRecordModifyCounter;
	static Dem_BfmDeletionCounterType m_BfmRecordDeleteCounter;
	Dem_BfmLocationDataType Dem_BfmCurrentlyUpdatingLocation;
	boolean Dem_BfmIsCurrentlyBusyWithUpdating;

	#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
	boolean Dem_BfmExtDbgDataRecIsCurrentlyBusyWithUpdating;
	Dem_BfmLocationDataType Dem_BfmExtDbgDataCurrentlyUpdatingLocation;
	#endif

#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

	static Dem_BfmRecord mBfmRecords[DEM_BFM_FIX_ARRAY_SIZE(DEM_BFM_AMOUNT_RECORDS)];
	Dem_BfmRecordManagementDataNvm Dem_BfmRecordManagementDataValuesNvm;

	#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
	static Dem_BfmExtendedDebugDataRecord mbfmExtDbgDataRam[DEM_BFM_FIX_ARRAY_SIZE(DEM_BFM_EXTENDED_DEBUG_DATA_AMOUNT_RECORDS)];
	#endif

#define DEM_STOP_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

	#if (DEM_BFM_CALLBACK_DELETE_RECORD == DEM_BFM_ON)
	static const Dem_BfmCallbackFunctionDeleteAllowed mBfmDeleteCallback = DEM_BFM_CALLBACK_FUNCTION_DELETE_ALLOWED;
	#endif

	#if (DEM_BFM_CALLBACK_MODIFY_LOCKED == DEM_BFM_ON)
	static const Dem_BfmCallbackFunctionModifyLockedAllowed mBfmModifyLockedCallback = DEM_BFM_CALLBACK_FUNCTION_MODIFY_LOCKED_ALLOWED;
	#endif

	#if(DEM_BFM_CALLBACK_REPLACE_RECORD == DEM_BFM_ON)
	static const Dem_BfmCallbackFunctionReplaceRecord mBfmReplaceCallback = DEM_BFM_CALLBACK_FUNCTION_REPLACE_RECORD_LOGIC;
	#endif

	#if (DEM_BFM_IS_OPERATIONCYCLE_REFERENCED == DEM_BFM_ON)
	static const uint8 Dem_Bfm_OperationCycleIndex[DEM_BFM_AMOUNT_OPERATIONCYCLE_ELEMENTS] = DEM_BFM_OPERATIONCYCLE_ELEMENTS_CONFIGURATION;
	#endif

	#if (DEM_BFM_IS_ABS_OPERATINGTIME_REFERENCED == DEM_BFM_ON)
	static const uint8 Dem_Bfm_AbsoluteOperatingTimeIndex[DEM_BFM_AMOUNT_ABSOLUTE_OPERATINGTIME_ELEMENTS] = DEM_BFM_ABSOLUTE_OPERATINGTIME_ELEMENTS_CONFIGURATION;
	#endif

	static const Dem_BfmCustomDataElement mBfmCustomData[DEM_BFM_FIX_ARRAY_SIZE(DEM_BFM_CUSTOM_DATA_AMOUNT)] = {DEM_BFM_CUSTOM_DATA_CONFIGURATION};

#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"


#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
//*****************************************************************************
void Dem_BfmRecordUpdateCustomData( Dem_BfmLocationDataType location, const Dem_BfmBufferData *buffer )
{
	uint8 i;
	Dem_BfmStatusAndQualificationBitType match;
	uint8 const *tempRecConfig =  Dem_BfmConfigParam_pcs->recordConfigurationPtr;

	for( i=0; i<DEM_BFM_CUSTOM_DATA_AMOUNT; i++ )
	{
		match = mBfmRecords[location].statusAndQualification & tempRecConfig[i];

		//which type should be updated: FAILED, HEALED,...
		if( (match & DEM_BFM_STQU_MASK_TYPE) != 0u )
		{
			//at which time should be updated: first occurrence, most recent occurrence, ...
			if( (match & DEM_BFM_STQU_MASK_TIME) != 0u )
			{
				Dem_BfmBufferRead( buffer, mBfmCustomData[i].bufferIndex, &mBfmRecords[location].customData[mBfmCustomData[i].offset] );
			}
		}
	}
}

void Dem_BfmRecordUpdate( Dem_BfmLocationDataType location, const Dem_BfmBufferData *buffer )
{
	boolean qualificationTransition = FALSE;

	BFM_ENTER_LOCK_EXTERNAL_READ_DIRECT_NESTED();
	Dem_BfmIsCurrentlyBusyWithUpdating = TRUE;
	Dem_BfmCurrentlyUpdatingLocation = location;
	BFM_EXIT_LOCK_EXTERNAL_READ_DIRECT_NESTED();

	if( mBfmRecords[location].eventId != buffer->eventId ) //new entry
	{
		DEM_MEMSET( &mBfmRecords[location], 0x00, DEM_SIZEOF_TYPE(Dem_BfmRecord) ); //necessary or eg occurrence counter does not work
		mBfmRecords[location].eventId = buffer->eventId;
		mBfmRecords[location].statusAndQualification = DEM_BFM_STQU_FIRST|DEM_BFM_STQU_MOST_RECENT;
		(void)Dem_BfmEventGetPriority( buffer->eventId, &mBfmRecords[location].priority );

		#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
		mBfmRecords[location].ExtDbgDataRecordIndex = DEM_BFM_INVALID_INDEX;
		#endif

		qualificationTransition = TRUE;
	}
	else //record already exists
	{
		if ((mBfmRecords[location].statusAndQualification & DEM_BFM_STQU_MASK_TYPE) != (buffer->qualification & DEM_BFM_STQU_MASK_TYPE))
		{
			qualificationTransition = TRUE;
		}

		mBfmRecords[location].statusAndQualification = DEM_BFM_STQU_MOST_RECENT;
	}

	//populate static header
	mBfmRecords[location].age = buffer->timestamp;
	mBfmRecords[location].statusAndQualification |= (buffer->qualification&DEM_BFM_STQU_MASK_TYPE); //add only Type: FAILED, HEALED, ...

	//Set eventId in the management data for this particular location
	Dem_BfmRecordSetManagementDataEventId( location, buffer->eventId);


	#if( DEM_BFM_OCCURRENCE_COUNTER == DEM_BFM_ON )
	if( (buffer->qualification & (Dem_BfmConfigParam_pcs->occurrenceCounterMask)) != 0x00 )
	{
		if ((Dem_BfmConfigParam_pcs->occurrenceCounterOnlyIncrementOnTransition && qualificationTransition) || //care about transition
			(Dem_BfmConfigParam_pcs->occurrenceCounterOnlyIncrementOnTransition==FALSE)) //don't care about transition
		{
			if( mBfmRecords[location].occurrences != DEM_BFM_OCCURRENCECOUNTER_MAX )
			{
				mBfmRecords[location].occurrences++;
			}
		}
	}
	#endif

	Dem_BfmRecordUpdateCustomData( location, buffer );
	Dem_BfmRecordResetEmpty( location );
	Dem_BfmRecordSetModified( location );

	//reset the flag
	Dem_BfmIsCurrentlyBusyWithUpdating = FALSE;
}

//****************************************************************************************************************************************
#if(( DEM_BFM_CALLBACK_REPLACE_RECORD == DEM_BFM_OFF ) || (DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON))
DEM_INLINE void Dem_BfmFindSlotForUpdateHelper( Dem_EventIdType eventId, Dem_BfmLocationDataType loc, Dem_BfmPriorityType eventPrio,
		Dem_BfmPriorityType *minPrio, Dem_BfmLocationDataType *locMinPrio )
{
	boolean isCurrentHealed;
	boolean isPreviousHealed;

	//search in occupied slots
	if( !Dem_BfmRecordIsEmpty(loc) )
	{
		//check if modifiable
		if( Dem_BfmRecordHandleAllowLockedModify(loc, eventId) )
		{
			//priority: 0==highest, 255==lowest

			//only replace records with a lower priority
			if( eventPrio < mBfmRecords[loc].priority )
			{
				if( mBfmRecords[loc].priority > (*minPrio) ) //current has lower prio than previous
				{
					*minPrio = mBfmRecords[loc].priority;
					*locMinPrio = loc;
				}
				else if( mBfmRecords[loc].priority == (*minPrio) )
				{
					isCurrentHealed = ((mBfmRecords[loc].statusAndQualification&DEM_BFM_STQU_HEALED)==DEM_BFM_STQU_HEALED);
					isPreviousHealed = ((mBfmRecords[(*locMinPrio)].statusAndQualification&DEM_BFM_STQU_HEALED)==DEM_BFM_STQU_HEALED);

					if( isCurrentHealed && !isPreviousHealed ) //current is healed, previous is not -> select current
					{
						*locMinPrio = loc;
					}
					else if( !isCurrentHealed && isPreviousHealed ) //current is not healed, but previous -> keep previous
					{
					}
					else //both healed or both not healed -> replace older
					{
						if( mBfmRecords[loc].age < mBfmRecords[(*locMinPrio)].age ) //current is older than previous -> select current
						{
							*locMinPrio = loc;
						}
					}
				}
				else
				{
					//priority is lower -> do nothing
				}
			}
		}
	}
}
#endif

//*****************************************************************************
Dem_BfmReturnType Dem_BfmRecordFindSlotForUpdate( const Dem_BfmBufferData *buffer, Dem_BfmLocationDataType *location )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( (buffer==NULL_PTR) || (location==NULL_PTR))
	{
		retVal = DEM_BFM_RET_NULL_PTR;
	}

	#if( DEM_BFM_CALLBACK_REPLACE_RECORD == DEM_BFM_ON )
	else
	{
		if( mBfmReplaceCallback( buffer->eventId, location ) == DEM_BFM_RET_OK )
		{
			if( *location < DEM_BFM_AMOUNT_RECORDS )
			{
				//reset lock bits
				Dem_BfmRecordResetLockedTemp( *location );
				if( Dem_BfmRecordIsLockedPerm( *location) )
				{
					Dem_BfmRecordResetLockedPerm( *location );
					m_BfmRecordIsManagmentDataModified = TRUE;
				}

				if( Dem_BfmRecordIsMarkedForDeletion( *location) )
				{
					Dem_BfmRecordSetEmpty( *location ); //to avoid delete callback
					Dem_BfmRecordHandleDeletion( *location );
				}

				retVal = DEM_BFM_RET_OK;
			}
		}
	}
	#else
	else
	{
		boolean continueSearch = TRUE;
		Dem_BfmLocationDataType loc;
		Dem_EventIdType eventId = buffer->eventId;


		//1. try to update same event
		for( loc=0; (loc<DEM_BFM_AMOUNT_RECORDS)&&(continueSearch==TRUE); loc++ )
		{
			if( mBfmRecords[loc].eventId == eventId )
			{
				continueSearch = FALSE; //stop here to avoid inconsistency -> only a (single) record is used

				//check if it is marked for deletion, if marked try to delete
				Dem_BfmRecordHandleDeletion( loc );

				//check if modifiable
				if( Dem_BfmRecordHandleAllowLockedModify(loc, eventId) )
				{
					*location = loc;

					retVal = DEM_BFM_RET_OK;
				}
			}
		}


		//2. find a free slot
		if( continueSearch==TRUE )
		{
			for( loc=0; loc<DEM_BFM_AMOUNT_RECORDS; loc++ )
			{
				//check if it is marked for deletion, if marked try to delete
				Dem_BfmRecordHandleDeletion( loc );

				//search for a free slot
				if( Dem_BfmRecordIsEmpty(loc) )
				{
					//check if modifiable
					if( Dem_BfmRecordHandleAllowLockedModify(loc, eventId) )
					{
						*location = loc;

						retVal = DEM_BFM_RET_OK;
						continueSearch = FALSE;
						break;
					}
				}
			}
		}


		//3. find lowest priority
		if( continueSearch==TRUE )
		{
			Dem_BfmLocationDataType locMinPrio = 0;
			Dem_BfmPriorityType minPrio = DEM_BFM_PRIORITY_MAX;
			Dem_BfmPriorityType eventPrio;
			(void)Dem_BfmEventGetPriority( eventId, &eventPrio );

			for( loc=0; loc<DEM_BFM_AMOUNT_RECORDS; loc++ )
			{
				Dem_BfmFindSlotForUpdateHelper( eventId, loc, eventPrio, &minPrio, &locMinPrio );

			}

			if( minPrio != DEM_BFM_PRIORITY_MAX )
			{
				*location = locMinPrio;

				retVal = DEM_BFM_RET_OK;
				//continueSearch = FALSE;
			}
		}
	}
	#endif

	return retVal;
}

//*******************************************************************************************************
/*
 * The below table provides the link between the BFM and EDD on how the record slot will be manipulated for each EDD record.
 *
 * BFM/EDD           RecordUpdate    NewEntry       ReplaceRecord
 * RecordUpdated         X               -              -
 * NewEntry              -               X              X
 * Replace               -               -              X
 *
 * where X denotes the applicable scenarios.
 */
#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
Dem_BfmReturnType Dem_BfmExtDbgDataRecordFindslotForUpdate(Dem_BfmLocationDataType location,Dem_BfmLocationDataType *locationEdd,const Dem_BfmBufferData *buffer )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;
	boolean continueSearch = TRUE;
	Dem_BfmLocationDataType loc;
	Dem_BfmPriorityType eventPrio;
	Dem_BfmStatusAndQualificationBitType match;

	if((buffer==NULL_PTR) || (locationEdd == NULL_PTR))
	{
		retVal = DEM_BFM_RET_NULL_PTR;
	}
	else
	{
		(void)Dem_BfmEventGetPriority( buffer->eventId, &eventPrio );
		*locationEdd = DEM_BFM_INVALID_INDEX;

		if(eventPrio >= (Dem_BfmConfigParam_pcs->extDbgDataPriorityThreshold)) //prio larger than threshold
		{
			//Check if the configured mask value matches with the event status
			match = ((Dem_BfmConfigParam_pcs->extDbgDataConfigMask) & (buffer->qualification));

			//which type should be updated: FAILED, HEALED,UNROBUST
			if( (match & DEM_BFM_STQU_MASK_TYPE) != 0u )
			{
				//1. find same not necessary
				if ( mBfmRecords[location].ExtDbgDataRecordIndex != DEM_BFM_INVALID_INDEX )
				{
					*locationEdd = mBfmRecords[location].ExtDbgDataRecordIndex;
					continueSearch = FALSE;

				}

				//2. find free
				if( continueSearch )
				{
					for( loc=0; loc<DEM_BFM_EXTENDED_DEBUG_DATA_AMOUNT_RECORDS; loc++ )
					{
						//check if it is marked for deletion, if marked try to delete
						Dem_BfmRecordHandleDeletion(Dem_BfmExtDbgDataGetBfmRecordIndex(loc)); //-> check edd delete bit & also handle index

						//search for a free slot
						if(Dem_BfmExtDbgDataRecordIsEmpty(loc)) //-> check edd empty bit
						{
							*locationEdd = loc;
							retVal = DEM_BFM_RET_OK;
							continueSearch = FALSE;
							break;
						}
					}
				}

				//3. find lower prio lower prio healed
				if( continueSearch )
				{
					Dem_BfmLocationDataType locMinPrio = 0;
					Dem_BfmPriorityType minPrio = DEM_BFM_PRIORITY_MAX;

					for( loc=0; loc<DEM_BFM_EXTENDED_DEBUG_DATA_AMOUNT_RECORDS; loc++ )
					{
						Dem_BfmFindSlotForUpdateHelper( buffer->eventId, loc, eventPrio, &minPrio, &locMinPrio );
					}

					if( minPrio != DEM_BFM_PRIORITY_MAX )
					{
						*locationEdd = locMinPrio;

						retVal = DEM_BFM_RET_OK;
					}
				}
			}
		}
	}

	return retVal;
}
#endif

//*****************************************************************************
Dem_BfmReturnType Dem_BfmRecordFind( Dem_EventIdType eventId, Dem_BfmLocationDataType *location )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOT_FOUND;

	if( location == NULL_PTR )
	{
		retVal = DEM_BFM_RET_NULL_PTR;
	}
	else if( (eventId==DEM_EVENTID_INVALID) || (eventId > DEM_EVENTID_COUNT) )
	{
		retVal = DEM_BFM_RET_OUT_OF_RANGE;
	}
	else
	{
		Dem_BfmLocationDataType loc;

		for( loc=0; loc<DEM_BFM_AMOUNT_RECORDS; loc++ )
		{
			if( mBfmRecords[loc].eventId == eventId )
			{
				*location = loc;
				retVal = DEM_BFM_RET_OK;
			}
		}
	}

	return retVal;
}

//*****************************************************************************
#if(DEM_ENABLE_BFM_DIRECT_ACCESS_INTERFACE == DEM_BFM_ON)
Dem_BfmReturnType Dem_BfmRecordGetDirectReadAccess( Dem_BfmLocationDataType location, Dem_BfmRecord const **bfmRecord,
		boolean *isMarkedForDeletion, boolean *isEmpty, boolean *isModified, boolean *isLockedPerm, boolean *isLockedTemp )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( (bfmRecord==NULL_PTR) || (isMarkedForDeletion==NULL_PTR) || (isEmpty==NULL_PTR) ||
			(isModified==NULL_PTR) || (isLockedPerm==NULL_PTR) || (isLockedTemp==NULL_PTR) )
	{
		retVal = DEM_BFM_RET_NULL_PTR;
	}
	else if( location >= DEM_BFM_AMOUNT_RECORDS )
	{
		retVal = DEM_BFM_RET_OUT_OF_RANGE;
	}
	else
	{
		*bfmRecord = &mBfmRecords[location];
		*isMarkedForDeletion = Dem_BfmRecordIsMarkedForDeletion( location );
		*isEmpty = Dem_BfmRecordIsEmpty( location );
		*isModified = Dem_BfmRecordIsModified( location );
		*isLockedPerm = Dem_BfmRecordIsLockedPerm( location );
		*isLockedTemp = Dem_BfmRecordIsLockedTemp( location );
		retVal = DEM_BFM_RET_OK;
	}

	return retVal;
}
#endif

//*****************************************************************************
Dem_BfmReturnType Dem_BfmRecordGetFirst( Dem_BfmLocationDataType *location )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( location==NULL_PTR )
	{
		retVal = DEM_BFM_RET_NULL_PTR;
	}
	else
	{
		*location = 0;
		retVal = DEM_BFM_RET_OK;
	}

	return retVal;
}

Dem_BfmReturnType Dem_BfmRecordGetNext( Dem_BfmLocationDataType *location )
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_NOK;

	if( location==NULL_PTR )
	{
		retVal = DEM_BFM_RET_NULL_PTR;
	}
	else if( (*location+1u) < DEM_BFM_AMOUNT_RECORDS )
	{
		*location = *location + 1;
		retVal = DEM_BFM_RET_OK;
	}
	else
	{
		// To avoid Misra Warning
	}

	return retVal;
}


//*****************************************************************************
void Dem_BfmRecordFindMaxTimestampAndLocation( Dem_BfmTimestampType *timestamp, Dem_BfmLocationDataType *location )
{
    Dem_BfmTimestampType ageMax = 0;
    Dem_BfmLocationDataType locMax = 0;
    Dem_BfmLocationDataType loc;

    for( loc=0; loc<DEM_BFM_AMOUNT_RECORDS; loc++ )
    {
        if( Dem_isEventIdValid( mBfmRecords[loc].eventId ) )
        {
            if( mBfmRecords[loc].age > ageMax )
            {
                ageMax = mBfmRecords[loc].age;
                locMax = loc;
            }
        }
    }

    if( timestamp!=NULL_PTR )
    {
        *timestamp = ageMax;
    }

    if( location!=NULL_PTR )
    {
        *location = locMax;
    }
}

Dem_BfmTimestampType Dem_BfmRecordGetTimestamp( Dem_BfmLocationDataType location )
{
	if( location<DEM_BFM_AMOUNT_RECORDS )
	{
		return mBfmRecords[location].age;
	}
	else
	{
		return 0;
	}
}



#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)

DEM_INLINE boolean Dem_BfmExtIndexIsValid (uint8 LocId)
{
	return (LocId < DEM_BFM_EXTENDED_DEBUG_DATA_AMOUNT_RECORDS);
}

void Dem_BfmExtSetBfmIndexToInvalid(Dem_BfmLocationDataType ExtRecIndex)
{
	if(ExtRecIndex < DEM_BFM_EXTENDED_DEBUG_DATA_AMOUNT_RECORDS)
	{
		mbfmExtDbgDataRam[ExtRecIndex].BfmRecIndex = DEM_BFM_INVALID_INDEX;
	}
}

uint8 Dem_BfmGetExtDbgDataRecordIndex( Dem_BfmLocationDataType location )
{
	if( location<DEM_BFM_EXTENDED_DEBUG_DATA_AMOUNT_RECORDS )
	{
		return mBfmRecords[location].ExtDbgDataRecordIndex;
	}
	else
	{
		return DEM_BFM_INVALID_INDEX;
	}
}

void Dem_BfmExtDbgDataRecordEmptyRam(uint8 ExtRecIndex)
{
	DEM_MEMSET( &mbfmExtDbgDataRam[ExtRecIndex].ExtData, 0x00, DEM_BFM_EXTENDED_DEBUG_DATA_ELEMENT_SIZE ); //zero RAM

	//invalidate the bfm record index
	mbfmExtDbgDataRam[ExtRecIndex].BfmRecIndex = DEM_BFM_INVALID_INDEX;
}

//*****************************************************************************
void Dem_BfmExtDbgDataRecordRead( Dem_BfmLocationDataType location, void *buffer )
{
	if(location != DEM_BFM_INVALID_INDEX)
	{
		DEM_MEMCPY( buffer, &mbfmExtDbgDataRam[location], DEM_SIZEOF_TYPE(Dem_BfmExtendedDebugDataRecord) );
	}
}


Dem_BfmLocationDataType Dem_BfmExtDbgDataGetBfmRecordIndex( Dem_BfmLocationDataType location )
{
	if( location<DEM_BFM_EXTENDED_DEBUG_DATA_AMOUNT_RECORDS )
	{
		return mbfmExtDbgDataRam[location].BfmRecIndex;
	}
	else
	{
		return DEM_BFM_INVALID_INDEX;
	}
}
#endif
//*****************************************************************************

Dem_EventIdType Dem_BfmRecordGetEventId( Dem_BfmLocationDataType location )
{
	return mBfmRecords[location].eventId;
}

//*****************************************************************************
void Dem_BfmRecordLockAllTemp(void)
{
	Dem_BfmLocationDataType loc;

	for( loc=0; loc<DEM_BFM_AMOUNT_RECORDS; loc++ )
	{
		Dem_BfmRecordSetLockedTemp( loc );
	}
}

void Dem_BfmRecordUnlockAllTemp(void)
{
	Dem_BfmLocationDataType loc;

	for( loc=0; loc<DEM_BFM_AMOUNT_RECORDS; loc++ )
	{
		Dem_BfmRecordResetLockedTemp( loc );
	}
}

boolean Dem_BfmRecordIsLockedTemp( Dem_BfmLocationDataType location )
{
	if( (Dem_BfmRecordManagementDataValuesRam.managementData[location]&DEM_BFM_ST_TEMP_LOCK) == 0u )
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

void Dem_BfmRecordSetLockedTemp( Dem_BfmLocationDataType location )
{
	Dem_BfmRecordManagementDataValuesRam.managementData[location] |= DEM_BFM_ST_TEMP_LOCK;
}

void Dem_BfmRecordResetLockedTemp( Dem_BfmLocationDataType location )
{
	Dem_BfmRecordManagementDataValuesRam.managementData[location] &= (uint8)(~DEM_BFM_ST_TEMP_LOCK);
}

#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)

void Dem_BfmExtDbgDataRecordSetDeletionFlag( Dem_BfmLocationDataType location )
{
	if( (Dem_BfmRecordManagementDataValuesNvm.managementData[location]&DEM_BFM_ST_PERM_EXT_DELETE) == 0u )
	{
		Dem_BfmRecordManagementDataValuesNvm.managementData[location]|= DEM_BFM_ST_PERM_EXT_DELETE;

		if( m_BfmRecordDeleteCounter == DEM_BFM_LOCATION_MAX )
		{
			DEM_DET(DEM_DET_APIID_BFM_RECORD,DEM_E_WRONG_CONDITION);
		}
		else
		{
			m_BfmRecordDeleteCounter++;
		}
	}
}

void Dem_BfmExtDbgRecordResetDeletionFlag( Dem_BfmLocationDataType location )
{
	if( (Dem_BfmRecordManagementDataValuesNvm.managementData[location]&DEM_BFM_ST_PERM_EXT_DELETE) != 0u )
	{
		Dem_BfmRecordManagementDataValuesNvm.managementData[location] &= (uint8)(~DEM_BFM_ST_PERM_EXT_DELETE);

		if( m_BfmRecordDeleteCounter == 0 )
		{
			DEM_DET(DEM_DET_APIID_BFM_RECORD,DEM_E_WRONG_CONDITION);
		}
		else
		{
			m_BfmRecordDeleteCounter--;

			if( m_BfmRecordDeleteCounter == 0 )
			{
				m_BfmRecordIsManagmentDataModified = TRUE;
			}
		}
	}
}

boolean Dem_BfmExtDbgDataRecordIsMarkedForDeletion( Dem_BfmLocationDataType location )
{
	if( (Dem_BfmRecordManagementDataValuesNvm.managementData[location]&DEM_BFM_ST_PERM_EXT_DELETE) == 0u )
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

void Dem_BfmExtDbgDataRecordHandleDeletion( Dem_BfmLocationDataType location )
{
	Dem_BfmLocationDataType BfmIndex;

	if(Dem_BfmExtDbgDataRecordIsMarkedForDeletion(location))
	{
		BFM_ENTER_LOCK_EXTERNAL_READ_DIRECT_NESTED();

		//Get the Bfm index linked to this extended debug data record
		BfmIndex = Dem_BfmExtDbgDataGetBfmRecordIndex(location);

		//Check if the BFM index is valid
		if(BfmIndex < DEM_BFM_AMOUNT_RECORDS)
		{
			//Set the EDD index to invalid in the linked BFM record
			Dem_BfmSetExtDbgDataRecIndexToInvalid(BfmIndex);
		}

		//Empty the content of the extended debug data record
		Dem_BfmExtDbgDataRecordEmptyRam(location);

		BFM_EXIT_LOCK_EXTERNAL_READ_DIRECT_NESTED();

		Dem_BfmExtDbgDataRecordSetEmpty(location);
		Dem_BfmExtDbgDataRecordResetModified(location);
		Dem_BfmExtDbgRecordResetDeletionFlag(location);
	}

}

boolean Dem_BfmExtDbgDataRecordIsModified(Dem_BfmLocationDataType location)
{
	if( (Dem_BfmRecordManagementDataValuesRam.managementData[location]&DEM_BFM_ST_TEMP_EXT_MODIFY) == 0u )
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

//*****************************************************************************
void Dem_BfmExtDbgDataRecordResetModified( Dem_BfmLocationDataType location )
{
	if( (Dem_BfmRecordManagementDataValuesRam.managementData[location]&DEM_BFM_ST_TEMP_EXT_MODIFY) != 0u  )
	{
		Dem_BfmRecordManagementDataValuesRam.managementData[location] &= (uint8)(~DEM_BFM_ST_TEMP_EXT_MODIFY);

		if( m_BfmRecordModifyCounter == 0u )
		{
			DEM_DET(DEM_DET_APIID_BFM_RECORD,DEM_E_WRONG_CONDITION);
		}
		else
		{
			m_BfmRecordModifyCounter--;
		}

		if( m_BfmRecordModifyCounter == 0u )
		{
			m_BfmRecordIsManagmentDataModified = TRUE;
		}
	}
}

void Dem_BfmExtDbgDataRecordSetModified( Dem_BfmLocationDataType location )
{
	if( (Dem_BfmRecordManagementDataValuesRam.managementData[location]&DEM_BFM_ST_TEMP_EXT_MODIFY) == 0u  )
	{
		Dem_BfmRecordManagementDataValuesRam.managementData[location] |= DEM_BFM_ST_TEMP_EXT_MODIFY;

		if( m_BfmRecordModifyCounter == DEM_BFM_LOCATION_MAX )
		{
			DEM_DET(DEM_DET_APIID_BFM_RECORD,DEM_E_WRONG_CONDITION);
		}
		else
		{
			m_BfmRecordModifyCounter++;
		}
	}
}

void Dem_BfmSetExtDbgDataRecIndexToInvalid(Dem_BfmLocationDataType BfmRecordIndex)
{
	mBfmRecords[BfmRecordIndex].ExtDbgDataRecordIndex = DEM_BFM_INVALID_INDEX;
}

#endif

//*****************************************************************************
void Dem_BfmRecordLockAllPerm(void)
{
	Dem_BfmLocationDataType loc;

	for( loc=0; loc<DEM_BFM_AMOUNT_RECORDS; loc++ )
	{
		Dem_BfmRecordSetLockedPerm( loc );
	}

	m_BfmRecordIsManagmentDataModified = TRUE;
}

void Dem_BfmRecordUnlockAllPerm(void)
{
	Dem_BfmLocationDataType loc;

	for( loc=0; loc<DEM_BFM_AMOUNT_RECORDS; loc++ )
	{
		Dem_BfmRecordResetLockedPerm( loc );
	}

	m_BfmRecordIsManagmentDataModified = TRUE;
}

boolean Dem_BfmRecordIsLockedPerm( Dem_BfmLocationDataType location )
{
	if( (Dem_BfmRecordManagementDataValuesNvm.managementData[location]&DEM_BFM_ST_PERM_LOCK) == 0u )
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

void Dem_BfmRecordSetLockedPerm( Dem_BfmLocationDataType location )
{
	Dem_BfmRecordManagementDataValuesNvm.managementData[location] |= DEM_BFM_ST_PERM_LOCK;
}

void Dem_BfmRecordResetLockedPerm( Dem_BfmLocationDataType location )
{
	Dem_BfmRecordManagementDataValuesNvm.managementData[location] &= (uint8)(~DEM_BFM_ST_PERM_LOCK);
}


//*****************************************************************************
boolean Dem_BfmRecordHandleAllowLockedModify( Dem_BfmLocationDataType location, Dem_EventIdType eventId )
{
	boolean allowOverwrite;
	DEM_UNUSED_PARAM(eventId);

	if( Dem_BfmRecordIsLockedTemp(location) || Dem_BfmRecordIsLockedPerm(location) )
	{
	#if( DEM_BFM_CALLBACK_MODIFY_LOCKED == DEM_BFM_ON )
		if( mBfmModifyLockedCallback( eventId, location ) )
		{
			allowOverwrite = TRUE;

			//reset bits
			Dem_BfmRecordResetLockedTemp(location);
			if( Dem_BfmRecordIsLockedPerm(location) )
			{
				Dem_BfmRecordResetLockedPerm(location);
				m_BfmRecordIsManagmentDataModified = TRUE;
			}
		}
		else
	#endif
		{
			allowOverwrite = FALSE;
		}
	}
	else
	{
		allowOverwrite = TRUE;
	}

	return allowOverwrite;
}


//*****************************************************************************
boolean Dem_BfmRecordIsSomeMarkedForDeletion(void)
{
	if( m_BfmRecordDeleteCounter==0 )
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

void Dem_BfmRecordResetDeletionCounter(void)
{
	m_BfmRecordDeleteCounter=0;
}

boolean Dem_BfmRecordIsMarkedForDeletion( Dem_BfmLocationDataType location )
{
	if( (Dem_BfmRecordManagementDataValuesNvm.managementData[location]&DEM_BFM_ST_PERM_DELETE) == 0u )
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

void Dem_BfmRecordResetDeletionFlag( Dem_BfmLocationDataType location )
{
	if( (Dem_BfmRecordManagementDataValuesNvm.managementData[location]&DEM_BFM_ST_PERM_DELETE) != 0u )
	{
		Dem_BfmRecordManagementDataValuesNvm.managementData[location] &= (uint8)(~DEM_BFM_ST_PERM_DELETE);

		if( m_BfmRecordDeleteCounter == 0u )
		{
			DEM_DET(DEM_DET_APIID_BFM_RECORD,DEM_E_WRONG_CONDITION);
		}
		else
		{
			m_BfmRecordDeleteCounter--;

			if( m_BfmRecordDeleteCounter == 0u )
			{
				m_BfmRecordIsManagmentDataModified = TRUE;
			}
		}
	}
}

void Dem_BfmRecordSetDeletionFlag( Dem_BfmLocationDataType location )
{
	if( (Dem_BfmRecordManagementDataValuesNvm.managementData[location]&DEM_BFM_ST_PERM_DELETE) == 0u )
	{
		Dem_BfmRecordManagementDataValuesNvm.managementData[location]|= DEM_BFM_ST_PERM_DELETE;

		if( m_BfmRecordDeleteCounter == DEM_BFM_LOCATION_MAX )
		{
			DEM_DET(DEM_DET_APIID_BFM_RECORD,DEM_E_WRONG_CONDITION);
		}
		else
		{
			m_BfmRecordDeleteCounter++;
		}
	}
}


//*****************************************************************************
void Dem_BfmRecordMarkAllForDeletion(void)
{
	Dem_BfmLocationDataType loc;

	for( loc=0; loc<DEM_BFM_AMOUNT_RECORDS; loc++ )
	{
		Dem_BfmRecordManagementDataValuesNvm.managementData[loc]|= DEM_BFM_ST_PERM_DELETE;
	}
	m_BfmRecordDeleteCounter = DEM_BFM_AMOUNT_RECORDS;

	#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)

	for( loc=0; loc<DEM_BFM_EXTENDED_DEBUG_DATA_AMOUNT_RECORDS; loc++ )
	{
		Dem_BfmRecordManagementDataValuesNvm.managementData[loc]|= DEM_BFM_ST_PERM_EXT_DELETE;
	}
	m_BfmRecordDeleteCounter += DEM_BFM_EXTENDED_DEBUG_DATA_AMOUNT_RECORDS;

	#endif
}

void Dem_BfmRecordHandleDeletion( Dem_BfmLocationDataType location )
{
	if( Dem_BfmRecordIsMarkedForDeletion(location) )
	{
		boolean performDelete = FALSE;

		#if( DEM_BFM_CALLBACK_DELETE_RECORD == DEM_BFM_ON )
		{
			if( Dem_BfmRecordIsEmpty(location) )
			{
				//it does not hurt to delete them again, but that way the init trick does work!
				//avoid usage of callback function
				performDelete = TRUE;
			}
			else if( mBfmDeleteCallback(location) )
			{
				performDelete = TRUE;
			}
			else
			{
				//To avoid Misra Warning
			}
		}
		#else
		{
			performDelete = TRUE;
		}
		#endif


		if( performDelete )
		{
			//set the event id to invalid for the location which is getting deleted.
			Dem_BfmRecordSetManagementDataEventId( location,DEM_EVENTID_INVALID );

			BFM_ENTER_LOCK_EXTERNAL_READ_DIRECT_NESTED();

			DEM_MEMSET( &mBfmRecords[location], 0, DEM_SIZEOF_TYPE(Dem_BfmRecord) ); //zero RAM

			#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
			//Set the BFM index record in EDD to invalid
			Dem_BfmExtSetBfmIndexToInvalid(mBfmRecords[location].ExtDbgDataRecordIndex);

			//Set Extended record index to invalid in the bfm record
			mBfmRecords[location].ExtDbgDataRecordIndex = DEM_BFM_INVALID_INDEX;
			#endif

			BFM_EXIT_LOCK_EXTERNAL_READ_DIRECT_NESTED();

			Dem_BfmRecordSetEmpty( location );
			Dem_BfmRecordResetModified( location );
		}

		//in any case reset delete flag, so that a record is only using callback function once
		Dem_BfmRecordResetDeletionFlag( location );
	}
}


//*****************************************************************************
void Dem_BfmRecordRead( Dem_BfmLocationDataType location, void *buffer )
{
	Dem_BfmRecordHandleDeletion( location );

	DEM_MEMCPY( buffer, &mBfmRecords[location], DEM_SIZEOF_TYPE(Dem_BfmRecord) );
}


#if( DEM_BFM_NVM_BYTE_SWAPPING == DEM_BFM_ON )

void Dem_BfmRecordSwapBytes( Dem_BfmRecord *pBfmRecDest, Dem_BfmRecord const *pBfmRecSrc )
{
	uint8 i;
	uint8 length;
	uint16 offset;
	uint8 const *tempRecConfig =  Dem_BfmConfigParam_pcs-> recordConfigurationPtr;

	Dem_ByteSwapping( (void*)(&pBfmRecDest->age), (void const*)(&pBfmRecSrc->age), DEM_SIZEOF_TYPE(Dem_BfmTimestampType) );
	Dem_ByteSwapping( (void*)(&pBfmRecDest->eventId), (void const*)(&pBfmRecSrc->eventId), DEM_SIZEOF_TYPE(Dem_EventIdType) );
	Dem_ByteSwapping( (void*)(&pBfmRecDest->priority), (void const*)(&pBfmRecSrc->priority), DEM_SIZEOF_TYPE(Dem_BfmPriorityType) );
	Dem_ByteSwapping( (void*)(&pBfmRecDest->statusAndQualification), (void const*)(&pBfmRecSrc->statusAndQualification), DEM_SIZEOF_TYPE(Dem_BfmStatusAndQualificationBitType) );
	#if( DEM_BFM_OCCURRENCE_COUNTER == DEM_BFM_ON )
	Dem_ByteSwapping( (void*)(&pBfmRecDest->occurrences), (void const*)(&pBfmRecSrc->occurrences), DEM_SIZEOF_TYPE(Dem_BfmOccurenceCounterType) );
	#endif

	#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
	//The byte swapping is also done for a 1 byte data, considering that there may be some future updates.
	Dem_ByteSwapping( (void*)(&pBfmRecDest->ExtDbgDataRecordIndex), (void const*)(&pBfmRecSrc->ExtDbgDataRecordIndex), DEM_SIZEOF_TYPE(Dem_BfmExtDbgDataRecordIndexType));
	#endif

	for( i=0; i<DEM_BFM_CUSTOM_DATA_AMOUNT; i++ )
	{
		offset = mBfmCustomData[i].offset;
		length = Dem_BfmBufferGetElementSize( mBfmCustomData[i].bufferIndex );

		if( ((tempRecConfig[i]) & DEM_BFM_STQU_MASK_ORIGIN) == DEM_BFM_STQU_INTERNAL )
		{
			Dem_ByteSwapping( (void*)(&pBfmRecDest->customData[offset]), (void const*)(&pBfmRecSrc->customData[offset]), length );
		}
		else
		{
			DEM_MEMCPY( (void*)(&pBfmRecDest->customData[offset]), (void const*)(&pBfmRecSrc->customData[offset]), length );
		}
	}
}


void Dem_BfmRecordReadByteSwapped( Dem_BfmLocationDataType location, void *destination, boolean handleDelete )
{
	if( handleDelete )
	{
		Dem_BfmRecordHandleDeletion( location );
	}

	/* MR12 RULE 11.5 VIOLATION: similar behaviour to memcpy */
	Dem_BfmRecordSwapBytes( (Dem_BfmRecord *)destination, &mBfmRecords[location] );
}


void Dem_BfmRecordWriteByteSwapped( Dem_BfmLocationDataType location, void const *source )
{
	/* MR12 RULE 11.5 VIOLATION: similar behaviour to memcpy */
	Dem_BfmRecordSwapBytes( &mBfmRecords[location], (Dem_BfmRecord const *)source );
}

#endif //#if( DEM_BFM_NVM_BYTE_SWAPPING == DEM_BFM_ON )


//*****************************************************************************
boolean Dem_BfmRecordIsManagementDataModified(void)
{
	return m_BfmRecordIsManagmentDataModified;
}

void Dem_BfmRecordSetManagementDataModified( boolean isModified )
{
	m_BfmRecordIsManagmentDataModified = isModified;
}

void Dem_BfmRecordGetManagementDataNvm( Dem_BfmRecordManagementDataNvm *managementDataNvm )
{
	if( managementDataNvm != NULL_PTR )
	{
		(void)Dem_BfmCounterGetTimestamp(&Dem_BfmRecordManagementDataValuesNvm.age);
		DEM_MEMCPY( managementDataNvm, &Dem_BfmRecordManagementDataValuesNvm, DEM_SIZEOF_TYPE(Dem_BfmRecordManagementDataNvm) );
	}
}

void Dem_BfmRecordSetManagementDataEventId( Dem_BfmLocationDataType location, Dem_EventIdType eventId )
{
	Dem_BfmRecordManagementDataValuesNvm.eventId[location] = eventId;
}

//*****************************************************************************
boolean Dem_BfmRecordIsSomeModified(void)
{
	if( m_BfmRecordModifyCounter==0 )
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

boolean Dem_BfmRecordIsModified( Dem_BfmLocationDataType location )
{
	if( (Dem_BfmRecordManagementDataValuesRam.managementData[location]&DEM_BFM_ST_TEMP_MODIFY) == 0u )
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

void Dem_BfmRecordResetModified( Dem_BfmLocationDataType location )
{
	if( (Dem_BfmRecordManagementDataValuesRam.managementData[location]&DEM_BFM_ST_TEMP_MODIFY) != 0u	 )
	{
		Dem_BfmRecordManagementDataValuesRam.managementData[location] &= (uint8)(~DEM_BFM_ST_TEMP_MODIFY);

		if( m_BfmRecordModifyCounter == 0u )
		{
			DEM_DET(DEM_DET_APIID_BFM_RECORD,DEM_E_WRONG_CONDITION);
		}
		else
		{
			m_BfmRecordModifyCounter--;
		}

		if( m_BfmRecordModifyCounter == 0u )
		{
			m_BfmRecordIsManagmentDataModified = TRUE;
		}
	}
}

void Dem_BfmRecordSetModified( Dem_BfmLocationDataType location )
{
	if( (Dem_BfmRecordManagementDataValuesRam.managementData[location]&DEM_BFM_ST_TEMP_MODIFY) == 0u	 )
	{
		Dem_BfmRecordManagementDataValuesRam.managementData[location] |= DEM_BFM_ST_TEMP_MODIFY;

		if( m_BfmRecordModifyCounter == DEM_BFM_LOCATION_MAX )
		{
			DEM_DET(DEM_DET_APIID_BFM_RECORD,DEM_E_WRONG_CONDITION);
		}
		else
		{
			m_BfmRecordModifyCounter++;
		}
	}
}


//*****************************************************************************
boolean Dem_BfmRecordIsEmpty( Dem_BfmLocationDataType location )
{
	if( (Dem_BfmRecordManagementDataValuesNvm.managementData[location]&DEM_BFM_ST_PERM_EMPTY) == 0u )
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

void Dem_BfmRecordSetEmpty( Dem_BfmLocationDataType location )
{
	Dem_BfmRecordManagementDataValuesNvm.managementData[location] |= DEM_BFM_ST_PERM_EMPTY;
}

void Dem_BfmRecordResetEmpty( Dem_BfmLocationDataType location )
{
	Dem_BfmRecordManagementDataValuesNvm.managementData[location] &= (uint8)(~DEM_BFM_ST_PERM_EMPTY);
}

//*****************************************************************************
void Dem_BfmRecordInitCheckNvM(void)
{
	Dem_BfmReturnType retVal = DEM_BFM_RET_OK;
	Dem_BfmLocationDataType loc;

	//for the case that NvM_ReadAll didn't work out in the beginning -> reset mem

	retVal = Dem_BfmNvmGetStatusManagementData();
	if( (retVal==DEM_BFM_RET_NOK) || (retVal==DEM_BFM_RET_UNSUPPORTED) || (retVal==DEM_BFM_RET_INVALIDATED) )
	{
		DEM_MEMSET( &Dem_BfmRecordManagementDataValuesNvm, 0x00, DEM_SIZEOF_TYPE(Dem_BfmRecordManagementDataNvm) );
	}

	for( loc=0; loc<DEM_BFM_AMOUNT_RECORDS; loc++ )
	{
		retVal = Dem_BfmNvmGetStatusRecord(loc);
		if( (retVal==DEM_BFM_RET_NOK) || (retVal==DEM_BFM_RET_UNSUPPORTED) || (retVal==DEM_BFM_RET_INVALIDATED) )
		{
			Dem_BfmRecordManagementDataValuesNvm.managementData[loc] = 0x00;
			Dem_BfmRecordSetManagementDataEventId(loc, DEM_EVENTID_INVALID);
			Dem_BfmRecordSetDeletionFlag( loc );

			Dem_BfmRecordSetEmpty(loc);

			#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
			//set the EDD index to invalid
			Dem_BfmSetExtDbgDataRecIndexToInvalid(loc);
			#endif
		}
	}

	#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
	for( loc=0; loc<DEM_BFM_EXTENDED_DEBUG_DATA_AMOUNT_RECORDS; loc++ )
	{
		retVal = Dem_BfmNvmGetStatusExtDbgDataRecord(loc);
		if( (retVal==DEM_BFM_RET_NOK) || (retVal==DEM_BFM_RET_UNSUPPORTED) || (retVal==DEM_BFM_RET_INVALIDATED) )
		{
			//Set the deletion flag for the EDD
			Dem_BfmExtDbgDataRecordSetDeletionFlag(loc);

			//Set the Empty flag for EDD
			Dem_BfmExtDbgDataRecordSetEmpty(loc);

			//Set the BFM index to invalid in EDD record
			Dem_BfmExtSetBfmIndexToInvalid(loc);
		}
	}
	#endif
}

void Dem_BfmInitCausality(void)
{
    Dem_BfmLocationDataType loc;

    for( loc=0; loc<DEM_BFM_AMOUNT_RECORDS; loc++ )
    {
        Dem_EventIdType evtId = mBfmRecords[loc].eventId;
        if (Dem_isEventIdValid(evtId))
        {
            if (Dem_EvtSt_GetTestFailed(evtId)){
                Dem_EvtSetCausal(evtId, TRUE);
            }
        }
    }
}


void Dem_BfmRecordInit(void)
{
	Dem_BfmLocationDataType loc;

	m_BfmRecordDeleteCounter = 0;
	m_BfmRecordModifyCounter = 0;

	for( loc=0; loc<DEM_BFM_AMOUNT_RECORDS; loc++ )
	{
		if( Dem_BfmRecordIsMarkedForDeletion(loc) )
		{
			m_BfmRecordDeleteCounter++;
		}

		if( Dem_BfmRecordIsModified(loc) )
		{
			m_BfmRecordModifyCounter++;
		}

		//might be useful for the very first start
		if( !Dem_isEventIdValid( mBfmRecords[loc].eventId ) )
		{
			Dem_BfmRecordSetEmpty(loc);
		}

		if( Dem_BfmRecordIsEmpty(loc) )
		{
			Dem_BfmRecordSetDeletionFlag( loc );
			#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
			//Set the EDD index to invalid in BFM record
			Dem_BfmSetExtDbgDataRecIndexToInvalid(loc);
			#endif
		}

		#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
		if(Dem_BfmExtIndexIsValid(loc))
		{
			if( Dem_BfmExtDbgDataRecordIsMarkedForDeletion(loc) )
			{
				m_BfmRecordDeleteCounter++;
			}

			//might be useful for the very first start
			if(Dem_BfmExtDbgDataGetBfmRecordIndex(loc) == DEM_BFM_INVALID_INDEX)
			{
				Dem_BfmExtDbgDataRecordSetEmpty(loc);
			}

			if( Dem_BfmExtDbgDataRecordIsModified(loc) )
			{
				m_BfmRecordModifyCounter++;
			}

			if(Dem_BfmExtDbgDataRecordIsEmpty(loc))
			{
				Dem_BfmExtDbgDataRecordSetDeletionFlag( loc );
				//Set the BFM index to invalid in EDD record
				Dem_BfmExtSetBfmIndexToInvalid(loc);
			}
		}
		#endif
	}
}

void Dem_BfmRecordShutdown(void)
{
	Dem_BfmLocationDataType loc;

	//PARANOIA: do not trust the counter at the end anymore, so that we have a clean exit for sure
	//if( Dem_BfmRecordIsSomeMarkedForDeletion() )
	for( loc=0; loc<DEM_BFM_AMOUNT_RECORDS; loc++ )
	{
		Dem_BfmRecordHandleDeletion( loc );
	}


	//PARANOIA: do not trust the counter at the end anymore, so that data gets written for sure
	//if( Dem_BfmRecordIsSomeModified() )
	for( loc=0; loc<DEM_BFM_AMOUNT_RECORDS; loc++ )
	{
		if( Dem_BfmRecordIsModified(loc) )
		{
			//let NvM write modified blocks in writeAll
			(void)Dem_BfmNvmSetRamBlockStatusRecord( loc, TRUE );

		}

		#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
		if(Dem_BfmExtIndexIsValid(loc))
		{
			if(Dem_BfmExtDbgDataRecordIsModified(loc))
			{
				(void)Dem_BfmNvmSetRamBlockStatusExtDbgDataRecord(loc, TRUE);
			}
		}
		#endif
	}

	//let NvM write management data in writeAll
	(void)Dem_BfmNvmSetRamBlockStatusManagementData( TRUE );
}


void* Dem_BfmRecordGetAddress( Dem_BfmLocationDataType location )
{
	return &mBfmRecords[location];
}

void Dem_BfmConsistencyChkForManagementData(void)
{
	Dem_BfmLocationDataType loc;
	Dem_BfmLocationDataType duplicate;

	for( loc=0; loc<DEM_BFM_AMOUNT_RECORDS; loc++ )
	{
		//Check whether the eventId is valid
		if( !Dem_isEventIdValid(mBfmRecords[loc].eventId) )
		{
			//set delete bit of management data
			Dem_BfmRecordSetDeletionFlag(loc);
			//set empty bit of management data
			Dem_BfmRecordSetEmpty(loc);
		}
		else //The eventid is valid
		{
			if(Dem_BfmRecordManagementDataValuesNvm.eventId[loc] != mBfmRecords[loc].eventId)
			{
				//ensure that the BFM record is newer than the management data record
				if( Dem_BfmRecordManagementDataValuesNvm.age < mBfmRecords[loc].age )
				{
					//reset empty bit of management data
					Dem_BfmRecordResetEmpty(loc);
					//reset delete bit of management data
					Dem_BfmRecordResetDeletionFlag(loc);
					//set valid EventId
					Dem_BfmRecordSetManagementDataEventId(loc, mBfmRecords[loc].eventId);
				}
				else
				{
					//set empty bit of management data
					Dem_BfmRecordSetEmpty(loc);
					//set delete bit of management data
					Dem_BfmRecordSetDeletionFlag(loc);
				}
			}
		}
	}

	//search and remove duplicates
	for( loc=0; loc<(DEM_BFM_AMOUNT_RECORDS-1u); loc++ )
	{
        if( !Dem_BfmRecordIsMarkedForDeletion(loc) )
        {
            for( duplicate=(loc+1); duplicate<DEM_BFM_AMOUNT_RECORDS; duplicate++ )
            {
                if( (!Dem_BfmRecordIsMarkedForDeletion(duplicate)) &&
                    (mBfmRecords[loc].eventId==mBfmRecords[duplicate].eventId) )
                {
                    if( mBfmRecords[loc].age < mBfmRecords[duplicate].age )
                    {
                        //set empty bit of management data
                        Dem_BfmRecordSetEmpty(loc);
                        //set delete bit of management data
                        Dem_BfmRecordSetDeletionFlag(loc);
                    }
                    else
                    {
                        //set empty bit of management data
                        Dem_BfmRecordSetEmpty(duplicate);
                        //set delete bit of management data
                        Dem_BfmRecordSetDeletionFlag(duplicate);
                    }
                }
            }
        }
	}

	#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)
	for( loc=0; loc<DEM_BFM_AMOUNT_RECORDS; loc++ )
	{
		//BFM record is ok but EDD is invalid
		if(!Dem_BfmRecordIsMarkedForDeletion(loc))
		{
			//Check the EDD index stored in BFM record is already set for deletion
			if(Dem_BfmExtDbgDataRecordIsMarkedForDeletion(Dem_BfmExtDbgDataGetBfmRecordIndex(loc)))
			{
				//Set the EDD index to invalid in the BFM record
				Dem_BfmSetExtDbgDataRecIndexToInvalid(Dem_BfmExtDbgDataGetBfmRecordIndex(loc));
			}
		}
	}

	for( loc=0; loc<DEM_BFM_EXTENDED_DEBUG_DATA_AMOUNT_RECORDS; loc++ )
	{
		//EDD record is ok but BFM is invalid
		if(!Dem_BfmExtDbgDataRecordIsMarkedForDeletion(loc))
		{
			//Check the BFM index stored in the EDD is already set for deletion
			if(Dem_BfmRecordIsMarkedForDeletion(Dem_BfmExtDbgDataGetBfmRecordIndex(loc)))
			{
				//Set the deletion flag for the EDD record since because the BFM record which is linked to it is already invalid
				Dem_BfmExtDbgDataRecordSetDeletionFlag(loc);

				//Set the empty flag of EDD to avoid the usage of callback function if supported in future
				Dem_BfmExtDbgDataRecordSetEmpty(loc);

				//Set the BFM index to invalid in EDD record
				Dem_BfmExtSetBfmIndexToInvalid(loc);
			}
		}
	}
	#endif
}

void Dem_BfmConsistencyChkForBfmCounters(void)
{
#if((DEM_BFM_IS_OPERATIONCYCLE_REFERENCED == DEM_BFM_ON)||(DEM_BFM_IS_ABS_OPERATINGTIME_REFERENCED == DEM_BFM_ON))

	#if(DEM_BFM_IS_OPERATIONCYCLE_REFERENCED == DEM_BFM_ON)
	Dem_BfmOperationCycleCounterType TempOpcycleCount;
	#endif
	#if(DEM_BFM_IS_ABS_OPERATINGTIME_REFERENCED == DEM_BFM_ON)
	Dem_BfmAbsoluteOperatingTimeCounterType TempAbsOpTimeCount;
	#endif

	Dem_BfmTimestampType MaxTimeIdinBfm = 0;
	Dem_BfmLocationDataType LastUpdatedRecord = 0;
	uint8 idx;

	//Get the maximum IimeId from the BfmRecord
	Dem_BfmRecordFindMaxTimestampAndLocation( &MaxTimeIdinBfm, &LastUpdatedRecord );

	if(MaxTimeIdinBfm > 0u)
	{
		#if(DEM_BFM_IS_OPERATIONCYCLE_REFERENCED == DEM_BFM_ON)
		//Get the custom data value for the BFM_Operationcylcetime
		for(idx=0 ;idx < DEM_BFM_AMOUNT_OPERATIONCYCLE_ELEMENTS;idx++)
		{
			//Get the maximum operation cycle
			DEM_MEMCPY(&TempOpcycleCount, &mBfmRecords[LastUpdatedRecord].customData[mBfmCustomData[Dem_Bfm_OperationCycleIndex[idx]].offset], DEM_SIZEOF_TYPE(Dem_BfmOperationCycleCounterType) );
			if(TempOpcycleCount > Dem_BfmCounterValuesNvm.OperationCycleCounter)
			{
				Dem_BfmCounterValuesNvm.OperationCycleCounter = TempOpcycleCount;

				//mark as modified
				Dem_BfmCounterSetNeedsToBeSaved( TRUE );
			}
		}
		#endif

		#if(DEM_BFM_IS_ABS_OPERATINGTIME_REFERENCED == DEM_BFM_ON)
		//Get the custom data value for the BFM_AbsoluteOperationcylcetime
		for(idx=0 ;idx < DEM_BFM_AMOUNT_ABSOLUTE_OPERATINGTIME_ELEMENTS;idx++)
		{
			//Get the maximum Absolute operation cycle time
			DEM_MEMCPY(&TempAbsOpTimeCount, &mBfmRecords[LastUpdatedRecord].customData[mBfmCustomData[Dem_Bfm_AbsoluteOperatingTimeIndex[idx]].offset], DEM_SIZEOF_TYPE(Dem_BfmAbsoluteOperatingTimeCounterType));

			//check which is the latest value and start updating the counter accordingly
			if(TempAbsOpTimeCount > Dem_BfmCounterValuesNvm.AbsoluteOperatingTimeCounter)
			{
				Dem_BfmCounterValuesNvm.AbsoluteOperatingTimeCounter = TempAbsOpTimeCount;

				//mark as modified
				Dem_BfmCounterSetNeedsToBeSaved( TRUE );
			}
		}
		#endif
	}

#endif
}

//*****************************************************************************
#if(DEM_BFM_EXTENDED_DEBUG_DATA_SUPPORTED == DEM_BFM_ON)

boolean Dem_BfmExtDbgDataRecordIsEmpty( Dem_BfmLocationDataType location )
{
	if( (Dem_BfmRecordManagementDataValuesNvm.managementData[location]&DEM_BFM_ST_PERM_EXT_EMPTY) == 0u )
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

void Dem_BfmExtDbgDataRecordSetEmpty(Dem_BfmLocationDataType location)
{
	Dem_BfmRecordManagementDataValuesNvm.managementData[location] |= DEM_BFM_ST_PERM_EXT_EMPTY;
}

void Dem_BfmExtDbgDataRecordResetEmpty( Dem_BfmLocationDataType location )
{
	Dem_BfmRecordManagementDataValuesNvm.managementData[location] &= (uint8)(~DEM_BFM_ST_PERM_EXT_EMPTY);
}

void Dem_BfmExtDbgDataRecordUpdate(Dem_BfmLocationDataType location, Dem_BfmLocationDataType ExtRecLocation)
{
	Dem_EventCategoryType EventPriorityThreshold;
	Std_ReturnType result = E_NOT_OK;


	//Get the Priority Threshold from the event category
	EventPriorityThreshold = Dem_EvtGetCategory(mBfmRecords[location].eventId);

	if(Dem_BfmExtIndexIsValid(ExtRecLocation))
	{
		BFM_ENTER_LOCK_EXTERNAL_READ_DIRECT_NESTED();
		Dem_BfmExtDbgDataRecIsCurrentlyBusyWithUpdating = TRUE;
		Dem_BfmExtDbgDataCurrentlyUpdatingLocation = ExtRecLocation;
		BFM_EXIT_LOCK_EXTERNAL_READ_DIRECT_NESTED();

		result = (DEM_BFM_EXTENDED_DEBUG_DATA_ELEMENT_CALLBACK_FUNCTION)(mbfmExtDbgDataRam[ExtRecLocation].ExtData);

		//delte index linking inside old ExtDebData user (for replacement reason)
		if((mBfmRecords[location].ExtDbgDataRecordIndex == DEM_BFM_INVALID_INDEX) && (mbfmExtDbgDataRam[ExtRecLocation].BfmRecIndex != DEM_BFM_INVALID_INDEX))
		{
			//Update the extend index in the bfm location for the replaced event to invalid as it is no longer valid.
			Dem_BfmSetExtDbgDataRecIndexToInvalid(mbfmExtDbgDataRam[ExtRecLocation].BfmRecIndex);

			//Set the modified flag for this particular index
			Dem_BfmRecordSetModified(mbfmExtDbgDataRam[ExtRecLocation].BfmRecIndex);
		}

		//Update the indexes
		mbfmExtDbgDataRam[ExtRecLocation].BfmRecIndex = location;
		mBfmRecords[location].ExtDbgDataRecordIndex = ExtRecLocation;

		Dem_BfmExtDbgDataRecordResetEmpty(ExtRecLocation);
		Dem_BfmExtDbgDataRecordSetModified(ExtRecLocation);

		if (result != E_OK)
		{
			DEM_DET(DEM_DET_APIID_BFM_EXT_RECORD, DEM_E_NODATAAVAILABLE);
		}

		Dem_BfmExtDbgDataRecIsCurrentlyBusyWithUpdating = FALSE;
	}
}

void* Dem_BfmExtDbgDataGetRecordAddress( Dem_BfmLocationDataType location )
{
	return &mbfmExtDbgDataRam[location];
}

#endif

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif //DEM_BFM_ENABLED
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.11.0.1; 0     03.02.2016 CLH2SI
 *   CSCRM01036799
 * 
 * AR40.11.0.0; 0     16.10.2015 VSA2COB
 *   Checkout by vsa2cob
 * 
 * AR40.10.0.0; 7     14.07.2015 WUG3ABT
 *   Checkout by wug3abt
 * 
 * AR40.10.0.0; 6     10.07.2015 CLH2SI
 *   CSCRM00938605
 * 
 * AR40.10.0.0; 5     09.07.2015 RPV5COB
 *   CSCRM00791814
 * 
 * AR40.10.0.0; 4     24.06.2015 WUG3ABT
 *   CSCRM00896357
 * 
 * AR40.10.0.0; 3     13.05.2015 WUG3ABT
 *   CSCRM00857269
 * 
 * AR40.10.0.0; 2     13.05.2015 WUG3ABT
 *   CSCRM00857327
 * 
 * AR40.10.0.0; 1     12.05.2015 CLH2SI
 *   CSCRM00789099
 * 
 * AR40.10.0.0; 0     17.03.2015 TVE5COB
 *   CSCRM00789300
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
