/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2013. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************
* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_BfmEvent$
* $Variant___:AR40.8.0.0$
* $Revision__:2$
**********************************************************************************************************************
</BASDKey>*/
#ifndef DEM_BFM_EVENT_H
#define DEM_BFM_EVENT_H

#include "Dem_Cfg_Bfm.h"
#if( DEM_BFM_ENABLED == DEM_BFM_ON )

#include "Dem_BfmTypes.h"
#include "Dem_InternalEnvData.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


/** * @ingroup DEM_BFM_H
 * Get the priority of an event.
 * The lower the value, the higher the priority.
 * An event that has no configured priority is filled with the reserved value DEM_BFM_PRIORITY_MIN.
 * The event priority is mapped to the DemEventCategory parameter.
 * The priority of an event is static.
 * @param [in]  eventId  the eventId you want to query
 * @param [out]  priority  pointer to a buffer that is filled with the found priority of this event
 * @return  DEM_BFM_RET_OK: priority got set\n
 *          DEM_BFM_RET_NULL_PTR: priority pointer is invalid\n
 *          DEM_BFM_RET_NOK: something went wrong
 */
Dem_BfmReturnType Dem_BfmEventGetPriority( Dem_EventIdType eventId, Dem_BfmPriorityType *priority );

#if( DEM_BFM_UNIQUEID == DEM_BFM_ON )
/** * @ingroup DEM_BFM_H
 * Get the unique id of an event.
 * An event that has no configured unique id is filled with the reserved value DEM_BFM_UNIQUE_ID_UNDEFINED.
 * The unique id is statically mapped to an event.
 * This feature needs to be enabled by seeting configuration switch DemBfmUniqueId to something else than "OFF".
 * @param [in]  eventId  the eventId you want to query
 * @param [out]  uniqueId  pointer to a buffer that is filled with the found unique id of this event
 * @return  DEM_BFM_RET_OK: uniqueId got set\n
 *          DEM_BFM_RET_NULL_PTR: uniqueId pointer is invalid\n
 *          DEM_BFM_RET_NOK: something went wrong
 */
Dem_BfmReturnType Dem_BfmEventGetUniqueId( Dem_EventIdType eventId, Dem_BfmUniqueIdDataType *uniqueId );
Std_ReturnType Dem_BfmWrapperGetUniqueEventId( uint8* buffer, const Dem_InternalEnvData* internalData );
#endif


#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


#endif //DEM_BFM_ENABLED
#endif
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.8.0.0; 2     17.04.2014 WUG3ABT
*   CSCRM00653602
* 
* AR40.8.0.0; 1     14.04.2014 WUG3ABT
*   CSCRM00625933
* 
* AR40.8.0.0; 0     13.02.2014 WUG3ABT
*   CSCRM00562030
* 
* AR40.7.0.0; 2     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 1     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 0     22.10.2013 AMN2KOR
*   CSCRM00547887
* 
* AR40.6.0.0; 0     21.06.2013 WUG3ABT
*   
* 
* $
**********************************************************************************************************************
</BASDKey>*/
