/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_EventRHandling$
* $Variant___:AR40.8.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/


#include "Dem_EventRHandling.h"
#include "Dem_Events.h"
#include "Dem_DTCStatusByte.h"


#if (DEM_CFG_EVTROBUSTNESS == DEM_CFG_EVTROBUSTNESS_ON )

#include MFT_UNROBUSTNESSEVENTBUFFER_COMMON_H
#include MFT_UNROBUSTMONITORINGOBSERVER_COMMON_H
#include MFT_UNROBUSTMIDQUEUE_COMMON_H

DEM_INLINE Dem_boolean_least Dem_EvtsAllowRobustness (Dem_EventIdType EventId)
{
    return (   Dem_NodeIsAvailable(Dem_NodeIdFromEventId(EventId))
            && (!Dem_EvtIsSuppressed (EventId))
    );
}



/**
 * DSM_D_564: set robustnessLevel of one monitoring and insert EventId into buffer
 */
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

void FUN_DIA_setRL_IMPL_V (Dem_EventIdType EventId, Dem_boolean_least robustnessLevel, uint32 robustnessInfo0, uint32 robustnessInfo1)
{
   Dem_boolean_least oldRobustnessLevel = Dem_EvtGetRobustnessLevel(EventId);


   if (!Dem_EvtAllEnableConditionsFulfilled(EventId))
   {
      return;
   }

   if (   FUN_DIA_getRobustnessLevel_B(EventId)
       || robustnessLevel )
   {
      if ( Dem_EvtsAllowRobustness(EventId) )
      )
      {
         DEM_ENTERLOCK_MON();

         Dem_EvtSetRobustnessLevel (EventId, robustnessLevel);

         if (robustnessLevel)
         {
            UnrobustEventIdQueue__insertEventId (EventId);
            if (!oldRobustnessLevel)
            {
                UnrobustnessEventBuffer__insert (EventId, robustnessInfo0, robustnessInfo1);
            }
         }

         DEM_EXITLOCK_MON();

#if (   (DEM_CFG_FFPRESTORAGESUPPORT == DEM_CFG_FFPRESTORAGESUPPORT_ON) \
     && (DEM_CFG_FFPRESTORAGEWITHROBUSTNESS == DEM_CFG_FFPRESTORAGEWITHROBUSTNESS_ON) \
    )
         /* Prestorage of FreezeFrame */
         if (!oldRobustnessLevel &&  robustnessLevel)
         {
            Dem_PrestoreFreezeFrameWithEnvData(EventId, robustnessInfo0, robustnessInfo1);
         }

         if (oldRobustnessLevel &&  !robustnessLevel)
         {
            Dem_ClearPrestoredFreezeFrame(EventId);
         }

#endif

      }
   }
}

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.8.0.0; 1     18.03.2014 NAL2KOR
*   CSCRM00633565_EventSuppression
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 3     21.11.2013 AMN2KOR
*   CSCRM00591723
* 
* AR40.7.0.0; 2     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 1     19.11.2013 CLH2SI
*   CSCRM00578067
* 
* AR40.7.0.0; 0     19.11.2013 BRM2COB
*   
* 
* AR40.6.0.0; 1     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.6.0.0; 0     23.05.2013 CRA1COB
*   CSCRM00467195
* 
* AR40.5.0.0; 0     07.01.2013 KAN1COB
*   Git transfer - >c7b60f6605db2476a382daf05b17f6c7f088f2d2
*   Fix- Obd Drv cycle and warmup cyce not configured in operationcycles
*   * CSCRM00479194 - [INT-Dem] pending review findings from CSCRM00434163
*   CSCRM00483492 - [INT-Dem] Fix findings -Vendor Specific parameters optional
*   CSCRM00479560 - [INT-DEM] Issue from PAC_DevDiagnosis November build
*   CSCRM00479557 - [INT-DEM] Remove compilation warnings
*   CSCRM00484190 - [INT-Dem] Fix Medium/Strong review findings
*   CSCRM00484194 - [INT-Dem] Fix Medium/Strong review findings
*   CSCRM00480461 : Fix Reviewfindings : 
*   Review12_636_COMP_Dem_AR40_5_2012-10_3.xls
*   CSCRM00482583: OBD: Fix review findings
*   Changes during code analysis of Defect CSCRM00467070 (DemClearDTCBehavior)
*   QAC-warning
*   
*   CSCRM00479820 - [INT-FIM] Fix review findings
*   CSCRM00479857 - [INT - FIM] remove BCT errors and warnings shown in 
*   problemes log
* 
* AR40.4.0.0; 1     27.06.2012 BRM2COB
*   GIT to eASEE 27-06
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
