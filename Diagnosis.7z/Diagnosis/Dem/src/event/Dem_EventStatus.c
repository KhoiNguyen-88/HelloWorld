/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_EventStatus$
* $Variant___:AR40.11.0.0$
* $Revision__:2$
**********************************************************************************************************************
</BASDKey>*/

#include "Dem_EventStatus.h"
#include "Dem_Events.h"
#include "Dem_Cfg_EvMem.h"
#include "Dem_Cfg_Clear.h"
#include "Dem_Dependencies.h"
#include "Dem_Nvm.h"
#include "Rte_Dem.h"
#include "Dem_Protected.h"
#if(DEM_CFG_TRIGGERFIMREPORTS == DEM_CFG_TRIGGERFIMREPORTS_ON)
#include "FiM.h"
#endif
#include "Dem_Prv_CallEvtStChngdCbk.h"
/* FC_VariationPoint_START */
#include "Dem_ObdMain.h"
#include "Dem_ObdRdy_Prv.h"
/* FC_VariationPoint_END */

#define DEM_START_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

DEM_ARRAY_DEFINE(      uint8, Dem_AllEventsStatusByte, DEM_EVENTID_ARRAYLENGTH);

#define DEM_STOP_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
DEM_ARRAY_DEFINE(      uint8, Dem_AllEventsStatusByteCust, DEM_EVENTID_ARRAYLENGTH);
#endif
static boolean Dem_EvtStatusTriggerImmediateNVMStorage;

#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


/* Called from Dem_Init to validate the Nv block */
void Dem_EventStatusInitCheckNvM(void)
{
    Dem_NvmResultType NvmResult;

    /* Get the Result of the NvM-Read (NvM_ReadAll) */
    NvmResult = Dem_NvmGetStatus (DEM_NVM_ID_EVT_STATUSBYTE);

    /* Data read successfully */
    if (NvmResult != DEM_NVM_SUCCESS)
    {
        /* Set the EventStatus to its default value */
        DEM_MEMSET( &Dem_AllEventsStatusByte, (sint32)DEM_ISO14229BYTE_INITVALUE, DEM_SIZEOF_VAR(Dem_AllEventsStatusByte));

        //Set the Dirty flag
        Dem_EvtStatusTriggerStoreToNvm();
    }
}


Std_ReturnType Dem_GetEventStatus(Dem_EventIdType EventId,
        Dem_EventStatusExtendedType* EventStatusExtended)
{
    if(Dem_EvtIsSuppressed(EventId))
    {
        return E_NOT_OK;
    }

    *EventStatusExtended = Dem_EvtGetIsoByte(EventId);
    return E_OK;
}


void Dem_ClearEvent(Dem_EventIdType eventId)
{
    Dem_EventStatusExtendedType statusOld, statusNew;
    Dem_EventStatusExtendedType dtcStByteOld;

    statusOld = DEM_ISO14229BYTE_INITVALUE;
    statusNew = DEM_ISO14229BYTE_INITVALUE;
    dtcStByteOld = DEM_ISO14229BYTE_INITVALUE;

    DEM_ENTERLOCK_MON();

    if (!Dem_EvtIsSuppressed(eventId))
    {
        Dem_StatusChange_GetOldStatus(eventId, &statusOld, &dtcStByteOld);
        Dem_EvtSt_HandleClear(eventId);
        statusNew = Dem_EvtGetIsoByte(eventId);

        Dem_EvtSetCausal(eventId, FALSE);
        Dem_EvtSetInitMonitoring(eventId, DEM_INIT_MONITOR_CLEAR);
        Dem_EvtSetLastReportedEvent(eventId, DEM_EVENT_STATUS_INVALIDREPORT);
        Dem_EvtRequestResetFailureFilter(eventId, TRUE);
        /* FC_VariationPoint_START */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
        Dem_ObdRdyClearEvent(eventId); /* Must be called under lock */
#endif
        /* FC_VariationPoint_END */

        if (statusNew != statusOld)
        {
            Dem_ClearIndicatorAttributes(eventId,statusOld,statusNew);
            Dem_NodeSetRecheckOnClear(Dem_NodeIdFromEventId(eventId), TRUE);
            Dem_TriggerOn_EventStatusChange(eventId,statusOld,statusNew,dtcStByteOld);
        }
    }

    DEM_EXITLOCK_MON();
}


Dem_boolean_least Dem_EvtStatusByteIsNvmImmediateStoragePending(Dem_boolean_least *anyFailed)
{
    Dem_NvmResultType nvmStatus;

    nvmStatus = Dem_NvmGetStatus (DEM_NVM_ID_EVT_STATUSBYTE);
    *anyFailed = (*anyFailed) || (nvmStatus == DEM_NVM_FAILED);
    return (   (Dem_EvtStatusTriggerImmediateNVMStorage )
            || (nvmStatus == DEM_NVM_PENDING)
            );
}


void Dem_EvtMainFunction(void)
{
    Dem_NvmReturnType writeResult;

    if ( Dem_EvtStatusTriggerImmediateNVMStorage )
    {
        /* clear flag*/
        Dem_EvtStatusTriggerImmediateNVMStorage = FALSE;

        /* indicate NVM to store the updated NVM block */
        writeResult = Dem_NvmWrite (DEM_NVM_ID_EVT_STATUSBYTE, NULL_PTR);

        /* if NvM_Write was not successful, reset the flag */
        if (writeResult != DEM_NVM_TRANSACTIONACCEPTED)
        {
            Dem_EvtStatusTriggerImmediateNVMStorage = TRUE;
        }
    }
}


void Dem_EvtStatusTriggerStoreToNvm(void)
{
    Dem_EvtStatusTriggerImmediateNVMStorage = TRUE;
}


void Dem_EvtAdvanceOperationCycle(Dem_OperationCycleList operationCycleList)
{
    Dem_EventIdIterator eventIt;
    Dem_EventIdType eventId;
    Dem_EventStatusExtendedType statusNew,statusOld;
    Dem_EventStatusExtendedType dtcStByteOld;

    DEM_ENTERLOCK_MON_BEFORE_INIT();
    for (Dem_EventIdIteratorNew(&eventIt); Dem_EventIdIteratorIsValid(&eventIt); Dem_EventIdIteratorNext(&eventIt))
    {
        eventId = Dem_EventIdIteratorCurrent(&eventIt);
        if (Dem_isEventAffectedByOperationCycleList(eventId, operationCycleList))
        {
            /* Set iso status-byte to next operation cycle */
            Dem_StatusChange_GetOldStatus(eventId, &statusOld, &dtcStByteOld);
            Dem_EvtSt_HandleNewOperationCycle(eventId);

            Dem_SetIndicatorDeActivation_OnOperationCycleChange(eventId, statusOld, Dem_EvtGetIsoByte(eventId));

            /* Updated Status */
            statusNew = Dem_EvtGetIsoByte(eventId);

            //Reset FDC-Threshold_reached-flag whenever the operation cycle starts/restarts
#if(DEM_CFG_SUPPORTEVENTMEMORYENTRY_ONFDCTHRESHOLD == DEM_CFG_SUPPORTEVENTMEMORYENTRY_ONFDCTHRESHOLD_ON)
            Dem_EvtSetFDCThresholdReachedTOC(eventId,FALSE);
#endif
            Dem_EvtSetInitMonitoring(eventId, DEM_INIT_MONITOR_RESTART);
            Dem_EvtRequestResetFailureFilter(eventId, TRUE);
            Dem_EvtSetLastReportedEvent(eventId,DEM_EVENT_STATUS_INVALIDREPORT);

            Dem_TriggerOn_EventStatusChange(eventId,statusOld,statusNew,dtcStByteOld);

        }
        if ((eventId % 16) == 0)
        {
            DEM_EXITLOCK_MON_BEFORE_INIT();
            DEM_ENTERLOCK_MON_BEFORE_INIT();
        }
    }
    DEM_EXITLOCK_MON_BEFORE_INIT();
}



Std_ReturnType Dem_OverwriteWIRStatus( Dem_EventIdType EventId, boolean WIRStatus )
{
    Std_ReturnType ret_val = E_NOT_OK;

    if( Dem_isEventIdValid(EventId) )
    {
        DEM_ENTERLOCK_MON();

        if (WIRStatus)
        {
            Dem_EvtSt_HandleIndicatorOn(EventId);
        }
        else
        {
            Dem_EvtSt_HandleIndicatorOff(EventId);
        }

        DEM_EXITLOCK_MON();
        ret_val = E_OK;
    }

    return ret_val;
}


#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 2     07.01.2016 TVE5COB
*   CSCRM01017790
* 
* AR40.11.0.0; 1     21.12.2015 NAL2KOR
*   CSCRM00957431
* 
* AR40.11.0.0; 0     20.11.2015 SUH4COB
*   CSCRM00540538
* 
* AR40.10.0.0; 10     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 9     10.07.2015 CLH2SI
*   CSCRM00938605
* 
* AR40.10.0.0; 8     09.07.2015 RPV5COB
*   CSCRM00791814
* 
* AR40.10.0.0; 7     06.07.2015 VSA2COB
*   CSCRM00830308
* 
* AR40.10.0.0; 6     17.06.2015 LIB8FE
*   CSCRM00764040
* 
* AR40.10.0.0; 5     26.05.2015 VSA2COB
*   CSCRM00874247
* 
* AR40.10.0.0; 4     18.05.2015 TVE5COB
*   CSCRM00588798
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
