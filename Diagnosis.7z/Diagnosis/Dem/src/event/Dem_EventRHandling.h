/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_EventRHandling$
* $Variant___:AR40.8.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_EVENTSRHANDLING_H
#define DEM_EVENTSRHANDLING_H


#include "Dem_Events.h"


#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#if (DEM_CFG_EVTROBUSTNESS == DEM_CFG_EVTROBUSTNESS_ON)

void FUN_DIA_setRL_IMPL_V (Dem_EventIdType EventId, Dem_boolean_least robustnessLevel, uint32 robustnessInfo0, uint32 robustnessInfo1);

#endif
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


/**
 * @ingroup DIA_MONITORING_PUBLIC
 *
 * The function is used to report the current robustness-state of the calling monitoring function. The robustness state
 * indicates, that the failure counter exceeded a certain threshold. The threshold should be set to a value where
 * something seems to be wrong and yet no system reaction is triggered (e.g. failure filter exceeds the regular flickering). (DSM_D_564)
 * The robustness information is an optional feature. The function is always available,
 * but it is empty, if the function switch DEM_CFG_EVTROBUSTNESS is set to OFF.
 *
 * @param EventId specifies the identifier of the monitoring to be queried
 * @param robustnessLevel_b is the current state of robustness. True means robustness-limit exceeded, false means everything is ok.
 * @param robustnessInfo0 is the robustness info of the monitoring.
 * @param robustnessInfo1 is the robustness info of the monitoring. The robustness info is individually specified for each
 * monitoring within DDB. Some data for analyzing failure events should be encoded as well as a failure debounce counter.
 */

DEM_INLINE void FUN_DIA_setRL_V (Dem_EventIdType EventId, Dem_boolean_least robustnessLevel_b, uint32 robustnessInfo0, uint32 robustnessInfo1)
{
	DEM_UNUSED_PARAM(EventId);
	DEM_UNUSED_PARAM(robustnessLevel_b);
	DEM_UNUSED_PARAM(robustnessInfo0);
	DEM_UNUSED_PARAM(robustnessInfo1);
#if (DEM_CFG_EVTROBUSTNESS == DEM_CFG_EVTROBUSTNESS_ON)
    /* if robustnessLevel -> enter into unrobustMIDBuffer
     * if robustnessLevel != getRobustnessLevel -> adjust bit
     */
        FUN_DIA_setRL_IMPL_V(EventId, robustnessLevel_b, robustnessInfo0, robustnessInfo1);
#endif
}



#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 1     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 0     19.11.2013 BRM2COB
*   
* 
* AR40.6.0.0; 2     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.6.0.0; 1     24.06.2013 AMN2KOR
*   CSCRM00371160 - [DEM] Clear Allowed Callback
* 
* AR40.6.0.0; 0     24.06.2013 AMN2KOR
*   CSCRM00371160 - [DEM] Clear Allowed Callback
* 
* AR40.5.0.0; 0     30.11.2012 KAN1COB
*   See: check in comment ofCOMP: DEM40.5_2012-11;5
* 
* AR40.4.0.0; 0     05.07.2012 BRM2COB
*   Version updated to AR40.4.0.0
* 
* AR40.0.0.1; 1     27.06.2012 BRM2COB
*   GIT to eASEE 27-06
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
