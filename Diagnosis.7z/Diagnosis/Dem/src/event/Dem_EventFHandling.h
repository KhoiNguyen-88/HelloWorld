/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_EventFHandling$
* $Variant___:AR40.11.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_EVENTFHANDLING_H
#define DEM_EVENTFHANDLING_H


#include "Dem_Events.h"
#include "Dem_Types.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
void Dem_ReportErrorStatusDisableQueue (void);
void Dem_ReportErrorStatusEnableQueue (void);
void Dem_PreInitErrorQueue(void);

/**
 * @ingroup DEM_EXT_H
 *
 * Trigger function to set the history status upon events reporting as failed.
 */
void Dem_AllowHistoryStatus(void);

/**
 * @ingroup DEM_EXT_H
 *
 * Interface to get the HistoryStatus
 * @param [in] : EventId for which the HistoryStatus is needed
 * @param [out] : HistoryStatus for the specified event
 * @return E_OK: When the pointer argument is not a null pointer
 * @return E_NOT_OK: When the pointer argument is a null pointer
 */
Std_ReturnType Dem_GetHistoryStatus ( Dem_EventIdType EventId, boolean *historyStatus);



/*-- FAILURE HANDLING --------------------------------------------------------*/

/**
 * @ingroup DEM_EXT_H
 *
 * Set the status of an event and additionally allow to specify environmental
 * data, which may be stored to memory within snapshot data.
 *
 * @param [in] EventId the identifier of the calling event
 * @param [in] EventStatus status of the calling event
 * @param [in] debug0 free defineable debug data
 * @param [in] debug1 free defineable debug data
 *
 * @return  E_OK = Event Status set was successful \n
 *          E_NOT_OK = Event Status set was not successful
 *
 * @see  Dem_SetEventStatus
 */
Std_ReturnType Dem_SetEventStatusWithEnvData (Dem_EventIdType EventId,
                                              Dem_EventStatusType EventStatus,
                                              Dem_DebugDataType debug0,
                                              Dem_DebugDataType debug1);

#if (DEM_CFG_TESTMODE_SUPPORT == DEM_CFG_TESTMODE_SUPPORT_ON)
/**
 * @ingroup DEM_EXT_H
 *
 * Allows activation or de-activation of Test Mode Reporting.
 * If Test Mode reporting is active then Normal reporting will be disabled and vice versa.
 *
 * @param [in] TestModeStatus: Status to Enable (TRUE) or Disable (FALSE) Test Mode reporting
 *
 * @return  None
 */
void Dem_EnableTestMode (boolean TestModeStatus);

/**
 * @ingroup DEM_EXT_H
 *
 * Set the status of an event for Test Mode Reporting.
 * If the Test Mode is active then only the event is set otherwise no action is performed
 *
 * @param [in] EventId the identifier of the calling event
 * @param [in] EventStatus status of the calling event
 *
 * @return  E_OK = Event Status set was successful \n
 *          E_NOT_OK = Event Status set was not successful
 *
 * @see  Dem_EnableTestMode
 */
Std_ReturnType  Dem_SetEventStatus_TestMode (Dem_EventIdType EventId, Dem_EventStatusType EventStatus);

/**
 * @ingroup DEM_H
 *
 * Dem206: Reports errors to the DEM when Test Mode reporting is active.
 * The api is called by monitoring functions to set the status of BSW errors
 * @param[in]  EventId          Identification of Event by ID.
 * @param[in]  EventStatus      Status of event to be set.
 *
 * Corresponding DIA Functions: Dem_SetEventStatusWithEnvData_TestMode, FUN_DIA_setDL_V
 */
void Dem_ReportErrorStatus_TestMode (Dem_EventIdType EventId, Dem_EventStatusType EventStatus );

/**
 * @ingroup DEM_EXT_H
 *
 * Set the status of an event and additionally allow to specify environmental
 * data, which may be stored to memory within snapshot data when Test mode reporting is active.
 *
 * @param [in] EventId the identifier of the calling event
 * @param [in] EventStatus status of the calling event
 * @param [in] debug0 free defineable debug data
 * @param [in] debug1 free defineable debug data
 *
 * @return  E_OK = Event Status set was successful \n
 *          E_NOT_OK = Event Status set was not successful
 *
 * @see  Dem_SetEventStatus_TestMode, Dem_EnableTestMode
 */
Std_ReturnType Dem_SetEventStatusWithEnvData_TestMode (Dem_EventIdType EventId,
                                                       Dem_EventStatusType EventStatus,
                                                       Dem_DebugDataType debug0,
                                                       Dem_DebugDataType debug1);
/**
 * @ingroup DEM_EXT_H
 *
 * Set the status of BSW errors and additionally allow to specify environmental
 * data, which may be stored to memory within snapshot data when Test mode reporting is active.
 *
 * @param [in] EventId the identifier of the calling event
 * @param [in] EventStatus status of the calling event
 * @param [in] debug0 free defineable debug data
 * @param [in] debug1 free defineable debug data
 *
 * Corresponding DIA Functions: Dem_SetEventStatusWithEnvData_TestMode, FUN_DIA_setDL_V
 */
void Dem_ReportErrorStatusWithEnvData_TestMode (Dem_EventIdType EventId,
                                                Dem_EventStatusType EventStatus,
                                                Dem_DebugDataType debug0,
                                                Dem_DebugDataType debug1);
#endif


void Dem_EvtProcessPassedAndFailed (Dem_EventIdType EventId, Dem_EventStatusType EventStatus
                      DEM_DEBUGDATA_PARAM(Dem_DebugDataType debug0_ul, Dem_DebugDataType debug1_ul));

/**
 * @ingroup DEM_H
 *
 * Dem206: Reports errors to the DEM. The api is called by monitoring
 * functions to set the status of BSW errors
 * @param[in]  EventId          Identification of Event by ID.
 * @param[in]  EventStatus      Status of event to be set.
 *
 * Corresponding DIA Functions: Dem_SetEventStatusWithEnvData, FUN_DIA_setDL_V
 */
void Dem_ReportErrorStatus( Dem_EventIdType EventId, Dem_EventStatusType EventStatus );

/**
 * @ingroup DEM_EXT_H
 *
 * Set the status of BSW errors and additionally allow to specify environmental
 * data, which may be stored to memory within snapshot data.
 *
 * @param [in] EventId the identifier of the calling event
 * @param [in] EventStatus status of the calling event
 * @param [in] debug0 free defineable debug data
 * @param [in] debug1 free defineable debug data
 *
 * Corresponding DIA Functions: Dem_SetEventStatusWithEnvData, FUN_DIA_setDL_V
 */

void Dem_ReportErrorStatusWithEnvData( Dem_EventIdType EventId,Dem_EventStatusType EventStatus,Dem_DebugDataType debug0,Dem_DebugDataType debug1);


Dem_boolean_least Dem_EvtsRestoreFailurefromPreviousIC (Dem_EventIdType EventId);

/*-- EVENT SUPPRESION --------------------------------------------------------*/

/**
 * @ingroup DEM_EXT_H
 *
 * Set the available status of a specific Event.
 *
 * @param [in] EventId : Identification of an event by assigned EventId.
 * @param [in] AvailableStatus : This parameter specifies whether the respective Event shall be available (TRUE) or not (FALSE).
 *
 * @return  E_OK = Operation was successful. \n
 *          E_NOT_OK = Available status of the event could not be set.
 */
Std_ReturnType Dem_SetEventAvailable(Dem_EventIdType EventId, boolean AvailableStatus);

/**
 * @ingroup DEM_H
 *
 * Dem_01048: Set the suppression status of a specific Event. \n
 *
 * \b Note: \n
 * When OBD Support is enabled in Dem, then it is not possible to set the suppression status of an event that refers to
 * an emission relevant DTC.
 *
 * @param [in] EventId : Identification of an event by assigned EventId
 * @param [in] SuppressionStatus : This parameter specifies whether the respective Event shall be suppressed (TRUE) or not (FALSE).
 *
 * @return  E_OK = Operation was successful.\n
 *          E_NOT_OK = Suppression status of the event could not be set.
 */
Std_ReturnType Dem_SetEventSuppression(Dem_EventIdType EventId, boolean SuppressionStatus);




#if (DEM_CFG_SETEVENTSTATUSCALLNOTIFICATION == DEM_CFG_SETEVENTSTATUSCALLNOTIFICATION_ON)

void Dem_SetEventStatusCallNotification (Dem_EventIdType EventId, boolean fault, Dem_DebugDataType debug0, Dem_DebugDataType debug1);

#endif




/*-- SUSPICION HANDLING ------------------------------------------------------*/

#if(DEM_CFG_SUSPICIOUS_SUPPORT)
/**
 * @ingroup DEM_EXT_H
 *
 * This function is used by a monitoring to report the failure suspicion state.
 *
 * @param EventId specifies the identifier of the calling monitoring
 * @param suspicion specifies whether to set or reset a failure suspicion. TRUE=set suspicious, FALSE=reset suspicious
 */

void Dem_SetEventSuspicion (Dem_EventIdType EventId, boolean suspicion);
#endif

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 1     20.11.2015 BPE4COB
*   CSCRM01002972
* 
* AR40.11.0.0; 0     10.11.2015 VSA2COB
*   Checkout by vsa2cob
* 
* AR40.9.0.0; 0     15.10.2014 GJ83ABT
*   CSCRM00719089, CSCRM00650337, CSCRM00625552, CSCRM00434933
* 
* AR40.8.0.0; 4     21.04.2014 SAL2COB
*   CSCRM00594800
* 
* AR40.8.0.0; 3     18.03.2014 NAL2KOR
*   CSCRM00633565_EventSuppression
* 
* AR40.8.0.0; 2     12.03.2014 SAL2COB
*   CSCRM00594822_IntroduceHistoryStatus
* 
* AR40.8.0.0; 1     10.03.2014 VSA2COB
*   CSCRM00619537_ComassoChanges
* 
* AR40.8.0.0; 0     20.02.2014 OPI2KOR
*   CSCRM00554994
* 
* AR40.7.0.0; 3     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 2     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
