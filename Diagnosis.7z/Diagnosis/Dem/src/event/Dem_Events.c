/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_Events$
* $Variant___:AR40.11.0.1$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#include "Dem_Events.h"
#include "Dem_Types.h"
#include "Dem_Dependencies.h"
#include "Dem_EventRecheck.h"
#include "Dem_Deb.h"
#include "Dem_Cfg_ExtPrototypes.h"
#include "Dem_Cfg_EventsCallback.h"
#include "Dem_DTCs.h"
#include "Dem_EventStatus.h"
#include "Dem_NvM.h"
#include "Rte_Dem.h"
#include "Dem_Protected.h"


#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

uint16 Dem_GlobalInitMonitoringCounter;

#if(DEM_CFG_EVTDISABLESTATUSUPDATE == DEM_CFG_EVTDISABLESTATUSUPDATE_ON)
boolean Dem_EvtGlobalStatusUpdateState;
#endif

DEM_ARRAY_DEFINE(Dem_EvtState, Dem_AllEventsState, DEM_EVENTID_ARRAYLENGTH);
DEM_ARRAY_DEFINE(Dem_EvtState8, Dem_AllEventsState8, DEM_EVENTID_ARRAYLENGTH);
DEM_BITARRAY_DEFINE(Dem_AllEventsResetDebouncerRequested, DEM_EVENTID_ARRAYLENGTH);

uint32 Dem_EvtIsAnyInitMonitoringRequestedMask;

#if(DEM_CFG_ALLOW_HISTORY == DEM_CFG_ALLOW_HISTORY_ON)
static boolean Dem_EvtHistoryStatusChanged;
#if (DEM_CFG_TRIGGER_TO_STORE_NVM_SUPPORTED)
static boolean Dem_EvtHistoryStatusTriggerImmediateNVMStorage;
#endif
#endif

#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"


#define DEM_START_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

#if(DEM_CFG_ALLOW_HISTORY == DEM_CFG_ALLOW_HISTORY_ON)
DEM_BITARRAY_DEFINE(Dem_AllEventsHistoryStatus, DEM_EVENTID_ARRAYLENGTH);
#endif

#define DEM_STOP_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"


#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

#if (DEM_CFG_EVT_ATTRIBUTE == DEM_CFG_EVT_ATTRIBUTE_ON)
DEM_ARRAY_DEFINE_CONST(Dem_EventAttributeType, Dem_AllEventsUserAttributes, DEM_EVENTID_ARRAYLENGTH, DEM_CFG_EVTUSERATTRIBUTES);
#endif

#if (DEM_CFG_EVT_STATUS_CHANGE_NUM_CALLBACKS > 0)
DEM_ARRAY_DEFINE_CONST(Dem_EvtStatusChangeFncType, Dem_AllEventsStatusChangedFnc, DEM_CFG_EVT_STATUS_CHANGE_NUM_CALLBACKS, DEM_EVT_ST_CH_CALLBACK_FUNCTIONS);
#endif

/* MISRA RULE 19.8 VIOLATION: A function-like macro shall not be invoked without all of its arguments, hence some of the arguments are optional based on configuration */
DEM_ARRAY_DEFINE_CONST(Dem_EvtParamFlags, Dem_AllEventsParamFlags, DEM_EVENTID_ARRAYLENGTH, DEM_CFG_EVENTPARAMS_FLAGS);
DEM_ARRAY_DEFINE_CONST(Dem_EvtParam, Dem_AllEventsParam, DEM_EVENTID_ARRAYLENGTH, DEM_CFG_EVENTPARAMS);

#if(DEM_CFG_CALLBACK_INIT_MON_FOR_EVENT_SUPPORTED == TRUE)
DEM_ARRAY_DEFINE_CONST(Dem_InitMonitorForE, Dem_Cfg_Callback_InitMForE_List, DEM_CFG_CALLBACK_INITMFORE_LISTLENGTH, DEM_CFG_CALLBACK_INITMFORE_LIST);
#endif

#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"



#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

DEM_DTC_ST_CH_CALLBACK_FUNCTION
DEM_EVT_ST_CH_CONTAINERCALLBACKS

/*----------------------------------------------------------------------------*/


void Dem_EvtSetCausal(Dem_EventIdType EventId, Dem_boolean_least causal)
{
	Dem_NodeIdType nodeId = Dem_NodeIdFromEventId(EventId);

	DEM_ENTERLOCK_MON_BEFORE_INIT();

	Dem_EvtSetCausal_Flag(EventId, causal);
	if (Dem_NodeIdIsValid(nodeId))
	{
		Dem_NodeSetHasCausalFault(nodeId, causal);
	}

	DEM_EXITLOCK_MON_BEFORE_INIT();
}

Dem_boolean_least Dem_EvtIsRecoverable(Dem_EventIdType EventId)
{
    /* resetting failure is only allowed, if failure is recoverable or failure is sequential */
    return (
            (   Dem_EvtIsRecoverable_Flag(EventId)
                    && Dem_NodeRecoveryAllowed(Dem_NodeIdFromEventId(EventId))
            )
            || (!Dem_EvtIsCausal(EventId))
            || (Dem_EvtIsRecheckedAndWaitingForMonResult(EventId)) /* in case the fault is rechecked and still in evbuffer */
            || (!Dem_EvtSt_GetTestFailedTOC(EventId))
    );
}


boolean Dem_EvtClearEventAllowed ( Dem_EventIdType eventId )
{
  boolean ret_val = TRUE;
  DEM_UNUSED_PARAM(eventId);

#if ( DEM_CFG_EVT_CLEARALLOWEDCALLBACK != DEM_CFG_EVT_CLEARALLOWEDCALLBACK_OFF )
  if ( Dem_AllEventsParam[eventId].clrAllwdCBFnc != NULL_PTR )
  {
    (void) (Dem_AllEventsParam[eventId].clrAllwdCBFnc)(&ret_val);
  }
  else
#endif
  {
#if ( DEM_CFG_EVT_GLOBALCLEARALLOWEDCALLBACK != DEM_CFG_EVT_GLOBALCLEARALLOWEDCALLBACK_OFF )
    (void) DEM_CFG_EVT_GLOBALCLEARALLOWEDCALLBACKFNC (eventId, &ret_val);
#endif
  }
  return (ret_val);
}

/* INTERNAL_USE:  used for calculating DTC status */
Dem_boolean_least Dem_EvtIsConsidered4DTCStatus(Dem_EventIdType EventId)
{
	return (   Dem_NodeIsAvailable(Dem_NodeIdFromEventId(EventId))
	        && (!Dem_EvtIsSuppressed(EventId))
	       );
}
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
#if (DEM_CFG_BUILDTARGET == DEM_CFG_BUILDTARGET_DEMTESTSUITE)
#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"
extern boolean TESTSUITE_ALLOW_INITIALIZE_EVENT_SUPPRESSION;
#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"
#endif
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
void Dem_EvtPreInitEvents(void)
{
	Dem_EventIdIterator eventIt;
	Dem_EventIdType eventId;

	for (Dem_EventIdIteratorNew(&eventIt); Dem_EventIdIteratorIsValid(&eventIt); Dem_EventIdIteratorNext(&eventIt))
	{
		eventId = Dem_EventIdIteratorCurrent(&eventIt);
		Dem_EvtSetLastReportedEvent(eventId, DEM_EVENT_STATUS_INVALIDREPORT);
		Dem_EvtSt_HandleInitialization(eventId);

		/**
		 * Function to update "DemEventSuppression" configuration value as intial value for availability of an event
		 * and may be changed dynamically via API Dem_SetEventSuppression().
		 */
#if((DEM_CFG_SUPPRESSION == DEM_EVENT_SUPPRESSION) || (DEM_CFG_SUPPRESSION == DEM_EVENT_AND_DTC_SUPPRESSION))
#if (DEM_CFG_BUILDTARGET == DEM_CFG_BUILDTARGET_DEMTESTSUITE)
		if (TESTSUITE_ALLOW_INITIALIZE_EVENT_SUPPRESSION)
#endif
		{
			Dem_EvtSetSuppression(eventId, Dem_EvtGetInitialSuppressionStatus(eventId));
		}
#endif
	}
}

void Dem_EvtInitEvents(void)
{
#if((DEM_CFG_SUPPRESSION == DEM_EVENT_SUPPRESSION) || (DEM_CFG_SUPPRESSION == DEM_EVENT_AND_DTC_SUPPRESSION))
    Dem_EventIdType EventId;
    Dem_EventIdIterator eventIt;

    for (Dem_EventIdIteratorNew(&eventIt); Dem_EventIdIteratorIsValid(&eventIt); Dem_EventIdIteratorNext(&eventIt))
    {
        EventId = Dem_EventIdIteratorCurrent(&eventIt);
        if(Dem_EvtIsSuppressed(EventId))
        {
            Dem_EvtSt_HandleEvtNotAvailable(EventId);
        }
    }
#endif
}

/* According to prototype "Std_ReturnType InitBlockCallbackFunction(void)" from NVM, this callback shall be called by
 * NVM, if the Iso-statusbytes may not be read from EEPROM. => enter in NvMInitBlockCallback
 */
Std_ReturnType Dem_EvtResetIsoByteCallback(void)
{
	Dem_EventIdIterator eventIt;

	for (Dem_EventIdIteratorNew(&eventIt); Dem_EventIdIteratorIsValid(&eventIt); Dem_EventIdIteratorNext(&eventIt))
	{
        Dem_EvtSt_HandleInitialization(Dem_EventIdIteratorCurrent(&eventIt));
	}
	return E_OK;
}


boolean Dem_IsInitMonitorForEventRequested(Dem_EventIdType EventId, Dem_InitMonitorReasonType* InitMonitorReason)
{
	uint8_least initMonitoring = Dem_EvtIsInitMonitoringRequested(EventId);

	if (initMonitoring != 0u)
	{
		DEM_ENTERLOCK_MON();

		*InitMonitorReason = Dem_EvtIsInitMonitoringRequested(EventId); /* has to be querried again here inside the lock! */
		Dem_EvtClearInitMonitoringRequests(EventId);

		DEM_EXITLOCK_MON();
		return TRUE;
	}
	return FALSE;
}



Std_ReturnType  Dem_GetEventTested(Dem_EventIdType  EventId,
                                   boolean*         EventTested)
{
	if(Dem_EvtIsSuppressed(EventId))
	{
		return E_NOT_OK;
	}

	*EventTested = (boolean) Dem_EvtSt_GetTestCompleteTOC(EventId);
	return E_OK;
}



Std_ReturnType Dem_GetEventCategory( Dem_EventIdType EventId, Dem_EventCategoryType *EventCategory)
{
#if (DEM_CFG_EVTCATEGORY == DEM_CFG_EVTCATEGORY_ON)
	Dem_EventCategoryType evtCategory;

	if(!Dem_isEventIdValid(EventId))
	{
		return E_NOT_OK;
	}
	else
	{
		evtCategory = Dem_EvtGetCategory(EventId);

		if (( evtCategory <= DEM_CFG_CATEGORY_COUNT ) && ( evtCategory != DemConf_DemEventCategory_INVALIDCATEGORY ))
		{
			*EventCategory = evtCategory;
			return E_OK;
		}
		else
		{
			return E_NOT_OK;
		}
	}
#else
	(void) EventId;
	*EventCategory = 0;
	return E_NOT_OK;
#endif
}

/**********Event User Attribute **************************************************/
#if (DEM_CFG_EVT_ATTRIBUTE == DEM_CFG_EVT_ATTRIBUTE_ON)
const Dem_EventAttributeType* Dem_getEventUserAttributes(Dem_EventIdType EventId)
{
	return (&Dem_AllEventsUserAttributes[EventId]);
}
#endif


Std_ReturnType Dem_GetDtcKindOfEvent (Dem_EventIdType EventId, Dem_DTCKindType *DtcKind)
{
   if(!Dem_isEventIdValid(EventId))
   {
      return E_NOT_OK;
   }
   else
   {
      if (!Dem_isDtcIdValid(Dem_DtcIdFromEventId(EventId)))
      {
         return E_NOT_OK;
      }
      else
      {
         *DtcKind = Dem_DtcGetKind(Dem_DtcIdFromEventId(EventId));
         return E_OK;
      }
   }
}


void Dem_EvtSetSuppression (Dem_EventIdType EventId, Dem_boolean_least newSuppressed)
{
    DEM_ENTERLOCK_MON_BEFORE_INIT();

    if (Dem_EvtIsSuppressed(EventId) && !newSuppressed)
    {
        Dem_EvtSt_HandleEvtAvailable(EventId);
        Dem_EvtSetInitMonitoring(EventId, DEM_INIT_MONITOR_CLEAR);
    }
    if(!Dem_EvtIsSuppressed(EventId) && newSuppressed)
    {
        Dem_EvtSt_HandleEvtNotAvailable(EventId);
    }

    DEM_EVTSTATE_OVERWRITEBIT(&Dem_AllEventsState[EventId].state, DEM_EVT_BP_STATE_NOTAVAILABLE, newSuppressed);

    DEM_EXITLOCK_MON_BEFORE_INIT();
}

//*****************************************************************************
Std_ReturnType Dem_IsAnyInitMonitorForEventRequested ( uint16 *localCounter, boolean *modified )
{
    Std_ReturnType retVal = E_NOT_OK;

    if( (localCounter!=NULL_PTR) && (modified!=NULL_PTR) )
    {
        retVal = E_OK;

        if( *localCounter==Dem_GlobalInitMonitoringCounter )
        {
            *modified = FALSE;
        }
        else
        {
            *localCounter = Dem_GlobalInitMonitoringCounter;
            *modified = TRUE;
        }
    }

    return retVal;
}


#if(DEM_CFG_ALLOW_HISTORY == DEM_CFG_ALLOW_HISTORY_ON)
void Dem_EvtSetHistoryStatusChanged(boolean status)
{
    Dem_EvtHistoryStatusChanged = status;
}

boolean Dem_EvtGetHistoryStatusChanged(void)
{
    return Dem_EvtHistoryStatusChanged;
}

void Dem_EvtHistoryStatusMainFunction(void)
{
#if (DEM_CFG_TRIGGER_TO_STORE_NVM_SUPPORTED)
    Dem_NvmReturnType writeResult;
    if ( Dem_EvtHistoryStatusTriggerImmediateNVMStorage )
    {
        /* Only changed data needs to be saved to NvM*/
        if(Dem_EvtGetHistoryStatusChanged())
        {
            /* clear flags*/
            Dem_EvtHistoryStatusTriggerImmediateNVMStorage = FALSE;
            Dem_EvtSetHistoryStatusChanged(FALSE);

            /* indicate NVM to store the updated NVM block */
            writeResult = Dem_NvmWrite (DEM_NVM_ID_HISTORY_STATUS_BYTE, NULL_PTR);

            /* if NvM_Write was not successful, reset the flags */
            if (writeResult != DEM_NVM_TRANSACTIONACCEPTED)
            {
                Dem_EvtSetHistoryStatusChanged(TRUE);
                Dem_EvtHistoryStatusTriggerImmediateNVMStorage = TRUE;
            }
        }
        /* Nothing to save, clear flag*/
        else
        {
            Dem_EvtHistoryStatusTriggerImmediateNVMStorage = FALSE;
        }
    }
#endif // (DEM_CFG_TRIGGER_TO_STORE_NVM_SUPPORTED)
}

void Dem_EvtHistoryStatusShutdown(void)
{
    if (Dem_EvtGetHistoryStatusChanged())
    {
        (void)Dem_NvmSetChanged(DEM_NVM_ID_HISTORY_STATUS_BYTE, TRUE);
        Dem_EvtSetHistoryStatusChanged(FALSE);
    }
}

void Dem_EvtHistoryStatusTriggerStoreToNvM(void)
{
#if (DEM_CFG_TRIGGER_TO_STORE_NVM_SUPPORTED)
    Dem_EvtHistoryStatusTriggerImmediateNVMStorage = TRUE;
#endif
}
#endif // (DEM_CFG_ALLOW_HISTORY == DEM_CFG_ALLOW_HISTORY_ON)

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.1; 0     03.02.2016 CLH2SI
*   CSCRM01036799
* 
* AR40.11.0.0; 1     07.01.2016 TVE5COB
*   CSCRM01017790
* 
* AR40.11.0.0; 0     16.10.2015 VSA2COB
*   Checkout by vsa2cob
* 
* AR40.10.0.0; 6     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 5     09.07.2015 RPV5COB
*   CSCRM00791814
* 
* AR40.10.0.0; 4     01.07.2015 CLH2SI
*   CSCRM00649773
* 
* AR40.10.0.0; 3     17.06.2015 VSA2COB
*   CSCRM00880343
* 
* AR40.10.0.0; 2     17.06.2015 LIB8FE
*   CSCRM00764040
* 
* AR40.10.0.0; 1     16.04.2015 CLH2SI
*   CSCRM00764027
* 
* AR40.10.0.0; 0     26.01.2015 LIB8FE
*   CSCRM00737824
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
