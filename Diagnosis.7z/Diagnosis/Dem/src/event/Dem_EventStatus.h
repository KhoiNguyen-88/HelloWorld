/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_EventStatus$
* $Variant___:AR40.11.0.0$
* $Revision__:2$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_EVENTSTATUS_H
#define DEM_EVENTSTATUS_H

#include "Dem_ISO14229Byte.h"
#include "Dem_Array.h"
#include "Dem_Cfg_Events.h"
#include "Dem_Cfg_EventId.h"
#include "Dem_Cfg_OperationCycle.h"
#include "Dem_Cfg_EvMem.h"
#include "Dem_Cfg_Clear.h"
#include "Dem_Events.h"




#define DEM_START_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

DEM_ARRAY_DECLARE(      uint8, Dem_AllEventsStatusByte, DEM_EVENTID_ARRAYLENGTH);

#define DEM_STOP_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
DEM_ARRAY_DECLARE(      uint8, Dem_AllEventsStatusByteCust, DEM_EVENTID_ARRAYLENGTH);
#endif

#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"



#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

DEM_INLINE Dem_EventStatusExtendedType Dem_EvtGetIsoByte (Dem_EventIdType EventId)
{
    return Dem_AllEventsStatusByte[EventId];
}
#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
DEM_INLINE Dem_EventStatusExtendedType Dem_EvtGetCustIsoByte (Dem_EventIdType EventId)
{
    return Dem_AllEventsStatusByteCust[EventId];
}
#endif

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
#include "Dem_CustomStatusByte.h"
#endif


#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"



#define DEM_STATUSBYTE_EVENT_UNAVAILABLE                   (0x00)
#define DEM_STATUSBYTE_NEW_OPERATIONCYCLE_SETMASK          (DEM_ISO14229_BM_TESTNOTCOMPLETE_TOC)
#define DEM_STATUSBYTE_NEW_OPERATIONCYCLE_CLEARMASK        (DEM_ISO14229_BM_TESTFAILED_TOC)

#define DEM_INIT_ISOBITS_CLEARMASK									(DEM_ISO14229_BM_TESTFAILED)



void Dem_EventStatusInitCheckNvM(void);
void Dem_ClearEvent(Dem_EventIdType eventId);
void Dem_EvtAdvanceOperationCycle(Dem_OperationCycleList operationCycleList);


DEM_INLINE void Dem_InitEventStatusTestFailed(void)
{
#if (!DEM_CFG_EVMEM_STORAGE_TESTFAILED_SUPPORTED)
	Dem_EventIdIterator eventIt;
	Dem_EventIdType eventId;
	Dem_EventStatusExtendedType statusNew;

	for (Dem_EventIdIteratorNew(&eventIt); Dem_EventIdIteratorIsValid(&eventIt); Dem_EventIdIteratorNext(&eventIt))
	{
		eventId = Dem_EventIdIteratorCurrent(&eventIt);
		statusNew = Dem_EvtGetIsoByte(eventId);
		if (!Dem_EvtStoreTestFailedToNextOC(eventId))
		{
			statusNew &= (Dem_EventStatusExtendedType)(~DEM_INIT_ISOBITS_CLEARMASK);
		}
		Dem_AllEventsStatusByte[eventId] = statusNew;
#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
		Dem_AllEventsStatusByteCust[eventId] = statusNew;
#endif
	}
#endif
}

void Dem_EvtStatusTriggerStoreToNvm(void);


/**
* @ingroup DEM_EXT_H
*
* Overwrite the WIR (warning indicator) bit of an event's ISO14229 byte.
* @param[in]  EventId the event id where the status of the WIR bit shall be overwritten
* @param[in]  WIRStatus  the status that shall be written, TRUE==set, FALSE==reset
* @return  Std_ReturnType returns whether the function was executed or not
*/
Std_ReturnType Dem_OverwriteWIRStatus( Dem_EventIdType EventId, boolean WIRStatus );


void Dem_EvtMainFunction(void);
Dem_boolean_least Dem_EvtStatusByteIsNvmImmediateStoragePending (Dem_boolean_least *anyFailed);






DEM_INLINE Dem_EventStatusExtendedType Dem_EvtGetIsoByte4DtcCalculation (Dem_EventIdType EventId)
{
#if !DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    return Dem_AllEventsStatusByte[EventId];
#else
    return Dem_AllEventsStatusByteCust[EventId];
#endif
}


DEM_INLINE void Dem_EvtSt_HandleInitialization (Dem_EventIdType EventId)
{
    Dem_AllEventsStatusByte[EventId] = DEM_ISO14229BYTE_INITVALUE;
#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_EvtSt_CustomInitialization(EventId, &(Dem_AllEventsStatusByteCust[EventId]));
#endif
}


DEM_INLINE void Dem_EvtSt_HandleFailed(Dem_EventIdType EventId)
{
    Dem_ISO14229ByteSetTestFailed (&(Dem_AllEventsStatusByte[EventId]), TRUE);
    Dem_ISO14229ByteSetTestFailedTOC (&(Dem_AllEventsStatusByte[EventId]), TRUE);
    Dem_ISO14229ByteSetTestFailedSLC (&(Dem_AllEventsStatusByte[EventId]), TRUE);
    Dem_ISO14229ByteSetTestCompleteTOC (&(Dem_AllEventsStatusByte[EventId]), TRUE);
    Dem_ISO14229ByteSetTestCompleteSLC (&(Dem_AllEventsStatusByte[EventId]), TRUE);
    /* only valid with failurecycle=operationcycle
    Dem_ISO14229ByteSetPendingDTC (&(Dem_AllEventsStatusByte[EventId]), TRUE);
    */
#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_EvtSt_CustomFailed(EventId, &(Dem_AllEventsStatusByteCust[EventId]));
#endif
}

DEM_INLINE void Dem_EvtSt_HandlePassed(Dem_EventIdType EventId)
{
    Dem_ISO14229ByteSetTestFailed (&(Dem_AllEventsStatusByte[EventId]), FALSE);
    Dem_ISO14229ByteSetTestCompleteTOC (&(Dem_AllEventsStatusByte[EventId]), TRUE);
    Dem_ISO14229ByteSetTestCompleteSLC (&(Dem_AllEventsStatusByte[EventId]), TRUE);
#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_EvtSt_CustomPassed(EventId, &(Dem_AllEventsStatusByteCust[EventId]));
#endif
}

DEM_INLINE void Dem_EvtSt_HandleResetEventStatus(Dem_EventIdType EventId)
{
    Dem_ISO14229ByteSetTestFailed(&(Dem_AllEventsStatusByte[EventId]), FALSE);
#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_EvtSt_CustomResetEventStatus(EventId, &(Dem_AllEventsStatusByteCust[EventId]));
#endif
}

DEM_INLINE void Dem_EvtSt_HandleEvtAvailable(Dem_EventIdType EventId)
{
    Dem_ISO14229ByteSetTestCompleteTOC(&(Dem_AllEventsStatusByte[EventId]), FALSE);
#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_EvtSt_CustomEvtAvailable(EventId, &(Dem_AllEventsStatusByteCust[EventId]));
#endif
}

DEM_INLINE void Dem_EvtSt_HandleEvtNotAvailable(Dem_EventIdType EventId)
{
    Dem_AllEventsStatusByte[EventId] = DEM_STATUSBYTE_EVENT_UNAVAILABLE;
#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_EvtSt_CustomEvtNotAvailable(EventId, &(Dem_AllEventsStatusByteCust[EventId]));
#endif
}

DEM_INLINE void Dem_EvtSt_HandleClear(Dem_EventIdType EventId)
{
#if DEM_CFG_CLEARDTCCLEARSALLBITS
    Dem_AllEventsStatusByte[EventId] = DEM_ISO14229BYTE_INITVALUE;
#else
    Dem_ISO14229ByteSetTestCompleteTOC (&(Dem_AllEventsStatusByte[EventId]), FALSE);
    Dem_ISO14229ByteSetTestCompleteSLC (&(Dem_AllEventsStatusByte[EventId]), FALSE);
    Dem_ISO14229ByteSetTestFailedTOC (&(Dem_AllEventsStatusByte[EventId]), FALSE);
    Dem_ISO14229ByteSetTestFailedSLC (&(Dem_AllEventsStatusByte[EventId]), FALSE);
    Dem_ISO14229ByteSetPendingDTC(&(Dem_AllEventsStatusByte[EventId]), FALSE);
    Dem_ISO14229ByteSetConfirmedDTC(&(Dem_AllEventsStatusByte[EventId]), FALSE);
    if(!(Dem_ISO14229ByteIsTestFailed(Dem_AllEventsStatusByte[EventId])))
    {
        Dem_ISO14229ByteSetWarningIndicatorRequested(&(Dem_AllEventsStatusByte[EventId]), FALSE);
    }


#endif

#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_EvtSt_CustomClear(EventId, &(Dem_AllEventsStatusByteCust[EventId]));
#endif
}

DEM_INLINE void Dem_EvtSt_HandleNewOperationCycle(Dem_EventIdType EventId)
{
    if(!Dem_EvtIsSuppressed(EventId))
    {
        /* only valid with failurecycle=operationcycle
    if (Dem_ISO14229ByteIsTestCompleteTOC(Dem_AllEventsStatusByte[EventId]) && !Dem_ISO14229ByteIsTestFailedTOC(Dem_AllEventsStatusByte[EventId]))
    {
        Dem_ISO14229ByteSetPendingDTC(&(Dem_AllEventsStatusByte[EventId]), FALSE);
    }
         */
        Dem_AllEventsStatusByte[EventId] &= (Dem_EventStatusExtendedType)(~DEM_STATUSBYTE_NEW_OPERATIONCYCLE_CLEARMASK);
        Dem_AllEventsStatusByte[EventId] |= DEM_STATUSBYTE_NEW_OPERATIONCYCLE_SETMASK;
#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
        Dem_EvtSt_CustomNewOperationCycle(EventId, &(Dem_AllEventsStatusByteCust[EventId]));
#endif
    }
}

DEM_INLINE void Dem_EvtSt_HandleIndicatorOn(Dem_EventIdType EventId)
{
    Dem_ISO14229ByteSetWarningIndicatorRequested(&(Dem_AllEventsStatusByte[EventId]), TRUE);
#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_EvtSt_CustomIndicatorOn(EventId, &(Dem_AllEventsStatusByteCust[EventId]));
#endif
}

DEM_INLINE void Dem_EvtSt_HandleIndicatorOff(Dem_EventIdType EventId)
{
    Dem_ISO14229ByteSetWarningIndicatorRequested(&(Dem_AllEventsStatusByte[EventId]), FALSE);
#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_EvtSt_CustomIndicatorOff(EventId, &(Dem_AllEventsStatusByteCust[EventId]));
#endif
}

DEM_INLINE void Dem_EvtSt_HandleDTCSettingOn(Dem_EventIdType EventId)
{
#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_EvtSt_CustomDTCSettingOn(EventId, &(Dem_AllEventsStatusByteCust[EventId]));
#else
    DEM_UNUSED_PARAM(EventId);
#endif
}

DEM_INLINE void Dem_EvtSt_HandleConfirmation(Dem_EventIdType EventId)
{
    Dem_ISO14229ByteSetPendingDTC(&(Dem_AllEventsStatusByte[EventId]), TRUE);
    Dem_ISO14229ByteSetConfirmedDTC(&(Dem_AllEventsStatusByte[EventId]), TRUE);
#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_EvtSt_CustomConfirmation(EventId, &(Dem_AllEventsStatusByteCust[EventId]));
#endif
}

DEM_INLINE void Dem_EvtSt_HandleAging(Dem_EventIdType EventId)
{
    if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)
    {
        Dem_ISO14229ByteSetTestFailedSLC(&(Dem_AllEventsStatusByte[EventId]), FALSE);
    }
    Dem_ISO14229ByteSetConfirmedDTC(&(Dem_AllEventsStatusByte[EventId]), FALSE);

#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_EvtSt_CustomAging(EventId, &(Dem_AllEventsStatusByteCust[EventId]));
#endif
}

DEM_INLINE void Dem_EvtSt_HandleAgingOfConfirmed(Dem_EventIdType EventId)
{

    Dem_ISO14229ByteSetConfirmedDTC(&(Dem_AllEventsStatusByte[EventId]), FALSE);

#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_EvtSt_CustomAging(EventId, &(Dem_AllEventsStatusByteCust[EventId]));
#endif
}

#if (DEM_CFG_PRJSPECIFICEVENTSTATUSHANDLING == FALSE)
DEM_INLINE void Dem_EvtSt_HandleImmediateAging(Dem_EventIdType EventId)
{
    if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)
    {
        Dem_ISO14229ByteSetTestFailedSLC(&(Dem_AllEventsStatusByte[EventId]), FALSE);
    }
    Dem_ISO14229ByteSetConfirmedDTC(&(Dem_AllEventsStatusByte[EventId]), FALSE);
    Dem_ISO14229ByteSetPendingDTC(&(Dem_AllEventsStatusByte[EventId]), FALSE);
#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_EvtSt_CustomSetImmediateAging(EventId, &(Dem_AllEventsStatusByteCust[EventId]));
#endif
}
#else
#include "Dem_PrjEventStatus.h"
#endif

DEM_INLINE void Dem_EvtSt_HandleDisplacement(Dem_EventIdType EventId)
{
    if (DEM_CFG_EVMEM_RESET_CONFIRMED_BIT_ON_OVERFLOW)
    {
        if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)
        {
            Dem_ISO14229ByteSetTestFailedSLC(&(Dem_AllEventsStatusByte[EventId]), FALSE);
        }
        Dem_ISO14229ByteSetConfirmedDTC(&(Dem_AllEventsStatusByte[EventId]), FALSE);
    }
    Dem_ISO14229ByteSetPendingDTC(&(Dem_AllEventsStatusByte[EventId]), FALSE);

#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_EvtSt_CustomDisplacement(EventId, &(Dem_AllEventsStatusByteCust[EventId]));
#endif
}

DEM_INLINE void Dem_EvtSt_HandleEvCombinationReplacement(Dem_EventIdType EventId)
{
    /* this function is used for event combination "on storage" for the event of a dtc, which is replaced by another event of the same dtc */
    if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)
    {
        Dem_ISO14229ByteSetTestFailedSLC(&(Dem_AllEventsStatusByte[EventId]), FALSE);
    }
    Dem_ISO14229ByteSetConfirmedDTC(&(Dem_AllEventsStatusByte[EventId]), FALSE);

    Dem_ISO14229ByteSetPendingDTC(&(Dem_AllEventsStatusByte[EventId]), FALSE);

#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_EvtSt_CustomEvCombinationReplacement(EventId, &(Dem_AllEventsStatusByteCust[EventId]));
#endif
}


DEM_INLINE void Dem_EvtSt_HandlePendingDTC(Dem_EventIdType EventId, Dem_boolean_least setBit)
{
    Dem_ISO14229ByteSetPendingDTC(&(Dem_AllEventsStatusByte[EventId]), setBit);
#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_EvtSt_CustomSetPending(EventId, &(Dem_AllEventsStatusByteCust[EventId]), setBit);
#endif
}



/****** ATTENTION: May only be used by consistency checks; otherwise use the HandleXXX functions! ******/
DEM_INLINE Dem_boolean_least Dem_EvtSt_GetTestFailed(Dem_EventIdType EventId)
{
    return Dem_ISO14229ByteIsTestFailed(Dem_AllEventsStatusByte[EventId]);
}
DEM_INLINE Dem_boolean_least Dem_EvtSt_GetTestFailedTOC(Dem_EventIdType EventId)
{
    return Dem_ISO14229ByteIsTestFailedTOC(Dem_AllEventsStatusByte[EventId]);
}
DEM_INLINE Dem_boolean_least Dem_EvtSt_GetTestCompleteTOC (Dem_EventIdType EventId)
{
    return Dem_ISO14229ByteIsTestCompleteTOC(Dem_AllEventsStatusByte[EventId]);
}

/* This function is used in Project Specific Implementation of Indicator, so this function should not be removed. */
DEM_INLINE Dem_boolean_least Dem_EvtSt_GetWIR (Dem_EventIdType EventId)
{
    return Dem_ISO14229ByteIsWarningIndicatorRequested(Dem_AllEventsStatusByte[EventId]);
}


DEM_INLINE void Dem_EvtSt_SetTestFailedSLC(Dem_EventIdType EventId, Dem_boolean_least setBit)
{
    Dem_ISO14229ByteSetTestFailedSLC(&(Dem_AllEventsStatusByte[EventId]), setBit);
#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_ISO14229ByteSetTestFailedSLC(&(Dem_AllEventsStatusByteCust[EventId]), setBit);
#endif
}
DEM_INLINE void Dem_EvtSt_SetTestCompleteSLC (Dem_EventIdType EventId, Dem_boolean_least setBit)
{
    Dem_ISO14229ByteSetTestCompleteSLC(&(Dem_AllEventsStatusByte[EventId]), setBit);
#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_ISO14229ByteSetTestCompleteSLC(&(Dem_AllEventsStatusByteCust[EventId]), setBit);
#endif
}
DEM_INLINE void Dem_EvtSt_SetConfirmedDTC(Dem_EventIdType EventId, Dem_boolean_least setBit)
{
    Dem_ISO14229ByteSetConfirmedDTC(&(Dem_AllEventsStatusByte[EventId]), setBit);
#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_ISO14229ByteSetConfirmedDTC(&(Dem_AllEventsStatusByteCust[EventId]), setBit);
#endif
}
DEM_INLINE void Dem_EvtSt_SetPendingDTC(Dem_EventIdType EventId, Dem_boolean_least setBit)
{
    Dem_ISO14229ByteSetPendingDTC(&(Dem_AllEventsStatusByte[EventId]), setBit);
#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    Dem_ISO14229ByteSetPendingDTC(&(Dem_AllEventsStatusByteCust[EventId]), setBit);
#endif
}


/*-- TestFailedSinceLastClear ----------------------------------------------------*/
#if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)
DEM_INLINE void Dem_EvtOverwriteTestFailedSinceLastClear(Dem_EventIdType EventId, Dem_EventStatusExtendedType newTestFailedSinceLastClearMask)
{
    Dem_EventStatusExtendedType tmpStatus = Dem_EvtGetIsoByte(EventId) & (~DEM_ISO14229BYTE_MASK_TESTFAILEDSINCELASTCLEAR);
    tmpStatus |= (newTestFailedSinceLastClearMask & DEM_ISO14229BYTE_MASK_TESTFAILEDSINCELASTCLEAR);
    Dem_AllEventsStatusByte[EventId] = tmpStatus;
}
#endif


/******************************************************************************************************/



#if 0

DEM_INLINE void Dem_EvtSetIsoByte (Dem_EventIdType EventId, Dem_EventStatusExtendedType status)
{
    Dem_AllEventsStatusByte[EventId] = status;
}



/*-- TESTFAILED SLC / TOC ----------------------------------------------------*/

DEM_INLINE void Dem_EvtSetTestFailed(Dem_EventIdType EventId, Dem_boolean_least newState)
{
    Dem_ISO14229ByteSetTestFailed(&(Dem_AllEventsStatusByte[EventId]), newState);
}

DEM_INLINE void Dem_EvtSetConfirmedDTC(Dem_EventIdType EventId, Dem_boolean_least newState)
{
    Dem_ISO14229ByteSetConfirmedDTC(&(Dem_AllEventsStatusByte[EventId]), newState);
}

DEM_INLINE void Dem_EvtSetTestFailedTOC(Dem_EventIdType EventId, Dem_boolean_least newState)
{
    Dem_ISO14229ByteSetTestFailedTOC(&(Dem_AllEventsStatusByte[EventId]), newState);
}

DEM_INLINE Dem_boolean_least Dem_EvtGetTestFailed(Dem_EventIdType EventId)
{
    return Dem_ISO14229ByteIsTestFailed(Dem_AllEventsStatusByte[EventId]);
}



DEM_INLINE Dem_boolean_least Dem_EvtGetTestFailedSLC(Dem_EventIdType EventId)
{
    return Dem_ISO14229ByteIsTestFailedSLC(Dem_AllEventsStatusByte[EventId]);
}



/*-- PENDING & CONFIRMED ----------------------------------------------------*/

DEM_INLINE void Dem_EvtOverwritePendingAndConfirmed(Dem_EventIdType EventId, Dem_EventStatusExtendedType newPendingConfirmedMask)
{
    Dem_EventStatusExtendedType tmpStatus = Dem_EvtGetIsoByte(EventId) & (~DEM_ISO14229BYTE_MASK_PENDING_CONFIRMED);
    tmpStatus |= (newPendingConfirmedMask & DEM_ISO14229BYTE_MASK_PENDING_CONFIRMED);
    Dem_EvtSetIsoByte(EventId, tmpStatus);
}


/*-- WIR ----------------------------------------------------*/
DEM_INLINE void Dem_EvtSetWIR(Dem_EventIdType EventId, Dem_boolean_least newState)
{
    Dem_ISO14229ByteSetWarningIndicatorRequested(&(Dem_AllEventsStatusByte[EventId]), newState);
}



/*-- TC* + TF* + WIR ----------------------------------------------------*/

DEM_INLINE void Dem_EvtOverwriteFailedCompleteAndWIR(Dem_EventIdType EventId, Dem_EventStatusExtendedType newTfTcWir)
{
    Dem_EventStatusExtendedType tmpStatus = Dem_EvtGetIsoByte(EventId) & (~DEM_ISO14229BYTE_MASK_FAILED_COMPLETE_WIR);
    tmpStatus |= (newTfTcWir & DEM_ISO14229BYTE_MASK_FAILED_COMPLETE_WIR);
    Dem_EvtSetIsoByte(EventId, tmpStatus);
}




/*-- TESTCOMPLETE ------------------------------------------------------------*/



DEM_INLINE void Dem_EvtSetTestCompleteTOC (Dem_EventIdType EventId, Dem_boolean_least setBit)
{
    Dem_ISO14229ByteSetTestCompleteTOC(&(Dem_AllEventsStatusByte[EventId]), setBit);
}


DEM_INLINE Dem_boolean_least Dem_EvtIsTestCompleteSLC (Dem_EventIdType EventId)
{
    return Dem_ISO14229ByteIsTestCompleteSLC(Dem_AllEventsStatusByte[EventId]);
}


#endif

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 2     11.01.2016 NAL2KOR
*   CSCRM01015983
* 
* AR40.11.0.0; 1     21.12.2015 NAL2KOR
*   CSCRM00957431
* 
* AR40.11.0.0; 0     19.10.2015 TVE5COB
*   CSCRM00957961
* 
* AR40.10.0.0; 8     10.07.2015 CLH2SI
*   CSCRM00938605
* 
* AR40.10.0.0; 7     09.07.2015 RPV5COB
*   CSCRM00791814
* 
* AR40.10.0.0; 6     09.07.2015 TVE5COB
*   CSCRM00825250
* 
* AR40.10.0.0; 5     06.07.2015 VSA2COB
*   CSCRM00830308
* 
* AR40.10.0.0; 4     17.06.2015 TVE5COB
*   CSCRM00783642
* 
* AR40.10.0.0; 3     17.06.2015 LIB8FE
*   CSCRM00764040
* 
* AR40.10.0.0; 2     20.04.2015 VSA2COB
*   CSCRM00790403
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
