/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_Prv_CallEvtStChngdCbk$
* $Variant___:AR40.11.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_PRV_CALLEVTSTCHNGDCBK_H
#define DEM_PRV_CALLEVTSTCHNGDCBK_H

#if(DEM_CFG_TRIGGERFIMREPORTS == DEM_CFG_TRIGGERFIMREPORTS_ON)
#include "FiM.h"
#endif
#if (DEM_CFG_TRIGGERDLTREPORTS == DEM_CFG_TRIGGERDLTREPORTS_ON)
#include "Dlt.h"
#endif
#include "Dem_DTCs.h"
#include "Dem_Cfg_EventsCallback.h"
#include "Dem_EventStatus.h"


DEM_INLINE void Dem_CallBackTriggerOnEventStatus (
		Dem_EventIdType EventId,
		Dem_EventStatusExtendedType EventStatusOld,
		Dem_EventStatusExtendedType EventStatusNew,
		Dem_EventStatusExtendedType dtcStByteOld
)
{
#if ( DEM_CFG_DTC_STATUSCHANGEDCALLBACK == DEM_CFG_DTC_STATUSCHANGEDCALLBACK_ON )
    Dem_DtcIdType dtcId;
    Dem_EventStatusExtendedType dtcStByteNew;
    Dem_DtcCodeType dtcCode;
#endif

    DEM_UNUSED_PARAM(dtcStByteOld);
    DEM_UNUSED_PARAM(EventId);
    DEM_UNUSED_PARAM(EventStatusOld);
    DEM_UNUSED_PARAM(EventStatusNew);

#if (DEM_CFG_EVT_STATUS_CHANGE_NUM_CALLBACKS > 0)
    Dem_CallEventStatusChangedCallBack(EventId, EventStatusOld, EventStatusNew);
#endif
#if ( DEM_CFG_TRIGGERDLTREPORTS == DEM_CFG_TRIGGERDLTREPORTS_ON )
    Dlt_DemTriggerOnEventStatus(EventId, EventStatusOld, EventStatusNew);
#endif
#if ( DEM_CFG_DTC_STATUSCHANGEDCALLBACK == DEM_CFG_DTC_STATUSCHANGEDCALLBACK_ON )
    if ( Dem_EventIdIsDtcAssigned(EventId) )
    {
        dtcId = Dem_DtcIdFromEventId(EventId);
        if ( Dem_DtcIsSupported(dtcId) )
        {
            dtcStByteNew = (uint8)(Dem_DtcStatusByteRetrieve (dtcId) & DEM_CFG_DTCSTATUS_AVAILABILITYMASK);
            if (dtcStByteNew != dtcStByteOld)
            {
                dtcCode = Dem_DtcGetCode(dtcId);
                Dem_CallbackDTCStatusChangedIndication( dtcCode, dtcStByteOld, dtcStByteNew);
            }
        }
    }
#endif
}

DEM_INLINE void Dem_StatusChange_GetOldStatus (
		Dem_EventIdType EventId,
		Dem_EventStatusExtendedType *isoByteOld,
		Dem_EventStatusExtendedType *dtcStByteOld
)
{
#if ( DEM_CFG_DTC_STATUSCHANGEDCALLBACK == DEM_CFG_DTC_STATUSCHANGEDCALLBACK_ON )
	Dem_DtcIdType dtcId;
#endif
	*(isoByteOld) = Dem_EvtGetIsoByte(EventId);
#if ( DEM_CFG_DTC_STATUSCHANGEDCALLBACK == DEM_CFG_DTC_STATUSCHANGEDCALLBACK_ON )
	if ( Dem_EventIdIsDtcAssigned(EventId) )
	{
		dtcId = Dem_DtcIdFromEventId(EventId);
		if ( Dem_DtcIsSupported(dtcId) )
		{
			*(dtcStByteOld) = (uint8)(Dem_DtcStatusByteRetrieve (dtcId) & DEM_CFG_DTCSTATUS_AVAILABILITYMASK);
		}
	}
#else
	*dtcStByteOld = 0;
	(void) dtcStByteOld;
#endif
}

DEM_INLINE void Dem_TriggerOn_EventStatusChange (
        Dem_EventIdType EventId,
        Dem_EventStatusExtendedType isoByteOld,
        Dem_EventStatusExtendedType isoByteNew,
        Dem_EventStatusExtendedType dtcStByteOld
)
{
    if ( isoByteNew != isoByteOld )
    {
#if (DEM_CFG_TRIGGERFIMREPORTS == DEM_CFG_TRIGGERFIMREPORTS_ON)
        FiM_DemTriggerOnEventStatus (EventId, isoByteOld, isoByteNew);
#endif
        Dem_CallBackTriggerOnEventStatus(EventId,isoByteOld,isoByteNew,dtcStByteOld);
    }

}
#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 1     21.10.2015 CLH2SI
*   CSCRM01002661
* 
* AR40.11.0.0; 0     19.10.2015 BPE4COB
*   CSCRM00973009
* 
* AR40.10.0.0; 1     17.06.2015 VSA2COB
*   CSCRM00880343
* 
* AR40.10.0.0; 0     18.05.2015 TVE5COB
*   CSCRM00588798
* 
* AR40.9.0.0; 0     22.08.2014 CLH2SI
*   CSCRM00688436
* 
* AR40.8.0.0; 2     16.07.2014 BRM2COB
*   CSCRM00688243
* 
* AR40.8.0.0; 1     20.03.2014 CLH2SI
*   CSCRM00633913
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 3     19.11.2013 BRM2COB
*   
* 
* AR40.7.0.0; 2     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
