/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_EnableCondition$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#include "Dem_EnableCondition.h"
#include "Dem_Lock.h"
#include "Dem_Types.h"
#include "Rte_Dem.h"
#include "Dem_Protected.h"

#define DEM_START_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"

#if (DEM_CFG_ENABLECONDITION == DEM_CFG_ENABLECONDITION_ON)
Dem_EnCoState Dem_EnCoAllStates = { DEM_CFG_ENCO_INITIALSTATE };
#endif

#define DEM_STOP_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
Std_ReturnType Dem_SetEnableCondition (uint8 EnableConditionID,
                                       boolean ConditionFulfilled)
{
#if (DEM_CFG_ENABLECONDITION == DEM_CFG_ENABLECONDITION_ON)

   Dem_EnCoList enableConditionBitmask = (Dem_EnCoList)(1u << EnableConditionID);

	if (EnableConditionID >=  DEM_ENABLECONDITION_COUNT)
	{
		DEM_DET(DEM_DET_APIID_SETENABLECONDITION, DEM_E_PARAM_CONFIG);
		return E_NOT_OK;
	}

   DEM_ENTERLOCK_MON_BEFORE_INIT();

   if (ConditionFulfilled)
   {
      Dem_EnCoAllStates.isActive |= enableConditionBitmask;
   }
   else
   {
      Dem_EnCoAllStates.isActive &= (Dem_EnCoList)(~enableConditionBitmask);
   }

   DEM_EXITLOCK_MON_BEFORE_INIT();

   return E_OK;

#else
   DEM_UNUSED_PARAM(EnableConditionID);
   DEM_UNUSED_PARAM(ConditionFulfilled);
   return E_NOT_OK;
#endif
}
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     07.01.2016 TVE5COB
*   CSCRM01017790
* 
* AR40.10.0.0; 1     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 0     10.07.2015 CLH2SI
*   CSCRM00938605
* 
* AR40.9.0.0; 1     06.01.2015 GJ83ABT
*   CSCRM00751490
* 
* AR40.9.0.0; 0     06.01.2015 TVE5COB
*   CSCRM00741126
* 
* AR40.8.0.0; 3     18.07.2014 GJ83ABT
*   CSCRM00697002
* 
* AR40.8.0.0; 2     16.07.2014 BRM2COB
*   CSCRM00688243
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 3     21.11.2013 AMN2KOR
*   CSCRM00591723
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
