/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_EnableCondition$
* $Variant___:AR40.10.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_ENABLECONDITION_H
#define DEM_ENABLECONDITION_H


#include "Dem_Types.h"
#include "Dem_Cfg_EnableCondition.h"


#if (DEM_CFG_ENABLECONDITION == DEM_CFG_ENABLECONDITION_ON)

typedef struct {
   Dem_EnCoList isActive;
} Dem_EnCoState;

#define DEM_START_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"
extern Dem_EnCoState Dem_EnCoAllStates;
#define DEM_STOP_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"

#endif

/* Dem449: If one enable condition is not fulfilled, all status reports from SW-Cs
   (Dem_SetEventStatus and Dem_ResetEventStatus) and BSW modules (Dem_ReportErrorStatus)
   for those events being assigned to this condition shall be ignored (no change of
   UDS DTC status byte) by the DEM.
 */

DEM_INLINE Dem_boolean_least Dem_EnCoAreAllFulfilled (Dem_EnCoList enableConditionList)
{
#if (DEM_CFG_ENABLECONDITION == DEM_CFG_ENABLECONDITION_ON)
   return ((enableConditionList & Dem_EnCoAllStates.isActive) == enableConditionList);
#else
   DEM_UNUSED_PARAM(enableConditionList);
   return TRUE;
#endif
}
#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 0     10.07.2015 CLH2SI
*   CSCRM00938605
* 
* AR40.8.0.0; 2     18.07.2014 GJ83ABT
*   CSCRM00697002
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 2     19.11.2013 BRM2COB
*   
* 
* AR40.7.0.0; 1     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 0     22.10.2013 AMN2KOR
*   CSCRM00547887
* 
* AR40.6.0.0; 0     21.05.2013 AMN2KOR
*   Updated for CSCRM00524612 - [Int-Dem] Introduce check for Redundant 
*   declarations
* 
* AR40.4.0.0; 1     27.06.2012 BRM2COB
*   GIT to eASEE 27-06
* 
* AR40.4.0.0; 0     14.02.2012 CLH2SI
*   GIT-SYNC: a0008d733d3a94fa3e0a3e39260972344e821bef
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
