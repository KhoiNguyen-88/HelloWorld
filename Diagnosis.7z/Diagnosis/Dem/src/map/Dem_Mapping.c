/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_Mapping$
* $Variant___:AR40.10.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#include "Dem_Cfg_EventId.h"
#include "Dem_Cfg_NodeId.h"
#include "Dem_Cfg_DtcId.h"
#include "Dem_Mapping.h"
#include "Dem_Array.h"



/*** EVENTID *****************************************************************/



/*** DTCID *******************************************************************/
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
DEM_MAP_EVENTID_DTCID
DEM_MAP_DTCID_EVENTID

/*** NODEID ******************************************************************/

#if (DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON)

DEM_MAP_EVENTID_NODEID
DEM_MAP_NODEID_EVENTID
DEM_MAP_NODEID_CHILDNODEID
DEM_CFG_NODETOCHILDNODEINDEX
#endif
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
const Dem_DtcGroupIdMapToDtcIdType Dem_DtcGroupIdMapToDtcId[DEM_DTCGROUPID_ARRAYLENGTH] = DEM_MAP_DTCGROUPID_DTCID;
#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 0     06.07.2015 VSA2COB
*   CSCRM00830308
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     10.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 2     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 1     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 0     22.10.2013 AMN2KOR
*   CSCRM00547887
* 
* AR40.6.0.0; 1     18.04.2013 BRM2COB
*   CSCRM00503658 : Restructure DtcGroup storage
* 
* AR40.6.0.0; 0     18.02.2013 BRM2COB
*   CSCRM00489922, CSCRM00484184, CSCRM00496074
*   CSCRM00487984, CSCRM00488028, CSCRM00489927
*   CSCRM00492148, CSCRM00496694, CSCRM00492144
*   CSCRM00432122, CSCRM00493702, CSCRM00484179
*   CSCRM00489947, Fix QAC-Warnings, 
*   corrected comment as per Review Review13_079_COMP__Dem___AR40_5_0_0__5.xls
* 
* AR40.5.0.0; 0     30.11.2012 KAN1COB
*   See: check in comment ofCOMP: DEM40.5_2012-11;5
* 
* AR40.4.0.0; 0     05.07.2012 BRM2COB
*   Version updated to AR40.4.0.0
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
