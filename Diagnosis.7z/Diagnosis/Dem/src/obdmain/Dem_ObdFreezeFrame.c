/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:C$
 * $Name______:Dem_ObdFreezeFrame$
 * $Variant___:AR40.10.0.0$
 * $Revision__:1$
 **********************************************************************************************************************
</BASDKey>*/

#include "Dem_Main.h"
#include "Dem_ObdFreezeFrame.h"
#include "Dem_ObdEvMem.h"
#include "Dem_ObdDTCs.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)

#define DEM_OBDFF_PRIO_OFFSET    255

DEM_INLINE uint8* Dem_ObdFFGetPIDDataPtr(uint16_least FFLocId)
{
    return (Dem_EvMemGetEventMemData(FFLocId)
            + Dem_EnvEDGetRawByteSize(Dem_Cfg_EnvEventId2EnvData[Dem_EvMemGetEventMemEventId(FFLocId)].extDataId)
            + (Dem_EvtGetMaxNumberOfFreezeFrames(Dem_EvMemGetEventMemEventId(FFLocId))
                    * Dem_EnvFFGetRawByteSize(Dem_Cfg_EnvEventId2EnvData[Dem_EvMemGetEventMemEventId(FFLocId)].freezeFrameId)));
}


uint16_least Dem_ObdFFGetFFLocation (void)
{
    uint16_least LocId;
    uint16_least FFLocId = DEM_EVMEM_INVALID_LOCID;
    uint16_least MemId = DEM_CFG_EVMEM_MEMID_PRIMARY;
    uint16 Prio = 0;
    uint16 MaxPrio = 0xFFFF;
    uint32 TimeId = DEM_OBD_EVMEM_MAX_FF_TIMEID;
    uint32 MinTimeId = DEM_OBD_EVMEM_MAX_FF_TIMEID;

    for    (Dem_EvMemEventMemoryLocIteratorNew    (&LocId, MemId);
            Dem_EvMemEventMemoryLocIteratorIsValid(&LocId, MemId);
            Dem_EvMemEventMemoryLocIteratorNext   (&LocId, MemId))
    {
        if (       (Dem_EvMemIsStored(Dem_EvMemGetEventMemStatus(LocId)))
                && (Dem_ObdDtcIsEmissionRelated(Dem_DtcIdFromEventId(Dem_EvMemGetEventMemEventId(LocId))))
                && (((Dem_EvMemGetEventMemStatus(LocId) & DEM_EVMEM_STSMASK_CONFIRMED) == DEM_EVMEM_STSMASK_CONFIRMED)
#if (DEM_CFG_OBD_FREEZEFRAME_VISIBILITY == DEM_CFG_OBD_FREEZEFRAME_VISIBILITY_PENDING_AND_CONFIRMED)
                        || ((Dem_EvMemGetEventMemStatus(LocId) & DEM_EVMEM_STSMASK_PENDING) == DEM_EVMEM_STSMASK_PENDING)
#endif
                )
        )
        {
            Prio = ((uint16)(Dem_EvtGetEventPriority(Dem_EvMemGetEventMemEventId(LocId))) << 8);

#if (DEM_CFG_OBD_FREEZEFRAME_VISIBILITY == DEM_CFG_OBD_FREEZEFRAME_VISIBILITY_PENDING_AND_CONFIRMED)
            if ( ((Dem_EvMemGetEventMemStatus(LocId) & DEM_EVMEM_STSMASK_CONFIRMED) != DEM_EVMEM_STSMASK_CONFIRMED)
              && ((Dem_EvMemGetEventMemStatus(LocId) & DEM_EVMEM_STSMASK_PENDING) == DEM_EVMEM_STSMASK_PENDING)
              )
            {
                Prio = (Prio | DEM_OBDFF_PRIO_OFFSET);
            }
#endif

            TimeId = Dem_ObdEvMemGetEventMemFFTimeId(LocId);

            if (Prio < MaxPrio)
            {
                /* choose location with high prio freeze frame */
                MaxPrio = Prio;
                MinTimeId = TimeId;
                FFLocId = LocId;
            }
            else if (Prio == MaxPrio)
            {
                if (TimeId <= MinTimeId)
                {
                    /* same priority: chose older confirmed entry */
                    MaxPrio = Prio;
                    MinTimeId = TimeId;
                    FFLocId = LocId;
                }
            }
            else
            {
                /* ignore entry if prio is lower */
            }
        }
    }
    return FFLocId;
}
#endif


/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is defined by AUTOSAR */
Std_ReturnType Dem_ReadDataOfOBDFreezeFrame (uint8 PID, uint8 DataElementIndexOfPID, uint8* DestBuffer, uint8* BufSize)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    Std_ReturnType retVal = E_NOT_OK;
    uint16_least FFLocId = DEM_EVMEM_INVALID_LOCID;
    uint8* pidDataPtr;
    uint8 pidIt, pidDataIt, pidDataIndex, pidDataSize;

    FFLocId = Dem_ObdFFGetFFLocation();

    if (!Dem_EvMemIsEventMemLocIdValid(FFLocId))
    {
        /* no confirmed DTC found */
        *BufSize = 0;
        retVal = E_OK;
    }
    else
    {
        pidDataPtr = Dem_ObdFFGetPIDDataPtr(FFLocId);

        for (pidIt = 1; pidIt < DEM_CFG_OBD_PID_ARRAY_LENGTH; pidIt++)
        {
            if (Dem_Cfg_ObdPid[pidIt].identifier == PID)
            {
                pidDataIndex = Dem_Cfg_ObdPid[pidIt - 1].dataElementIndex;

                for (pidDataIt = Dem_Cfg_ObdPid[pidIt - 1].dataElementIndex; pidDataIt < Dem_Cfg_ObdPid[pidIt].dataElementIndex; pidDataIt++)
                {
                    pidDataSize = Dem_Cfg_EnvDataElement[Dem_Cfg_ObdPid2DataElement[pidDataIt]].Size;

                    if ((pidDataIt - pidDataIndex) == DataElementIndexOfPID)
                    {
                        if (*BufSize >= pidDataSize)
                        {
                            *BufSize = pidDataSize;
                            DEM_MEMCPY(DestBuffer, pidDataPtr, pidDataSize);
                            retVal = E_OK;
                        }
                        break;
                    }
                    else
                    {
                        pidDataPtr = pidDataPtr + pidDataSize;
                    }
                }
                break;
            }
            else
            {
                for (pidDataIt = Dem_Cfg_ObdPid[pidIt - 1].dataElementIndex; pidDataIt < Dem_Cfg_ObdPid[pidIt].dataElementIndex; pidDataIt++)
                {
                    pidDataPtr = pidDataPtr + Dem_Cfg_EnvDataElement[Dem_Cfg_ObdPid2DataElement[pidDataIt]].Size;
                }
            }
        }
    }
    return retVal;
#else
    DEM_UNUSED_PARAM(PID);
    DEM_UNUSED_PARAM(DataElementIndexOfPID);
    DEM_UNUSED_PARAM(DestBuffer);
    DEM_UNUSED_PARAM(BufSize);
    return E_NOT_OK;
#endif
}


/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is defined by AUTOSAR */
Dem_ReturnGetFreezeFrameDataByRecordType Dem_GetFreezeFrameDataByRecord( uint8 RecordNumber, Dem_DTCOriginType DTCOrigin, uint32* DTC, uint8* DestBuffer, uint16* BufSize )
{

#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    uint16_least FFLocId;
    uint16 BufLength;
    uint8* pidDataPtr;
    uint8 pidIt, pidDataIt, pidDataSize;

    if (!Dem_OpMoIsInitialized())
    {
        DEM_DET(DEM_DET_APIID_GETFREEZEFRAMEDATABYRECORD, DEM_E_UNINIT);
        return DEM_GET_FFBYRECORD_NO_DTC_FOR_RECORD;
    }

    if (RecordNumber != 0)
    {
        DEM_DET(DEM_DET_APIID_GETFREEZEFRAMEDATABYRECORD, DEM_E_PARAM_CONFIG);
        return DEM_GET_FFBYRECORD_WRONG_RECORD;
    }

    if (DTCOrigin != DEM_DTC_ORIGIN_PRIMARY_MEMORY)
    {
        DEM_DET(DEM_DET_APIID_GETFREEZEFRAMEDATABYRECORD, DEM_E_PARAM_CONFIG);
        return DEM_GET_FFBYRECORD_NO_DTC_FOR_RECORD;
    }

    FFLocId = Dem_ObdFFGetFFLocation();
    if (!Dem_EvMemIsEventMemLocIdValid(FFLocId))
    {
        return DEM_GET_FFBYRECORD_NO_DTC_FOR_RECORD;
    }

    pidDataPtr = Dem_ObdFFGetPIDDataPtr(FFLocId);

    /* Number of PIDs */
    if (*BufSize < 1)
    {
        return DEM_GET_FFBYRECORD_WRONG_BUFFERSIZE;
    }

    *DestBuffer = DEM_CFG_OBD_NUMBER_OF_PIDS_STORED;
    DestBuffer++;
    BufLength = 1;

    for (pidIt = 1; pidIt < DEM_CFG_OBD_PID_ARRAY_LENGTH; pidIt++)
    {   /* PID */
        if (*BufSize < (BufLength + 2))
        {
            return DEM_GET_FFBYRECORD_WRONG_BUFFERSIZE;
        }
        BufLength = BufLength + 2;
        /* High Byte of DID is mapped to 0xF4 for a PID */
        *DestBuffer = 0xF4 ;
        DestBuffer++;
        /* Low Byte of DID is the 1-Byte PID */
        *DestBuffer = Dem_Cfg_ObdPid[pidIt].identifier;
        DestBuffer++;

        /* PID Data */
        for (pidDataIt = Dem_Cfg_ObdPid[pidIt - 1].dataElementIndex; pidDataIt < Dem_Cfg_ObdPid[pidIt].dataElementIndex; pidDataIt++)
        {
            /* PID Data Element Data */
            pidDataSize = Dem_Cfg_EnvDataElement[Dem_Cfg_ObdPid2DataElement[pidDataIt]].Size;
            if (*BufSize < (BufLength + pidDataSize))
            {
                return DEM_GET_FFBYRECORD_WRONG_BUFFERSIZE;
            }
            DEM_MEMCPY(DestBuffer, pidDataPtr, pidDataSize);
            BufLength  = BufLength  + pidDataSize;
            DestBuffer = DestBuffer + pidDataSize;
            pidDataPtr = pidDataPtr + pidDataSize;
        }
    }

    /* Number of written bytes */
    *BufSize = BufLength;
    /* UDS DTC Code */
    *DTC = Dem_DtcGetCode(Dem_DtcIdFromEventId(Dem_EvMemGetEventMemEventId(FFLocId)));
    return DEM_GET_FFBYRECORD_OK;

#else
    DEM_UNUSED_PARAM(RecordNumber);
    DEM_UNUSED_PARAM(DTCOrigin);
    DEM_UNUSED_PARAM(DTC);
    DEM_UNUSED_PARAM(DestBuffer);
    DEM_UNUSED_PARAM(BufSize);

    return E_NOT_OK;
#endif
}


#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
Std_ReturnType Dem_ObdRetrievePidData (uint8 PID, uint8* DestBuffer, uint8* BufSize, uint16_least LocId)
{
    Std_ReturnType retVal = E_NOT_OK;
    uint8* pidDataPtr;
    uint8 pidIt, pidDataIt, pidDataSize;

    pidDataSize = 0;

    /* find the starting address of OBD freeze frame*/
    pidDataPtr = Dem_ObdFFGetPIDDataPtr(LocId);

    for (pidIt = 1; pidIt < DEM_CFG_OBD_PID_ARRAY_LENGTH; pidIt++)
    {
        /* Search for the requested PID in configuration list. Abstract the PID number from PID */
        if (Dem_Cfg_ObdPid[pidIt].identifier == PID)
        {
            for (pidDataIt = Dem_Cfg_ObdPid[pidIt - 1].dataElementIndex; pidDataIt < Dem_Cfg_ObdPid[pidIt].dataElementIndex; pidDataIt++)
            {
                pidDataSize += Dem_Cfg_EnvDataElement[Dem_Cfg_ObdPid2DataElement[pidDataIt]].Size;
            }

            if (*BufSize >= pidDataSize)
            {
                *BufSize = pidDataSize;
                DEM_MEMCPY(DestBuffer, pidDataPtr, pidDataSize);
                retVal = E_OK;
            }
            else
            {
                retVal = E_NOT_OK;
            }

            break;
        }
        else
        {
            for (pidDataIt = Dem_Cfg_ObdPid[pidIt - 1].dataElementIndex; pidDataIt < Dem_Cfg_ObdPid[pidIt].dataElementIndex; pidDataIt++)
            {
                pidDataPtr = pidDataPtr + Dem_Cfg_EnvDataElement[Dem_Cfg_ObdPid2DataElement[pidDataIt]].Size;
            }
        }
    }

    return retVal;
}
#endif


/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is defined by AUTOSAR */
Std_ReturnType Dem_GetDTCOfOBDFreezeFrame (uint8 FrameNumber, uint32* DTC)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    Std_ReturnType retVal = E_NOT_OK;
    uint16_least FFLocId = DEM_EVMEM_INVALID_LOCID;

    *DTC = DEM_OBD_DTC_INVALID;

    if (FrameNumber == 0x00)
    {
        FFLocId = Dem_ObdFFGetFFLocation();
        if (Dem_EvMemIsEventMemLocIdValid(FFLocId))
        {
            *DTC = Dem_ObdDtcGetCode(Dem_DtcIdFromEventId(Dem_EvMemGetEventMemEventId(FFLocId)));
            retVal = E_OK;
        }
    }
    else
    {
        /* other freeze frames not specified by ISO/SAE for now */
    }
    return retVal;
#else
    DEM_UNUSED_PARAM(FrameNumber);
    DEM_UNUSED_PARAM(DTC);
    return E_NOT_OK;
#endif
}

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)

#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

const uint8 Dem_Cfg_ObdPid2DataElement[] = DEM_CFG_OBDPID2DATAELEMENT;
DEM_ARRAY_DEFINE_CONST(Dem_ObdPid, Dem_Cfg_ObdPid, DEM_CFG_OBD_PID_ARRAY_LENGTH, DEM_CFG_OBDPID);

#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


void Dem_ObdFFSetNewTimeId (uint16_least LocId)
{
    uint16_least MemId = DEM_CFG_EVMEM_MEMID_PRIMARY; /* for now only primary memory supported */
    uint16_least LocIdIt;
    uint32 MaxTimeId = 0;

    for (   Dem_EvMemEventMemoryLocIteratorNew    (&LocIdIt, MemId);
            Dem_EvMemEventMemoryLocIteratorIsValid(&LocIdIt, MemId);
            Dem_EvMemEventMemoryLocIteratorNext   (&LocIdIt, MemId))
    {
        if (   (((Dem_EvMemGetEventMemStatus(LocIdIt) & DEM_EVMEM_STSMASK_CONFIRMED) == DEM_EVMEM_STSMASK_CONFIRMED)
#if (DEM_CFG_OBD_FREEZEFRAME_VISIBILITY == DEM_CFG_OBD_FREEZEFRAME_VISIBILITY_PENDING_AND_CONFIRMED)
               || ((Dem_EvMemGetEventMemStatus(LocIdIt) & DEM_EVMEM_STSMASK_PENDING) == DEM_EVMEM_STSMASK_PENDING)
#endif
               )
               && (Dem_ObdEvMemGetEventMemFFTimeId(LocIdIt) > MaxTimeId)
        )
        {
            MaxTimeId = Dem_ObdEvMemGetEventMemFFTimeId(LocIdIt);
        }
    }

    /* overflow */
    if (MaxTimeId >= DEM_OBD_EVMEM_MAX_FF_TIMEID)
    {
        for (   Dem_EvMemEventMemoryLocIteratorNew    (&LocIdIt, MemId);
                Dem_EvMemEventMemoryLocIteratorIsValid(&LocIdIt, MemId);
                Dem_EvMemEventMemoryLocIteratorNext   (&LocIdIt, MemId))
        {
            if (((Dem_EvMemGetEventMemStatus(LocIdIt) & DEM_EVMEM_STSMASK_CONFIRMED) == DEM_EVMEM_STSMASK_CONFIRMED)
#if (DEM_CFG_OBD_FREEZEFRAME_VISIBILITY == DEM_CFG_OBD_FREEZEFRAME_VISIBILITY_PENDING_AND_CONFIRMED)
                        || ((Dem_EvMemGetEventMemStatus(LocIdIt) & DEM_EVMEM_STSMASK_PENDING) == DEM_EVMEM_STSMASK_PENDING)
#endif
            )
            {
                Dem_ObdEvMemSetEventMemFFTimeId(LocIdIt, 0);
            }
        }
        MaxTimeId = 0;
    }

    Dem_ObdEvMemSetEventMemFFTimeId(LocId, MaxTimeId + 1);
}


void Dem_ObdFFCaptureFF (Dem_EventIdType EventId, uint8* dest, uint16 destSize   DEM_DEBUGDATA_PARAM(Dem_DebugDataType debug0, Dem_DebugDataType debug1))
{
    uint8* writepos;
    uint8 i;
    uint16 size;
    uint8 edId = Dem_Cfg_EnvEventId2EnvData[EventId].extDataId;
    uint8 ffId = Dem_Cfg_EnvEventId2EnvData[EventId].freezeFrameId;
    Dem_InternalEnvData internalEnvData;
    internalEnvData.eventId = EventId;
    internalEnvData.evMemLocation = NULL_PTR;

#if (DEM_CFG_DEBUGDATA != DEM_CFG_DEBUGDATA_OFF)
    DEM_UNUSED_PARAM(debug0);
    DEM_UNUSED_PARAM(debug1);
#endif

    DEM_ASSERT(Dem_isEventIdValid(EventId), DEM_DET_APIID_OBDENVCAPTUREFF,0);
    DEM_ASSERT((Dem_EnvEDGetRawByteSize (edId) + Dem_EnvFFGetRawByteSize (ffId)) <= destSize, DEM_DET_APIID_OBDENVCAPTUREFF, 1);
    writepos = dest + Dem_EnvEDGetRawByteSize(edId) + Dem_EnvFFGetRawByteSize(ffId);
    size = Dem_ObdFFGetRawByteSize();

    for (i = 1; i < DEM_CFG_OBD_PID_ARRAY_LENGTH; i++)
    {
        Dem_ObdFFCapturePids(i, &writepos, writepos + size, &internalEnvData);
    }
}


void Dem_ObdFFCopyFF (Dem_EventIdType EventId, uint8* dest, uint16 destSize, const uint8* src)
{
    uint16 obdFFsize = Dem_ObdFFGetRawByteSize();
    uint16 EDsize = Dem_EnvEDGetRawByteSize(Dem_Cfg_EnvEventId2EnvData[EventId].extDataId);
    uint16_least FFsize = Dem_EnvFFGetRawByteSize(Dem_Cfg_EnvEventId2EnvData[EventId].freezeFrameId);
    uint8* writepos = dest + EDsize + (Dem_EvtGetMaxNumberOfFreezeFrames(EventId) * FFsize);
    const uint8* obdFFpos = src + EDsize + FFsize;

    DEM_ASSERT(Dem_isEventIdValid(EventId), DEM_DET_APIID_ENVCOPYRAWFF,0);
    DEM_ASSERT((writepos + obdFFsize) <= (dest + destSize), DEM_DET_APIID_ENVCOPYRAWFF, 1);

    Dem_ObdFFCopyRaw(writepos, obdFFsize, obdFFpos);
}

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif /* (DEM_CFG_OBD != DEM_CFG_OBD_OFF) */

/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.10.0.0; 1     10.04.2015 LIB8FE
 *   CSCRM00783636
 * 
 * AR40.10.0.0; 0     29.01.2015 LIB8FE
 *   CSCRM00683261
 * 
 * AR40.9.0.0; 1     13.01.2015 GJ83ABT
 *   CSCRM00771175
 * 
 * AR40.9.0.0; 0     15.10.2014 GJ83ABT
 *   CSCRM00719089, CSCRM00650337, CSCRM00625552, CSCRM00434933
 * 
 * AR40.8.0.0; 3     16.06.2014 GJ83ABT
 *   CSCRM00615634, CSCRM00671513
 * 
 * AR40.8.0.0; 2     19.05.2014 GJ83ABT
 *   CSCRM00615636, CSCRM00591553
 * 
 * AR40.8.0.0; 1     20.03.2014 CLH2SI
 *   CSCRM00633913
 * 
 * AR40.8.0.0; 0     28.01.2014 GJ83ABT
 *   CSCRM00478859
 * 
 * AR40.7.0.0; 8     21.11.2013 GIN9COB
 *   CSCRM00598921
 * 
 * AR40.7.0.0; 7     18.11.2013 BPE4COB
 *   CSCRM00560880: [Dem] Provided Memmap header
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
