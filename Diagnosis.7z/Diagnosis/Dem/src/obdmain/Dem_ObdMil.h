/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:H$
 * $Name______:Dem_ObdMil$
 * $Variant___:AR40.9.0.0$
 * $Revision__:0$
 **********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_OBDMIL_H
#define DEM_OBDMIL_H

#include "Dem_Types.h"
#include "Dem_Cfg_ObdMain.h"


#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

extern Dem_IndicatorStatusType Dem_ObdMil;

#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

#define DEM_OBD_MIL_HEALING_CYCLES  3 /* min. 3 driving cycle with MilOn */

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

void Dem_ObdMilInit (void);
void Dem_ObdMilCheckIndicatorState (void);
void Dem_ObdMilStartDrivingCycle (void);
void Dem_ObdMilStopIgnitionCycle (void);
void Dem_ObdMilRequest (boolean state);
Dem_boolean_least Dem_ObdMilIsEvtRequestingMil (Dem_EventIdType EventId);
Dem_boolean_least Dem_ObdMilIsEvMemLocRequestingMil (uint16_least LocId, uint16_least MemId);

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

DEM_INLINE void Dem_ObdMilClearDiagnosticInformation (void)
{
    Dem_ObdMilCheckIndicatorState();
}


#endif /* (DEM_CFG_OBD != DEM_CFG_OBD_OFF) */

#endif /* DEM_OBDMIL_H */

/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.9.0.0; 0     13.01.2015 GJ83ABT
 *   CSCRM00771175
 * 
 * AR40.8.0.0; 1     16.06.2014 GJ83ABT
 *   CSCRM00615634, CSCRM00671513
 * 
 * AR40.8.0.0; 0     28.01.2014 GJ83ABT
 *   CSCRM00478859
 * 
 * AR40.7.0.0; 3     21.11.2013 GIN9COB
 *   CSCRM00598921
 * 
 * AR40.7.0.0; 2     18.11.2013 BPE4COB
 *   CSCRM00560880: [Dem] Provided Memmap header
 * 
 * AR40.7.0.0; 1     24.10.2013 GJ83ABT
 *   CSCRM00467090
 * 
 * AR40.7.0.0; 0     22.10.2013 AMN2KOR
 *   CSCRM00547887
 * 
 * AR40.5.0.0; 3     08.07.2013 BRM2COB
 *   CSCRM00541186 : Removal of MISRA warnings
 * 
 * AR40.5.0.0; 2     07.01.2013 KAN1COB
 *   Git transfer - >c7b60f6605db2476a382daf05b17f6c7f088f2d2
 *   Fix- Obd Drv cycle and warmup cyce not configured in operationcycles
 *   * CSCRM00479194 - [INT-Dem] pending review findings from CSCRM00434163
 *   CSCRM00483492 - [INT-Dem] Fix findings -Vendor Specific parameters optional
 *   CSCRM00479560 - [INT-DEM] Issue from PAC_DevDiagnosis November build
 *   CSCRM00479557 - [INT-DEM] Remove compilation warnings
 *   CSCRM00484190 - [INT-Dem] Fix Medium/Strong review findings
 *   CSCRM00484194 - [INT-Dem] Fix Medium/Strong review findings
 *   CSCRM00480461 : Fix Reviewfindings : 
 *   Review12_636_COMP_Dem_AR40_5_2012-10_3.xls
 *   CSCRM00482583: OBD: Fix review findings
 *   Changes during code analysis of Defect CSCRM00467070 (DemClearDTCBehavior)
 *   QAC-warning
 *   
 *   CSCRM00479820 - [INT-FIM] Fix review findings
 *   CSCRM00479857 - [INT - FIM] remove BCT errors and warnings shown in 
 *   problemes log
 * 
 * AR40.5.0.0; 1     30.11.2012 KAN1COB
 *   See: check in comment ofCOMP: DEM40.5_2012-11;5
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
