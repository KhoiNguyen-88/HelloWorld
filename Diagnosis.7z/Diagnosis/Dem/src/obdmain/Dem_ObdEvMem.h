/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:H$
 * $Name______:Dem_ObdEvMem$
 * $Variant___:AR40.11.0.0$
 * $Revision__:0$
 **********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_OBDEVMEM_H
#define DEM_OBDEVMEM_H

#include "Dem_Types.h"
#include "Dem_Mapping.h"

#include "Dem_Cfg_ObdMain.h"
#include "Dem_ObdMil.h"
#include "Dem_ObdFreezeFrame.h"
#include "Dem_ObdPdtcMem.h"
#include "Dem_ObdDTCs.h"
#include "Dem_ObdEvents.h"


/* --- Mil Counter --- */

DEM_INLINE void Dem_ObdEvMemSetMilCounter (uint16_least LocId, uint8 counter)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    Dem_EvMemEventMemory[LocId].ObdMilCounter = counter;
    (void)Dem_NvmSetChanged(Dem_EvMemGetNvmIdFromLocId(LocId), TRUE);
#else
    DEM_UNUSED_PARAM(LocId);
    DEM_UNUSED_PARAM(counter);
#endif
}

DEM_INLINE uint8 Dem_ObdEvMemGetMilCounter (uint16_least LocId)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    return Dem_EvMemEventMemory[LocId].ObdMilCounter;
#else
    DEM_UNUSED_PARAM(LocId);
    return 0;
#endif
}

#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
DEM_INLINE Dem_boolean_least Dem_ObdEvMemIsTestCompleteThisDCY (uint16_least LocId)
{
    return ((Dem_EvMemEventMemory[LocId].Hdr.Data.Status & DEM_EVMEM_STSMASK_TESTCOMPLETE_TFC) == DEM_EVMEM_STSMASK_TESTCOMPLETE_TFC);
}

DEM_INLINE Dem_boolean_least Dem_ObdEvMemIsTestFailedThisDCY (uint16_least LocId)
{
    return ((Dem_EvMemEventMemory[LocId].Hdr.Data.Status & DEM_EVMEM_STSMASK_TESTFAILED_TFC) == DEM_EVMEM_STSMASK_TESTFAILED_TFC);
}
#endif

DEM_INLINE Dem_boolean_least Dem_ObdEvMemLocationRequestsIllumination (uint16_least LocId, uint16_least MemId)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
   return Dem_ObdMilIsEvMemLocRequestingMil(LocId, MemId);
#else
    DEM_UNUSED_PARAM(LocId);
    DEM_UNUSED_PARAM(MemId);
    return FALSE;
#endif
}


/* --- Common mil debouncing --- */

DEM_INLINE void Dem_ObdEvMemCommonMilDebModifyFailureCounter (uint16_least LocId, uint16_least MemId, Dem_EventIdType EventId, uint16_least *failureCounter)
{
#if (DEM_CFG_OBDCOMMONMILDEB == DEM_CFG_OBDCOMMONMILDEB_ON)

    uint16_least LocIdIt;
    uint16_least CounterOtherEvent;
    Dem_EventIdType MilRepEventId = Dem_ObdEvtGetMilRepEvent(EventId);

    if (MilRepEventId  != DEM_EVENTID_INVALID)
    {
        for ( Dem_EvMemEventMemoryLocIteratorNew    (&LocIdIt, MemId);
                Dem_EvMemEventMemoryLocIteratorIsValid(&LocIdIt, MemId);
                Dem_EvMemEventMemoryLocIteratorNext   (&LocIdIt, MemId))
        {
            if (Dem_EvMemIsStored(Dem_EvMemGetEventMemStatus(LocIdIt)))
            {
                if ((LocId != LocIdIt) && (MilRepEventId == Dem_ObdEvtGetMilRepEvent(Dem_EvMemGetEventMemEventId(LocIdIt))))
                {
                    /* Get the fault failure counter of event of same group */
                    CounterOtherEvent = Dem_EvMemGetEventMemFailureCounter (LocIdIt);

                    /* Only pending is relevant for MIL counters*/
                    if ((CounterOtherEvent > *failureCounter)
                        && (CounterOtherEvent < Dem_EvtGetFailureConfirmationThreshold(Dem_EvMemGetEventMemEventId(LocIdIt))))

                    {
                        /* take over counter value */
                        if (Dem_ObdEvMemIsTestFailedThisDCY(LocIdIt))
                        {
                            /* counter already incremented in this DCY -> avoid new incrementation */
                            *failureCounter = CounterOtherEvent - 1;
                        }
                        else
                        {
                            *failureCounter = CounterOtherEvent;
                        }
                    }
                }
            }
        }
    }
#else
    DEM_UNUSED_PARAM(LocId);
    DEM_UNUSED_PARAM(MemId);
    DEM_UNUSED_PARAM(EventId);
    *failureCounter = *failureCounter; /* MISRA */
#endif
}


/* --- Freeze Frame / TimeId --- */

#define DEM_OBD_EVMEM_MAX_FF_TIMEID    (0xFFFFFFFFuL)

DEM_INLINE uint32 Dem_ObdEvMemGetEventMemFFTimeIdByPtr (const Dem_EvMemEventMemoryType *EventMemory)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    return EventMemory->ObdFFTimeId;
#else
    DEM_UNUSED_PARAM(EventMemory);
    return 0;
#endif
}

DEM_INLINE uint32 Dem_ObdEvMemGetEventMemFFTimeId (uint16_least LocId)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    return Dem_ObdEvMemGetEventMemFFTimeIdByPtr(&Dem_EvMemEventMemory[LocId]);
#else
    DEM_UNUSED_PARAM(LocId);
    return 0;
#endif
}

DEM_INLINE void Dem_ObdEvMemSetEventMemFFTimeId (uint16_least LocId, uint32 ObdFFTimeId)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    Dem_EvMemEventMemory[LocId].ObdFFTimeId = ObdFFTimeId;
    (void)Dem_NvmSetChanged(Dem_EvMemGetNvmIdFromLocId(LocId), TRUE);
#else
    DEM_UNUSED_PARAM(LocId);
    DEM_UNUSED_PARAM(ObdFFTimeId);
#endif
}

DEM_INLINE void Dem_ObdEvMemCopyObdFreezeFrame (Dem_EventIdType EventId, uint8* dest, uint16 destSize, const uint8* src)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    Dem_ObdFFCopyFF(EventId, dest, destSize, src);
#else
    *dest = 0;
    DEM_UNUSED_PARAM(EventId);
    DEM_UNUSED_PARAM(dest);
    DEM_UNUSED_PARAM(destSize);
    DEM_UNUSED_PARAM(src);
#endif
}

DEM_INLINE uint16_least Dem_ObdEvMemGetLocationOfOBDFreezeFrame (void)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    return Dem_ObdFFGetFFLocation();
#else
    return DEM_EVMEM_INVALID_LOCID;
#endif
}

/* --- Aging / Displacement --- */

DEM_INLINE Dem_boolean_least Dem_ObdEvMemIsAgingOfLocationAllowed (uint16_least LocId)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    /* allow aging if:
     * - DTC is not OBD relevant: always (MilCounter always = 0)
     * - DTC is OBD relevant:
     *    Mil healing completed (MilCounter = 0)
     *    AND
     *    DTC has not been detected again in current cycle (complete cycles without failure is necessary for OBD aging)
     */
    return (    (Dem_ObdEvMemGetMilCounter(LocId) == 0)
            && (     (!Dem_ObdDtcIsEmissionRelated(Dem_DtcIdFromEventId(Dem_EvMemGetEventMemEventId(LocId))))
                    || (((Dem_EvMemGetEventMemStatus(LocId) & DEM_EVMEM_STSMASK_PENDING)) != DEM_EVMEM_STSMASK_PENDING))
    );
#else
    DEM_UNUSED_PARAM(LocId);
    return TRUE;
#endif
}


DEM_INLINE Dem_boolean_least Dem_ObdEvMemIsDisplaceEventMemoryLocAllowed (Dem_EventIdType NewEventId, uint16_least LocId, uint16_least LocIdObdServ02)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
#if (DEM_CFG_OBD_EVENT_DISPLACEMENT != DEM_CFG_OBD_EVENT_DISPLACEMENT_OFF)
    /* OBD displacement:
     * Emission related events that are
     * - Pending
     * - Illuminating the MIL
     * - Providing the Serv $02 freeze frame
     * and have the same or an higher priority than the new event
     * or are visible in Serv $0A (permanent) are not displaced */

    Dem_EventIdType EventId = Dem_EvMemGetEventMemEventId(LocId);
    Dem_boolean_least retVal = TRUE;

    if (Dem_ObdEventIsEmissionRelated(EventId))
    {
        if (Dem_ObdPdtcMemIsEvtPdtc(EventId))
        {
            retVal = FALSE;
        }
        else if (Dem_EvtGetEventPriority(EventId) <= Dem_EvtGetEventPriority(NewEventId))
        {
            /* old event has same or higher prio than new event: consider OBD criteria */
            if (     (LocId == LocIdObdServ02)
                    || (Dem_ObdMilIsEvMemLocRequestingMil(LocId, DEM_CFG_EVMEM_MEMID_PRIMARY))
                    || ((Dem_EvMemGetEventMemStatus(LocId) & DEM_EVMEM_STSMASK_PENDING) == DEM_EVMEM_STSMASK_PENDING)
            )
            {
                retVal = FALSE;
            }
        }
        else
        {
            /* MISRA */
        }
    }

        return retVal;
#else
        DEM_UNUSED_PARAM(NewEventId);
        DEM_UNUSED_PARAM(LocId);
        DEM_UNUSED_PARAM(LocIdObdServ02);
        return TRUE;
#endif //(DEM_CFG_OBD_EVENT_DISPLACEMENT != DEM_CFG_OBD_EVENT_DISPLACEMENT_OFF)
#else
        DEM_UNUSED_PARAM(NewEventId);
        DEM_UNUSED_PARAM(LocId);
        DEM_UNUSED_PARAM(LocIdObdServ02);
        return TRUE;
#endif //(DEM_CFG_OBD != DEM_CFG_OBD_OFF)
}

/* --- Status Nofications --- */


DEM_INLINE void Dem_ObdEvMemStatusNotificationPending (uint16_least LocId, Dem_EventIdType EventId)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    if (Dem_ObdDtcIsEmissionRelated(Dem_DtcIdFromEventId(EventId)))
    {
#if (DEM_CFG_OBD_FREEZEFRAME_VISIBILITY == DEM_CFG_OBD_FREEZEFRAME_VISIBILITY_PENDING_AND_CONFIRMED)
        if ((Dem_EvMemGetEventMemStatus(LocId) & DEM_EVMEM_STSMASK_CONFIRMED) != DEM_EVMEM_STSMASK_CONFIRMED)
        {
            Dem_ObdFFSetNewTimeId(LocId);
        }
#else
        DEM_UNUSED_PARAM(LocId);
#endif
    }
#else
    DEM_UNUSED_PARAM(EventId);
    DEM_UNUSED_PARAM(LocId);
#endif
}

DEM_INLINE void Dem_ObdEvMemStatusNotificationPendingConfirmed (uint16_least LocId, Dem_EventIdType EventId)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    if (Dem_ObdDtcIsEmissionRelated(Dem_DtcIdFromEventId(EventId)))
    {
        Dem_ObdEvMemSetMilCounter(LocId, DEM_OBD_MIL_HEALING_CYCLES);
        Dem_ObdMilRequest(TRUE);
        Dem_ObdEvtSetWarningIndicator(EventId, TRUE);
        Dem_ObdPdtcMemStoreNewEventId(EventId);
    }
    else
    {
        Dem_ObdEvMemSetMilCounter(LocId, 0);
    }
#else
    DEM_UNUSED_PARAM(LocId);
    DEM_UNUSED_PARAM(EventId);
#endif
}

DEM_INLINE void Dem_ObdEvMemStatusNotificationConfirmed (uint16_least LocId, Dem_EventIdType EventId)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    if (Dem_ObdDtcIsEmissionRelated(Dem_DtcIdFromEventId(EventId)))
    {
        Dem_ObdFFSetNewTimeId(LocId);
    }
#else
    DEM_UNUSED_PARAM(LocId);
    DEM_UNUSED_PARAM(EventId);
#endif
}

DEM_INLINE Dem_boolean_least Dem_ObdEvMemIsTriggerObdFreezeFrame (Dem_EventIdType EventId, uint16_least MemId, uint16_least StatusOld, uint16_least StatusNew)
{
    Dem_boolean_least trigger = FALSE;

    DEM_UNUSED_PARAM(MemId);

#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    if (Dem_ObdDtcIsEmissionRelated(Dem_DtcIdFromEventId(EventId)))
    {
        if ((StatusOld & DEM_EVMEM_STSMASK_CONFIRMED) != DEM_EVMEM_STSMASK_CONFIRMED)
        {
            trigger = Dem_EvMemIsEdgeTrigger (StatusOld, StatusNew, DEM_EVMEM_STSMASK_PENDING);
        }
#if (DEM_CFG_OBD_FREEZEFRAME_CAPTURE == DEM_CFG_OBD_FREEZEFRAME_CAPTURE_CONFIRMED)
        if (Dem_EvMemIsEdgeTrigger (StatusOld, StatusNew, DEM_EVMEM_STSMASK_CONFIRMED))
        {
            trigger = TRUE;
        }
#endif
    }
#else /* DEM_CFG_OBD_OFF */
    DEM_UNUSED_PARAM(EventId);
    DEM_UNUSED_PARAM(StatusOld);
    DEM_UNUSED_PARAM(StatusNew);
#endif
    return trigger;
}


#endif

/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.11.0.0; 0     11.01.2016 NAL2KOR
 *   CSCRM01015983
 * 
 * AR40.10.0.0; 0     10.04.2015 LIB8FE
 *   CSCRM00783636
 * 
 * AR40.9.0.0; 6     15.01.2015 LIB8FE
 *   CSCRM00771713
 * 
 * AR40.9.0.0; 5     14.01.2015 TVE5COB
 *   CSCRM00769536
 * 
 * AR40.9.0.0; 4     13.01.2015 GJ83ABT
 *   CSCRM00771175
 * 
 * AR40.9.0.0; 3     18.11.2014 LIB8FE
 *   CSCRM00737017
 * 
 * AR40.9.0.0; 2     18.11.2014 TVE5COB
 *   CSCRM00737328
 * 
 * AR40.9.0.0; 1     12.11.2014 CLH2SI
 *   CSCRM00735646
 * 
 * AR40.9.0.0; 0     15.10.2014 GJ83ABT
 *   CSCRM00719089, CSCRM00650337, CSCRM00625552, CSCRM00434933
 * 
 * AR40.8.0.0; 4     16.06.2014 GJ83ABT
 *   CSCRM00615634, CSCRM00671513
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/

