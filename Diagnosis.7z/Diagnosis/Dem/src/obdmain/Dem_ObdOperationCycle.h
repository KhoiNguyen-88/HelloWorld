/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:H$
 * $Name______:Dem_ObdOperationCycle$
 * $Variant___:AR40.9.0.0$
 * $Revision__:3$
 **********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_OBDOPERATIONCYCLE_H
#define DEM_OBDOPERATIONCYCLE_H

#include "Dem_Types.h"
#include "Dem_Cfg_ObdMain.h"
#include "Dem_ObdPdtcMem.h"
#include "Dem_ObdMil.h"
#include "Dem_Cfg_OperationCycle.h"
#include "Dem_GenericNvData.h"
#include "Dem_ObdRdy_Prv.h"
#include "Dem_ObdIumpr_Prv.h"
#include "Dem_ObdDemPids.h"


#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)

extern Dem_boolean_least Dem_ObdWarmupCycleCondition;

DEM_INLINE void Dem_ObdSetWarmupCycleQualified (Dem_boolean_least conditionActive)
{
    Dem_GenericNvData.ObdWarmupCycleCondition = (uint8)conditionActive;
    /* notify to store in NVM */
    Dem_NvGenericNvmWriteNotification();
}

DEM_INLINE Dem_boolean_least Dem_ObdIsWarmupCycleQualified (void)
{
    return ((Dem_boolean_least)Dem_GenericNvData.ObdWarmupCycleCondition);
}


DEM_INLINE void Dem_ObdSetOperationCycleState (Dem_OperationCycleList *operationCycleBitmask, Dem_OperationCycleStateType CycleState)
{
    if (CycleState == DEM_CYCLE_STATE_START)
    {
        if (*operationCycleBitmask & (1 << DEM_OPCYC_WARMUP))
        {
            Dem_ObdSetWarmupCycleQualified(TRUE);
            *operationCycleBitmask &= ~(1 << DEM_OPCYC_WARMUP);
        }

        if (*operationCycleBitmask & (1 << DEM_OPCYC_OBD_DCY))
        {
            *operationCycleBitmask |= (1 << DEM_OPCYC_IGNITION);

            if (Dem_ObdIsWarmupCycleQualified())
            {
                *operationCycleBitmask |= (1 << DEM_OPCYC_WARMUP);
            }
        }
    }
}


DEM_INLINE void Dem_ObdStartOperationCycle (Dem_OperationCycleList currentTriggers)
{
    if(!Dem_GetEvMemLock())
    {
        if (currentTriggers & (1 << DEM_OPCYC_OBD_DCY))
        {
            Dem_ObdMilStartDrivingCycle();
            Dem_ObdRdyStartDrivingCycle();
            Dem_ObdPdtcMemStartDrivingCycle();
            Dem_ObdIumprStartDrivingCycle();

            if (Dem_ObdIsWarmupCycleQualified())
            {
                Dem_ObdDemPidsStartWarmupCycle();
                Dem_ObdSetWarmupCycleQualified(FALSE);
            }
        }

        if (currentTriggers & (1 << DEM_OPCYC_IGNITION))
        {
            Dem_ObdPdtcMemStartIgnitionCycle();
        }
    }
}


#endif /* (DEM_CFG_OBD != DEM_CFG_OBD_OFF) */

#endif /* DEM_OBDOPERATIONCYCLE_H */

/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.9.0.0; 3     13.01.2015 GJ83ABT
 *   CSCRM00771175
 * 
 * AR40.9.0.0; 2     18.11.2014 LIB8FE
 *   CSCRM00737017
 * 
 * AR40.9.0.0; 1     18.11.2014 TVE5COB
 *   CSCRM00737328
 * 
 * AR40.9.0.0; 0     15.10.2014 GJ83ABT
 *   CSCRM00719089, CSCRM00650337, CSCRM00625552, CSCRM00434933
 * 
 * AR40.8.0.0; 3     16.06.2014 GJ83ABT
 *   CSCRM00615634, CSCRM00671513
 * 
 * AR40.8.0.0; 2     16.06.2014 BPE4COB
 *   CSCRM00666829
 * 
 * AR40.8.0.0; 1     10.02.2014 SAL2COB
 *   CSCRM00554992_AllowLockingEventMemory
 * 
 * AR40.8.0.0; 0     28.01.2014 GJ83ABT
 *   CSCRM00478859
 * 
 * AR40.7.0.0; 1     24.10.2013 GJ83ABT
 *   CSCRM00467090
 * 
 * AR40.7.0.0; 0     22.10.2013 AMN2KOR
 *   CSCRM00547887
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
