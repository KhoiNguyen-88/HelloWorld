/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:H$
 * $Name______:Dem_ObdClear$
 * $Variant___:AR40.9.0.0$
 * $Revision__:2$
 **********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_OBDCLEAR_H
#define DEM_OBDCLEAR_H


#include "Dem_Types.h"
#include "Dem_Cfg_ObdMain.h"
#include "Dem_ObdPdtcMem.h"
#include "Dem_ObdRdy_Prv.h"
#include "Dem_ObdIumpr_Prv.h"


DEM_INLINE void Dem_ObdClearDiagnosticInformation (Dem_DTCOriginType DTCOrigin)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    /* for now only primary memory supported */
    if (DTCOrigin == DEM_DTC_ORIGIN_PRIMARY_MEMORY)
    {
        Dem_ObdMilClearDiagnosticInformation();
        Dem_ObdPdtcMemClearDiagnosticInformation();
        Dem_ObdRdyClear();
        Dem_ObdIumprClear();
        Dem_ObdDemPidsClearDiagnosticInformation();
    }
#else
    DEM_UNUSED_PARAM(DTCOrigin);
    /* do nothing */
#endif
}

DEM_INLINE Dem_boolean_least Dem_ObdIsNvmImmediateStoragePending (Dem_boolean_least *anyFailed)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    return (Dem_ObdPdtcMemIsNvmImmediateStoragePending(anyFailed));
#else
    *anyFailed = *anyFailed; /* avoid MISRA warning for rule 16.7 (pointer not declared as pointer to const) */
    return FALSE;
#endif
}

#endif /* DEM_OBDCLEAR_H */

/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.9.0.0; 2     13.01.2015 GJ83ABT
 *   CSCRM00771175
 * 
 * AR40.9.0.0; 1     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.9.0.0; 0     15.10.2014 GJ83ABT
 *   CSCRM00719089, CSCRM00650337, CSCRM00625552, CSCRM00434933
 * 
 * AR40.8.0.0; 1     16.06.2014 GJ83ABT
 *   CSCRM00615634, CSCRM00671513
 * 
 * AR40.8.0.0; 0     28.01.2014 GJ83ABT
 *   CSCRM00478859
 * 
 * AR40.7.0.0; 1     24.10.2013 GJ83ABT
 *   CSCRM00467090
 * 
 * AR40.7.0.0; 0     22.10.2013 AMN2KOR
 *   CSCRM00547887
 * 
 * AR40.5.0.0; 2     22.01.2013 KAN1COB
 *   git transfer -> Commit:03ba9b4beb6ab853c12f8b3c32711045037c5c57
 * 
 * AR40.5.0.0; 1     30.11.2012 KAN1COB
 *   See: check in comment ofCOMP: DEM40.5_2012-11;5
 * 
 * AR40.5.0.0; 0     02.11.2012 CRA1COB
 *   GiT to eASEE
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
