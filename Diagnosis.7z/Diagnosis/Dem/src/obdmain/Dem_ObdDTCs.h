/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:H$
 * $Name______:Dem_ObdDTCs$
 * $Variant___:AR40.10.0.0$
 * $Revision__:0$
 **********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_OBDDTCS_H
#define DEM_OBDDTCS_H


#include "Dem_Types.h"
#include "Dem_Cfg_ObdMain.h"
#include "Dem_ObdMil.h"
#include "Dem_DTCs.h"


#define DEM_OBD_DTC_INVALID   (0x00000000)
#define DEM_OBD_DTC_MASK      (0x00FFFF00)

DEM_INLINE Dem_boolean_least Dem_ObdDtcIsEmissionRelated (Dem_DtcIdType DtcId)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    return (   (Dem_isDtcIdValid(DtcId))
            && (Dem_DtcGetKind(DtcId) == DEM_DTC_KIND_EMISSION_REL_DTCS)
    );
#else
    DEM_UNUSED_PARAM(DtcId);
    return FALSE;
#endif
}


#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)

DEM_INLINE Dem_DtcCodeType Dem_ObdDtcGetCode (Dem_DtcIdType dtcId)
{
    Dem_DtcCodeType dtcCode = DEM_OBD_DTC_INVALID;

    if ((Dem_ObdDtcIsEmissionRelated(dtcId)) && (Dem_isDtcIdValid(dtcId)))
    {
#if (DEM_CFG_OBD_DTC_CONFIG != DEM_CFG_OBD_DTC_CONFIG_ON)
        dtcCode = (Dem_DtcGetCode(dtcId)) & (DEM_OBD_DTC_MASK);
#else
        dtcCode = ((Dem_DtcGetOBDCode(dtcId) << 8) & (DEM_OBD_DTC_MASK));
#endif
    }
    return dtcCode;
}


DEM_INLINE Dem_DtcIdType Dem_ObdDtcIdFromDtcCode (Dem_DtcCodeType dtcCode)
{
    DEM_UNUSED_PARAM(dtcCode);
    /* TODO: return first DTCID? */
    return DEM_DTCID_INVALID;
}

#endif /* (DEM_CFG_OBD != DEM_CFG_OBD_OFF) */

#endif /* DEM_OBDDTCS_H */

/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.10.0.0; 0     01.07.2015 CLH2SI
 *   CSCRM00649773
 * 
 * AR40.9.0.0; 0     13.01.2015 GJ83ABT
 *   CSCRM00771175
 * 
 * AR40.8.0.0; 2     16.06.2014 GJ83ABT
 *   CSCRM00615634, CSCRM00671513
 * 
 * AR40.8.0.0; 1     20.03.2014 CLH2SI
 *   CSCRM00633913
 * 
 * AR40.8.0.0; 0     28.01.2014 GJ83ABT
 *   CSCRM00478859
 * 
 * AR40.7.0.0; 4     24.10.2013 GJ83ABT
 *   CSCRM00467090
 * 
 * AR40.7.0.0; 3     22.10.2013 AMN2KOR
 *   CSCRM00547887
 * 
 * AR40.7.0.0; 2     21.10.2013 HNH2ABT
 *   CSCRM00583641
 * 
 * AR40.7.0.0; 1     27.09.2013 GJ83ABT
 *   CSCRM00498768
 * 
 * AR40.7.0.0; 0     08.08.2013 CLH2SI
 *   CSCRM00532300
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
