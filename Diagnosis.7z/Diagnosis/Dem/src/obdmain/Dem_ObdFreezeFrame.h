/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:H$
 * $Name______:Dem_ObdFreezeFrame$
 * $Variant___:AR40.9.0.0$
 * $Revision__:0$
 **********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_OBDFREEZEFRAME_H
#define DEM_OBDFREEZEFRAME_H

#include "Dem_Types.h"
#include "Dem_BitArray.h"
#include "Dem_Cfg_EvMem.h"
#include "Dem_EnvDataElement.h"

#include "Dem_Cfg_ObdMain.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
/**
 * @ingroup DEM_H
 *
 * Dem327:  Gets data element per PID and index of the most important freeze frame being selected for the output of service $02.
 *          The function stores the data in the provided DestBuffer.
 *
 * @param [in] PID This parameter is an identifier for a PID as defined in ISO15031-5.
 *
 * @param [in] DataElementIndexOfPID Data element index of this PID according to the Dcm configuration of service $02.
 *                                   It is zero-based and consecutive, and ordered by the data element positions
 *                                   (configured in Dcm, refer to Dem597).
 *
 * @param [in,out] DestBuffer This parameter contains a byte pointer that points to the buffer, to which the data element of the PID shall be written to.
 *                           The format is raw hexadecimal values and contains no header-information.
 *
 * @param [in,out] BufSize When the function is called this parameter contains the maximum number of data bytes that can be written to the buffer.
 *                        The function returns the actual number of written data bytes in this parameter.
 *
 * @return  E_OK Freeze frame data was successfully reported\n
 *          E_NOT_OK Freeze frame data was not successfully reported
 */
Std_ReturnType Dem_ReadDataOfOBDFreezeFrame (uint8 PID, uint8 DataElementIndexOfPID, uint8* DestBuffer, uint8* BufSize);

/**
 * @ingroup DEM_H
 *
 * Dem624:  Gets DTC by freeze frame record number.
 *
 * @param [in] FrameNumber Unique identifier for a freeze frame record as defined in ISO 15031-5.
 *                         The value 0x00 indicates the complete OBD freeze frame.
 *                         Other values are reserved for future functionality.
 *
 * @param [out] DTC Diagnostic Trouble Code. If the return value of the function is other than E_OK this parameter does not contain valid data.
 *
 * @return  E_OK: operation was successful\n
 *          E_NOT_OK: no DTC available
 */
Std_ReturnType Dem_GetDTCOfOBDFreezeFrame (uint8 FrameNumber, uint32* DTC);
#define DEM_STOP_SEC_ROM_CODE

#include "Dem_Cfg_MemMap.h"

/**
 * @ingroup DEM_H
 *
 * Dem235: Gets DTC and its associated freeze frame record by absolute record number. The function stores the data in the provided DestBuffer.
 * @param[in]   	RecordNumber		   This parameter is a unique identifier for a freeze frame record.
 *                                         Only the value 0x00 which indicates the complete OBD freeze frame is supported.
 * @param[in]   	DTCOrigin			   If the Dem supports more than one event memory, this parameter is used to select
 *                                         the source memory the DTCs shall be read from.
 * @param[in,out]   BufSize			       When the function is called this parameter contains the maximum number of data bytes that can be written to the buffer.
 *                                         The function returns the actual number of written data bytes in this parameter.
 * @param[out]  	DTC					   Receives the DTC value returned by the function.
 *                                         If the return value of the function is other than DEM_GET_FFBYRECORD_OK this parameter does not contain valid data.
 * @param[out]  	DestBuffer 		       This parameter contains a byte pointer that points to the buffer, to which the freeze frame data record shall be written to.
 *                                         The format is: {NumOfDIDs, DID[1], data[1], ..., DID[N], data[N]}.
 * @return 	    Dem_ReturnGetFreezeFrameDataByRecordType : Status of the operation to retrieve the DTC and its associated freeze frame record
 *
 * <b>Note:</b>\n
 - returntype Dem_ReturnGetFreezeFrameDataByRecordType extended by one additional value:
   DEM_GET_FFBYRECORD_WRONG_BUFFERSIZE (value 0x03)
 - Restrict allowed record numbers to only OBD-record (0x00)
 */

Dem_ReturnGetFreezeFrameDataByRecordType Dem_GetFreezeFrameDataByRecord( uint8 RecordNumber, Dem_DTCOriginType DTCOrigin,  uint32* DTC, uint8* DestBuffer, uint16* BufSize );


#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)

typedef struct
{
    uint8 dataElementIndex;
    uint8 identifier;
} Dem_ObdPid;

#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

extern const uint8 Dem_Cfg_ObdPid2DataElement[];

DEM_ARRAY_DECLARE(const Dem_ObdPid, Dem_Cfg_ObdPid, DEM_CFG_OBD_PID_ARRAY_LENGTH);

#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

void Dem_ObdFFSetNewTimeId (uint16_least LocId);
void Dem_ObdFFCaptureFF (Dem_EventIdType EventId, uint8* dest, uint16 destSize   DEM_DEBUGDATA_PARAM(Dem_DebugDataType debug0, Dem_DebugDataType debug1));
void Dem_ObdFFCopyFF (Dem_EventIdType EventId, uint8* dest, uint16 destSize, const uint8* src);
uint16_least Dem_ObdFFGetFFLocation (void);

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

DEM_INLINE void Dem_ObdFFCapturePids (uint8 pidId, uint8** start, const uint8* end, const Dem_InternalEnvData *internalEnvData)
{
    uint16_least i;

    for (i = Dem_Cfg_ObdPid[pidId - 1].dataElementIndex; i < Dem_Cfg_ObdPid[pidId].dataElementIndex; i++)
    {
        Dem_EnvDACapture(Dem_Cfg_ObdPid2DataElement[i], start, end, internalEnvData);
    }
}


DEM_INLINE uint16 Dem_ObdFFGetRawByteSize (void)
{
    return DEM_CFG_OBD_FREEZEFRAME_LENGTH;
}


DEM_INLINE void Dem_ObdFFCopyRaw (uint8* dest, uint16 bufsize, const uint8* src)
{
    const uint16 bytesize = Dem_ObdFFGetRawByteSize();
    DEM_ASSERT(bytesize <= bufsize, DEM_DET_APIID_OBDENVFFCOPYRAW, 0);
    DEM_MEMCPY (dest, src, bytesize);
}

Std_ReturnType Dem_ObdRetrievePidData (uint8 PID, uint8* DestBuffer, uint8* BufSize, uint16_least LocId);

#endif /* (DEM_CFG_OBD != DEM_CFG_OBD_OFF) */

#endif /* DEM_OBDFREEZEFRAME_H */

/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.9.0.0; 0     13.01.2015 GJ83ABT
 *   CSCRM00771175
 * 
 * AR40.8.0.0; 2     16.07.2014 BRM2COB
 *   CSCRM00688243
 * 
 * AR40.8.0.0; 1     16.06.2014 GJ83ABT
 *   CSCRM00615634, CSCRM00671513
 * 
 * AR40.8.0.0; 0     19.05.2014 GJ83ABT
 *   CSCRM00615636, CSCRM00591553
 * 
 * AR40.7.0.0; 8     21.11.2013 GIN9COB
 *   CSCRM00598921
 * 
 * AR40.7.0.0; 7     18.11.2013 BPE4COB
 *   CSCRM00560880: [Dem] Provided Memmap header
 * 
 * AR40.7.0.0; 6     30.10.2013 UDKOEGEL
 *   CSCRM00559234
 * 
 * AR40.7.0.0; 5     24.10.2013 GJ83ABT
 *   CSCRM00467090
 * 
 * AR40.7.0.0; 4     22.10.2013 AMN2KOR
 *   CSCRM00547887
 * 
 * AR40.7.0.0; 3     21.10.2013 HNH2ABT
 *   CSCRM00583641
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
