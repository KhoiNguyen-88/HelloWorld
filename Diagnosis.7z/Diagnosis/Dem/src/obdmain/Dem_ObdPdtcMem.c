/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:C$
 * $Name______:Dem_ObdPdtcMem$
 * $Variant___:AR40.10.0.0$
 * $Revision__:6$
 **********************************************************************************************************************
</BASDKey>*/

#include "Dem_ObdPdtcMem.h"
#include "Dem_ObdEvMem.h"
#include "Dem_GenericNvData.h"


#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)

#define DEM_START_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

DEM_ARRAY_DEFINE(Dem_ObdPdtcMemType, Dem_ObdPdtcMem, DEM_CFG_PERMANENT_MEMORY_SIZE);

#define DEM_STOP_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

DEM_ARRAY_DEFINE_CONST(Dem_NvmIdType, Dem_ObdPdtcMemNvmId, DEM_CFG_PERMANENT_MEMORY_SIZE, DEM_CFG_OBD_PERMANENT_MEMORY_NVMIDS);

#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

DEM_ARRAY_DEFINE(Dem_ObdPdtcMemStorageStateType, Dem_ObdPdtcMemStorageState, DEM_CFG_PERMANENT_MEMORY_SIZE);

typedef struct
{
    boolean Busy;
    uint16 LocId;
    Dem_ObdPdtcMemType Data;
} Dem_ObdPdtcMemStorageBufferType;

static Dem_ObdPdtcMemStorageBufferType Dem_ObdPdtcMemStorageBuffer;

#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

void Dem_ObdPdtcInitCheckNvM(void)
{
    Dem_ObdPdtcMemIterator PdtcIt;
    uint16_least PdtcLocIt;
    Dem_NvmResultType NvmResult;

    for ( Dem_ObdPdtcMemLocIteratorNew(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorIsValid(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorNext(&PdtcIt)
    )
    {
        PdtcLocIt = Dem_ObdPdtcMemLocIteratorCurrent(&PdtcIt);

        /* get the Result of the NvM-Read (NvM_ReadAll) */
        NvmResult = Dem_NvmGetStatus (Dem_ObdPdtcMemNvmId[PdtcLocIt]);

        /* Data read successfully */
        if (NvmResult == DEM_NVM_SUCCESS)
        {
            /* Check if eventid stored in the location is valid */
            if((!Dem_isEventIdValid(Dem_ObdPdtcMemGetEventId(PdtcLocIt))) &&
                    (Dem_ObdPdtcMemGetState(PdtcLocIt) != OBD_PDTC_LOCID_STATE_EMPTY))
            {
                NvmResult = DEM_NVM_FAILED;
            }
        }

        if(NvmResult != DEM_NVM_SUCCESS)
        {
            /* Zero the RAM content of this particular OBD location */
            DEM_MEMSET( &Dem_ObdPdtcMem[PdtcLocIt], 0x00, DEM_SIZEOF_VAR(Dem_ObdPdtcMem[PdtcLocIt]) );
            Dem_ObdPdtcMemSetStorageState(PdtcLocIt, OBD_PDTC_LOCID_STORAGE_PENDING);
        }
    }
}

void Dem_ObdPdtcMemStoreNewEventId (Dem_EventIdType EventId)
{
    Dem_ObdPdtcMemIterator PdtcIt;
    uint16_least PdtcLocIt;
    uint16_least PdtcLocItPrio = OBD_PDTC_STORAGE_PRIO_UNDEF;
    uint16_least PdtcLocFound = OBD_PDTC_LOC_INVALID;

    for ( Dem_ObdPdtcMemLocIteratorNew(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorIsValid(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorNext(&PdtcIt)
    )
    {
        PdtcLocIt = Dem_ObdPdtcMemLocIteratorCurrent(&PdtcIt);

        if (Dem_ObdPdtcMemGetState(PdtcLocIt) == OBD_PDTC_LOCID_STATE_EMPTY)
        {
            if (PdtcLocItPrio < OBD_PDTC_STORAGE_PRIO_EMPTY)
            {
                PdtcLocFound = PdtcLocIt;
                PdtcLocItPrio = OBD_PDTC_STORAGE_PRIO_EMPTY;
            }
        }
        else
        {
            if (Dem_ObdPdtcMemIsEventIdStored(PdtcLocIt, EventId))
            {
                if (     (Dem_ObdPdtcMemGetState(PdtcLocIt) == OBD_PDTC_LOCID_STATE_MILON)
                        || (Dem_ObdPdtcMemGetState(PdtcLocIt) == OBD_PDTC_LOCID_STATE_MILON_VISIBLE_0A)
                )
                {
                    /* do not store PDTC again */
                    PdtcLocFound = OBD_PDTC_LOC_INVALID;
                    break;
                }
                else
                {
                    if (PdtcLocItPrio < OBD_PDTC_STORAGE_PRIO_STORED)
                    {
                        PdtcLocFound = PdtcLocIt;
                        PdtcLocItPrio = OBD_PDTC_STORAGE_PRIO_STORED;
                    }
                }
            }
        }
    }

    if (PdtcLocFound != OBD_PDTC_LOC_INVALID)
    {
        Dem_ObdPdtcMemSetEventId(PdtcLocFound, EventId);
#if (DEM_CFG_OBD_PDTC_VISIBILITY == DEM_CFG_OBD_PDTC_VISIBILITY_NEXTCYCLE)
        Dem_ObdPdtcMemSetState(PdtcLocFound, OBD_PDTC_LOCID_STATE_MILON);
#else
        Dem_ObdPdtcMemSetState(PdtcLocFound, OBD_PDTC_LOCID_STATE_MILON_VISIBLE_0A);
#endif
        Dem_ObdPdtcMemSetStorageState(PdtcLocFound, OBD_PDTC_LOCID_STORAGE_PENDING);
    }
}


void Dem_ObdPdtcMemClearDiagnosticInformation (void)
{
    Dem_ObdPdtcMemIterator PdtcIt;
    uint16_least PdtcLocIt;
    uint16_least LocId;

    for ( Dem_ObdPdtcMemLocIteratorNew(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorIsValid(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorNext(&PdtcIt)
    )
    {
        PdtcLocIt = Dem_ObdPdtcMemLocIteratorCurrent(&PdtcIt);

        /* if PDTC is illuminating the Mil -> move to shadow memory */
        if (       (Dem_ObdPdtcMemGetState(PdtcLocIt) == OBD_PDTC_LOCID_STATE_MILON_VISIBLE_0A)
                || (Dem_ObdPdtcMemGetState(PdtcLocIt) == OBD_PDTC_LOCID_STATE_MILON)
        )
        {

            LocId = Dem_EvMemGetEventMemoryLocIdOfEvent(Dem_ObdPdtcMemGetEventId(PdtcLocIt), DEM_CFG_EVMEM_MEMID_PRIMARY);

            if (!Dem_EvMemIsEventMemLocIdValid(LocId)) /* EventId deleted from failure memory */
            {
                Dem_ObdPdtcMemSetState(PdtcLocIt, OBD_PDTC_LOCID_STATE_MILOFF_VISIBLE_0A);
                Dem_ObdPdtcMemSetStorageState(PdtcLocIt, OBD_PDTC_LOCID_STORAGE_PENDING);
            }
        }
    }
}


void Dem_ObdPdtcMemClearLocation (uint16_least LocId)
{
    DEM_MEMSET(&Dem_ObdPdtcMem[LocId], 0, DEM_SIZEOF_TYPE(Dem_ObdPdtcMemType));
    Dem_ObdPdtcMemSetStorageState(LocId, OBD_PDTC_LOCID_STORAGE_PENDING);
}


void Dem_ObdPdtcMemClearAllLocations (void)
{
    Dem_ObdPdtcMemIterator PdtcIt;
    uint16_least PdtcLocIt;

    DEM_MEMSET(&Dem_ObdPdtcMem[0], 0, DEM_CFG_PERMANENT_MEMORY_SIZE * DEM_SIZEOF_TYPE(Dem_ObdPdtcMemType));

    for ( Dem_ObdPdtcMemLocIteratorNew(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorIsValid(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorNext(&PdtcIt)
    )
    {
        PdtcLocIt = Dem_ObdPdtcMemLocIteratorCurrent(&PdtcIt);
        Dem_ObdPdtcMemSetStorageState(PdtcLocIt, OBD_PDTC_LOCID_STORAGE_PENDING);
    }
}


Dem_boolean_least Dem_ObdPdtcMemIsEvtPdtc (Dem_EventIdType EventId)
{
    /* Note: this function does not consider event combination, as it is called by EvMem (event combination already considered).
     * If event combination shall be considered, use Dem_ObdPdtcMemIsPdtc */

    Dem_boolean_least PdtcFound = FALSE;
    Dem_ObdPdtcMemIterator PdtcIt;
    uint16_least PdtcLocIt;

    for ( Dem_ObdPdtcMemLocIteratorNew(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorIsValid(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorNext(&PdtcIt)
    )
    {
        PdtcLocIt = Dem_ObdPdtcMemLocIteratorCurrent(&PdtcIt);

        if (Dem_ObdPdtcMemGetState(PdtcLocIt) != OBD_PDTC_LOCID_STATE_EMPTY)
        {
            if (Dem_ObdPdtcMemGetEventId(PdtcLocIt) == EventId)
            {
                PdtcFound = TRUE;
                break;
            }
        }
    }
    return PdtcFound;
}


Dem_boolean_least Dem_ObdPdtcMemIsEvtPdtcServ0A(Dem_EventIdType EventId)
{
    /* Note: this function does not consider event combination, as it is called by EvMem (event combination already considered).
     * If event combination shall be considered, use Dem_ObdPdtcMemIsPdtcServ0A*/

    Dem_boolean_least PdtcFound = FALSE;
    Dem_ObdPdtcMemIterator PdtcIt;
    uint16_least PdtcLocIt;

    for ( Dem_ObdPdtcMemLocIteratorNew(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorIsValid(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorNext(&PdtcIt)
    )
    {
        PdtcLocIt = Dem_ObdPdtcMemLocIteratorCurrent(&PdtcIt);

        if (     (Dem_ObdPdtcMemGetState(PdtcLocIt) == OBD_PDTC_LOCID_STATE_MILON_VISIBLE_0A)
                || (Dem_ObdPdtcMemGetState(PdtcLocIt) == OBD_PDTC_LOCID_STATE_MILOFF_VISIBLE_0A))
        {
            if (Dem_ObdPdtcMemGetEventId(PdtcLocIt) == EventId)
            {
                PdtcFound = TRUE;
                break;
            }
        }
    }
    return PdtcFound;
}


Dem_boolean_least Dem_ObdPdtcMemIsPdtc (Dem_DtcIdType DtcId)
{
    Dem_boolean_least PdtcFound = FALSE;
    Dem_ObdPdtcMemIterator PdtcIt;
    uint16_least PdtcLocIt;

    for ( Dem_ObdPdtcMemLocIteratorNew(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorIsValid(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorNext(&PdtcIt)
    )
    {
        PdtcLocIt = Dem_ObdPdtcMemLocIteratorCurrent(&PdtcIt);

        if (Dem_ObdPdtcMemGetState(PdtcLocIt) != OBD_PDTC_LOCID_STATE_EMPTY)
        {
            if (Dem_DtcIdFromEventId(Dem_ObdPdtcMemGetEventId(PdtcLocIt)) == DtcId)
            {
                PdtcFound = TRUE;
                break;
            }
        }
    }
    return PdtcFound;
}


Dem_boolean_least Dem_ObdPdtcMemIsPdtcServ0A(Dem_DtcIdType DtcId)
{
    Dem_boolean_least PdtcFound = FALSE;
    Dem_ObdPdtcMemIterator PdtcIt;
    uint16_least PdtcLocIt;

    for ( Dem_ObdPdtcMemLocIteratorNew(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorIsValid(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorNext(&PdtcIt)
    )
    {
        PdtcLocIt = Dem_ObdPdtcMemLocIteratorCurrent(&PdtcIt);

        if (     (Dem_ObdPdtcMemGetState(PdtcLocIt) == OBD_PDTC_LOCID_STATE_MILON_VISIBLE_0A)
                || (Dem_ObdPdtcMemGetState(PdtcLocIt) == OBD_PDTC_LOCID_STATE_MILOFF_VISIBLE_0A))
        {
            if (Dem_DtcIdFromEventId(Dem_ObdPdtcMemGetEventId(PdtcLocIt)) == DtcId)
            {
                PdtcFound = TRUE;
                break;
            }
        }
    }
    return PdtcFound;
}

Dem_boolean_least Dem_ObdPdtcMemLocIsNotEmpty(uint16_least LocId)
{
    return (Dem_ObdPdtcMemGetState(LocId) != OBD_PDTC_LOCID_STATE_EMPTY);
}


Dem_boolean_least Dem_ObdPdtcMemLocIsEventVisibleServ0A(uint16_least LocId)
{
    return ((Dem_ObdPdtcMemGetState(LocId) == OBD_PDTC_LOCID_STATE_MILON_VISIBLE_0A)
            ||  (Dem_ObdPdtcMemGetState(LocId) == OBD_PDTC_LOCID_STATE_MILOFF_VISIBLE_0A));
}

static void Dem_ObdPdtcMemUpdateVisibility (void)
{
    Dem_ObdPdtcMemIterator PdtcIt;
    uint16_least PdtcLocIt;

    for ( Dem_ObdPdtcMemLocIteratorNew(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorIsValid(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorNext(&PdtcIt)
    )
    {
        PdtcLocIt = Dem_ObdPdtcMemLocIteratorCurrent(&PdtcIt);

        if (Dem_ObdPdtcMemGetState(PdtcLocIt) == OBD_PDTC_LOCID_STATE_MILON)
        {
            /* enable mode visibility for service $0A */
            Dem_ObdPdtcMemSetState(PdtcLocIt, OBD_PDTC_LOCID_STATE_MILON_VISIBLE_0A);
            Dem_ObdPdtcMemSetStorageState(PdtcLocIt, OBD_PDTC_LOCID_STORAGE_PENDING);
        }
    }
}


void Dem_ObdPdtcMemInit (void)
{
    Dem_boolean_least EventFound = FALSE;
    Dem_ObdPdtcMemIterator PdtcIt;
    uint16_least PdtcLocIt;
    uint16_least EvMemLocId, EvMemLocIdStatus;
    uint16_least EvMemMemId = DEM_CFG_EVMEM_MEMID_PRIMARY; /* for now only primary memory supported */

    /* plausibility check for entries */
    for ( Dem_ObdPdtcMemLocIteratorNew(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorIsValid(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorNext(&PdtcIt)
    )
    {
        PdtcLocIt = Dem_ObdPdtcMemLocIteratorCurrent(&PdtcIt);

        if (     (  (!Dem_isEventIdValid(Dem_ObdPdtcMemGetEventId(PdtcLocIt)))
                &&  (Dem_ObdPdtcMemGetState(PdtcLocIt) != OBD_PDTC_LOCID_STATE_EMPTY)
        )
                || (     (Dem_ObdPdtcMemGetState(PdtcLocIt) != OBD_PDTC_LOCID_STATE_EMPTY)
                        && (Dem_ObdPdtcMemGetState(PdtcLocIt) != OBD_PDTC_LOCID_STATE_MILON)
                        && (Dem_ObdPdtcMemGetState(PdtcLocIt) != OBD_PDTC_LOCID_STATE_MILON_VISIBLE_0A)
                        && (Dem_ObdPdtcMemGetState(PdtcLocIt) != OBD_PDTC_LOCID_STATE_MILOFF_VISIBLE_0A)
                )
        )
        {
            Dem_ObdPdtcMemClearLocation(PdtcLocIt);
        }
    }

    /* update visibility of permanent DTCs if necessary */
    Dem_ObdPdtcMemUpdateVisibility();

    /* plausibility check for MIL ON events that are not stored in failure memory*/
    for ( Dem_ObdPdtcMemLocIteratorNew(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorIsValid(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorNext(&PdtcIt)
    )
    {
        PdtcLocIt = Dem_ObdPdtcMemLocIteratorCurrent(&PdtcIt);
        EventFound = FALSE;

        if (        (Dem_ObdPdtcMemGetState(PdtcLocIt) == OBD_PDTC_LOCID_STATE_MILON)
                ||  (Dem_ObdPdtcMemGetState(PdtcLocIt) == OBD_PDTC_LOCID_STATE_MILON_VISIBLE_0A)
        )
        {
            for (   Dem_EvMemEventMemoryLocIteratorNew    (&EvMemLocId, EvMemMemId);
                    Dem_EvMemEventMemoryLocIteratorIsValid(&EvMemLocId, EvMemMemId);
                    Dem_EvMemEventMemoryLocIteratorNext   (&EvMemLocId, EvMemMemId))
            {
                if (Dem_DtcIdFromEventId(Dem_ObdPdtcMemGetEventId(PdtcLocIt)) == Dem_DtcIdFromEventId(Dem_EvMemGetEventMemEventId(EvMemLocId)))
                {
                    EventFound = TRUE;
                    break;
                }
            }

            if (!EventFound)
            {
                /* Set PDTC state to OFF if event is not stored in failure memory */
                Dem_ObdPdtcMemSetState(PdtcLocIt, OBD_PDTC_LOCID_STATE_MILOFF_VISIBLE_0A);
            }
        }
    }

    /* event is in failure memory, illuminates the MIL and is not marked as PDTC */
    for (   Dem_EvMemEventMemoryLocIteratorNew    (&EvMemLocId, EvMemMemId);
            Dem_EvMemEventMemoryLocIteratorIsValid(&EvMemLocId, EvMemMemId);
            Dem_EvMemEventMemoryLocIteratorNext   (&EvMemLocId, EvMemMemId))
    {
        EvMemLocIdStatus = Dem_EvMemGetEventMemStatus(EvMemLocId);

        if (Dem_EvMemIsStored(EvMemLocIdStatus))
        {
            if (Dem_ObdMilIsEvMemLocRequestingMil(EvMemLocId, EvMemMemId))
            {
                Dem_ObdPdtcMemStoreNewEventId(Dem_EvMemGetEventMemEventId(EvMemLocId));
            }
        }
    }
}


void Dem_ObdPdtcMemStartIgnitionCycle (void)
{
    Dem_ObdPdtcMemUpdateVisibility();
}


void Dem_ObdPdtcMemStartDrivingCycle (void)
{
    Dem_ObdPdtcMemIterator PdtcIt;
    uint16_least PdtcLocIt;
    uint16_least EvMemLocId, EvMemLocIdStatus;
    uint16_least EvMemMemId = DEM_CFG_EVMEM_MEMID_PRIMARY; /* for now only primary memory supported */
#if (DEM_CFG_EVCOMB == DEM_CFG_EVCOMB_TYPE1)
    Dem_EventIdListIterator EventIt;
#endif
    Dem_boolean_least anyEventMilOn = FALSE;

    /********************************************************/
    /**** UPDATE STATUS OF CURRENT PERMANENT DTC ENTRIES ****/
    /********************************************************/
    for ( Dem_ObdPdtcMemLocIteratorNew(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorIsValid(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorNext(&PdtcIt)
    )
    {
        PdtcLocIt = Dem_ObdPdtcMemLocIteratorCurrent(&PdtcIt);

        /* check if PDTC should be deleted after MIL healing (normal operation) */
        if (Dem_ObdPdtcMemGetState(PdtcLocIt) == OBD_PDTC_LOCID_STATE_MILON_VISIBLE_0A)
        {
#if (DEM_CFG_EVCOMB == DEM_CFG_EVCOMB_TYPE1)
            for ( Dem_EventIdListIteratorNewFromDtcId(&EventIt, Dem_DtcIdFromEventId(Dem_ObdPdtcMemGetEventId(PdtcLocIt)));
                    Dem_EventIdListIteratorIsValid(&EventIt);
                    Dem_EventIdListIteratorNext(&EventIt)
            )
            {
                /* Event combination type 1: all events mapped to the DTC shall be be healed */
                anyEventMilOn = (anyEventMilOn) || (Dem_ObdEvtIsRequestingMil(Dem_EventIdListIteratorCurrent(&EventIt)));
            }
#else
            /* Event combination type 2 or no combination: each PDTC is healed separately */
            anyEventMilOn = Dem_ObdEvtIsRequestingMil(Dem_ObdPdtcMemGetEventId(PdtcLocIt));
#endif

            if (!anyEventMilOn)
            {
                Dem_ObdPdtcMemClearLocation(PdtcLocIt);
            }
        }

        /* check if PDTC should be deleted if failure memory has been cleared
         * (healing conditions: 1 DCY with "test passed" and PFC cycle has been set) */
        if (Dem_ObdPdtcMemGetState(PdtcLocIt) == OBD_PDTC_LOCID_STATE_MILOFF_VISIBLE_0A)
        {
            /* check healing conditions */
            if (Dem_ObdPdtcMemIsTestFailedThisDCY(PdtcLocIt))
            {
                Dem_ObdPdtcMemResetHealingConditions(PdtcLocIt);
            }
            else
            {
                if (!Dem_ObdPdtcMemIsOkCycleSet(PdtcLocIt))
                {
                    if (Dem_ObdPdtcMemIsTestCompleteThisDCY(PdtcLocIt))
                    {
                        Dem_ObdPdtcMemSetOkCycle(PdtcLocIt);
                        Dem_ObdPdtcMemSetStorageState(PdtcLocIt, OBD_PDTC_LOCID_STORAGE_PENDING);
                    }
                }

                if (!Dem_ObdPdtcMemIsPfcCycleSet(PdtcLocIt))
                {
                    if (Dem_ObdPdtcMemIsPfcCycleQualified())
                    {
                        Dem_ObdPdtcMemSetPfcCycle(PdtcLocIt);
                        Dem_ObdPdtcMemSetStorageState(PdtcLocIt, OBD_PDTC_LOCID_STORAGE_PENDING);
                    }
                }

                /* delete PDTC if general denominator has been set and monitoring has report PASSED
                 * (in any DC after clearing the failure memory) */
                if (Dem_ObdPdtcMemIsPfcCycleSet(PdtcLocIt) && Dem_ObdPdtcMemIsOkCycleSet(PdtcLocIt))
                {
                    Dem_ObdPdtcMemClearLocation(PdtcLocIt);
                }
            }
        }

        /* reset status bits "this driving cycle" */
        Dem_ObdPdtcMemSetTestFailedThisDCY(PdtcLocIt, FALSE);
        Dem_ObdPdtcMemSetTestCompleteThisDCY(PdtcLocIt, FALSE);
    }


    /********************************************************/
    /******** CHECK IF OTHER DTCS SHALL BE PERMANENT ********/
    /* use case: more events in EvMem than PdtcMem size     */
    /*           and healing of some of them at DCY start   */
    /********************************************************/
    for (Dem_EvMemEventMemoryLocIteratorNew    (&EvMemLocId, EvMemMemId);
            Dem_EvMemEventMemoryLocIteratorIsValid(&EvMemLocId, EvMemMemId);
            Dem_EvMemEventMemoryLocIteratorNext   (&EvMemLocId, EvMemMemId))
    {
        EvMemLocIdStatus = Dem_EvMemGetEventMemStatus(EvMemLocId);

        if (Dem_EvMemIsStored(EvMemLocIdStatus))
        {
            if (Dem_ObdMilIsEvMemLocRequestingMil(EvMemLocId, EvMemMemId))
            {
                Dem_ObdPdtcMemStoreNewEventId(Dem_EvMemGetEventMemEventId(EvMemLocId));
            }
        }
    }

    Dem_ObdPdtcMemSetPfcCycleQualified(FALSE);
}


Std_ReturnType Dem_SetPfcCycleQualified (void)
{
    Dem_ObdPdtcMemSetPfcCycleQualified(TRUE);
    return E_OK;
}


Std_ReturnType Dem_GetPfcCycleQualified(boolean *isqualified)
{
    *isqualified = (boolean)Dem_ObdPdtcMemIsPfcCycleQualified();

    return E_OK;
}


DEM_INLINE Dem_boolean_least Dem_ObdPdtcMemIsStorageBufferAvailable (void)
{
    return (!Dem_ObdPdtcMemStorageBuffer.Busy);
}


DEM_INLINE void Dem_ObdPdtcMemCopyToStorageBuffer (uint16_least LocId)
{
    Dem_ObdPdtcMemStorageBuffer.LocId = (uint16) LocId;
    Dem_ObdPdtcMemStorageBuffer.Data = Dem_ObdPdtcMem[LocId];
    Dem_ObdPdtcMemStorageBuffer.Busy = TRUE;
}


DEM_INLINE void Dem_ObdPdtcMemReleaseStorageBuffer (void)
{
    Dem_ObdPdtcMemStorageBuffer.Busy = FALSE;
}


DEM_INLINE void Dem_ObdPdtcMemStorageBufferMainFunction (void)
{
    if (Dem_ObdPdtcMemStorageBuffer.Busy)
    {
        if (Dem_NvmGetStatus(Dem_ObdPdtcMemNvmId[Dem_ObdPdtcMemStorageBuffer.LocId]) != DEM_NVM_PENDING)
        {
            Dem_ObdPdtcMemStorageBuffer.Busy = FALSE;
        }
    }
}


Dem_boolean_least Dem_ObdPdtcMemIsNvmImmediateStoragePending (Dem_boolean_least *anyFailed)
{
    Dem_NvmResultType nvmStatus;
    Dem_ObdPdtcMemIterator PdtcIt;
    uint16_least PdtcLocIt;

    Dem_boolean_least Pending = FALSE;

    for ( Dem_ObdPdtcMemLocIteratorNew(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorIsValid(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorNext(&PdtcIt)
    )
    {
        PdtcLocIt = Dem_ObdPdtcMemLocIteratorCurrent(&PdtcIt);
        nvmStatus = Dem_NvmGetStatus(Dem_ObdPdtcMemNvmId[PdtcLocIt]);
        Pending = (Dem_boolean_least) (Pending
                || (nvmStatus == DEM_NVM_PENDING)
                || (Dem_ObdPdtcMemGetStorageState(PdtcLocIt) == OBD_PDTC_LOCID_STORAGE_PENDING));
        *anyFailed = (*anyFailed) || (nvmStatus == DEM_NVM_FAILED);
    }
    return Pending;
}


void Dem_ObdPdtcMemDeleteEvent (Dem_EventIdType EventId)
{
    /* Note: this function does not consider event combination, as it is called by EvMem (event combination already considered). */

    Dem_ObdPdtcMemIterator PdtcIt;
    uint16_least PdtcLocIt;

    for ( Dem_ObdPdtcMemLocIteratorNew(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorIsValid(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorNext(&PdtcIt)
    )
    {
        PdtcLocIt = Dem_ObdPdtcMemLocIteratorCurrent(&PdtcIt);

        if (Dem_ObdPdtcMemGetState(PdtcLocIt) != OBD_PDTC_LOCID_STATE_EMPTY)
        {
            if (Dem_ObdPdtcMemGetEventId(PdtcLocIt) == EventId)
            {
                Dem_ObdPdtcMemClearLocation(PdtcLocIt);
                break;
            }
        }
    }
}


void Dem_ObdPdtcMemMainFunction (void)
{
    Dem_ObdPdtcMemIterator PdtcIt;
    uint16_least PdtcLocIt;
    Dem_NvmReturnType writeAccepted;
    uint8 statusByte;
    if(!Dem_GetEvMemLock())
    {
        for ( Dem_ObdPdtcMemLocIteratorNew(&PdtcIt);
                Dem_ObdPdtcMemLocIteratorIsValid(&PdtcIt);
                Dem_ObdPdtcMemLocIteratorNext(&PdtcIt)
        )
        {
            PdtcLocIt = Dem_ObdPdtcMemLocIteratorCurrent(&PdtcIt);

            if (Dem_ObdPdtcMemGetState(PdtcLocIt) != OBD_PDTC_LOCID_STATE_EMPTY)
            {

                /***** Update of "TestComplete this driving cycle" and "TestFailed this driving cycle" *****/

#if (DEM_CFG_EVCOMB == DEM_CFG_EVCOMB_TYPE1)
                statusByte = Dem_DtcStatusByteRetrieve(Dem_DtcIdFromEventId(Dem_ObdPdtcMemGetEventId(PdtcLocIt)));
#else
                statusByte = Dem_EvtGetIsoByte(Dem_ObdPdtcMemGetEventId(PdtcLocIt));
#endif
                if (!Dem_ObdPdtcMemIsTestCompleteThisDCY(PdtcLocIt))
                {
                    if ((statusByte & DEM_ISO14229_BM_TESTNOTCOMPLETE_TOC) == 0)
                    {
                        Dem_ObdPdtcMemSetTestCompleteThisDCY(PdtcLocIt, TRUE);
                        Dem_ObdPdtcMemSetStorageState(PdtcLocIt, OBD_PDTC_LOCID_STORAGE_PENDING);
                    }
                }

                if (!Dem_ObdPdtcMemIsTestFailedThisDCY(PdtcLocIt))
                {
                    if ((statusByte & DEM_ISO14229_BM_TESTFAILED) == DEM_ISO14229_BM_TESTFAILED)
                    {
                        Dem_ObdPdtcMemSetTestFailedThisDCY(PdtcLocIt, TRUE);
                        Dem_ObdPdtcMemSetStorageState(PdtcLocIt, OBD_PDTC_LOCID_STORAGE_PENDING);
                    }
                }
            }

            /***** NvM Storage handling (immediate) *****/

            Dem_ObdPdtcMemStorageBufferMainFunction();

            if (Dem_ObdPdtcMemGetStorageState(PdtcLocIt) == OBD_PDTC_LOCID_STORAGE_PENDING)
            {
                if (Dem_ObdPdtcMemIsStorageBufferAvailable())
                {
                    /* copy data to buffer and clear flag*/
                    Dem_ObdPdtcMemCopyToStorageBuffer(PdtcLocIt);
                    Dem_ObdPdtcMemSetStorageState(PdtcLocIt, OBD_PDTC_LOCID_STORAGE_IDLE);

                    writeAccepted = Dem_NvmWrite(Dem_ObdPdtcMemNvmId[PdtcLocIt], &Dem_ObdPdtcMemStorageBuffer.Data);

                    /* if NvM_Write was not successful, reset the flag */
                    if (writeAccepted != DEM_NVM_TRANSACTIONACCEPTED)
                    {
                        Dem_ObdPdtcMemSetStorageState(PdtcLocIt, OBD_PDTC_LOCID_STORAGE_PENDING);
                        Dem_ObdPdtcMemReleaseStorageBuffer();
                    }
                }
            }
        }
    }
}


void Dem_ObdPdtcMemShutdown (void)
{
    Dem_ObdPdtcMemIterator PdtcIt;
    uint16_least PdtcLocIt;
    Std_ReturnType stateChanged;

    for ( Dem_ObdPdtcMemLocIteratorNew(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorIsValid(&PdtcIt);
            Dem_ObdPdtcMemLocIteratorNext(&PdtcIt)
    )
    {
        PdtcLocIt = Dem_ObdPdtcMemLocIteratorCurrent(&PdtcIt);

        if (Dem_ObdPdtcMemGetStorageState(PdtcLocIt) == OBD_PDTC_LOCID_STORAGE_PENDING)
        {
            /* trigger NvM storage */
            stateChanged = Dem_NvmSetChanged(Dem_ObdPdtcMemNvmId[PdtcLocIt], TRUE);
            if (stateChanged == E_OK)
            {
                Dem_ObdPdtcMemSetStorageState(PdtcLocIt, OBD_PDTC_LOCID_STORAGE_IDLE);
            }
        }
    }
}
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
#endif /* (DEM_CFG_OBD != DEM_CFG_OBD_OFF) */

/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.10.0.0; 6     10.07.2015 CLH2SI
 *   CSCRM00938605
 * 
 * AR40.10.0.0; 5     09.07.2015 RPV5COB
 *   CSCRM00791814
 * 
 * AR40.10.0.0; 4     17.06.2015 LIB8FE
 *   CSCRM00764040
 * 
 * AR40.10.0.0; 3     17.06.2015 BPE4COB
 *   CSCRM00835665
 * 
 * AR40.10.0.0; 2     12.05.2015 CLH2SI
 *   CSCRM00789099
 * 
 * AR40.10.0.0; 1     11.05.2015 LIB8FE
 *   CSCRM00876812
 * 
 * AR40.10.0.0; 0     17.03.2015 TVE5COB
 *   CSCRM00789300
 * 
 * AR40.9.0.0; 6     15.01.2015 LIB8FE
 *   CSCRM00771713
 * 
 * AR40.9.0.0; 5     14.01.2015 TVE5COB
 *   CSCRM00769536
 * 
 * AR40.9.0.0; 4     13.01.2015 GJ83ABT
 *   CSCRM00771175
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
