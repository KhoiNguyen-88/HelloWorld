/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:H$
 * $Name______:Dem_ObdDemPids$
 * $Variant___:AR40.10.0.0$
 * $Revision__:1$
 **********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_OBDDEMPIDS_H
#define DEM_OBDDEMPIDS_H

#include "Dem_Types.h"


#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)

#include "Dem_Cfg_ObdMain.h"
#include "Dem_EnvDataElement.h"
#include "Dem_GenericNvData.h"
#include "Dem_ObdMil.h"
#include "Dem_ObdRdy_Prv.h"
#include "Dem_ObdEvents.h"
#include "Dem_ObdDTCs.h"


/* Defines */
#define DEM_OBDDEMPIDS_MAXUINT8                 0xFF
#define DEM_OBDDEMPIDS_MAXUINT16                0xFFFF
#define DEM_OBDDEMPIDS_MAXUINT32                0xFFFFFFFF


#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


/* Functions */
void Dem_ObdDemPidsInit (void);
void Dem_ObdDemPidsMainFunction (void);
void Dem_ObdDemPidsClearDiagnosticInformation (void);
void Dem_ObdDemPidsStartWarmupCycle (void);
void Dem_ObdDemPidsComputePid01ByteA (void);


DEM_INLINE void Dem_ObdDemPidsUpdateNvMData (void)
{
    Dem_NvGenericNvmWriteNotification();
}


/**
 * @ingroup DEM_H
 *
 * API to report the current calculated load value as taken for OBD FreezeFrame (PID 0x04)
 *
 * @param [out] DestBuffer: Buffer containing the contents of PID $04 computed by any SW-C.
 *                          The buffer is provided by the SW-C with the appropriate size.
 *
 * @return  E_OK if SW-C function is available
 */
Std_ReturnType Dem_GetCurrLoadCond (uint8* DestBuffer );


/**
 * @ingroup DEM_H
 *
 * API to report the current engine coolant temperature as taken for OBD FreezeFrame (PID 0x05)
 *
 * @param [out] DestBuffer: Buffer containing the contents of PID $05 computed by any SW-C.
 *                          The buffer is provided by the SW-C with the appropriate size.
 *
 * @return  E_OK if SW-C function is available
 */
Std_ReturnType Dem_GetCurrCoolTemp (uint8* DestBuffer );


/**
 * @ingroup DEM_H
 *
 * API to report the current engine RPM as taken for OBD FreezeFrame (PID 0x0C)
 *
 * @param [out] DestBuffer: Buffer containing the contents of PID $0C computed by any SW-C.
 *                          The buffer is provided by the SW-C with the appropriate size.
 *
 * @return  E_OK if SW-C function is available
 */
Std_ReturnType Dem_GetCurrEngineSpeed (uint8* DestBuffer );


/**
 * @ingroup DEM_H
 *
 * Set the Mil status for calculation of PIDs 21 and 4D.
 * Usually only the OBD master ECU will need this functionality,
 * if the global mil status is not only depending on Dem events stored in the local failure memory.
 *
 * @param [in] IndicatorStatus Status of the indicator, like off, on, or blinking.
 *
 * @return  Always E_OK is returned, as E_NOT_OK will never appear.
 */
Std_ReturnType Dem_ObdPidsSetExternalMilStatus (Dem_IndicatorStatusType IndicatorStatus);

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/**
 * @ingroup DEM_H
 *
 * Dem318: Service to report the value of PID $01 - Monitor status since DTCs cleared (4 bytes) - computed by the Dem.
 *
 * @param [out] PID01value Buffer containing the contents of PID $01 computed by the Dem.
 *                         The buffer is provided by the Dcm with the appropriate size, i.e.
 *                         during configuration, the Dcm identifies the required size from the
 *                         largest PID in order to configure a PIDBuffer.
 *
 * @return E_NOT_OK is returned when OBD support is not enabled in Dem. Otherwise, E_OK is returned.
 */
Std_ReturnType Dem_DcmReadDataOfPID01 (uint8* PID01value);


/**
 * @ingroup DEM_H
 *
 * Dem325: Service to report the value of PID $1C - OBD requirements to which vehicle or engine is certified (1 byte)- computed by the Dem.
 *
 * @param [out] PID1Cvalue Buffer containing the contents of PID $1C computed by the Dem.
 *                         The buffer is provided by the Dcm with the appropriate size, i.e.
 *                         during configuration, the Dcm identifies the required size from the
 *                         largest PID in order to configure a PIDBuffer.
 *
 * @return  Always E_OK is returned, as E_NOT_OK will never appear.
 */
Std_ReturnType Dem_DcmReadDataOfPID1C (uint8* PID1Cvalue);


/**
 * @ingroup DEM_H
 *
 * Dem319: Service to report the value of PID $21 - Distance Traveled While MIL is Activated (2 bytes) - computed by the Dem.
 *
 * @param [out] PID21value Buffer containing the contents of PID $21 computed by the Dem.
 *                         The buffer is provided by the Dcm with the appropriate size, i.e.
 *                         during configuration, the Dcm identifies the required size from the
 *                         largest PID in order to configure a PIDBuffer.
 *
 * @return  Always E_OK is returned, as E_NOT_OK will never appear.
 */
Std_ReturnType Dem_DcmReadDataOfPID21 (uint8* PID21value);


/**
 * @ingroup DEM_H
 *
 * Dem320: Service to report the value of PID $30 - Number of warm-ups since DTCs cleared (1 byte) - computed by the Dem.
 *
 * @param [out] PID30value Buffer containing the contents of PID $30 computed by the Dem.
 *                         The buffer is provided by the Dcm with the appropriate size, i.e.
 *                         during configuration, the Dcm identifies the required size from the
 *                         largest PID in order to configure a PIDBuffer.
 *
 * @return  Always E_OK is returned, as E_NOT_OK will never appear.
 */
Std_ReturnType Dem_DcmReadDataOfPID30 (uint8* PID30value);


/**
 * @ingroup DEM_H
 *
 * Dem321: Service to report the value of PID $31 - Distance traveled since DTCs cleared (2 bytes) - computed by the Dem.
 *
 * @param [out] PID31value Buffer containing the contents of PID $31 computed by the Dem.
 *                         The buffer is provided by the Dcm with the appropriate size, i.e.
 *                         during configuration, the Dcm identifies the required size from the
 *                         largest PID in order to configure a PIDBuffer.
 *
 * @return  Always E_OK is returned, as E_NOT_OK will never appear.
 */
Std_ReturnType Dem_DcmReadDataOfPID31 (uint8* PID31value);


/**
 * @ingroup DEM_H
 *
 * Dem322: Service to report the value of PID $41 - Monitor status this driving cycle (4 bytes) - computed by the Dem.
 *
 * @param [out] PID41value Buffer containing the contents of PID $41 computed by the Dem.
 *                         The buffer is provided by the Dcm with the appropriate size, i.e.
 *                         during configuration, the Dcm identifies the required size from the
 *                         largest PID in order to configure a PIDBuffer.
 *
 * @return E_NOT_OK is returned when support for OBD or PID$41 computation is not enabled in Dem. \n
 * Otherwise, E_OK is returned.
 */
Std_ReturnType Dem_DcmReadDataOfPID41 (uint8* PID41value);


/**
 * @ingroup DEM_H
 *
 * Dem323: Service to report the value of PID $4D - Engine run time while MIL is activated (2 bytes) - computed by the Dem.
 *
 * @param [out] PID4Dvalue Buffer containing the contents of PID $4D computed by the Dem.
 *                         The buffer is provided by the Dcm with the appropriate size, i.e.
 *                         during configuration, the Dcm identifies the required size from the
 *                         largest PID in order to configure a PIDBuffer.
 *
 * @return  Always E_OK is returned, as E_NOT_OK will never appear.
 */
Std_ReturnType Dem_DcmReadDataOfPID4D (uint8* PID4Dvalue);


/**
 * @ingroup DEM_H
 *
 * Dem324: Service to report the value of PID $4E - Engine run time since DTCs cleared (2 bytes) - computed by the Dem.
 *
 * @param [out] PID4Evalue Buffer containing the contents of PID $4E computed by the Dem.
 *                         The buffer is provided by the Dcm with the appropriate size, i.e.
 *                         during configuration, the Dcm identifies the required size from the
 *                         largest PID in order to configure a PIDBuffer.
 *
 * @return  Always E_OK is returned, as E_NOT_OK will never appear.
 */
Std_ReturnType Dem_DcmReadDataOfPID4E (uint8* PID4Evalue);


#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif /* DEM_OBDDEMPIDS_H */

/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.10.0.0; 1     17.06.2015 LIB8FE
 *   CSCRM00764040
 * 
 * AR40.10.0.0; 0     29.01.2015 LIB8FE
 *   CSCRM00683261
 * 
 * AR40.9.0.0; 3     13.01.2015 GJ83ABT
 *   CSCRM00771175
 * 
 * AR40.9.0.0; 2     06.01.2015 GJ83ABT
 *   CSCRM00751490
 * 
 * AR40.9.0.0; 1     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.9.0.0; 0     15.10.2014 GJ83ABT
 *   CSCRM00719089, CSCRM00650337, CSCRM00625552, CSCRM00434933
 * 
 * AR40.8.0.0; 1     16.06.2014 GJ83ABT
 *   CSCRM00615634, CSCRM00671513
 * 
 * AR40.8.0.0; 0     28.01.2014 GJ83ABT
 *   CSCRM00478859
 * 
 * AR40.7.0.0; 2     21.11.2013 GIN9COB
 *   CSCRM00598921
 * 
 * AR40.7.0.0; 1     18.11.2013 BPE4COB
 *   CSCRM00560880: [Dem] Provided Memmap header
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
