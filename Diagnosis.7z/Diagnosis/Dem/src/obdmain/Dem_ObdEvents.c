/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:C$
 * $Name______:Dem_ObdEvents$
 * $Variant___:AR40.9.0.0$
 * $Revision__:4$
 **********************************************************************************************************************
</BASDKey>*/

#include "Dem_ObdEvents.h"
#include "Dem_Prv_CallEvtStChngdCbk.h"


#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"


#if ((DEM_CFG_OBD != DEM_CFG_OBD_OFF) && (DEM_CFG_OBDCOMMONMILDEB == DEM_CFG_OBDCOMMONMILDEB_ON))

DEM_ARRAY_DEFINE_CONST(Dem_EventIdType, Dem_ObdAllEvtMilRepEvents, DEM_EVENTID_ARRAYLENGTH, DEM_CFG_EVENT2DEBGROUPEVENT);

#endif


#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"




#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)

void Dem_ObdEvtSetWarningIndicator (Dem_EventIdType EventId, Dem_boolean_least setOrReset)
{
    Dem_EventStatusExtendedType statusOld, statusNew, dtcStByteOld;

   DEM_ENTERLOCK_MON_BEFORE_INIT();
   Dem_StatusChange_GetOldStatus(EventId, &statusOld, &dtcStByteOld);
   if (setOrReset)
   {
       Dem_EvtSt_HandleIndicatorOn(EventId);
   }
   else
   {
       Dem_UpdateISO14229WIRStatus(EventId);
   }
   statusNew = Dem_EvtGetIsoByte(EventId);
   DEM_EXITLOCK_MON_BEFORE_INIT();

    if (statusNew != statusOld )
    {
        Dem_CallBackTriggerOnEventStatus(EventId, statusOld, statusNew, dtcStByteOld);
    }
}

#endif


#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"



/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.9.0.0; 4     15.01.2015 LIB8FE
 *   CSCRM00771713
 * 
 * AR40.9.0.0; 3     14.01.2015 TVE5COB
 *   CSCRM00769536
 * 
 * AR40.9.0.0; 2     13.01.2015 GJ83ABT
 *   CSCRM00771175
 * 
 * AR40.9.0.0; 1     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.9.0.0; 0     22.08.2014 CLH2SI
 *   CSCRM00688436
 * 
 * AR40.8.0.0; 0     19.05.2014 GJ83ABT
 *   CSCRM00615636, CSCRM00591553
 * 
 * MDG1_FORD; 0     22.04.2014 GJ83ABT
 *   first revision for Ford project
 * 
 * AR40.5.0.0; 3     22.01.2013 KAN1COB
 *   git transfer -> Commit:03ba9b4beb6ab853c12f8b3c32711045037c5c57
 * 
 * AR40.5.0.0; 2     07.01.2013 KAN1COB
 *   Git transfer - >c7b60f6605db2476a382daf05b17f6c7f088f2d2
 *   Fix- Obd Drv cycle and warmup cyce not configured in operationcycles
 *   * CSCRM00479194 - [INT-Dem] pending review findings from CSCRM00434163
 *   CSCRM00483492 - [INT-Dem] Fix findings -Vendor Specific parameters optional
 *   CSCRM00479560 - [INT-DEM] Issue from PAC_DevDiagnosis November build
 *   CSCRM00479557 - [INT-DEM] Remove compilation warnings
 *   CSCRM00484190 - [INT-Dem] Fix Medium/Strong review findings
 *   CSCRM00484194 - [INT-Dem] Fix Medium/Strong review findings
 *   CSCRM00480461 : Fix Reviewfindings : 
 *   Review12_636_COMP_Dem_AR40_5_2012-10_3.xls
 *   CSCRM00482583: OBD: Fix review findings
 *   Changes during code analysis of Defect CSCRM00467070 (DemClearDTCBehavior)
 *   QAC-warning
 *   
 *   CSCRM00479820 - [INT-FIM] Fix review findings
 *   CSCRM00479857 - [INT - FIM] remove BCT errors and warnings shown in 
 *   problemes log
 * 
 * AR40.5.0.0; 1     03.12.2012 KAN1COB
 *   
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
