/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:H$
 * $Name______:Dem_ObdEvents$
 * $Variant___:AR40.9.0.0$
 * $Revision__:4$
 **********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_OBDEVENTS_H
#define DEM_OBDEVENTS_H


#include "Dem_Types.h"
#include "Dem_Cfg_ObdMain.h"
#include "Dem_Events.h"
#include "Dem_ObdMil.h"
#include "Dem_ObdDTCs.h"


#if ((DEM_CFG_OBD != DEM_CFG_OBD_OFF) && (DEM_CFG_OBDCOMMONMILDEB == DEM_CFG_OBDCOMMONMILDEB_ON))

#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

DEM_ARRAY_DECLARE_CONST (Dem_EventIdType, Dem_ObdAllEvtMilRepEvents, DEM_EVENTID_ARRAYLENGTH);

#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

#endif

DEM_INLINE Dem_boolean_least Dem_ObdEventIsEmissionRelated (Dem_EventIdType EventId)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    return (Dem_ObdDtcIsEmissionRelated(Dem_DtcIdFromEventId(EventId)));
#else
    DEM_UNUSED_PARAM(EventId);
    return FALSE;
#endif
}


DEM_INLINE Dem_boolean_least Dem_ObdEvtIsRequestingMil (Dem_EventIdType EventId)
{
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
   if (Dem_ObdEventIsEmissionRelated(EventId))
   {
      return Dem_ObdMilIsEvtRequestingMil(EventId);
   }
   else
   {
      return FALSE;
   }
#else
    DEM_UNUSED_PARAM(EventId);
    return FALSE;
#endif
}


#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)

void Dem_ObdEvtSetWarningIndicator (Dem_EventIdType EventId, Dem_boolean_least setOrReset);


#if(DEM_CFG_OBDCOMMONMILDEB == DEM_CFG_OBDCOMMONMILDEB_ON)

/* --- Event Grouping for OBD purpose --- */
DEM_INLINE Dem_EventIdType Dem_ObdEvtGetMilRepEvent(Dem_EventIdType EventId)
{
    return Dem_ObdAllEvtMilRepEvents[EventId];
}

#endif

#endif

#endif /* DEM_OBDEVENTS_H */

/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.9.0.0; 4     15.01.2015 LIB8FE
 *   CSCRM00771713
 * 
 * AR40.9.0.0; 3     14.01.2015 TVE5COB
 *   CSCRM00769536
 * 
 * AR40.9.0.0; 2     13.01.2015 GJ83ABT
 *   CSCRM00771175
 * 
 * AR40.9.0.0; 1     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.9.0.0; 0     22.08.2014 CLH2SI
 *   CSCRM00688436
 * 
 * AR40.8.0.0; 1     16.06.2014 GJ83ABT
 *   CSCRM00615634, CSCRM00671513
 * 
 * AR40.8.0.0; 0     19.05.2014 GJ83ABT
 *   CSCRM00615636, CSCRM00591553
 * 
 * AR40.7.0.0; 2     21.11.2013 AMN2KOR
 *   CSCRM00591723
 * 
 * AR40.7.0.0; 1     24.10.2013 GJ83ABT
 *   CSCRM00467090
 * 
 * AR40.7.0.0; 0     22.10.2013 AMN2KOR
 *   CSCRM00547887
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/

