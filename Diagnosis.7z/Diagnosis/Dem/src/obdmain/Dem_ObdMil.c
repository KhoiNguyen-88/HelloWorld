/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:C$
 * $Name______:Dem_ObdMil$
 * $Variant___:AR40.9.0.0$
 * $Revision__:3$
 **********************************************************************************************************************
</BASDKey>*/

#include "Dem_ObdMil.h"
#include "Dem_ObdEvMem.h"


#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

Dem_IndicatorStatusType Dem_ObdMil;

#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


void Dem_ObdMilRequest (boolean state)
{
    if (state == TRUE)
    {
        Dem_ObdMil = DEM_INDICATOR_CONTINUOUS;
    }
    else
    {
        Dem_ObdMil = DEM_INDICATOR_OFF;
    }
}


void Dem_ObdMilInit (void)
{
    Dem_ObdMilCheckIndicatorState();
}


void Dem_ObdMilCheckIndicatorState (void)
{
    uint16_least MemId = DEM_CFG_EVMEM_MEMID_PRIMARY; /* for now only primary memory supported */
    uint16_least LocId, LocIdStatus;
    boolean MilOn = FALSE;

    for (   Dem_EvMemEventMemoryLocIteratorNew    (&LocId, MemId);
            Dem_EvMemEventMemoryLocIteratorIsValid(&LocId, MemId);
            Dem_EvMemEventMemoryLocIteratorNext   (&LocId, MemId))
    {
        LocIdStatus = Dem_EvMemGetEventMemStatus(LocId);
        if (Dem_EvMemIsStored(LocIdStatus))
        {
            if ((Dem_ObdEvMemGetMilCounter(LocId) > 0) && ((LocIdStatus & DEM_EVMEM_STSMASK_CONFIRMED) == DEM_EVMEM_STSMASK_CONFIRMED))
            {
                MilOn = TRUE;
                break;
            }
        }
    }

    Dem_ObdMilRequest(MilOn);
}


void Dem_ObdMilStartDrivingCycle (void)
{
    uint16_least MemId = DEM_CFG_EVMEM_MEMID_PRIMARY; /* for now only primary memory supported */
    uint16_least LocId, LocIdStatus;

    for (   Dem_EvMemEventMemoryLocIteratorNew    (&LocId, MemId);
            Dem_EvMemEventMemoryLocIteratorIsValid(&LocId, MemId);
            Dem_EvMemEventMemoryLocIteratorNext   (&LocId, MemId))
    {
        LocIdStatus = Dem_EvMemGetEventMemStatus(LocId);

        if (Dem_EvMemIsStored(LocIdStatus) && ((LocIdStatus & DEM_EVMEM_STSMASK_CONFIRMED) == DEM_EVMEM_STSMASK_CONFIRMED))
        {
            if (Dem_ObdEvMemGetMilCounter(LocId) > 0)
            {
                if (Dem_ObdEvMemIsTestFailedThisDCY(LocId))
                {
                    Dem_ObdEvMemSetMilCounter(LocId, DEM_OBD_MIL_HEALING_CYCLES);
                }
                else if (Dem_ObdEvMemIsTestCompleteThisDCY(LocId))
                {
                    /* test passed in last driving cycle -> decrement MIL healing counter */
                    Dem_ObdEvMemSetMilCounter(LocId, Dem_ObdEvMemGetMilCounter(LocId) - 1);

                    if (     (Dem_ObdEvMemGetMilCounter(LocId) == 0)
                            && (!Dem_EvtIsWIRExternal(Dem_EvMemGetEventMemEventId(LocId)))
                    )
                    {
                        /* Event is no more illuminating the mil -> reset warning indicator bit */
                        Dem_ObdEvtSetWarningIndicator(Dem_EvMemGetEventMemEventId(LocId), FALSE);
                    }
                }
                else
                {
                    /* do nothing if event not tested */
                }
            }
        }
    }

    Dem_ObdMilCheckIndicatorState();
}


Dem_boolean_least Dem_ObdMilIsEvtRequestingMil (Dem_EventIdType EventId)
{
    uint16_least MemId = DEM_CFG_EVMEM_MEMID_PRIMARY; /* for now only primary memory supported */
    uint16_least LocId;

    LocId = Dem_EvMemGetEventMemoryLocIdOfEvent(EventId, MemId);

   return (Dem_EvMemIsEventMemLocIdValid(LocId)) && (Dem_ObdMilIsEvMemLocRequestingMil(LocId, MemId));
}


Dem_boolean_least Dem_ObdMilIsEvMemLocRequestingMil (uint16_least LocId, uint16_least MemId)
{
    Dem_boolean_least MilRequest = FALSE;

    if (MemId == DEM_CFG_EVMEM_MEMID_PRIMARY) /* for now only primary memory supported */
    {
        if (     (Dem_EvMemIsStored(Dem_EvMemGetEventMemStatus(LocId)))
                && (Dem_ObdEvMemGetMilCounter(LocId) > 0)
                && ((Dem_EvMemGetEventMemStatus(LocId) & DEM_EVMEM_STSMASK_CONFIRMED) == DEM_EVMEM_STSMASK_CONFIRMED)
        )
        {
            MilRequest = TRUE;
        }
    }
    return MilRequest;
}

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif /* (DEM_CFG_OBD != DEM_CFG_OBD_OFF) */

/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.9.0.0; 3     15.01.2015 LIB8FE
 *   CSCRM00771713
 * 
 * AR40.9.0.0; 2     14.01.2015 TVE5COB
 *   CSCRM00769536
 * 
 * AR40.9.0.0; 1     13.01.2015 GJ83ABT
 *   CSCRM00771175
 * 
 * AR40.9.0.0; 0     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.8.0.0; 0     28.01.2014 GJ83ABT
 *   CSCRM00478859
 * 
 * AR40.7.0.0; 5     12.12.2013 GET1COB
 *   CSCRM00597621
 * 
 * AR40.7.0.0; 4     21.11.2013 GIN9COB
 *   CSCRM00598921
 * 
 * AR40.7.0.0; 3     18.11.2013 BPE4COB
 *   CSCRM00560880: [Dem] Provided Memmap header
 * 
 * AR40.7.0.0; 2     24.10.2013 GJ83ABT
 *   CSCRM00467090
 * 
 * AR40.7.0.0; 1     21.10.2013 HNH2ABT
 *   CSCRM00583641
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/

