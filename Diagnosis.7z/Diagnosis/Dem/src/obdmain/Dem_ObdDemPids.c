/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:C$
 * $Name______:Dem_ObdDemPids$
 * $Variant___:AR40.11.0.0$
 * $Revision__:0$
 **********************************************************************************************************************
 </BASDKey>*/

#include "Dem_ObdDemPids.h"
#include "Dem_EvMem.h"
#include "Rte_Dem.h"
#include "Dem_Protected.h"


#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)

#include "Mfx.h"

#define PID01_MIL_STATUS_MASK       0x80
#define PID21_MAX                   DEM_OBDDEMPIDS_MAXUINT16
#define PID30_MAX                   DEM_OBDDEMPIDS_MAXUINT8
#define PID31_MAX                   DEM_OBDDEMPIDS_MAXUINT16
#define PID4D_MAX                   DEM_OBDDEMPIDS_MAXUINT16
#define PID4E_MAX                   DEM_OBDDEMPIDS_MAXUINT16
#define DISTANCE_MAX                DEM_OBDDEMPIDS_MAXUINT32
#define TIME_MAX                    DEM_OBDDEMPIDS_MAXUINT32

#define DISTANCE_INC_STEP           1000    /* 1000 * 1 m = 1 km   */
#define TIME_INC_STEP               600     /*  600 * 1 s = 1 min  */


#ifndef DEM_CFG_OBD_DATA_PID04
#error >>>> PID04 in OBD FreezeFrame not configured, but needed for SimilarCondition interface.
#endif
#ifndef DEM_CFG_OBD_DATA_PID05
#error >>>> PID05 in OBD FreezeFrame not configured, but needed for SimilarCondition interface.
#endif
#ifndef DEM_CFG_OBD_DATA_PID0C
#error >>>> PID0C in OBD FreezeFrame not configured, but needed for SimilarCondition interface.
#endif

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

static Dem_IndicatorStatusType globalMilStatus;
static Dem_IndicatorStatusType globalMilStatusPrev;

static uint8 Dem_ObdDemPidsPid01ByteA_u8;              /* Byte A of PID$01 */
static uint32 Dem_ObdDemPids_DistanceRef_u32;          /* reference distance of last process call, set to Invalid at ECU start */
static uint32 Dem_ObdDemPids_TimeRef_u32;              /* reference time of last process call, set to Invalid at ECU start */


#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

#endif

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


/* MISRA RULE 16.7 VIOLATION: parameter  'PID01value' not made const, as it is modified when OBD is Configured ON */
Std_ReturnType Dem_DcmReadDataOfPID01 (uint8* PID01value)
{
    /* PID$01 is always supported in all OBD systems */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)

    uint32 stBuf_u32;       /* Temporary buffer for assembling the PID bytes */

    /* Get bytes B, C and D and merge with Byte A */
    stBuf_u32 = (((uint32)Dem_ObdDemPidsPid01ByteA_u8) << 24u) | (Dem_ObdRdyGetPid01ByteBCD());

    PID01value[0] = (uint8) (stBuf_u32 >> 24);
    PID01value[1] = (uint8) (stBuf_u32 >> 16);
    PID01value[2] = (uint8) (stBuf_u32 >> 8);
    PID01value[3] = (uint8) (stBuf_u32);

    return E_OK;
#else
    DEM_UNUSED_PARAM(PID01value);

    /* As per Autosar, E_NOT_OK is not at all allowed. However, Autosar 4.0.2 does not clarify what to do when OBD
     * support is not enabled. Therefore, we live with E_NOT_OK. In newer AR versions (4.1) it is mentioned that the API
     * itself is relevant only in OBD ECUS, but we support AR 4.0.2 and hence, API is present always */
    return E_NOT_OK;
#endif
}


/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is defined by AUTOSAR */
Std_ReturnType Dem_DcmReadDataOfPID1C (uint8* PID1Cvalue)
{
#if ((DEM_CFG_OBD != DEM_CFG_OBD_OFF) && (DEM_CFG_SUPPORT_PID1C == TRUE))
    *PID1Cvalue = (uint8) DEM_CFG_OBD_COMPLIANCY;
    return E_OK;
#else
    DEM_UNUSED_PARAM(PID1Cvalue);
    return E_NOT_OK;
#endif
}


/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is defined by AUTOSAR */
Std_ReturnType Dem_DcmReadDataOfPID21 (uint8* PID21value)
{
#if ((DEM_CFG_OBD != DEM_CFG_OBD_OFF) && (DEM_CFG_SUPPORT_PID21 == TRUE))
    PID21value[0] = (uint8) (Dem_GenericNvData.cntrPID21_u16 >> 8);
    PID21value[1] = (uint8) (Dem_GenericNvData.cntrPID21_u16);
    return E_OK;
#else
    DEM_UNUSED_PARAM(PID21value);
    return E_NOT_OK;
#endif
}

/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is defined by AUTOSAR */
Std_ReturnType Dem_DcmReadDataOfPID30 (uint8* PID30value)
{
#if ((DEM_CFG_OBD != DEM_CFG_OBD_OFF) && (DEM_CFG_SUPPORT_PID30 == TRUE))
    *PID30value = Dem_GenericNvData.cntrPID30_u8;
    return E_OK;
#else
    DEM_UNUSED_PARAM(PID30value);
    return E_NOT_OK;
#endif
}


/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is defined by AUTOSAR */
Std_ReturnType Dem_DcmReadDataOfPID31 (uint8* PID31value)
{
#if ((DEM_CFG_OBD != DEM_CFG_OBD_OFF) && (DEM_CFG_SUPPORT_PID31 == TRUE))
    PID31value[0] = (uint8) (Dem_GenericNvData.cntrPID31_u16 >> 8);
    PID31value[1] = (uint8) (Dem_GenericNvData.cntrPID31_u16);
    return E_OK;
#else
    DEM_UNUSED_PARAM(PID31value);
    return E_NOT_OK;
#endif
}


/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is defined by AUTOSAR */
Std_ReturnType Dem_DcmReadDataOfPID41 (uint8* PID41value)
{
#if ((DEM_CFG_OBD != DEM_CFG_OBD_OFF) && (DEM_CFG_SUPPORT_PID41 == TRUE))
    uint32 stBuf_u32; /* Temporary buffer for assembling the PID bytes */
    stBuf_u32 = Dem_ObdRdyGetPid41ByteBCD(); /* Get bytes B, C and D (Byte A is always 0 for PID$41) */

    PID41value[0] = (uint8) (stBuf_u32 >> 24);
    PID41value[1] = (uint8) (stBuf_u32 >> 16);
    PID41value[2] = (uint8) (stBuf_u32 >> 8);
    PID41value[3] = (uint8) (stBuf_u32);

    return E_OK;
#else
    DEM_UNUSED_PARAM(PID41value);

    /* As per Autosar, E_NOT_OK is not at all allowed. However, Autosar 4.0.2 does not clarify what to do when OBD
     * support is not enabled. Therefore, we live with E_NOT_OK. In newer AR versions (4.1) it is mentioned that the API
     * itself is relevant only in OBD ECUS, but we support AR 4.0.2 and hence, API is present always */
    return E_NOT_OK;
#endif
}


/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is defined by AUTOSAR */
Std_ReturnType Dem_DcmReadDataOfPID4D (uint8* PID4Dvalue)
{
#if ((DEM_CFG_OBD != DEM_CFG_OBD_OFF) && (DEM_CFG_SUPPORT_PID4D == TRUE))
    PID4Dvalue[0] = (uint8) (Dem_GenericNvData.cntrPID4D_u16 >> 8);
    PID4Dvalue[1] = (uint8) (Dem_GenericNvData.cntrPID4D_u16);
    return E_OK;
#else
    DEM_UNUSED_PARAM(PID4Dvalue);
    return E_NOT_OK;
#endif
}


/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is defined by AUTOSAR */
Std_ReturnType Dem_DcmReadDataOfPID4E (uint8* PID4Evalue)
{
#if ((DEM_CFG_OBD != DEM_CFG_OBD_OFF) && (DEM_CFG_SUPPORT_PID4E == TRUE))
    PID4Evalue[0] = (uint8) (Dem_GenericNvData.cntrPID4E_u16 >> 8);
    PID4Evalue[1] = (uint8) (Dem_GenericNvData.cntrPID4E_u16);
    return E_OK;
#else
    DEM_UNUSED_PARAM(PID4Evalue);
    return E_NOT_OK;
#endif
}


#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)


static Std_ReturnType Dem_ObdDemPidsGetTotalDistance (uint32 *totalDistance)
{
#if ((DEM_CFG_SUPPORT_PID21 == TRUE) || (DEM_CFG_SUPPORT_PID31 == TRUE))

    uint8 tempBuffer[4];

    if (Dem_Cfg_EnvDataElement[DEM_CFG_OBD_DATA_DIST].ReadExtCSFnc(tempBuffer) == E_OK)
    {
        *totalDistance = ((uint32)tempBuffer[0] << 24) | ((uint32)tempBuffer[1] << 16) | ((uint32)tempBuffer[2] << 8) | ((uint32)tempBuffer[3]);
        return E_OK;
    }
    else
    {
        return E_NOT_OK;
    }

#else
    *totalDistance = 0;
    return E_NOT_OK;
#endif
}

/* MISRA RULE 16.7 VIOLATION: parameter not made const, as it is defined by AUTOSAR */
static Std_ReturnType Dem_ObdDemPidsGetTimeSinceEngineStart (uint32 *timeSinceEngineStart)
{
#if ((DEM_CFG_SUPPORT_PID4D == TRUE) || (DEM_CFG_SUPPORT_PID4E == TRUE))

    uint8 tempBuffer[4];

    if (Dem_Cfg_EnvDataElement[DEM_CFG_OBD_DATA_ENGTIME].ReadExtCSFnc(tempBuffer) == E_OK)
    {
        *timeSinceEngineStart = ((uint32)tempBuffer[0] << 24) | ((uint32)tempBuffer[1] << 16) | ((uint32)tempBuffer[2] << 8) | ((uint32)tempBuffer[3]);
        return E_OK;
    }
    else
    {
        return E_NOT_OK;
    }

#else
    *timeSinceEngineStart = 0;
    return E_NOT_OK;
#endif
}


Std_ReturnType Dem_ObdPidsSetExternalMilStatus (Dem_IndicatorStatusType IndicatorStatus)
{
#if (DEM_CFG_OBD_PIDS_MIL == DEM_CFG_OBD_PIDS_MIL_GLOBAL)
    Dem_GenericNvData.externalMilStatus = IndicatorStatus;
    Dem_ObdDemPidsUpdateNvMData();
    return E_OK;
#else
    DEM_UNUSED_PARAM(IndicatorStatus);
    return E_NOT_OK;
#endif
}


static Std_ReturnType Dem_ObdPidsGetGlobalMilStatus (Dem_IndicatorStatusType *milStatus)
{
    Dem_IndicatorStatusType milStatus_tmp;

    if (Dem_GetIndicatorStatus(DEM_OBD_CFG_MIL_INDICATOR_ID, &milStatus_tmp) == E_OK)
    {
        *milStatus = milStatus_tmp;
    }
    else
    {
        return E_NOT_OK;
    }

#if (DEM_CFG_OBD_PIDS_MIL == DEM_CFG_OBD_PIDS_MIL_GLOBAL)
    *milStatus = (*milStatus) | Dem_GenericNvData.externalMilStatus;
#endif

    return E_OK;
}



static Std_ReturnType Dem_ObdPidsGetLocalMilStatus (Dem_IndicatorStatusType *milStatus)
{
    Dem_IndicatorStatusType milStatus_tmp;

    if (Dem_GetIndicatorStatus(DEM_OBD_CFG_MIL_INDICATOR_ID, &milStatus_tmp) == E_OK)
    {
        *milStatus = milStatus_tmp;
        return E_OK;
    }
    else
    {
        return E_NOT_OK;
    }
}


void Dem_ObdDemPidsInit (void)
{
    Dem_ObdDemPids_DistanceRef_u32 = DISTANCE_MAX;
    Dem_ObdDemPids_TimeRef_u32 = TIME_MAX;

    if (Dem_ObdPidsGetGlobalMilStatus(&globalMilStatus) == E_OK)
    {
        globalMilStatusPrev = globalMilStatus;
    }
    else
    {
        globalMilStatus = DEM_INDICATOR_OFF;
        globalMilStatusPrev = DEM_INDICATOR_OFF;
    }
}


void Dem_ObdDemPidsMainFunction (void)
{
    uint32 current_total_distance_u32 = 0;
    uint32 current_engine_time_u32 = 0;

#if (DEM_CFG_OBD_PIDS_MIL == DEM_CFG_OBD_PIDS_MIL_LOCAL)
    uint16_least LocId, LocIdStatus;
    Dem_boolean_least anyObdConfirmedFailure = FALSE;
#endif

    if (Dem_ObdPidsGetGlobalMilStatus(&globalMilStatus) != E_OK)
    {
        globalMilStatus = DEM_INDICATOR_OFF;
    }
    else if ((globalMilStatus == DEM_INDICATOR_CONTINUOUS) || (globalMilStatus == DEM_INDICATOR_BLINK_CONT))
    {
        if (globalMilStatusPrev == DEM_INDICATOR_OFF)
        {
            /* MIL status change --> reset the MIL related PID data */
#if (DEM_CFG_SUPPORT_PID21 == TRUE)
            Dem_GenericNvData.cntrPID21_u16 = 0;
#endif
#if (DEM_CFG_SUPPORT_PID4D == TRUE)
            Dem_GenericNvData.cntrPID4D_u16 = 0;
#endif
#if (DEM_CFG_OBD_PIDS_MIL == DEM_CFG_OBD_PIDS_MIL_GLOBAL)
            Dem_GenericNvData.cntrWUCnoMIL_u8 = 0;
#endif
            Dem_ObdDemPidsUpdateNvMData();
        }

        globalMilStatusPrev = globalMilStatus;
    }
    else
    {
        /* MIL Off -> check if counter shall be reset */
        /* WUC related reset of PID 21 and PID 4D */
#if (DEM_CFG_OBD_PIDS_MIL == DEM_CFG_OBD_PIDS_MIL_GLOBAL)
        /* global MIL handling - evalute the reset condition 40 WUC's without MIL activation */
        if (Dem_GenericNvData.cntrWUCnoMIL_u8 == 40)
        {
#if (DEM_CFG_SUPPORT_PID21 == TRUE)
            Dem_GenericNvData.cntrPID21_u16 = 0;
#endif
#if (DEM_CFG_SUPPORT_PID4D == TRUE)
            Dem_GenericNvData.cntrPID4D_u16 = 0;
#endif
            Dem_ObdDemPidsUpdateNvMData();
        }
#else
        /* local MIL handling - check on MIL related Events in EvMem (Mode 3 visibility) */
        if (        (FALSE)
#if (DEM_CFG_SUPPORT_PID21 == TRUE)
                ||  (Dem_GenericNvData.cntrPID21_u16 > 0)
#endif
#if (DEM_CFG_SUPPORT_PID4D == TRUE)
                ||  (Dem_GenericNvData.cntrPID4D_u16 > 0)
#endif
        )
        {
            /* loop over the whole Primary EvMem and check that no emission relevant Event is active */
            for (Dem_EvMemEventMemoryLocIteratorNew(&LocId, DEM_CFG_EVMEM_MEMID_PRIMARY);
                    Dem_EvMemEventMemoryLocIteratorIsValid(&LocId, DEM_CFG_EVMEM_MEMID_PRIMARY);
                    Dem_EvMemEventMemoryLocIteratorNext(&LocId, DEM_CFG_EVMEM_MEMID_PRIMARY))
            {
                LocIdStatus = Dem_EvMemGetEventMemStatus(LocId);

                if (Dem_EvMemIsStored(Dem_EvMemGetEventMemStatus(LocId)))
                {
                    if ((LocIdStatus & DEM_EVMEM_STSMASK_CONFIRMED) == DEM_EVMEM_STSMASK_CONFIRMED)
                    {
                        if (Dem_ObdEventIsEmissionRelated(Dem_EvMemGetEventMemEventId(LocId)))
                        {
                            anyObdConfirmedFailure = TRUE;
                            break;
                        }
                    }
                }
            }

            if (!anyObdConfirmedFailure)
            {
#if (DEM_CFG_SUPPORT_PID21 == TRUE)
                Dem_GenericNvData.cntrPID21_u16 = 0;
#endif
#if (DEM_CFG_SUPPORT_PID4D == TRUE)
                Dem_GenericNvData.cntrPID4D_u16 = 0;
#endif
                Dem_ObdDemPidsUpdateNvMData();
            }
        }
#endif
    }

    /* PID 21 and PID 31 - Distance related values */
    /* import global distance counter */
    if (Dem_ObdDemPidsGetTotalDistance(&current_total_distance_u32) == E_OK)
    {
        if (Dem_ObdDemPids_DistanceRef_u32 < DISTANCE_MAX)
        {
            if (current_total_distance_u32 > Dem_ObdDemPids_DistanceRef_u32)
            {
#if (DEM_CFG_SUPPORT_PID31 == TRUE)
                if (Dem_GenericNvData.cntrPID31_u16 < PID31_MAX)
                {
                    Dem_GenericNvData.cntrPID31_u16++;
                    Dem_ObdDemPidsUpdateNvMData();
                }
#endif
#if (DEM_CFG_SUPPORT_PID21 == TRUE)
                if ((globalMilStatus != DEM_INDICATOR_OFF) && (Dem_GenericNvData.cntrPID21_u16 < PID21_MAX))
                {
                    Dem_GenericNvData.cntrPID21_u16++;
                    Dem_ObdDemPidsUpdateNvMData();
                }
#endif

                /* update reference value for next calculation */
                Dem_ObdDemPids_DistanceRef_u32 = Mfx_Add_u32u32_u32(Dem_ObdDemPids_DistanceRef_u32, DISTANCE_INC_STEP);

            }
        }
        else
        {
            Dem_ObdDemPids_DistanceRef_u32 = current_total_distance_u32;
        }
    }
    else
    {
        /* error behaviour in case of distance information import fails, is not defined */
    }

    /* PID 4D and PID 4E - Engine Time related values */
    /* import Time Since Engine Start counter */
    if (Dem_ObdDemPidsGetTimeSinceEngineStart(&current_engine_time_u32) == E_OK)
    {
        if (Dem_ObdDemPids_TimeRef_u32 < TIME_MAX)
        {
            if (current_engine_time_u32 > Dem_ObdDemPids_TimeRef_u32)
            {
#if (DEM_CFG_SUPPORT_PID4E == TRUE)
                if (Dem_GenericNvData.cntrPID4E_u16 < PID4E_MAX)
                {
                    Dem_GenericNvData.cntrPID4E_u16++;
                    Dem_ObdDemPidsUpdateNvMData();
                }
#endif
#if (DEM_CFG_SUPPORT_PID4D == TRUE)
                if ((globalMilStatus != DEM_INDICATOR_OFF) && (Dem_GenericNvData.cntrPID4D_u16 < PID4D_MAX))
                {
                    Dem_GenericNvData.cntrPID4D_u16++;
                    Dem_ObdDemPidsUpdateNvMData();
                }
#endif

                /* update reference value for next calculation */
                Dem_ObdDemPids_TimeRef_u32 = Mfx_Add_u32u32_u32(Dem_ObdDemPids_TimeRef_u32, TIME_INC_STEP);
            }
        }
        else
        {
            Dem_ObdDemPids_TimeRef_u32 = current_engine_time_u32;
        }
    }
    else
    {
        /* error behaviour in case of Engine Time imports fails, is not defined */
    }

    /* Compute PID$01-Byte A here cyclically to enable measurement possibility. If runtime problems occur in future,
     * then this can instead be done only when PID$01 is requested and not cyclically */
    Dem_ObdDemPidsComputePid01ByteA();
}


void Dem_ObdDemPidsClearDiagnosticInformation(void)
{
    Dem_ObdDemPidsPid01ByteA_u8 = 0;
#if (DEM_CFG_SUPPORT_PID21 == TRUE)
    Dem_GenericNvData.cntrPID21_u16 = 0;
#endif
#if (DEM_CFG_OBD_PIDS_MIL == DEM_CFG_OBD_PIDS_MIL_GLOBAL)
    Dem_GenericNvData.cntrWUCnoMIL_u8 = 0;
#endif
#if (DEM_CFG_SUPPORT_PID30 == TRUE)
    Dem_GenericNvData.cntrPID30_u8 = 0;
#endif
#if (DEM_CFG_SUPPORT_PID31 == TRUE)
    Dem_GenericNvData.cntrPID31_u16 = 0;
#endif
#if (DEM_CFG_SUPPORT_PID4D == TRUE)
    Dem_GenericNvData.cntrPID4D_u16 = 0;
#endif
#if (DEM_CFG_SUPPORT_PID4E == TRUE)
    Dem_GenericNvData.cntrPID4E_u16 = 0;
#endif
    Dem_ObdDemPidsUpdateNvMData();
}


void Dem_ObdDemPidsStartWarmupCycle (void)
{
#if (DEM_CFG_SUPPORT_PID30 == TRUE)
    /* PID 30 - count the Warm-up cycle */
    /* HINT: If the MIL gets switched on, the WUC counter gets cleared inside the cyclic PID process */
    if (Dem_GenericNvData.cntrPID30_u8 < PID30_MAX)
    {
        Dem_GenericNvData.cntrPID30_u8++; /* increment warm-up-cycle */
    }
#endif

#if (DEM_CFG_OBD_PIDS_MIL == DEM_CFG_OBD_PIDS_MIL_GLOBAL)
    if ((Dem_GenericNvData.cntrWUCnoMIL_u8 < PID30_MAX) && (globalMilStatus == DEM_INDICATOR_OFF))
    {
        Dem_GenericNvData.cntrWUCnoMIL_u8++; /* increment warm-up-cycle without MIL activation - for centralized PID 21*/
    }
#endif
}


/***********************************************************************************************************************
 *                                            PID$01 Byte A computation
 **********************************************************************************************************************/
void Dem_ObdDemPidsComputePid01ByteA (void)
{
    uint16_least LocId;
    uint16_least LocIdStatus;
    Dem_EventIdType EventId;
    Dem_IndicatorStatusType stMil;
    uint8 tmpPid01ByteA_u8;

    tmpPid01ByteA_u8 = 0;

    /* loop over the whole Primary EvMem */
    for (Dem_EvMemEventMemoryLocIteratorNew     (&LocId, DEM_CFG_EVMEM_MEMID_PRIMARY);
            Dem_EvMemEventMemoryLocIteratorIsValid(&LocId, DEM_CFG_EVMEM_MEMID_PRIMARY);
            Dem_EvMemEventMemoryLocIteratorNext   (&LocId, DEM_CFG_EVMEM_MEMID_PRIMARY))
    {
        LocIdStatus = Dem_EvMemGetEventMemStatus(LocId);

        /* If the location is occupied */
        if (Dem_EvMemIsStored(LocIdStatus))
        {
            /* get Event ID of current entry */
            EventId = Dem_EvMemGetEventMemEventId(LocId);

            /* If event is mapped to emission relevant DTC and the event memory entry is in confirmed state */
            if(   (Dem_ObdEventIsEmissionRelated (EventId))
                    && ((LocIdStatus & DEM_EVMEM_STSMASK_CONFIRMED) == DEM_EVMEM_STSMASK_CONFIRMED)
            )
            {
                tmpPid01ByteA_u8++;
            }
        }
    }

    /* Get DEM MIL status (for Pid 01 only local MIL is considered) */
    if (Dem_ObdPidsGetLocalMilStatus(&stMil) == E_OK)
    {
        /* Only continuous illumination considered (DEM_INDICATOR_BLINK_CONT includes continuous too) */
        if ((stMil == DEM_INDICATOR_CONTINUOUS) || (stMil == DEM_INDICATOR_BLINK_CONT))
        {
            /* It is not expected that the number of confirmed faults will exceed 127, so direct masking without first
             * limiting to 127 is acceptable */
            tmpPid01ByteA_u8 |= (uint8)PID01_MIL_STATUS_MASK;
        }
    }

    /* update locally computed value to the actual output variable */
    Dem_ObdDemPidsPid01ByteA_u8 = tmpPid01ByteA_u8;
}


/* Interfaces for checking similar conditions */

Std_ReturnType Dem_GetCurrLoadCond(uint8* DestBuffer)
{
    uint8 tempValue;

    if (Dem_Cfg_EnvDataElement[DEM_CFG_OBD_DATA_PID04].ReadExtCSFnc(&tempValue) == E_OK)
    {
        *DestBuffer = tempValue;
        return E_OK;
    }
    else
    {
        return E_NOT_OK;
    }
}


Std_ReturnType Dem_GetCurrCoolTemp(uint8* DestBuffer)
{
    uint8 tempValue;

    if (Dem_Cfg_EnvDataElement[DEM_CFG_OBD_DATA_PID05].ReadExtCSFnc(&tempValue) == E_OK)
    {
        *DestBuffer = tempValue;
        return E_OK;
    }
    else
    {
        return E_NOT_OK;
    }
}


Std_ReturnType Dem_GetCurrEngineSpeed(uint8* DestBuffer)
{
    uint8 tempBuffer[2];

    if (Dem_Cfg_EnvDataElement[DEM_CFG_OBD_DATA_PID0C].ReadExtCSFnc(tempBuffer) == E_OK)
    {
        DestBuffer[0] = tempBuffer[0];
        DestBuffer[1] = tempBuffer[1];

        return E_OK;
    }
    else
    {
        return E_NOT_OK;
    }
}

#endif

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.11.0.0; 0     07.01.2016 TVE5COB
 *   CSCRM01017790
 * 
 * AR40.10.0.0; 0     01.04.2015 LIB8FE
 *   CSCRM00823705
 * 
 * AR40.9.0.0; 5     13.01.2015 GJ83ABT
 *   CSCRM00771175
 * 
 * AR40.9.0.0; 4     06.01.2015 GJ83ABT
 *   CSCRM00751490
 * 
 * AR40.9.0.0; 3     06.01.2015 TVE5COB
 *   CSCRM00741126
 * 
 * AR40.9.0.0; 2     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.9.0.0; 1     12.11.2014 CLH2SI
 *   CSCRM00735646
 * 
 * AR40.9.0.0; 0     15.10.2014 GJ83ABT
 *   CSCRM00719089, CSCRM00650337, CSCRM00625552, CSCRM00434933
 * 
 * AR40.8.0.0; 0     28.01.2014 GJ83ABT
 *   CSCRM00478859
 * 
 * AR40.7.0.0; 1     21.11.2013 GIN9COB
 *   CSCRM00598921
 * 
 * $
 **********************************************************************************************************************
 </BASDKey>*/
