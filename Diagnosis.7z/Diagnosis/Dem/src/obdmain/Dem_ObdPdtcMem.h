/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************
 * Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:H$
 * $Name______:Dem_ObdPdtcMem$
 * $Variant___:AR40.10.0.0$
 * $Revision__:3$
 **********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_OBDPDTCMEM_H
#define DEM_OBDPDTCMEM_H

#include "Dem_Types.h"
#include "Dem_Cfg_ObdMain.h"
#include "Dem_Nvm.h"
#include "Dem_Cfg_Nvm.h"
#include "Dem_Array.h"
#include "Dem_GenericNvData.h"
#include "Dem_Mapping.h"
#include "Dem_EventStatus.h"


#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)

/* PDTC state */
#define OBD_PDTC_LOCID_STATE_EMPTY                 0x00
#define OBD_PDTC_LOCID_STATE_MILON                 0x01
#define OBD_PDTC_LOCID_STATE_MILON_VISIBLE_0A      0x02
#define OBD_PDTC_LOCID_STATE_MILOFF_VISIBLE_0A     0x03
#define OBD_PDTC_LOCID_STATE_MASK                  0x0F

/* PDTC test status this driving cycle */
#define OBD_PDTC_LOCID_TESTFAILED_BITMASK          0x10
#define OBD_PDTC_LOCID_TESTCOMPLETE_BITMASK        0x20

/* PDTC healing conditions */
#define OBD_PDTC_LOCID_PFC_CYCLE_BITMASK           0x40
#define OBD_PDTC_LOCID_OK_CYCLE_BITMASK            0x80
#define OBD_PDTC_LOCID_HEALING_MASK                0xC0

/* NV-RAM storage state */
#define OBD_PDTC_LOCID_STORAGE_IDLE                0x00
#define OBD_PDTC_LOCID_STORAGE_PENDING             0x01

/* storage priorities */
#define OBD_PDTC_STORAGE_PRIO_UNDEF                0x00
#define OBD_PDTC_STORAGE_PRIO_EMPTY                0x01
#define OBD_PDTC_STORAGE_PRIO_STORED               0x02

#define OBD_PDTC_LOC_INVALID                       DEM_CFG_PERMANENT_MEMORY_SIZE

typedef struct
{
    uint8             state;
    Dem_EventIdType   EventId;
}  Dem_ObdPdtcMemType;

typedef uint8 Dem_ObdPdtcMemStorageStateType;

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

DEM_ARRAY_DECLARE(Dem_ObdPdtcMemStorageStateType, Dem_ObdPdtcMemStorageState, DEM_CFG_PERMANENT_MEMORY_SIZE);

#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

DEM_ARRAY_DECLARE(Dem_ObdPdtcMemType, Dem_ObdPdtcMem, DEM_CFG_PERMANENT_MEMORY_SIZE);

#define DEM_STOP_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

DEM_ARRAY_DECLARE(const Dem_NvmIdType, Dem_ObdPdtcMemNvmId, DEM_CFG_PERMANENT_MEMORY_SIZE);

#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

DEM_INLINE Dem_DtcIdType Dem_ObdPdtcMemGetEventId (uint16_least LocId)
{
    return (Dem_ObdPdtcMem[LocId].EventId);
}

DEM_INLINE void Dem_ObdPdtcMemSetEventId(uint16_least LocId, Dem_EventIdType EventId)
{
    Dem_ObdPdtcMem[LocId].EventId = EventId;
}

DEM_INLINE uint8 Dem_ObdPdtcMemGetState (uint16_least LocId)
{
    return (Dem_ObdPdtcMem[LocId].state & OBD_PDTC_LOCID_STATE_MASK);
}

DEM_INLINE void Dem_ObdPdtcMemSetState (uint16_least LocId, uint8_least state)
{
    Dem_ObdPdtcMem[LocId].state = (uint8)state;
    /* automatically delete the PFC and OK cycle flags at state change */
}

DEM_INLINE Dem_boolean_least Dem_ObdPdtcMemIsTestFailedThisDCY (uint16_least LocId)
{
    return ((Dem_ObdPdtcMem[LocId].state & OBD_PDTC_LOCID_TESTFAILED_BITMASK) == OBD_PDTC_LOCID_TESTFAILED_BITMASK);
}

DEM_INLINE Dem_boolean_least Dem_ObdPdtcMemIsTestCompleteThisDCY (uint16_least LocId)
{
    return ((Dem_ObdPdtcMem[LocId].state & OBD_PDTC_LOCID_TESTCOMPLETE_BITMASK) == OBD_PDTC_LOCID_TESTCOMPLETE_BITMASK);
}

DEM_INLINE void Dem_ObdPdtcMemSetTestFailedThisDCY (uint16_least LocId, uint8_least setOrReset)
{
    if (setOrReset)
    {
        Dem_ObdPdtcMem[LocId].state |= OBD_PDTC_LOCID_TESTFAILED_BITMASK;
    }
    else
    {
        Dem_ObdPdtcMem[LocId].state &= (~OBD_PDTC_LOCID_TESTFAILED_BITMASK);
    }
}

DEM_INLINE void Dem_ObdPdtcMemSetTestCompleteThisDCY (uint16_least LocId, uint8_least setOrReset)
{
    if (setOrReset)
    {
        Dem_ObdPdtcMem[LocId].state |= OBD_PDTC_LOCID_TESTCOMPLETE_BITMASK;
    }
    else
    {
        Dem_ObdPdtcMem[LocId].state &= (~OBD_PDTC_LOCID_TESTCOMPLETE_BITMASK);
    }
}

DEM_INLINE Dem_boolean_least Dem_ObdPdtcMemIsPfcCycleSet (uint16_least LocId)
{
    return (	(Dem_ObdPdtcMemGetState(LocId) == OBD_PDTC_LOCID_STATE_MILOFF_VISIBLE_0A)
            && ((Dem_ObdPdtcMem[LocId].state & OBD_PDTC_LOCID_PFC_CYCLE_BITMASK) == OBD_PDTC_LOCID_PFC_CYCLE_BITMASK)
    );
}

DEM_INLINE Dem_boolean_least Dem_ObdPdtcMemIsOkCycleSet (uint16_least LocId)
{
    return (Dem_boolean_least)
            (  (Dem_ObdPdtcMemGetState(LocId) == OBD_PDTC_LOCID_STATE_MILOFF_VISIBLE_0A)
                    && ((Dem_ObdPdtcMem[LocId].state & OBD_PDTC_LOCID_OK_CYCLE_BITMASK) == OBD_PDTC_LOCID_OK_CYCLE_BITMASK)
            );
}

DEM_INLINE void Dem_ObdPdtcMemSetPfcCycle (uint16_least LocId)
{
    Dem_ObdPdtcMem[LocId].state |= (uint8)OBD_PDTC_LOCID_PFC_CYCLE_BITMASK;
}

DEM_INLINE void Dem_ObdPdtcMemSetOkCycle (uint16_least LocId)
{
    Dem_ObdPdtcMem[LocId].state |= (uint8)OBD_PDTC_LOCID_OK_CYCLE_BITMASK;
}

DEM_INLINE void Dem_ObdPdtcMemResetHealingConditions (uint16_least LocId)
{
    Dem_ObdPdtcMem[LocId].state &= (uint8)(~OBD_PDTC_LOCID_HEALING_MASK);
}

DEM_INLINE void Dem_ObdPdtcMemSetStorageState(uint16_least LocId, Dem_ObdPdtcMemStorageStateType state)
{
    Dem_ObdPdtcMemStorageState[LocId] = state;
}

DEM_INLINE Dem_ObdPdtcMemStorageStateType Dem_ObdPdtcMemGetStorageState(uint16_least LocId)
{
    return (Dem_ObdPdtcMemStorageState[LocId]);
}

typedef uint16_least Dem_ObdPdtcMemIterator;

DEM_INLINE void Dem_ObdPdtcMemLocIteratorNew (Dem_ObdPdtcMemIterator *It)
{
    *It = 0;
}

DEM_INLINE Dem_boolean_least Dem_ObdPdtcMemLocIteratorIsValid (const Dem_ObdPdtcMemIterator *It)
{
    return (Dem_boolean_least)(*It < DEM_CFG_PERMANENT_MEMORY_SIZE);
}

DEM_INLINE void Dem_ObdPdtcMemLocIteratorNext (Dem_ObdPdtcMemIterator *It)
{
    (*It)++;
}

DEM_INLINE void Dem_ObdPdtcMemLocIteratorInvalidate (Dem_ObdPdtcMemIterator *It)
{
    *It = DEM_CFG_PERMANENT_MEMORY_SIZE;
}

DEM_INLINE uint16_least Dem_ObdPdtcMemLocIteratorCurrent (const Dem_ObdPdtcMemIterator *It)
{
    return (*It);
}

DEM_INLINE Dem_boolean_least Dem_ObdPdtcMemIsEventIdStored (uint16_least LocId, Dem_EventIdType EventId)
{
#if (DEM_CFG_EVCOMB == DEM_CFG_EVCOMB_TYPE1)
    return (Dem_boolean_least)(Dem_DtcIdFromEventId(Dem_ObdPdtcMemGetEventId(LocId)) == Dem_DtcIdFromEventId(EventId));
#else
    return (Dem_boolean_least)(Dem_ObdPdtcMemGetEventId(LocId) == EventId);
#endif
}

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/**
 * @ingroup DEM_H
 *
 * Dem739: Marks the current OBD driving cycle as having met the criteria for the PFC cycle.
 * API is needed in OBD-relevant ECUs only.
 *
 * @return  Always E_OK is returned, as E_NOT_OK will never appear.
 */
Std_ReturnType Dem_SetPfcCycleQualified (void);

/**
 * @ingroup DEM_H
 *
 * Dem740: Returns TRUE if the criteria for the PFC cycle have been met during the current OBD driving cycle. API is
 * needed in OBD-relevant ECUs only.
 *
 * @param [out] isqualified TRUE - During the current OBD driving cycle, the criteria for the PFC cycle have been met.
 *                          FALSE - During the current OBD driving cycle, the criteria for the PFC cycle have not been met.
 *
 * @return  Always E_OK is returned, as E_NOT_OK will never appear.
 */
Std_ReturnType Dem_GetPfcCycleQualified(boolean *isqualified);


DEM_INLINE void Dem_ObdPdtcMemSetPfcCycleQualified (Dem_boolean_least conditionActive)
{
    Dem_GenericNvData.ObdPfcCycleCondition = (boolean)conditionActive;

    /* notify to store in NVM */
    Dem_NvGenericNvmWriteNotification();
}

DEM_INLINE Dem_boolean_least Dem_ObdPdtcMemIsPfcCycleQualified (void)
{
    return Dem_GenericNvData.ObdPfcCycleCondition;
}

void Dem_ObdPdtcInitCheckNvM(void);

void Dem_ObdPdtcMemStoreNewEventId (Dem_EventIdType EventId);

void Dem_ObdPdtcMemClearDiagnosticInformation (void);
void Dem_ObdPdtcMemClearLocation (uint16_least LocId);
void Dem_ObdPdtcMemClearAllLocations (void);

Dem_boolean_least Dem_ObdPdtcMemIsPdtc (Dem_DtcIdType DtcId);
Dem_boolean_least Dem_ObdPdtcMemIsPdtcServ0A(Dem_DtcIdType DtcId);
Dem_boolean_least Dem_ObdPdtcMemLocIsNotEmpty (uint16_least LocId);
Dem_boolean_least Dem_ObdPdtcMemLocIsEventVisibleServ0A(uint16_least LocId);
Dem_boolean_least Dem_ObdPdtcMemIsEvtPdtc (Dem_EventIdType EventId);
Dem_boolean_least Dem_ObdPdtcMemIsEvtPdtcServ0A(Dem_EventIdType EventId);
void Dem_ObdPdtcMemDeleteEvent (Dem_EventIdType EventId);

Dem_boolean_least Dem_ObdPdtcMemIsNvmImmediateStoragePending (Dem_boolean_least *anyFailed);

void Dem_ObdPdtcMemInit (void);
void Dem_ObdPdtcMemStartIgnitionCycle (void);
void Dem_ObdPdtcMemStartDrivingCycle (void);
void Dem_ObdPdtcMemMainFunction (void);
void Dem_ObdPdtcMemShutdown (void);

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif /* (DEM_CFG_OBD != DEM_CFG_OBD_OFF) */

#endif /* DEM_OBDPDTCMEM_H */

/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.10.0.0; 3     10.07.2015 CLH2SI
 *   CSCRM00938605
 * 
 * AR40.10.0.0; 2     09.07.2015 RPV5COB
 *   CSCRM00791814
 * 
 * AR40.10.0.0; 1     04.07.2015 BPE4COB
 *   CSCRM00835665
 * 
 * AR40.10.0.0; 0     17.06.2015 BPE4COB
 *   CSCRM00835665
 * 
 * AR40.9.0.0; 2     23.12.2014 BPE4COB
 *   CSCRM00715627
 * 
 * AR40.9.0.0; 1     17.11.2014 GJ83ABT
 *   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
 * 
 * AR40.9.0.0; 0     25.08.2014 GJ83ABT
 *   CSCRM00617667
 * 
 * AR40.8.0.0; 3     16.06.2014 GJ83ABT
 *   CSCRM00615634, CSCRM00671513
 * 
 * AR40.8.0.0; 2     16.06.2014 BPE4COB
 *   CSCRM00666829
 * 
 * AR40.8.0.0; 1     15.05.2014 VSA2COB
 *   CSCRM00662943
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
