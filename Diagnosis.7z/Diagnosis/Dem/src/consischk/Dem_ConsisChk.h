/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_ConsisChk$
* $Variant___:AR40.11.0.0$
* $Revision__:2$
**********************************************************************************************************************
</BASDKey>*/
#ifndef DEM_CONSISCHK_H
#define DEM_CONSISCHK_H

#include "Dem_EvMemGen.h"
#include "Dem_EventStatus.h"
#include "Dem_IndicatorAttributes.h"

DEM_INLINE void Dem_StatusByteConsistencyCheck(uint16_least LocId, uint16_least Status)
{
	/* ISO Byte Consistency check: Confirmed/Pending versus TestFailedSLC/TestNotCompleteSLC */
	/* events stored in PRIMARY or SECONDARY memory ? */
	if (Dem_EvMemIsOriginPrimary(LocId) || Dem_EvMemIsOriginSecondary(LocId))
	{   /* events with PENDING or CONFIRMRD ISO bits  */
		if ((Status & (DEM_EVMEM_STSMASK_PENDING | DEM_EVMEM_STSMASK_CONFIRMED
#if (DEM_CFG_TFSLC_RESET_AFTER_AGING_AND_DISPLACEMENT)
		        | DEM_EVMEM_STSMASK_TESTFAILED_SLC
#endif
		)) != 0u)
		{   /* patch TestFailedSLC and TestNotCompleteSLC to ensure data consistency */
			Dem_EventIdType EventId;
			EventId = Dem_EvMemGetEventMemEventId(LocId);
			Dem_EvtSt_SetTestFailedSLC(EventId,TRUE);
			Dem_EvtSt_SetTestCompleteSLC(EventId,TRUE);
            if ((Status & (DEM_EVMEM_STSMASK_CONFIRMED)) != 0u)
            {
                Dem_EvtSt_SetConfirmedDTC(EventId,TRUE);
            }
            if ((Status & (DEM_EVMEM_STSMASK_PENDING)) != 0u)
            {
               Dem_EvtSt_SetPendingDTC(EventId,TRUE);
            }

            Dem_IndicatorAttribute_ConsistencyCheck(EventId, Status);

		}
	}
}

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

void Dem_ConsistencyCheckForDTC(void);

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


#endif
/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 2     11.01.2016 NAL2KOR
*   CSCRM01015983
* 
* AR40.11.0.0; 1     21.12.2015 NAL2KOR
*   CSCRM00957431
* 
* AR40.11.0.0; 0     19.10.2015 TVE5COB
*   CSCRM00957961
* 
* AR40.10.0.0; 1     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 0     17.06.2015 TVE5COB
*   CSCRM00783642
* 
* AR40.9.0.0; 1     21.11.2014 CLH2SI
*   CSCRM00712155
* 
* AR40.9.0.0; 0     22.08.2014 CLH2SI
*   CSCRM00688436
* 
* AR40.8.0.0; 0     18.04.2014 BPE4COB
*   CSCRM00581953
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
