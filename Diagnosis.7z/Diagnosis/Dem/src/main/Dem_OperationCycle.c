/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_OperationCycle$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/

#include "Std_Types.h"
#include "Dem_Cfg.h"
#include "Dem_Events.h"
#include "Dem_Main.h"
#include "Dem_Types.h"
#include "Dem_Lock.h"
#include "Dem_OperationCycle.h"
#include "Dem_Mapping.h"
#include "Dem_EventStatus.h"
#include "Dem_ISO14229Byte.h"
#include "Dem_EvMem.h"
#include "Dem_EventRecheck.h"
#include "Rte_Dem.h"
#include "Dem_Protected.h"
/* FC_VariationPoint_START */
#include "Dem_ObdMain.h"
/* FC_VariationPoint_END */
#include "Dem_GenericNvData.h"

/* FC_VariationPoint_START */
#include "Dem_Cfg_Bfm.h"
#include "Dem_BfmCounter.h"
/* FC_VariationPoint_END */

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"
Dem_OperationCycleList Dem_OperationCycleStates;
static Dem_OperationCycleList Dem_StartOperationCycleCollectedTriggers;
/* static Dem_OperationCycleList Dem_StopOperationCycleCollectedTriggers; */
#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

Std_ReturnType Dem_SetOperationCycleState (uint8 OperationCycleId, Dem_OperationCycleStateType CycleState)
{
   Std_ReturnType retVal = E_OK;
   Dem_OperationCycleList operationCycleBitmask;

   if (!Dem_IsOperationCycleIdValid(OperationCycleId))
   {
      retVal = E_NOT_OK;
   }
   else
   {
      operationCycleBitmask = (Dem_OperationCycleList)(1u << OperationCycleId);

      DEM_ENTERLOCK_MON_BEFORE_INIT();
/* FC_VariationPoint_START */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
      Dem_ObdSetOperationCycleState (&operationCycleBitmask, CycleState);
#endif
/* FC_VariationPoint_END */
      if (CycleState == DEM_CYCLE_STATE_START)
      {
         Dem_OperationCycleStates |= operationCycleBitmask;
         Dem_StartOperationCycleCollectedTriggers |= operationCycleBitmask;
      }
      else if (CycleState == DEM_CYCLE_STATE_END)
      {
         Dem_OperationCycleStates &= (Dem_OperationCycleList)(~operationCycleBitmask);
      }
      else
      {
         retVal = E_NOT_OK;
      }

      DEM_EXITLOCK_MON_BEFORE_INIT();
   }
   return retVal;
}


void Dem_OperationCyclesMainFunction(void)
{
   Dem_OperationCycleList currentTriggers;

   if (Dem_StartOperationCycleCollectedTriggers != 0)
   {
	  DEM_ENTERLOCK_MON_BEFORE_INIT();
      currentTriggers = Dem_StartOperationCycleCollectedTriggers;
      Dem_StartOperationCycleCollectedTriggers = 0;
      DEM_EXITLOCK_MON_BEFORE_INIT();
/* FC_VariationPoint_START */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
      /* check mil state before update of event status to get the state from last driving cycle! */
      Dem_ObdStartOperationCycle(currentTriggers);
#endif
/* FC_VariationPoint_END */
/* FC_VariationPoint_START */
#if( DEM_BFM_ENABLED == DEM_BFM_ON )
      Dem_BfmCounterAdvanceOperationCycle( currentTriggers );
#endif
/* FC_VariationPoint_END */
      Dem_EvMemStartOperationCycleAllMem(currentTriggers);
      Dem_EvtAdvanceOperationCycle(currentTriggers);
      Dem_RecheckNodeNotRecoverableRequest();
      /* trigger NvM storage */
#if (DEM_CFG_OPERATIONCYCLESTATUSSTORAGE == DEM_CFG_OPERATIONCYCLESTATUSSTORAGE_ON)
      Dem_GenericNvData.OperationCycleStates = Dem_OperationCycleStates;

      /* notify to store in NVM */
      Dem_NvGenericNvmWriteNotification();
#endif
   }
}

void Dem_OperationCycleInit (void)
{
#if (DEM_CFG_OPERATIONCYCLESTATUSSTORAGE == DEM_CFG_OPERATIONCYCLESTATUSSTORAGE_ON)
   DEM_ENTERLOCK_MON_BEFORE_INIT();
   Dem_OperationCycleStates |= Dem_GenericNvData.OperationCycleStates;
   DEM_EXITLOCK_MON_BEFORE_INIT();
#endif
}
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     07.01.2016 TVE5COB
*   CSCRM01017790
* 
* AR40.10.0.0; 1     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 0     16.04.2015 CLH2SI
*   CSCRM00764027
* 
* AR40.9.0.0; 0     20.08.2014 VSA2COB
*   CSCRM00698491
* 
* AR40.8.0.0; 7     18.07.2014 UDKOEGEL
*   CSCRM00533942
* 
* AR40.8.0.0; 6     16.06.2014 GJ83ABT
*   CSCRM00615634, CSCRM00671513
* 
* AR40.8.0.0; 5     16.06.2014 BPE4COB
*   CSCRM00666829
* 
* AR40.8.0.0; 4     14.06.2014 VSA2COB
*   CSCRM00672188
* 
* AR40.8.0.0; 3     22.04.2014 VSA2COB
*   CSCRM00321012
* 
* AR40.8.0.0; 2     10.03.2014 VSA2COB
*   CSCRM00619537_ComassoChanges
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
