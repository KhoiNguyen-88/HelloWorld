/* BASDKey_start */
/*<BASDKey>
 **********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 **********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
 * $Domain____:BASD$
 * $Namespace_:\Comp\Dem$
 * $Class_____:C$
 * $Name______:Dem_Main$
 * $Variant___:AR40.11.0.1$
 * $Revision__:0$
 **********************************************************************************************************************
</BASDKey>*/


#include "Dem_Main.h"
#include "Dem_Cfg_AssertionChk.h"
#include "Dem_IndicatorAttributes.h"
#include "Dem_OperationCycle.h"
#include "Dem_Clear.h"
#include "Dem_Events.h"
#include "Dem_Deb.h"
#include "Dem_EventFHandling.h"
#include "Dem_EventStatus.h"
#include "Dem_EventRecheck.h"
#include "Dem_EvBuff.h"
#include "Dem_EvBuffDistributor.h"
#include "Dem_DTCStatusByte.h"
#include "Dem_DTCFilter.h"
#include "Dem_DTCStateManager.h"
#include "Dem_EventStatus.h"
#include "Dem_EvMem.h"
#include "Dem_NvM.h"
#include "Rte_Dem.h"
#include "Dem_Protected.h"
#include "SchM_Dem.h"
#if (DEM_CFG_FIM_USED == DEM_CFG_FIM_ON)
#include "FiM.h"
#endif
#include "Dem_EvBuffDistributor.h"
#include "Dem_DisturbanceMemory.h"
/* FC_VariationPoint_START */
#include "Dem_ObdMain.h"
#include "Dem_Bfm.h"
#include "Dem_PB_Bfm.h"
/* FC_VariationPoint_END */

#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

/* FC_VariationPoint_START */
#if(DEM_BFM_ENABLED == DEM_BFM_OFF)
/* FC_VariationPoint_END */
const Dem_ConfigType Dem_ConfigAlternativeParameters = { TRUE, TRUE };
/* FC_VariationPoint_START */
#else
const Dem_ConfigType Dem_ConfigAlternativeParameters = { TRUE, TRUE, &Dem_BfmConfigParam_cs };
#endif
/* FC_VariationPoint_END */

#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

#if (DEM_CFG_VERSION_INFO_API == DEM_CFG_VERSION_INFO_API_ON)
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
void Dem_GetVersionInfo(Std_VersionInfoType* versioninfo)
{
    versioninfo->vendorID = DEM_VENDOR_ID;
    versioninfo->moduleID = DEM_MODULE_ID;
    versioninfo->sw_major_version = DEM_SW_MAJOR_VERSION;
    versioninfo->sw_minor_version = DEM_SW_MINOR_VERSION;
    versioninfo->sw_patch_version = DEM_SW_PATCH_VERSION;
}
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
#endif

/*
 #include "src\sifi\Dem_SituationFilter.h"
 */
#define DEM_START_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"
Dem_OpMoStateType Dem_OpMoState = DEM_OPMO_STATE_NOTINITIALIZED;
static boolean Dem_OpMoWasInitialized = FALSE;
#define DEM_STOP_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
void Dem_PreInit(const Dem_ConfigType* ConfigPtr)
{
    DEM_ASSERT(Dem_OpMoState==DEM_OPMO_STATE_NOTINITIALIZED, DEM_DET_APIID_PREINIT, 0);
    /*Dem_AllEventsState is a global variable, so this variable is already set to 0*/
    Dem_EvtPreInitEvents();

    Dem_PreInitErrorQueue();

    Dem_ReportErrorStatusEnableQueue();

    if (ConfigPtr != NULL_PTR)
    {
        if (ConfigPtr->debouncerAlternativeParameters) {
            Dem_DebSwitchToAlternativeParameters();
        }
#if (DEM_CFG_ALTERNATIVEDTC == DEM_CFG_ALTERNATIVEDTC_ON)
        if(ConfigPtr->dtcAlternativeParameters) {
            Dem_SwitchToAlternativeDtc();
        }
#endif
    }

/* FC_VariationPoint_START */
	#if (DEM_BFM_ENABLED == DEM_BFM_ON)
	if( ConfigPtr != NULL_PTR )
	{
		Dem_BfmPreInit( ConfigPtr->demBfmConfigPointer );
	}
	else
	{
		Dem_BfmPreInit( NULL_PTR );
	}
	#endif
/* FC_VariationPoint_END */

	Dem_OpMoState = DEM_OPMO_STATE_PREINITIALIZED;
}

/*API for locking all failure info*/
Std_ReturnType Dem_LockAllFailureInfo (void)
{
#if(DEM_CFG_LOCK_ALLFAILUREINFO == DEM_CFG_LOCK_ALLFAILUREINFO_ON)
    Dem_OpMoState = DEM_OPMO_STATE_LOCK_ALL_FAILURE_INFO;
    (void)Dem_LockEventMemory(TRUE);
    return E_OK;
#else
    return E_NOT_OK;
#endif
}

void Dem_Init(void)
{
#if(DEM_CFG_LOCK_ALLFAILUREINFO == DEM_CFG_LOCK_ALLFAILUREINFO_ON)
    if(!Dem_OpMoIsAllFailureInfoLocked())
#endif
    {
        DEM_ASSERT(Dem_OpMoState==DEM_OPMO_STATE_PREINITIALIZED, DEM_DET_APIID_INIT, 0);
        if (Dem_OpMoState == DEM_OPMO_STATE_PREINITIALIZED)
        {
            Dem_OperationCycleInit();
            Dem_ClearDtcInit();
            Dem_DtcFilterInit();
            if (!Dem_OpMoWasInitialized)
            {
                 //Set the event status to 0 for the events which are currently not available or suppressed
                Dem_EvtInitEvents();

                Dem_EventStatusInitCheckNvM();

#if(DEM_CFG_ALLOW_HISTORY == DEM_CFG_ALLOW_HISTORY_ON)
                Dem_EvtHistoryStatusInitCheckNvM();
#endif

                Dem_IndicatorAttributeInitCheckNvM();


                Dem_InitEventStatusTestFailed();
#if (DEM_CFG_DEPENDENCY == DEM_CFG_DEPENDENCY_ON)
                Dem_DependencyInit();
#endif
                Dem_EvMemInit();

             /* Required to move the indicator attribute init below Event Memory Init because of consistency check
			 * introduced for Indicator attributes in Event Memory Init */

                Dem_IndicatorAttributeInit();

#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
                Dem_ObdPdtcInitCheckNvM();
#endif

#if (DEM_CFG_FFPRESTORAGESUPPORT == DEM_CFG_FFPRESTORAGESUPPORT_ON)
                Dem_PreStoredFFInitCheckNvM();
#endif

#if (DEM_CFG_DISTURBANCE_MEMORY == DEM_CFG_DISTURBANCE_MEMORY_ON)
                Dem_DistMemInitCheckNvM();
#endif

#if( DEM_BFM_ENABLED == DEM_BFM_ON )
                Dem_BfmInitCheckNvM();
#endif

#if( DEM_BFM_ENABLED == DEM_BFM_ON )
                Dem_BfmInitCausality();
#endif
                Dem_EvMemInitCausality();
            }

            /* do processing of operation cycle states immediately, to have TestComplete set  */
            Dem_OperationCyclesMainFunction();
            /* FC_VariationPoint_START */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
            Dem_ObdInit();
#endif
            /* FC_VariationPoint_END */

#if (DEM_CFG_DISTURBANCE_MEMORY == DEM_CFG_DISTURBANCE_MEMORY_ON)
            Dem_DistMemInit();
#endif


            /*
             * Process eventStatusByte:  restore faultLevel from testFailed;
             * clear test failed if !DemStatusBitStorageTestFailed oder NeverStoreTestFailed;
             * reconstruct Graph
             */
#if(DEM_CFG_FIM_USED == DEM_CFG_FIM_ON)
            FiM_DemInit();
#endif

            /* FC_VariationPoint_START */
#if( DEM_BFM_ENABLED == DEM_BFM_ON )
            Dem_BfmInit();
#endif
            /* FC_VariationPoint_END */

            Dem_ReportErrorStatusDisableQueue();
            Dem_OpMoWasInitialized = TRUE;
            Dem_OpMoState = DEM_OPMO_STATE_INITIALIZED;

        }
    }
}

DEM_INLINE void Dem_HandleImmediateTrigger(void)
{
#if(DEM_CFG_TRIGGER_TO_STORE_NVM_SUPPORTED)
    if(Dem_NvMIsImmediateStorageRequested())
    {
        Dem_NvMSetImmediateStorageRequested(FALSE);

        Dem_EvMemTriggerStoreToNvm();

        Dem_NvGenericTriggerStoreToNvm();

        Dem_EvtStatusTriggerStoreToNvm();

#if (DEM_CFG_DISTURBANCE_MEMORY == DEM_CFG_DISTURBANCE_MEMORY_ON)
        Dem_DistMemTriggerStoreToNvM();
#endif

    /* FC_VariationPoint_START */
#if( DEM_BFM_ENABLED == DEM_BFM_ON )
        (void)Dem_BfmTriggerStoreToNvm();
#endif
    /* FC_VariationPoint_END */

#if(DEM_CFG_ALLOW_HISTORY == DEM_CFG_ALLOW_HISTORY_ON)
        Dem_EvtHistoryStatusTriggerStoreToNvM();
#endif

#if (DEM_CFG_EVT_INDICATOR == DEM_CFG_EVT_INDICATOR_ON)
        Dem_EvtIndicatorTriggerStoreToNvm();
#endif

#if (DEM_CFG_FFPRESTORAGE_NONVOLATILE_IMMEDIATE == DEM_CFG_FFPRESTORAGE_NONVOLATILE_IMMEDIATE_ON)
        Dem_PreStoredFFTriggerStoreToNvM();
#endif
    }
#endif //(DEM_CFG_TRIGGER_TO_STORE_NVM_SUPPORTED)
}


void Dem_MainFunction(void)
{
    if (Dem_OpMoState == DEM_OPMO_STATE_INITIALIZED)
    {
        Dem_HandleImmediateTrigger();

        Dem_OperationCyclesMainFunction();

        Dem_DebMainFunction();

        /* The Dem_IndicatorAttributeMainFunction() needs to be called before Dem_EvtMainFunction(),
         * because the PSspecific Indicator will update WIR bit in this function call and these values need to be updated for NvM write */
        Dem_IndicatorAttributeMainFunction();

        Dem_EvtMainFunction();

#if(DEM_CFG_ALLOW_HISTORY == DEM_CFG_ALLOW_HISTORY_ON)
        Dem_EvtHistoryStatusMainFunction();
#endif


        /* FC_VariationPoint_START */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
        Dem_ObdMainFunction();
#endif
        /* FC_VariationPoint_END */

        Dem_EvBuffMainFunction();
        /* FC_VariationPoint_START */
#if( DEM_BFM_ENABLED == DEM_BFM_ON )
        Dem_BfmMainFunction();
#endif
        /* FC_VariationPoint_END */
        Dem_DependencyMainFunction();

        Dem_StoCoMainFunction();

        Dem_DtcStateManagerMainFunction();
        Dem_EvBuffDistributorMainFunction();

#if(DEM_CFG_DTCFILTER_EXTERNALPROCESSING == DEM_CFG_DTCFILTER_EXTERNALPROCESSING_OFF)
        Dem_DTCFilterMainFunction();
#endif

        Dem_ClearMainFunction();

        Dem_EvMemMainFunction();

        Dem_NvGenericMainFunction();

#if (DEM_CFG_DISTURBANCE_MEMORY == DEM_CFG_DISTURBANCE_MEMORY_ON)
        Dem_DistMemMainFunction();
#endif
#if (DEM_CFG_CALLBACK_INIT_MON_FOR_EVENT_SUPPORTED == TRUE)
        Dem_InitMonitorForEFnc();
#endif
    }
#if(DEM_CFG_LOCK_ALLFAILUREINFO == DEM_CFG_LOCK_ALLFAILUREINFO_ON)
    if (Dem_OpMoIsAllFailureInfoLocked())
    {
#if(DEM_CFG_DTCFILTER_EXTERNALPROCESSING == DEM_CFG_DTCFILTER_EXTERNALPROCESSING_OFF)
        Dem_DTCFilterMainFunction();
#endif
    }
#endif
}

void Dem_Shutdown(void)
{
#if(DEM_CFG_LOCK_ALLFAILUREINFO == DEM_CFG_LOCK_ALLFAILUREINFO_ON)
    if(!Dem_OpMoIsAllFailureInfoLocked())
#endif
    {
        DEM_ASSERT(Dem_OpMoState==DEM_OPMO_STATE_INITIALIZED, DEM_DET_APIID_SHUTDOWN, 0);

        if (Dem_OpMoState == DEM_OPMO_STATE_INITIALIZED)
        {
            /* FC_VariationPoint_START */
            /*TODO*/

            //DEM102 : Dem_Shutdown shall finalize all pending operations in the Dem module
            //DEM341 : For individual non-volatile blocks the API NvM_WriteBlock shall be called within the API Dem_Shutdown.

#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
            Dem_ObdShutdown();
#endif
            /* FC_VariationPoint_END */
            Dem_ReportErrorStatusEnableQueue();
            Dem_OpMoState = DEM_OPMO_STATE_PREINITIALIZED;

            Dem_EvBuffDistributorMainFunction();
            Dem_EvMemShutdown();
            (void)Dem_NvmSetChanged(DEM_NVM_ID_EVT_STATUSBYTE, TRUE);

#if(DEM_CFG_ALLOW_HISTORY == DEM_CFG_ALLOW_HISTORY_ON)
            Dem_EvtHistoryStatusShutdown();
#endif

#if (DEM_CFG_FFPRESTORAGESUPPORT == DEM_CFG_FFPRESTORAGESUPPORT_ON)
            /* Store prestored freeze frame in NVRAM*/
            Dem_PreStoredFFShutdown();
#endif

#if (DEM_CFG_DISTURBANCE_MEMORY == DEM_CFG_DISTURBANCE_MEMORY_ON)
            Dem_DistMemShutdown();
#endif
            /* FC_VariationPoint_START */
#if( DEM_BFM_ENABLED == DEM_BFM_ON )
            Dem_BfmShutdown();
#endif
            /* FC_VariationPoint_END */

            Dem_IndicatorAttributeShutdown();


        }
    }
}

#if(DEM_CFG_TRIGGER_TO_STORE_NVM_SUPPORTED)
Std_ReturnType Dem_TriggerStorageToNvm(void)
{
    Dem_NvMSetImmediateStorageRequested(TRUE);
    return E_OK;
}
#endif

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
/* FC_VariationPoint_START */
/*<BASDKey>
 **********************************************************************************************************************
 * $History___:
 * 
 * AR40.11.0.1; 0     03.02.2016 CLH2SI
 *   CSCRM01036799
 * 
 * AR40.11.0.0; 3     07.01.2016 TVE5COB
 *   CSCRM01017790
 * 
 * AR40.11.0.0; 2     21.12.2015 NAL2KOR
 *   CSCRM00957431
 * 
 * AR40.11.0.0; 1     20.11.2015 BPE4COB
 *   CSCRM01002972
 * 
 * AR40.11.0.0; 0     01.10.2015 TVE5COB
 *   CSCRM00976841
 * 
 * AR40.10.0.0; 3     14.07.2015 WUG3ABT
 *   Checkout by wug3abt
 * 
 * AR40.10.0.0; 2     04.07.2015 BPE4COB
 *   CSCRM00835665
 * 
 * AR40.10.0.0; 1     17.06.2015 LIB8FE
 *   CSCRM00764040
 * 
 * AR40.10.0.0; 0     16.04.2015 CLH2SI
 *   CSCRM00764027
 * 
 * AR40.9.0.0; 10     12.01.2015 VSA2COB
 *   CSCRM00756386
 * 
 * $
 **********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
