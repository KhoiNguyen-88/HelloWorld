/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_GenericNvData$
* $Variant___:AR40.10.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_GENERICNVDATA_H
#define DEM_GENERICNVDATA_H

#include "Dem_OperationCycle.h"
/* FC_VariationPoint_START */
#include "Dem_Cfg_ObdMain.h"
#include "Dem_ObdRdy_Prv.h"
/* FC_VariationPoint_END */
#include "Dem_EvMemGenTypes.h"
#include "Dem_EvMemBase.h"

typedef struct
{
/* FC_VariationPoint_START */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)

#if (DEM_CFG_OBDRDY_SCOPE == DEM_CFG_OBDRDY_SCOPE_FULL)
    /* Nv data related to PID$01 and $41 - Necessary only when non-comprehensive component monitors are available even
     * though PID$01 is always present in OBD systems */
    /* Readiness: Nv data related to PID$01 and $41 */
    Dem_ObdRdyGenericNvData_t Dem_ObdRdyGenericNvData;
#endif

    /* Dem PIDs calcualation */
#if (DEM_CFG_SUPPORT_PID21 == TRUE)
    uint16 cntrPID21_u16;
#endif

#if (DEM_CFG_SUPPORT_PID30 == TRUE)
    uint8 cntrPID30_u8;
#endif

#if (DEM_CFG_OBD_PIDS_MIL == DEM_CFG_OBD_PIDS_MIL_GLOBAL)
    uint8 cntrWUCnoMIL_u8;
    Dem_IndicatorStatusType externalMilStatus;
#endif

#if (DEM_CFG_SUPPORT_PID31 == TRUE)
    uint16 cntrPID31_u16;
#endif

#if (DEM_CFG_SUPPORT_PID4D == TRUE)
    uint16 cntrPID4D_u16;
#endif

#if (DEM_CFG_SUPPORT_PID4E == TRUE)
    uint16 cntrPID4E_u16;
#endif

    boolean ObdPfcCycleCondition;
    boolean ObdWarmupCycleCondition;
#endif
/* FC_VariationPoint_END */

   Dem_OperationCycleList OperationCycleStates;

#if DEM_CFG_EVMEMGENERIC_SUPPORTED
    /* used in API service Dem_GetEventMemoryOverflow */
   boolean           Overflow[DEM_EVMEMGEN_OVERFLOW_ARRAYSIZE];
   /* used in API service Dem_GetDTCByOccurrenceTime */
   Dem_DtcIdType     DtcIdsByOccurrenceTime[DEM_EVMEMGEN_DTCIDS_BY_OCCURRENCE_TIME_ARRAYSIZE];
#endif
}  Dem_GenericNvDataType;

#define DEM_START_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"
extern Dem_GenericNvDataType Dem_GenericNvData;
#define DEM_STOP_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"
extern boolean Dem_NvGenericMemoryUpdateFlag;
#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"


#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
/* -------------------------------------------------
   common data
   -------------------------------------------------
 */
DEM_INLINE boolean Dem_NvGenericIsMemoryUpdated(void)
{
    return Dem_NvGenericMemoryUpdateFlag;
}

DEM_INLINE void Dem_NvGenericSetMemoryUpdated(boolean state)
{
    Dem_NvGenericMemoryUpdateFlag = state;
}


DEM_INLINE void Dem_NvGenericNvmWriteNotification(void)
{
    Dem_NvGenericSetMemoryUpdated(TRUE);
}

/* -------------------------------------------------
   common shutdown
   -------------------------------------------------
 */

DEM_INLINE void Dem_NvGenericShutdown(void)
{
   Std_ReturnType StdRet;
   /* Are any objects controlled by EvMemgen updated ? */
   if (Dem_NvGenericIsMemoryUpdated())
   {
      /* indicate NVM to store the updated NVM block */
      StdRet = Dem_NvmSetChanged (DEM_NVM_ID_DEM_GENERIC_NV_DATA, TRUE);
      if (StdRet == E_OK)
      {
          Dem_NvGenericSetMemoryUpdated(FALSE);
      }
   }
}


void Dem_NvGenericTriggerStoreToNvm(void);
boolean Dem_NvGenericIsImmediateStoragePending(void);
void Dem_NvGenericHandleTriggerStoreToNvm(void);


DEM_INLINE void Dem_NvGenericMainFunction(void)
{
    Dem_NvGenericHandleTriggerStoreToNvm();
}

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif /* DEM_GENERICNVDATA_H */

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 0     09.07.2015 RPV5COB
*   CSCRM00791814
* 
* AR40.9.0.0; 2     06.01.2015 VSA2COB
*   CSCRM00743974
* 
* AR40.9.0.0; 1     17.11.2014 GJ83ABT
*   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
* 
* AR40.9.0.0; 0     15.10.2014 GJ83ABT
*   CSCRM00719089, CSCRM00650337, CSCRM00625552, CSCRM00434933
* 
* AR40.8.0.0; 4     16.06.2014 GJ83ABT
*   CSCRM00615634, CSCRM00671513
* 
* AR40.8.0.0; 3     16.06.2014 BPE4COB
*   CSCRM00666829
* 
* AR40.8.0.0; 2     15.05.2014 VSA2COB
*   CSCRM00662943
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     10.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 2     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
