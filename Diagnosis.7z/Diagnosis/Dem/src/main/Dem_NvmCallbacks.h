/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_NvmCallbacks$
* $Variant___:AR40.10.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_NVMCALLBACKS_H
#define DEM_NVMCALLBACKS_H

#include "Dem_Cfg_NvmCallbacks.h"
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

Std_ReturnType Dem_EvMemNvMWriteRamBlockToNvCallback(void* NvMBuffer, uint16_least LocId);
Std_ReturnType Dem_EvMemNvmReadRamBlockFromNvCallback(void* NvMBuffer, uint16_least LocId);

Std_ReturnType Dem_ObdNvMWriteRamBlockToNvCallback(void* NvMBuffer, uint16_least LocId);
Std_ReturnType Dem_ObdNvmReadRamBlockFromNvCallback(void* NvMBuffer, uint16_least LocId);

Std_ReturnType Dem_PreStoredFFWriteRamBlockToNvCallback(void* NvMBuffer, uint16_least LocId);
Std_ReturnType Dem_PreStoredFFReadRamBlockFromNvCallback(void* NvMBuffer, uint16_least LocId);

Std_ReturnType Dem_EventStatusByteWriteRamBlockToNvCallback(void* NvMBuffer);
Std_ReturnType Dem_EventStatusByteReadRamBlockFromNvCallback(void* NvMBuffer);

Std_ReturnType Dem_HistoryStatusByteWriteRamBlockToNvCallback(void* NvMBuffer);
Std_ReturnType Dem_HistoryStatusByteReadRamBlockFromNvCallback(void* NvMBuffer);

Std_ReturnType Dem_DistMemWriteRamBlockToNvCallback(void* NvMBuffer);
Std_ReturnType Dem_DistMemReadRamBlockFromNvCallback(void* NvMBuffer);

Std_ReturnType Dem_GenericNVDataWriteRamBlockToNvCallback(void* NvMBuffer);
Std_ReturnType Dem_GenericNVDataReadRamBlockFromNvCallback(void* NvMBuffer);

Std_ReturnType Dem_EventIndicatorWriteRamBlockToNvCallback(void* NvMBuffer);
Std_ReturnType Dem_EventIndicatorReadRamBlockFromNvCallback(void* NvMBuffer);

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 0     17.06.2015 LIB8FE
*   CSCRM00764040
* 
* AR40.8.0.0; 3     21.03.2014 BRM2COB
*   CSCRM00320811
* 
* AR40.8.0.0; 2     20.03.2014 CLH2SI
*   CSCRM00633913
* 
* AR40.8.0.0; 1     12.03.2014 SAL2COB
*   CSCRM00594822_IntroduceHistoryStatus
* 
* AR40.8.0.0; 0     10.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 2     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 1     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 0     22.10.2013 AMN2KOR
*   CSCRM00547887
* 
* AR40.6.0.0; 0     10.07.2013 CLH2SI
*   
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
