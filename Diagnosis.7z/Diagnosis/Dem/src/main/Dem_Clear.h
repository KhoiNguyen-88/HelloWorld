/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_Clear$
* $Variant___:AR40.10.0.0$
* $Revision__:3$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_CLEAR_H
#define DEM_CLEAR_H

#include "Dem_Cfg_Clear.h"
#include "Dem_Types.h"
#include "Dem_Cfg_Events.h"
#include "Dem_Mapping.h"


#define DEM_CLEAR_DTC_STATE_IDLE     0
#define DEM_CLEAR_DTC_STATE_EXEC     1
#define DEM_CLEAR_DTC_STATE_RSLT     2

typedef struct
{
  /* Only passed parameters from Dem_Clear to Dem_MainFunction (and vice versa) needs to be volatile */
  /* DEM API clear parameter */
  volatile uint32                   DTC;
  volatile Dem_DTCFormatType        DTCFormat;
  volatile Dem_DTCOriginType        DTCOrigin;
  /* DEM clear return status */
  volatile Dem_ReturnClearDTCType   returnSts;
  /* DEM clear state machine */
  volatile uint8                    state;
  volatile uint8                    subState;
  volatile boolean                  init;
} Dem_ClearDtcDataType;

typedef struct
{
    /* Boolean variable to indicate the clear is requested newly and the iterators has to be initialized */
    boolean IsNewClearRequest;
    /* Boolean variable to indicate the limit to procees the events per cycle has reached */
    boolean IsClearInterrupted;
    /* Variable to indicate the no of events cleared in a cycle */
    uint16 NumberOfEventsProcessed;
    /* Iterators */
    Dem_DtcIdListIterator DtcIt;
    Dem_EventIdIterator EvtIt;
    Dem_EventIdListIterator EvtListIt;
} Dem_ClearHandlerType;

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
/**
 * @ingroup DEM_H
 *
 * Clears single DTCs as well as groups of DTCs.
 *
 * @param DTC           Defines the DTC in respective format, that shall be cleared from the event memory.
 *                      If the DTC fits to a DTC group number, all DTCs of the group shall be cleared.
 * @param DTCFormat     Defines the input-format of the provided DTC value.
 * @param DTCOrigin     If the Dem supports more than one event memory this parameter is used to select
 *                      the source memory the DTCs shall be read from.
 *
 * @return  Dem_ReturnClearDTCType: Returns the result of the parameter check when performing a clear command with same parameters (refer to Dem_DcmClearDTC).
 *          Only the following return values will be used:\n
 *          DEM_CLEAR_OK - DTC successfully  cleared
 *          DEM_CLEAR_WRONG_DTC - DTC value not existing (in this format)
 *          DEM_CLEAR_WRONG_DTCORIGIN - Wrong DTC origin
 *          DEM_CLEAR_FAILED - In case of general errors with clear parameters
 */
Dem_ReturnClearDTCType Dem_DcmCheckClearParameter (uint32 DTC, Dem_DTCFormatType DTCFormat, Dem_DTCOriginType DTCOrigin);


/**
 * @ingroup DEM_H
 *
 * Clears single DTCs as well as groups of DTCs.
 *
 * @param DTC           Defines the DTC in respective format, that shall be cleared from the event memory.
 *                      If the DTC fits to a DTC group number, all DTCs of the group shall be cleared.
 * @param DTCFormat     Defines the input-format of the provided DTC value.
 * @param DTCOrigin     If the Dem supports more than one event memory this parameter is used to select
 *                      the source memory the DTCs shall be read from.
 *
 * @return  Dem_ReturnClearDTCType: Status of the operation of type Dem_ReturnClearDTCType.
 */
Dem_ReturnClearDTCType Dem_ClearDTC (uint32 DTC, Dem_DTCFormatType DTCFormat, Dem_DTCOriginType DTCOrigin);


/**
 * @ingroup DEM_H
 *
 * Dem560 : Cancel pending operation started from Dcm.
 *
 * @param  -  None
 * @return -  None
 */
void Dem_DcmCancelOperation(void);

void Dem_ClearMainFunction(void);
void Dem_ClearDtcInit(void);
Dem_boolean_least Dem_ClearIsInPgrogress (void);

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 3     06.07.2015 VSA2COB
*   CSCRM00830308
* 
* AR40.10.0.0; 2     03.07.2015 CLH2SI
*   CSCRM00895547
* 
* AR40.10.0.0; 1     03.07.2015 TVE5COB
*   CSCRM00825238
* 
* AR40.10.0.0; 0     13.05.2015 CLH2SI
*   CSCRM00818782
* 
* AR40.8.0.0; 5     18.07.2014 UDKOEGEL
*   CSCRM00533942
* 
* AR40.8.0.0; 4     16.07.2014 BRM2COB
*   CSCRM00688243
* 
* AR40.8.0.0; 3     14.06.2014 VSA2COB
*   CSCRM00672188
* 
* AR40.8.0.0; 2     22.04.2014 VSA2COB
*   CSCRM00321012
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     10.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
