/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_OperationCycle$
* $Variant___:AR40.10.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_OPERATIONCYCLE_H
#define DEM_OPERATIONCYCLE_H


#include "Dem_Cfg_OperationCycle.h"
#include "Dem_Types.h"

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"
extern Dem_OperationCycleList Dem_OperationCycleStates;
#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

DEM_INLINE Dem_boolean_least Dem_isOperationCycleStarted (uint8 OperationCycleId)
{
	Dem_OperationCycleList operationCycleBitmask = (Dem_OperationCycleList)(1u << OperationCycleId);
	return ((Dem_OperationCycleStates & operationCycleBitmask)!=0u);
}

DEM_INLINE Dem_boolean_least Dem_IsOperationCycleIdValid (uint8 OperationCycleId)
{
	/* as id is of type uint8 it is always positiv and hence check against >= 0 not necessary
	 * return ((0 <= checkID) && (checkID < DEM_OPERATIONCYCLE_COUNT));
	 */
	return (OperationCycleId < DEM_OPERATIONCYCLE_COUNT);
}
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
void Dem_OperationCycleInit (void);

void Dem_OperationCyclesMainFunction(void);
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
#endif


/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 0     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     10.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 3     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 2     19.11.2013 BRM2COB
*   
* 
* AR40.7.0.0; 1     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 0     22.10.2013 AMN2KOR
*   CSCRM00547887
* 
* AR40.6.0.0; 1     21.05.2013 AMN2KOR
*   Updated for CSCRM00524612 - [Int-Dem] Introduce check for Redundant 
*   declarations
* 
* AR40.6.0.0; 0     18.02.2013 BRM2COB
*   CSCRM00489922, CSCRM00484184, CSCRM00496074
*   CSCRM00487984, CSCRM00488028, CSCRM00489927
*   CSCRM00492148, CSCRM00496694, CSCRM00492144
*   CSCRM00432122, CSCRM00493702, CSCRM00484179
*   CSCRM00489947, Fix QAC-Warnings, 
*   corrected comment as per Review Review13_079_COMP__Dem___AR40_5_0_0__5.xls
* 
* AR40.5.0.0; 3     22.01.2013 CLH2SI
*   * CSCRM00488171/CSCRM00487665:
*   - rename to Dem_SWCD.arxml
*   - correction of return type and return value in oaw scripts
*   
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
