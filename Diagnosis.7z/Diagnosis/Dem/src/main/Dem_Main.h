/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_Main$
* $Variant___:AR40.8.0.0$
* $Revision__:5$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_MAIN_H
#define DEM_MAIN_H


#include "Dem_Types.h"
#include "Dem_Version.h"
#include "Dem_Cfg_Main.h"
#include "Dem_Cfg_Events.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
#if (DEM_CFG_VERSION_INFO_API == DEM_CFG_VERSION_INFO_API_ON)

/**
 * @ingroup DEM_H
 *
 * Dem177: Returns the version information of this module.
 *
 * @param versioninfo   Pointer to where to store the version information of this module.
 * @return  -
 */

void Dem_GetVersionInfo(Std_VersionInfoType* versioninfo);
#endif
#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


typedef uint8 Dem_OpMoStateType;
#define  DEM_OPMO_STATE_NOTINITIALIZED   0
#define  DEM_OPMO_STATE_PREINITIALIZED   1
#define  DEM_OPMO_STATE_INITIALIZED      2

#if(DEM_CFG_LOCK_ALLFAILUREINFO == DEM_CFG_LOCK_ALLFAILUREINFO_ON)
#define  DEM_OPMO_STATE_LOCK_ALL_FAILURE_INFO	3
#endif

#define DEM_START_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"
extern Dem_OpMoStateType Dem_OpMoState;
#define DEM_STOP_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"


DEM_INLINE Dem_boolean_least Dem_OpMoIsUnitialized(void)
{
   return (Dem_OpMoState == DEM_OPMO_STATE_NOTINITIALIZED);
}

DEM_INLINE Dem_boolean_least Dem_OpMoIsPreInitialized(void)
{
   return (Dem_OpMoState == DEM_OPMO_STATE_PREINITIALIZED);
}

DEM_INLINE Dem_boolean_least Dem_OpMoIsInitialized(void)
{
   return (Dem_OpMoState == DEM_OPMO_STATE_INITIALIZED);
}


#if(DEM_CFG_LOCK_ALLFAILUREINFO == DEM_CFG_LOCK_ALLFAILUREINFO_ON)
DEM_INLINE Dem_boolean_least Dem_OpMoIsAllFailureInfoLocked(void)
{
   return (Dem_OpMoState == DEM_OPMO_STATE_LOCK_ALL_FAILURE_INFO);
}
#endif
#define DEM_START_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"
/**
 * @ingroup DEM_EXT_H
 *
 * Post-build configuration to select the Alternative Debouncer parameter for CounterClass-Debouncer.
 */
extern const Dem_ConfigType Dem_ConfigAlternativeParameters;
#define DEM_STOP_SEC_ROM_CONST
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
/**
 * @ingroup DEM_H
 *
 * Dem179: Initializes the internal states necessary to process events reported by BSW-modules.
 * @param[in]  ConfigPtr
 */
void Dem_PreInit(const Dem_ConfigType* ConfigPtr);


/**
 * @ingroup DEM_EXT_H
 *
 * Interface to lock the FailureInfo.
 * @return E_OK: FailureInfo is locked.
 * @return E_NOT_OK: FailureInfo is not locked.
*/
Std_ReturnType Dem_LockAllFailureInfo (void);

/**
 * @ingroup DEM_H
 *
 * Dem181: Initializes or reinitializes this module.
 * @see  Dem_Shutdown
 */
void Dem_Init(void);


/**
 * @ingroup DEM_H
 *
 * Dem182: Shuts down this module.
 * @see  Dem_Init
 */
void Dem_Shutdown(void);

/**
 * @ingroup DEM_EXT_H
 *
 * Dem182: Trigger the storage to NVM for all persistently stored DEM-internal data.
 * @param[in]  None
 * @return : Std_ReturnType (always E_OK)
 */
#if(DEM_CFG_TRIGGER_TO_STORE_NVM_SUPPORTED)
Std_ReturnType Dem_TriggerStorageToNvm(void);
#endif

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.8.0.0; 5     16.07.2014 BRM2COB
*   CSCRM00688243
* 
* AR40.8.0.0; 4     16.06.2014 BPE4COB
*   CSCRM00666829
* 
* AR40.8.0.0; 3     21.04.2014 SAL2COB
*   CSCRM00594800
* 
* AR40.8.0.0; 2     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 1     10.03.2014 VSA2COB
*   CSCRM00619537_ComassoChanges
* 
* AR40.8.0.0; 0     27.01.2014 BRM2COB
*   
* 
* AR40.7.0.0; 3     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 2     19.11.2013 BRM2COB
*   
* 
* AR40.7.0.0; 1     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 0     22.10.2013 AMN2KOR
*   CSCRM00547887
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
