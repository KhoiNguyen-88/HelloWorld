/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_GenericNvData$
* $Variant___:AR40.10.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/

#include "Dem_Types.h"
#include "Dem_GenericNvData.h"


/* -------------------------------------------------
   NV-RAM Immediate Storage
   -------------------------------------------------
 */

typedef struct
{
   boolean Busy;
   Dem_GenericNvDataType Data;
} Dem_NvGenericStorageBufferType;

#define DEM_START_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"
Dem_GenericNvDataType Dem_GenericNvData;
#define DEM_STOP_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"
boolean Dem_NvGenericMemoryUpdateFlag;
static Dem_NvGenericStorageBufferType Dem_NvGenericStorageBuffer;
static boolean Dem_NvGenericTriggerImmediateNVMStorage;
#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


DEM_INLINE Dem_boolean_least Dem_NvGenericIsStorageBufferAvailable(void)
{
   return (!Dem_NvGenericStorageBuffer.Busy);
}


DEM_INLINE void Dem_NvGenericCopyToStorageBuffer(void)
{
   Dem_NvGenericStorageBuffer.Data = Dem_GenericNvData;
   Dem_NvGenericStorageBuffer.Busy = TRUE;
}


DEM_INLINE void Dem_NvGenericReleaseStorageBuffer(void)
{
   Dem_NvGenericStorageBuffer.Busy = FALSE;
}


DEM_INLINE void Dem_NvGenericStorageBufferMainFunction(void)
{
   if (Dem_NvGenericStorageBuffer.Busy)
   {
      if (Dem_NvmGetStatus (DEM_NVM_ID_DEM_GENERIC_NV_DATA) != DEM_NVM_PENDING)
      {
         Dem_NvGenericStorageBuffer.Busy = FALSE;
      }
   }
}

void Dem_NvGenericTriggerStoreToNvm(void)
{
	Dem_NvGenericTriggerImmediateNVMStorage = TRUE;
}

boolean Dem_NvGenericIsImmediateStoragePending(void)
{
	return Dem_NvGenericTriggerImmediateNVMStorage;
}

void Dem_NvGenericHandleTriggerStoreToNvm(void)
{
    Dem_NvmReturnType writeResult;

    /* Check if the trigger flag is set */
    if (Dem_NvGenericTriggerImmediateNVMStorage)
    {
        /* Are any objects controlled by Generic Nv data updated ? */
        if (Dem_NvGenericIsMemoryUpdated())
        {
            Dem_NvGenericStorageBufferMainFunction();

            if (Dem_NvGenericIsStorageBufferAvailable ())
            {
                /* copy data to buffer and clear flags*/
                Dem_NvGenericCopyToStorageBuffer ();
                Dem_NvGenericSetMemoryUpdated(FALSE);
                Dem_NvGenericTriggerImmediateNVMStorage = FALSE;

                /* indicate NVM to store the updated NVM block */
                writeResult = Dem_NvmWrite (DEM_NVM_ID_DEM_GENERIC_NV_DATA, &Dem_NvGenericStorageBuffer.Data);

                /* if NvM_Write was not successful, reset the flags */
                if (writeResult != DEM_NVM_TRANSACTIONACCEPTED)
                {
                    Dem_NvGenericSetMemoryUpdated(TRUE);
                    Dem_NvGenericTriggerImmediateNVMStorage = TRUE;
                    Dem_NvGenericReleaseStorageBuffer();
                }
            }
        }
        else
        {
            Dem_NvGenericTriggerImmediateNVMStorage = FALSE;
        }
    }
}

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 1     09.07.2015 RPV5COB
*   CSCRM00791814
* 
* AR40.10.0.0; 0     17.06.2015 LIB8FE
*   CSCRM00764040
* 
* AR40.9.0.0; 0     06.01.2015 VSA2COB
*   CSCRM00743974
* 
* AR40.8.0.0; 3     16.07.2014 BRM2COB
*   CSCRM00688243
* 
* AR40.8.0.0; 2     16.06.2014 BPE4COB
*   CSCRM00666829
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     10.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 1     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 0     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.4.0.0; 0     05.07.2012 BRM2COB
*   Version updated to AR40.4.0.0
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
