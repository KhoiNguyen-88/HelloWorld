/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_Clear$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/

#include "Dem_Clear.h"

#include "Dem_Events.h"
#include "Dem_EventRecheck.h"
#include "Dem_StorageCondition.h"
#include "Dem_EvMem.h"
#include "Dem_DTCs.h"
#include "Dem_DTCGroup.h"
#include "Dem_DTCStatusByte.h"
/* FC_VariationPoint_START */
#include "Dem_ObdMain.h"
/* FC_VariationPoint_END */
#include "Dem_EventStatus.h"
#include "Dem_EvMemGen.h"
#include "Dem_Cfg_ExtPrototypes.h"

static Dem_ClearDtcDataType Dem_ClearDtcData;
static Dem_ClearHandlerType Dem_ClearHandler;

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
static Dem_ReturnClearDTCType Dem_ClearDTCBody(uint32 DTC, Dem_DTCOriginType DTCOrigin)
{

#if(DEM_CFG_CLEAR_DTC_LIMITATION == DEM_CFG_CLEAR_DTC_LIMITATION_ALL_SUPPORTED_DTCS)
    Dem_DtcIdType dtcId;
    Dem_DTCGroupIdType DTCGroupId;
#endif


    /* Initialization */
    Dem_ClearHandler.IsClearInterrupted = FALSE;
    Dem_ClearHandler.NumberOfEventsProcessed = 0;

    if (DTC == DEM_DTC_GROUP_ALL_DTCS)
    { /* clear all DTCs */

        Dem_ClearAllDTCs(DTCOrigin, &Dem_ClearHandler);

        if (!Dem_ClearHandler.IsClearInterrupted)
        {
            Dem_EvMemGenClearDtcByOccurrenceTime(DTCOrigin);
            Dem_EvMemGenClearOverflow(DTCOrigin);
            /* FC_VariationPoint_START */
            Dem_ObdClearDiagnosticInformation(DTCOrigin);
            /* FC_VariationPoint_END */
            return DEM_CLEAR_OK;
        }
        return DEM_CLEAR_PENDING;
    }

#if(DEM_CFG_CLEAR_DTC_LIMITATION == DEM_CFG_CLEAR_DTC_LIMITATION_ALL_SUPPORTED_DTCS)
    DTCGroupId = Dem_DtcGroupIdFromDtcGroupCode(DTC);
    if (DTCGroupId != DEM_DTCGROUPID_INVALID)
    {
        /* Clear All DTCs which belongs to DTCGroup */
        Dem_DtcsClearDtcInGroup(DTCGroupId, DTCOrigin, &Dem_ClearHandler);
        if (!Dem_ClearHandler.IsClearInterrupted)
        {
            return DEM_CLEAR_OK;
        }
        return DEM_CLEAR_PENDING;
    }
    else
    { /* clear single DTC */
        dtcId = Dem_DtcIdFromDtcCode(DTC);

        Dem_ClearSingleDTC(dtcId, DTCOrigin, &Dem_ClearHandler);

        if (!Dem_ClearHandler.IsClearInterrupted)
        {
            return DEM_CLEAR_OK;
        }
        return DEM_CLEAR_PENDING;
    }

#else
    return DEM_CLEAR_FAILED;
#endif
}

void Dem_ClearMainFunction(void)
{
   uint8                  state;
   Dem_boolean_least anyNvmFailed = FALSE;

   /* read state machine data */
   state = Dem_ClearDtcData.state;

   /* process state machine */
   if (state == DEM_CLEAR_DTC_STATE_EXEC)
   {
      if (Dem_ClearDtcData.init)
      {
         state = DEM_CLEAR_DTC_STATE_IDLE;
      }
      else
      {
          /* Step 0 - Initialize */
          if(Dem_ClearDtcData.subState == 0)
          {
              Dem_ClearHandler.IsNewClearRequest = TRUE;
              Dem_ClearDtcData.subState++;
          }
         /* Step 1 - Clear */
         if (Dem_ClearDtcData.subState == 1)
         {
            Dem_ClearDtcData.returnSts = Dem_ClearDTCBody(Dem_ClearDtcData.DTC, Dem_ClearDtcData.DTCOrigin);
            Dem_ClearHandler.IsNewClearRequest = FALSE;
            if (Dem_ClearDtcData.returnSts != DEM_CLEAR_PENDING)
            {
               Dem_ClearDtcData.subState++;
            }
         }
         /* Step 2 - Sync to NVM-Storage (optional) */
         if (Dem_ClearDtcData.subState == 2)
         {
             /* Remark:
              * Synchronization with NVM and delivering of error information requires that the NVM block status NVM_REQ_INTEGRITY_FAILED
              * is not mapped to DEM_NVM_FAILED in the wrapper function Dem_NvmGetStatus. */
        	 if ( (    (DEM_CFG_CLEAR_DTC_BEHAVIOR == DEM_CFG_CLEAR_DTC_BEHAVIOR_NONVOLATILE_FINISH)
        			 && (Dem_ClearDtcData.returnSts == DEM_CLEAR_OK)
        			 && (     Dem_EvMemIsNvmImmediateStoragePending(&anyNvmFailed)
        					 || Dem_EvtStatusByteIsNvmImmediateStoragePending(&anyNvmFailed)
        					 || Dem_IndicatorAttribIsNvmClearPending(&anyNvmFailed)
        					 || Dem_EvMemGenIsNvmImmediateStoragePending(&anyNvmFailed)
        					 /* FC_VariationPoint_START */
        					 || Dem_ObdIsNvmImmediateStoragePending(&anyNvmFailed)
        					 /* FC_VariationPoint_END */
        			 )
        	 )
#if (DEM_CFG_TRIGGERMONITORINITBEFORECLEAROK == TRUE)
        	 ||  Dem_EvtIsAnyInitMonitoringRequestedClear()
#endif
        	 )
            {
               /* Do not change state --> NVM storage pending */
            }
            else
            {
				if (   (DEM_CFG_CLEAR_DTC_BEHAVIOR == DEM_CFG_CLEAR_DTC_BEHAVIOR_NONVOLATILE_FINISH)
            	    && (anyNvmFailed)
            	    )
            	{
            		Dem_ClearDtcData.returnSts = DEM_CLEAR_MEMORY_ERROR;
            	}

            	state = DEM_CLEAR_DTC_STATE_RSLT;
/* Callback function to notify when ClearDTC is finished */
#if(DEM_CFG_CLEAR_DTC_NOTIFICATION_CALLBACK_ALLOWED == DEM_CFG_CLEAR_DTC_NOTIFICATION_CALLBACK_ALLOWED_ON )
            	/*MISRA RULE 8.1 VIOLATION: False warning raised by MISRA despite proper declaration and inclusion of DemTest_ClearDTCFinishHookFnc(), this is not a violation, the comment is added only to suppress the false misra warning */
      DEM_CFG_CLEAR_DTC_FINISH_NOTIFICATION_CALLBACK_ALLOWEDFNC(Dem_ClearDtcData.DTC,Dem_ClearDtcData.DTCFormat,Dem_ClearDtcData.DTCOrigin);
#endif
            }
         }
      }
      /* write state machine data */
      Dem_ClearDtcData.state = state;
   }
}



Dem_ReturnClearDTCType Dem_DcmCheckClearParameter (uint32 DTC, Dem_DTCFormatType DTCFormat, Dem_DTCOriginType DTCOrigin)
{
    Dem_DtcIdType dtcId;
    Dem_DTCGroupIdType DTCGroupId;

    if (!Dem_EvMemIsDtcOriginValid(DTCOrigin))
    {
        return DEM_CLEAR_WRONG_DTCORIGIN;
    }


    if (   (DTCFormat != DEM_DTC_FORMAT_UDS)
        /* FC_VariationPoint_START */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
         && (DTCFormat != DEM_DTC_FORMAT_OBD)
#endif
         /* FC_VariationPoint_END */
        )
    {
        return DEM_CLEAR_WRONG_DTC;
    }

    if (DTC == DEM_DTC_GROUP_ALL_DTCS)
    {
        return DEM_CLEAR_OK;
    }
    else
    {

        if (DEM_CFG_CLEAR_DTC_LIMITATION == DEM_CFG_CLEAR_DTC_LIMITATION_ONLY_CLEAR_ALL_DTCS)
        {
            DEM_DET(DEM_DET_APIID_CLEARDTC, DEM_E_PARAM_CONFIG);
            return DEM_CLEAR_FAILED;
        }
        else
        {
            DTCGroupId = Dem_DtcGroupIdFromDtcGroupCode(DTC);
            if (DTCGroupId != DEM_DTCGROUPID_INVALID)
            {
                return DEM_CLEAR_OK;
            }
            else
            { /* clear single DTC */
                dtcId = Dem_DtcIdFromDtcCode(DTC);
                if ((!Dem_DtcIsSupported(dtcId)) || (DTCFormat == DEM_DTC_FORMAT_OBD))
                {
                    /* clear single OBD DTC is not allowed according to SAE-1979! */
                    return DEM_CLEAR_WRONG_DTC;
                }
                return DEM_CLEAR_OK;
            }
        }
    }
}


Dem_ReturnClearDTCType Dem_ClearDTC (uint32 DTC, Dem_DTCFormatType DTCFormat, Dem_DTCOriginType DTCOrigin)
{
   uint8                  state;

   Dem_ReturnClearDTCType returnSts = Dem_DcmCheckClearParameter(DTC, DTCFormat, DTCOrigin);
   if (returnSts != DEM_CLEAR_OK)
   {
       return returnSts;
   }


   /* read state machine data */
   state = Dem_ClearDtcData.state;

   returnSts = DEM_CLEAR_PENDING;

   if ((state == DEM_CLEAR_DTC_STATE_IDLE) ||
      ((state == DEM_CLEAR_DTC_STATE_RSLT) && Dem_ClearDtcData.init))
   {
      Dem_ClearDtcData.init      = FALSE;
      Dem_ClearDtcData.DTC       = DTC;
      Dem_ClearDtcData.DTCFormat   = DTCFormat;
      Dem_ClearDtcData.DTCOrigin = DTCOrigin;
      Dem_ClearDtcData.subState  = 0;
      /* Setting STATE variable must be the last operation */
      Dem_ClearDtcData.state     = DEM_CLEAR_DTC_STATE_EXEC;

/* Callback function to notify when ClearDTC is triggered */
#if(DEM_CFG_CLEAR_DTC_NOTIFICATION_CALLBACK_ALLOWED == DEM_CFG_CLEAR_DTC_NOTIFICATION_CALLBACK_ALLOWED_ON )
      /*MISRA RULE 8.1 VIOLATION: False warning raised by MISRA despite proper declaration and inclusion of DemTest_ClearDTCStartHookFnc(), this is not a violation, the comment is added only to suppress the false misra warning */
      DEM_CFG_CLEAR_DTC_START_NOTIFICATION_CALLBACK_ALLOWEDFNC(DTC,DTCFormat,DTCOrigin);
#endif
   }
   else if (state == DEM_CLEAR_DTC_STATE_RSLT)
   {
      returnSts = Dem_ClearDtcData.returnSts;
      Dem_ClearDtcData.state = DEM_CLEAR_DTC_STATE_IDLE;
   }
   else /* state DEM_CLEAR_DTC_STATE_EXEC */
   {
      if (Dem_ClearDtcData.init)
      {
         returnSts = DEM_CLEAR_FAILED;
      }
   }

   return returnSts;
}


void Dem_ClearDtcInit(void)
{
   Dem_ClearDtcData.init = TRUE;
}



Dem_boolean_least Dem_ClearIsInPgrogress (void)
{
	return (Dem_ClearDtcData.state == DEM_CLEAR_DTC_STATE_EXEC);
}

void Dem_DcmCancelOperation (void)
{
   Dem_ClearDtcInit();
}

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     16.10.2015 VSA2COB
*   Checkout by vsa2cob
* 
* AR40.10.0.0; 6     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 5     07.07.2015 TVE5COB
*   CSCRM00818788
* 
* AR40.10.0.0; 4     06.07.2015 VSA2COB
*   CSCRM00830308
* 
* AR40.10.0.0; 3     17.06.2015 VSA2COB
*   CSCRM00880343
* 
* AR40.10.0.0; 2     13.05.2015 CLH2SI
*   CSCRM00818782
* 
* AR40.10.0.0; 1     16.04.2015 CLH2SI
*   CSCRM00764027
* 
* AR40.10.0.0; 0     02.03.2015 UDKOEGEL
*   CSCRM00791919
* 
* AR40.9.0.0; 3     06.01.2015 VSA2COB
*   CSCRM00743974
* 
* AR40.9.0.0; 2     30.12.2014 TVE5COB
*   CSCRM00758414
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
