/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_NvmCallbacks$
* $Variant___:AR40.11.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/

#include "Dem_NvmCallbacks.h"
#include "Dem_EventStatus.h"
#include "Dem_DisturbanceMemory.h"
#include "Dem_GenericNvData.h"
#include "Dem_EvMemBase.h"
#include "Dem_EvBuff.h"

/* FC_VariationPoint_START */
#include "Dem_ObdRdy_Prv.h"
#include "Dem_ObdPdtcMem.h"
/* FC_VariationPoint_END */

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

/* Event Memory: Nvm Explicit Synchronization: */
Std_ReturnType Dem_EvMemNvMWriteRamBlockToNvCallback(void* NvMBuffer, uint16_least LocId)
{
    DEM_MEMCPY(NvMBuffer, &Dem_EvMemEventMemory[LocId], DEM_SIZEOF_TYPE(Dem_EvMemEventMemoryType));
    return E_OK;
}

/* MISRA RULE 16.7 VIOLATION: Interface is defined by AUTOSAR */
Std_ReturnType Dem_EvMemNvmReadRamBlockFromNvCallback(void* NvMBuffer, uint16_least LocId)
{
    DEM_MEMCPY(&Dem_EvMemEventMemory[LocId], NvMBuffer, DEM_SIZEOF_TYPE(Dem_EvMemEventMemoryType));
    return E_OK;
}


/*  OBD: Nvm Explicit Synchronization: */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
Std_ReturnType Dem_ObdNvMWriteRamBlockToNvCallback(void* NvMBuffer, uint16_least LocId)
{
    DEM_MEMCPY(NvMBuffer, &Dem_ObdPdtcMem[LocId], DEM_SIZEOF_TYPE(Dem_ObdPdtcMemType));
    return E_OK;
}

/* MISRA RULE 16.7 VIOLATION: Interface is defined by AUTOSAR */
Std_ReturnType Dem_ObdNvmReadRamBlockFromNvCallback(void* NvMBuffer, uint16_least LocId)
{
    DEM_MEMCPY(&Dem_ObdPdtcMem[LocId], NvMBuffer, DEM_SIZEOF_TYPE(Dem_ObdPdtcMemType));
    return E_OK;
}
#endif


/*  Pre-stored Freeze frame : Nvm Explicit Synchronization: */
#if (DEM_CFG_FFPRESTORAGE_NONVOLATILE == DEM_CFG_FFPRESTORAGE_NONVOLATILE_ON)
Std_ReturnType Dem_PreStoredFFWriteRamBlockToNvCallback(void* NvMBuffer, uint16_least LocId)
{
    DEM_ENTERLOCK_MON_BEFORE_INIT();
    if ((Dem_EvtBuffer.Locations[LocId].eventType == C_EVENTTYPE_PRESTORE) && (Dem_isEventIdValid(Dem_EvtBuffer.Locations[LocId].eventId)))
    {
        DEM_MEMCPY(NvMBuffer, &Dem_EvtBuffer.Locations[LocId], DEM_SIZEOF_TYPE(Dem_EvBuffEvent));
    }
    else
    {
        DEM_MEMSET(NvMBuffer, 0u, DEM_SIZEOF_TYPE(Dem_EvBuffEvent));
    }

    DEM_EXITLOCK_MON_BEFORE_INIT();
    return E_OK;
}

/* MISRA RULE 16.7 VIOLATION: Interface is defined by AUTOSAR */
Std_ReturnType Dem_PreStoredFFReadRamBlockFromNvCallback(void* NvMBuffer, uint16_least LocId)
{
    DEM_ENTERLOCK_MON_BEFORE_INIT();
    DEM_MEMCPY(&Dem_EvtBuffer.Locations[LocId], NvMBuffer, DEM_SIZEOF_TYPE(Dem_EvBuffEvent));
    DEM_EXITLOCK_MON_BEFORE_INIT();
    return E_OK;
}
#endif


/* Event StatusByte: Nvm Explicit Synchronization: */
/* ATTENTION: When changing the NVM-handling of EventStatusByte, consider the size dependencies during project development (see config-table).*/
Std_ReturnType Dem_EventStatusByteWriteRamBlockToNvCallback(void* NvMBuffer)
{
    DEM_MEMCPY(NvMBuffer, &Dem_AllEventsStatusByte, DEM_SIZEOF_VAR(Dem_AllEventsStatusByte));

/* FC_VariationPoint_START */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    /* Move to the next NvM byte that needs to be copied to */
    NvMBuffer = (uint8*)NvMBuffer + DEM_SIZEOF_VAR(Dem_AllEventsStatusByte);
    /* Merge the readiness part */
    (void)Dem_ObdRdyEventStatusWriteRamBlockToNvCallback(NvMBuffer);
#endif
/* FC_VariationPoint_END */

    return E_OK;
}

/* MISRA RULE 16.7 VIOLATION: Function defined according to AR Spec in NVM - Std_ReturnType NvM_ReadRamBlockFromNvm( void* NvMBuffer ) */
Std_ReturnType Dem_EventStatusByteReadRamBlockFromNvCallback(void* NvMBuffer)
{
    /* ATTENTION: When changing the NVM-handling of EventStatusByte, consider the size dependencies during project development (see config-table).*/
    DEM_MEMCPY(&Dem_AllEventsStatusByte, NvMBuffer, DEM_SIZEOF_VAR(Dem_AllEventsStatusByte));

#if DEM_CFG_CUSTOMIZABLEDTCSTATUSBYTE
    DEM_MEMCPY(&Dem_AllEventsStatusByteCust, NvMBuffer, DEM_SIZEOF_VAR(Dem_AllEventsStatusByte));
#endif

/* FC_VariationPoint_START */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)
    /* Handle the readiness part */
    NvMBuffer = (uint8*)NvMBuffer + DEM_SIZEOF_VAR(Dem_AllEventsStatusByte);
    NvMBuffer = Dem_ObdRdyEventStatusReadRamBlockFromNvCallback(NvMBuffer);
#endif
/* FC_VariationPoint_END */

    (void)NvMBuffer; /* to avoid any MISRA warnings */

    return E_OK;
}


/* History StatusByte: Nvm Explicit Synchronization: */
#if(DEM_CFG_ALLOW_HISTORY == DEM_CFG_ALLOW_HISTORY_ON)
Std_ReturnType Dem_HistoryStatusByteWriteRamBlockToNvCallback(void* NvMBuffer)
{
    DEM_ENTERLOCK_MON_BEFORE_INIT();
    DEM_MEMCPY(NvMBuffer, &Dem_AllEventsHistoryStatus, DEM_SIZEOF_VAR(Dem_AllEventsHistoryStatus));
    DEM_EXITLOCK_MON_BEFORE_INIT();
    return E_OK;
}

/* MISRA RULE 16.7 VIOLATION: Function defined according to AR Spec in NVM - Std_ReturnType NvM_ReadRamBlockFromNvm( void* NvMBuffer ) */
Std_ReturnType Dem_HistoryStatusByteReadRamBlockFromNvCallback(void* NvMBuffer)
{
    DEM_ENTERLOCK_MON_BEFORE_INIT();
    DEM_MEMCPY(&Dem_AllEventsHistoryStatus, NvMBuffer, DEM_SIZEOF_VAR(Dem_AllEventsHistoryStatus));
    DEM_EXITLOCK_MON_BEFORE_INIT();
    return E_OK;
}
#endif


/* Disturbance Memory */
/* MISRA RULE 11.4 VIOLATION: Function defined according to AR Spec in NVM - Std_ReturnType NvM_WriteRamBlockFromNvm( void* NvMBuffer ) */
#if(DEM_CFG_DISTURBANCE_MEMORY == DEM_CFG_DISTURBANCE_MEMORY_ON)
Std_ReturnType Dem_DistMemWriteRamBlockToNvCallback(void* NvMBuffer)
{
    DEM_ENTERLOCK_MON_BEFORE_INIT();
    DEM_MEMCPY(NvMBuffer, &Dem_DistMemLocations, DEM_SIZEOF_VAR(Dem_DistMemLocations));
    DEM_EXITLOCK_MON_BEFORE_INIT();
    return E_OK;
}

/* MISRA RULE 16.7 VIOLATION: Function defined according to AR Spec in NVM - Std_ReturnType NvM_ReadRamBlockFromNvm( void* NvMBuffer ) */
Std_ReturnType Dem_DistMemReadRamBlockFromNvCallback(void* NvMBuffer)
{
    DEM_ENTERLOCK_MON_BEFORE_INIT();
    DEM_MEMCPY(&Dem_DistMemLocations, NvMBuffer, DEM_SIZEOF_VAR(Dem_DistMemLocations));
    DEM_EXITLOCK_MON_BEFORE_INIT();
    return E_OK;
}
#endif


/* Dem_GenericNvData */
Std_ReturnType Dem_GenericNVDataWriteRamBlockToNvCallback(void* NvMBuffer)
{
    DEM_MEMCPY(NvMBuffer, &Dem_GenericNvData, DEM_SIZEOF_VAR(Dem_GenericNvData));
    return E_OK;
}

/* MISRA RULE 16.7 VIOLATION: Function defined according to AR Spec in NVM - Std_ReturnType NvM_ReadRamBlockFromNvm( void* NvMBuffer ) */
Std_ReturnType Dem_GenericNVDataReadRamBlockFromNvCallback(void* NvMBuffer)
{
    DEM_MEMCPY(&Dem_GenericNvData, NvMBuffer, DEM_SIZEOF_VAR(Dem_GenericNvData));
    return E_OK;
}


/* Event Indicator */
#if (DEM_CFG_EVT_INDICATOR == DEM_CFG_EVT_INDICATOR_ON)
Std_ReturnType Dem_EventIndicatorWriteRamBlockToNvCallback(void* NvMBuffer)
{
    DEM_ENTERLOCK_MON_BEFORE_INIT();
    DEM_MEMCPY(NvMBuffer, &Dem_AllEventsIndicatorState, DEM_SIZEOF_VAR(Dem_AllEventsIndicatorState));
    DEM_EXITLOCK_MON_BEFORE_INIT();
    return E_OK;
}

/* MISRA RULE 16.7 VIOLATION: Function defined according to AR Spec in NVM - Std_ReturnType NvM_ReadRamBlockFromNvm( void* NvMBuffer ) */
Std_ReturnType Dem_EventIndicatorReadRamBlockFromNvCallback(void* NvMBuffer)
{
    DEM_ENTERLOCK_MON_BEFORE_INIT();
    DEM_MEMCPY(&Dem_AllEventsIndicatorState, NvMBuffer, DEM_SIZEOF_VAR(Dem_AllEventsIndicatorState));
    DEM_EXITLOCK_MON_BEFORE_INIT();
    return E_OK;
}
#endif

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 1     11.01.2016 NAL2KOR
*   CSCRM01015983
* 
* AR40.11.0.0; 0     16.10.2015 VSA2COB
*   Checkout by vsa2cob
* 
* AR40.10.0.0; 4     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 3     03.07.2015 CLH2SI
*   CSCRM00895547
* 
* AR40.10.0.0; 2     17.06.2015 LIB8FE
*   CSCRM00764040
* 
* AR40.10.0.0; 1     12.05.2015 CLH2SI
*   CSCRM00789099
* 
* AR40.10.0.0; 0     17.03.2015 TVE5COB
*   CSCRM00789300
* 
* AR40.9.0.0; 5     12.01.2015 VSA2COB
*   CSCRM00756386
* 
* AR40.9.0.0; 4     12.11.2014 CLH2SI
*   CSCRM00735646
* 
* AR40.9.0.0; 3     15.10.2014 GJ83ABT
*   CSCRM00719089, CSCRM00650337, CSCRM00625552, CSCRM00434933
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
