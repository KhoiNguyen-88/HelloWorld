/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_Nvm$
* $Variant___:AR40.10.0.0$
* $Revision__:2$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_NVM_H
#define DEM_NVM_H


#include "Dem_Types.h"
#include "Dem_Cfg_Main.h"
#include "NvM.h"
#include "Dem_Cfg_Nvm.h"


typedef NvM_BlockIdType Dem_NvmIdType;


typedef NvM_RequestResultType Dem_NvmResultType;
#define DEM_NVM_PENDING           NVM_REQ_PENDING
#define DEM_NVM_SUCCESS           NVM_REQ_OK
#define DEM_NVM_CANCELED          NVM_REQ_CANCELED
#define DEM_NVM_FAILED            NVM_REQ_NOT_OK
#define DEM_NVM_INVALID           NVM_REQ_NV_INVALIDATED
#define DEM_NVM_INTEGRITY_FAILED  NVM_REQ_INTEGRITY_FAILED
#define DEM_NVM_BLOCK_SKIPPED     NVM_REQ_BLOCK_SKIPPED
#define DEM_DELAYED_NVRAMWRITE_DELAY_TIME (5000/DEM_MAIN_CYCLETIME)


typedef Std_ReturnType Dem_NvmReturnType;
#define DEM_NVM_TRANSACTIONACCEPTED     E_OK
#define DEM_NVM_TRANSACTIONDENIED       E_NOT_OK


#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"
#if(DEM_CFG_TRIGGER_TO_STORE_NVM_SUPPORTED)
extern boolean Dem_NvMImmediateStorageRequested;
#endif
#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"


DEM_INLINE Dem_NvmReturnType Dem_NvmErase (Dem_NvmIdType id)
{
	return NvM_InvalidateNvBlock (id);
}


DEM_INLINE Dem_NvmReturnType Dem_NvmSetChanged(Dem_NvmIdType id, boolean isChanged)
{
	return NvM_SetRamBlockStatus(id, isChanged);
}


DEM_INLINE Dem_NvmResultType Dem_NvmGetStatus (Dem_NvmIdType id)
{
	NvM_RequestResultType result;
	if (NvM_GetErrorStatus (id, &result) == E_NOT_OK)
	{
		return DEM_NVM_FAILED;
	}

	switch (result)
	{
		case NVM_REQ_CANCELED:
		return DEM_NVM_CANCELED;

		case NVM_REQ_OK:
		case NVM_REQ_REDUNDANCY_FAILED:     /* Driver could trigger correction of the damaged part of the redundant block; data is read correctly nevertheless */
		case NVM_REQ_RESTORED_FROM_ROM:
		return DEM_NVM_SUCCESS;

		case NVM_REQ_PENDING:
		return DEM_NVM_PENDING;

		case NVM_REQ_NV_INVALIDATED:
		return DEM_NVM_INVALID;

        case NVM_REQ_INTEGRITY_FAILED:
        return DEM_NVM_INTEGRITY_FAILED;    /* NVM_REQ_INTEGRITY_FAILED: description in NVM-doc: Indicates that the latest read operation did not find any valid data for this block on the persistent media. */

        case NVM_REQ_BLOCK_SKIPPED:
        return DEM_NVM_BLOCK_SKIPPED;       /* NVM_REQ_BLOCK_SKIPPED: if readall would be skipped, it is treated as failure for DEM, because all NVM data has to be available
                                               at init (ErrorQueue is flushed and event status / eventMemory content needs to be available)
                                               This is ensured as the checks during init are checked to be DEM_NVM_SUCCESS. All other states are handled as error */

		default:
		/*   NVM_REQ_NOT_OK: Indicates that the latest operation failed due to an unexpected event.  */
		return DEM_NVM_FAILED;
	}
}


DEM_INLINE Dem_NvmReturnType Dem_NvmWrite (Dem_NvmIdType id, void* memory)
{
    Dem_NvmResultType result = DEM_NVM_TRANSACTIONDENIED;
    if (Dem_NvmGetStatus(id) != DEM_NVM_PENDING)
    {
        result = NvM_WriteBlock (id, memory);
    }
    return result;
}


#if(DEM_CFG_TRIGGER_TO_STORE_NVM_SUPPORTED)
DEM_INLINE void Dem_NvMSetImmediateStorageRequested(boolean state)
{
    Dem_NvMImmediateStorageRequested = state;
}


DEM_INLINE boolean Dem_NvMIsImmediateStorageRequested(void)
{
    return Dem_NvMImmediateStorageRequested;
}
#endif


#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 2     17.06.2015 LIB8FE
*   CSCRM00764040
* 
* AR40.10.0.0; 1     05.03.2015 UDKOEGEL
*   CSCRM00794300
* 
* AR40.10.0.0; 0     02.03.2015 UDKOEGEL
*   CSCRM00791919
* 
* AR40.8.0.0; 3     15.05.2014 VSA2COB
*   CSCRM00662943
* 
* AR40.8.0.0; 2     20.03.2014 CLH2SI
*   CSCRM00633913
* 
* AR40.8.0.0; 1     12.03.2014 SAL2COB
*   CSCRM00594822_IntroduceHistoryStatus
* 
* AR40.8.0.0; 0     10.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 7     12.12.2013 GET1COB
*   CSCRM00597621
* 
* AR40.7.0.0; 6     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* AR40.7.0.0; 5     19.11.2013 BRM2COB
*   
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
