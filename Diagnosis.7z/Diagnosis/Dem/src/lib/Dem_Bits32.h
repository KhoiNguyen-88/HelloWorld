/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_Bits32$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_BITS32_H_
#define DEM_BITS32_H_


#include "Dem_Types.h"


DEM_INLINE uint32 Dem_BitMsk32(uint8 pos, uint8 len)
{
    uint32 bit2shift = 1;
    return (((bit2shift << len) - 1u ) << pos);
}

DEM_INLINE uint32 Dem_Bit32ExtractBitField(uint32 value, uint8 pos, uint8 len)
{
    return ((value & Dem_BitMsk32(pos, len)) >> pos);
}

DEM_INLINE void Dem_Bit32MergeBitField(uint32* base, uint8 pos, uint8 len, uint32 pattern)
{
    *base = ((*base & (~(Dem_BitMsk32(pos, len)))) | ((pattern & Dem_BitMsk32(0, len)) << pos));
}


DEM_INLINE void Dem_Bit32SetBit(uint32 *buffer, uint8 bit_position)
{
    uint32 bit2shift = 1;
    *buffer |= ((uint32)(bit2shift << bit_position));
}


DEM_INLINE void Dem_Bit32ClearBit(uint32 *buffer, uint8 bit_position)
{
    uint32 bit2shift = 1;
    *buffer &= ((uint32)(~((uint32)(bit2shift << bit_position))));
}


DEM_INLINE void Dem_Bit32OverwriteBit(uint32 *buffer, uint8 bit_position, Dem_boolean_least will_bit_be_set)
{
   if (will_bit_be_set)
   {
      Dem_Bit32SetBit(buffer, bit_position);
   }
   else
   {
      Dem_Bit32ClearBit(buffer, bit_position);
   }
}


DEM_INLINE Dem_boolean_least Dem_Bit32IsBitSet(uint32 value, uint8 bit_position)
{
   return (Dem_boolean_least)(((value >> bit_position) & 1u) != 0u);
}


DEM_INLINE uint32 Dem_Bit32GetBits(uint32 value, uint8 bit_position, uint8 number_of_bits)
{
    uint32 bit2shift = 1;
    value = value >> bit_position;
    value = value % ((uint32)(bit2shift << number_of_bits));
    return value;
}


DEM_INLINE void Dem_Bit32ClearBits(uint32 *value, uint8 bit_position, uint8 number_of_bits)
{
    uint32 bit2shift = 1;
    *value &= ((uint32)(~((uint32)((((uint32)(bit2shift << number_of_bits))-1u) << bit_position ))));
}

DEM_INLINE void Dem_Bit32OverwriteBits(uint32 *value, uint8 bit_position, uint8 number_of_bits, uint32 newValue)
{
    uint32 bit2shift = 1;
    Dem_Bit32ClearBits(value,bit_position,number_of_bits);
    *value |= ((uint32)((newValue % ((uint32)(bit2shift << number_of_bits))) << bit_position));
}

DEM_INLINE void Dem_Bit32ClearAll (uint8 *buffer)
{
   *buffer = 0u;
}

#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     16.10.2015 VSA2COB
*   Checkout by vsa2cob
* 
* AR40.10.0.0; 1     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 0     16.04.2015 CLH2SI
*   CSCRM00764027
* 
* AR40.9.0.0; 0     15.10.2014 GJ83ABT
*   CSCRM00719089, CSCRM00650337, CSCRM00625552, CSCRM00434933
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     10.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 0     21.10.2013 CLH2SI
*   CSCRM00585471
* 
* AR40.4.0.0; 1     08.07.2013 BRM2COB
*   CSCRM00541186 : Removal of MISRA warnings
* 
* AR40.4.0.0; 0     05.07.2012 BRM2COB
*   Version updated to AR40.4.0.0
* 
* AR 40.4_2012-5; 1     27.06.2012 BRM2COB
*   GIT to eASEE 27-06
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
