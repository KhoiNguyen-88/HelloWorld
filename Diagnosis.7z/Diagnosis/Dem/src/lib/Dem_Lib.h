/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2014. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_Lib$
* $Variant___:AR40.11.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_LIB_H
#define DEM_LIB_H

#include "Dem_Types.h"

/* Defines */
#define DEM_MAXSINT16   0x7FFF

void Dem_ByteSwapping( void *dest, void const *src, uint32 size );



// these functions are necessary to avoid compiler warnings of the kind "statement is always FALSE"
DEM_INLINE uint32 Dem_LibGetParamUI32( uint32 parameter )
{
    return parameter;
}

DEM_INLINE uint16 Dem_LibGetParamUI16( uint16 parameter )
{
    return parameter;
}

DEM_INLINE uint8 Dem_LibGetParamUI8( uint8 parameter )
{
    return parameter;
}

DEM_INLINE boolean Dem_LibGetParamBool( boolean parameter )
{
    return parameter;
}

DEM_INLINE void Dem_BigEndian_WriteValue2Buffer(uint8 *buffer, uint32 value, uint32 size)
{
    while (size > 0u)
    {
        size--;
        buffer[size] = (uint8)(value & 0xFFu);
        value = value / 0x100u;
    }
}

#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 1     10.11.2015 VSA2COB
*   Checkout by vsa2cob
* 
* AR40.11.0.0; 0     17.09.2015 UDKOEGEL
*   CSCRM00960004
* 
* AR40.10.0.0; 0     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.8.0.0; 0     13.06.2014 WUG3ABT
*   CSCRM00610171
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
