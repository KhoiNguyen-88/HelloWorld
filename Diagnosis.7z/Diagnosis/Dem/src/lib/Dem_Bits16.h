/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_Bits16$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_BITS16_H
#define DEM_BITS16_H


#include "Dem_Types.h"


DEM_INLINE void Dem_Bit16SetBit(uint16 *buffer, uint8 bit_position)
{
    uint16 bit2shift = 1;
    *buffer |= ((uint16)(bit2shift << bit_position));
}


DEM_INLINE void Dem_Bit16ClearBit(uint16 *buffer, uint8 bit_position)
{
    uint16 bit2shift = 1;
    *buffer &= ((uint16)(~((uint16)(bit2shift << bit_position))));
}


DEM_INLINE void Dem_Bit16OverwriteBit(uint16 *buffer, uint8 bit_position, Dem_boolean_least will_bit_be_set)
{
   if (will_bit_be_set)
   {
      Dem_Bit16SetBit(buffer, bit_position);
   }
   else
   {
      Dem_Bit16ClearBit(buffer, bit_position);
   }
}


DEM_INLINE Dem_boolean_least Dem_Bit16IsBitSet(uint16 value, uint8 bit_position)
{
   return (Dem_boolean_least)(((value >> bit_position) & 1u) != 0u);
}


DEM_INLINE uint16 Dem_Bit16GetBits(uint16 value, uint8 bit_position, uint8 number_of_bits)
{
    uint16 bit2shift = 1;
    value = value >> bit_position;
    value = value % ((uint16)(bit2shift << number_of_bits));
    return value;
}


DEM_INLINE void Dem_Bit16ClearBits(uint16 *value, uint8 bit_position, uint8 number_of_bits)
{
    uint16 bit2shift = 1;
    *value &= ((uint16)(~((uint16)((((uint16)(bit2shift << number_of_bits))-1u) << bit_position ))));
}

DEM_INLINE void Dem_Bit16OverwriteBits(uint16 *value, uint8 bit_position, uint8 number_of_bits, uint16 newValue)
{
    uint16 bit2shift = 1;
    Dem_Bit16ClearBits(value,bit_position,number_of_bits);
    *value |= ((uint16)((newValue % ((uint16)(bit2shift << number_of_bits))) << bit_position));
}

DEM_INLINE void Dem_Bit16ClearAll (uint16 *buffer)
{
   *buffer = 0u;
}


#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     16.10.2015 VSA2COB
*   Checkout by vsa2cob
* 
* AR40.10.0.0; 1     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 0     16.04.2015 CLH2SI
*   CSCRM00764027
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     10.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 2     19.11.2013 BRM2COB
*   
* 
* AR40.7.0.0; 1     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 0     21.10.2013 CLH2SI
*   CSCRM00585471
* 
* AR40.4.0.0; 1     08.07.2013 BRM2COB
*   CSCRM00541186 : Removal of MISRA warnings
* 
* AR40.4.0.0; 0     05.07.2012 BRM2COB
*   Version updated to AR40.4.0.0
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
