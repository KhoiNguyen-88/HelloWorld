/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2014. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_Lib$
* $Variant___:AR40.8.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/

#include "Dem_Lib.h"

//HIGH_BYTE_FIRST / big endian / motorola
//LOW_BYTE_FIRST / little endian / intel

#ifndef CPU_BYTE_ORDER
	#error "Macro for CPU byte order is not defined"
#endif

#ifndef HIGH_BYTE_FIRST
	#error "Macro for endianess byte order is not defined"
#endif

#ifndef LOW_BYTE_FIRST
	#error "Macro for endianess byte order is not defined"
#endif

#if (CPU_BYTE_ORDER != HIGH_BYTE_FIRST) && (CPU_BYTE_ORDER != LOW_BYTE_FIRST)
	#error "Macro CPU byte order is not mapped to a know endianess byte order"
#endif


//local variables and memcpy is necessary, because
//we are not aware of the memory alignment of dest and src

void Dem_ByteSwapping(void *dest, void const *src, uint32 size)
{
	if (1 == size)
	{
		DEM_MEMCPY(dest, src, size);
	}
	else if (2 == size)
	{
		uint16 tmp16;
		DEM_MEMCPY((void*)(&tmp16), src, size);
		tmp16 = rba_BswSrv_ByteOrderSwap16(tmp16);
		DEM_MEMCPY(dest, (void const *)(&tmp16), size);
	}
	else if (4 == size)
	{
		uint32 tmp32;
		DEM_MEMCPY((void*)(&tmp32), src, size);
		tmp32 = rba_BswSrv_ByteOrderSwap32(tmp32);
		DEM_MEMCPY(dest, (void const *)(&tmp32), size);
	}
	else
	{
		DEM_DET(DEM_DET_APIID_SERIALIZATION, DEM_E_PARAM_LENGTH);
	}
}

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.8.0.0; 0     13.06.2014 WUG3ABT
*   CSCRM00610171
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
