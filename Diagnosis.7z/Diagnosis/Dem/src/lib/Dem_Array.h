/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_Array$
* $Variant___:AR40.10.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_ARRAY_H
#define DEM_ARRAY_H


#include "Dem_Cfg_Main.h"
#include "Dem_Types.h"


/* USAGE examples:

Array definitions with automatic bound-check during Simulation and Testsuite run.
Arrays have to be declared and defined as the following examples show:

in header:
==========
DEM_DECLARE_ARRAY(Monitoring_State, Dem_AllEventsState, C_NUMBER_OF_EVENTS+1);
DEM_DECLARE_ARRAY(const Monitoring, Dem_AllEventsParam, C_NUMBER_OF_EVENTS+1);

in source:
==========
DEM_DEFINE_ARRAY(Monitoring_State, Dem_AllEventsState, C_NUMBER_OF_EVENTS+1);
DEM_DEFINE_ARRAY(const Monitoring, Dem_AllEventsParam, C_NUMBER_OF_EVENTS+1) = {
    DEM_EVTS_INIT (C_SID_INVALID,                  0,      DEM_SENSITIVITY_BASE, DEM_SENSITIVITY_BASE, 0,         0,           RECOV,   DCYC,      NOWIR,    RESET_FL, NO_GC,     Dem_EventCategoryExternalFault,          (0),                                         (0))
   ,DEM_EVTS_INIT (C_SID_N01_N,                    1,      DEM_SENSITIVITY_BASE, DEM_SENSITIVITY_BASE, 0,         0,           RECOV,   DCYC,      NOWIR,    RESET_FL, NO_GC,     Dem_EventCategoryExternalFault,          SITUATIONFILTER_Monitoring_01,               ENABLECONDITION_Monitoring_01)
   ,DEM_EVTS_INIT (C_SID_N01_N,                    1,      DEM_SENSITIVITY_BASE, DEM_SENSITIVITY_BASE, 0,         0,           RECOV,   NODC,      NOWIR,    NO_RESET, NO_GC,     Dem_EventCategoryExternalFault,          SITUATIONFILTER_Monitoring_09,               ENABLECONDITION_Monitoring_09)
}

*/


#if (   (DEM_CFG_BUILDTARGET == DEM_CFG_BUILDTARGET_ECU) \
     || (defined DEM_TEST_FORCE_PLAIN_ARRAY))


/* MISRA RULE 19.10 VIOLATION : Macro parameter may not be enclosed in (). */
   #define DEM_ARRAY_DECLARE(TYPE,NAME,SIZE)                 extern TYPE NAME[SIZE]
/* MISRA RULE 19.10 VIOLATION : Macro parameter may not be enclosed in (). */
   #define DEM_ARRAY_DECLARE_CONST(TYPE,NAME,SIZE)           extern const TYPE NAME[SIZE]

/* MISRA RULE 19.10 VIOLATION : Macro parameter may not be enclosed in (). */
   #define DEM_ARRAY_DEFINE(TYPE,NAME,SIZE)                  TYPE NAME[SIZE]

/* MISRA RULE 19.10 VIOLATION : Macro parameter may not be enclosed in (). */
   #define DEM_ARRAY_DEFINE_CONST(TYPE,NAME,SIZE,INITVALUE)  const TYPE NAME[SIZE] = INITVALUE

/* MISRA RULE 19.10 VIOLATION : Macro parameter may not be enclosed in (). */
   #define DEM_ARRAY_FUNCPARAM(TYPE,NAME)                    TYPE NAME[]
/* MISRA RULE 19.10 VIOLATION : Macro parameter may not be enclosed in (). */
   #define DEM_ARRAY_CONSTFUNCPARAM(TYPE,NAME)               const TYPE NAME[]

   #define DEM_SIZEOF_VAR(x)                sizeof(x)
   #define DEM_SIZEOF_TYPE(x)               sizeof(x)


#else

#include "DemTest_Array.h"

#endif


#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 1     12.05.2015 CLH2SI
*   CSCRM00789099
* 
* AR40.10.0.0; 0     17.03.2015 TVE5COB
*   CSCRM00789300
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     10.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 7     19.11.2013 CLH2SI
*   CSCRM00578067
* 
* AR40.7.0.0; 6     22.10.2013 AMN2KOR
*   CSCRM00547887
* 
* AR40.7.0.0; 5     21.10.2013 CLH2SI
*   CSCRM00585471
* 
* AR40.7.0.0; 4     19.09.2013 WUG3ABT
*   CSCRM00553699
* 
* AR40.7.0.0; 3     30.08.2013 OPI2KOR
*   CSCRM00536559:[Int-Diagnosis] Updated of latest BSWSIM and STB packages into
*    Development environment
* 
* AR40.7.0.0; 2     08.08.2013 CLH2SI
*   CSCRM00532300
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
