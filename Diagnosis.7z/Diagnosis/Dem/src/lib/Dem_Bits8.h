/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_Bits8$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_BITS8_H
#define DEM_BITS8_H


#include "Dem_Types.h"


DEM_INLINE void Dem_Bit8SetBit(uint8 *buffer, uint8 bit_position)
{
    uint8 bit2shift = 1;
    *buffer |= ((uint8)(bit2shift << bit_position));
}


DEM_INLINE void Dem_Bit8ClearBit(uint8 *buffer, uint8 bit_position)
{
    uint8 bit2shift = 1;
    *buffer &= ((uint8)(~((uint8)(bit2shift << bit_position))));
}


DEM_INLINE void Dem_Bit8OverwriteBit(uint8 *buffer, uint8 bit_position, Dem_boolean_least will_bit_be_set)
{
   if (will_bit_be_set)
   {
      Dem_Bit8SetBit(buffer, bit_position);
   }
   else
   {
      Dem_Bit8ClearBit(buffer, bit_position);
   }
}


DEM_INLINE Dem_boolean_least Dem_Bit8IsBitSet (uint8 value, uint8 bit_position)
{
   return (Dem_boolean_least)(((value >> (bit_position)) & 1u) != 0u);
}


DEM_INLINE uint8 Dem_Bit8GetBits(uint8 value, uint8 bit_position, uint8 number_of_bits)
{
    uint8 bit2shift = 1;
    value = value >> bit_position;
    value = value % ((uint8)(bit2shift << number_of_bits));
    return value;
}


DEM_INLINE void Dem_Bit8ClearBits(uint8 *value, uint8 bit_position, uint8 number_of_bits)
{
    uint8 bit2shift = 1;
    *value &= ((uint8)(~((uint8)((((uint8)(bit2shift << number_of_bits))-1u) << bit_position ))));
}

DEM_INLINE void Dem_Bit8OverwriteBits(uint8 *value, uint8 bit_position, uint8 number_of_bits, uint8 newValue)
{
    uint8 bit2shift = 1;
    Dem_Bit8ClearBits(value,bit_position,number_of_bits);
    *value |= ((uint8)((newValue % ((uint8)(bit2shift << number_of_bits))) << bit_position));
}

DEM_INLINE void Dem_Bit8ClearAll (uint8 *buffer)
{
   *buffer = 0u;
}

DEM_INLINE uint8 Dem_Bit8BitsDeactivated (uint8 oldValue, uint8 newValue)
{
   return ((oldValue ^ newValue) & oldValue);
}

DEM_INLINE uint8 Dem_Bit8BitsActivated (uint8 oldValue, uint8 newValue)
{
   return ((oldValue ^ newValue) & newValue);
}

#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     16.10.2015 VSA2COB
*   Checkout by vsa2cob
* 
* AR40.10.0.0; 1     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 0     16.04.2015 CLH2SI
*   CSCRM00764027
* 
* AR40.8.0.0; 2     19.06.2014 BRM2COB
*   CSCRM00659761
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     10.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 3     19.11.2013 BRM2COB
*   
* 
* AR40.7.0.0; 2     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* AR40.7.0.0; 1     21.10.2013 CLH2SI
*   CSCRM00585471
* 
* AR40.7.0.0; 0     08.08.2013 CLH2SI
*   CSCRM00532300
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
