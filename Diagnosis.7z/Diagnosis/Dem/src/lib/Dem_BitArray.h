/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_BitArray$
* $Variant___:AR40.10.0.0$
* $Revision__:2$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_BITARRAY_H
#define DEM_BITARRAY_H


#include "Dem_Types.h"
#include "Dem_Array.h"
#include "Dem_Lock.h"


#define DEM_BITARRAY_DATAELEMENTS( BITCOUNT )            ((((BITCOUNT)-1u) >> 5u)+1UL)
/* #define DEM_BITARRAY_ELEMENTINDEX( BITNO )               ((BITNO) >> 5)
   #define DEM_BITARRAY_BITMASK( BITNO )                    ((UL)(1 << (((BITNO)) & 31)))
   #define DEM_BITARRAY_BYTESIZE( VARNAME, BITCOUNT )       (DEM_BITARRAY_DATAELEMENTS(BITCOUNT)*DEM_SIZEOF_VAR(uint32))
   #define DEM_BITARRAY_ADDRESS(VARNAME)                    DEM_ARRAY_ADDRESS(VARNAME) */

#define DEM_BITARRAY_DECLARE( VARNAME, BITCOUNT )        DEM_ARRAY_DECLARE(uint32, VARNAME, DEM_BITARRAY_DATAELEMENTS(BITCOUNT))
#define DEM_BITARRAY_DECLARE_CONST( VARNAME, BITCOUNT )  DEM_ARRAY_DECLARE(const uint32, VARNAME, DEM_BITARRAY_DATAELEMENTS(BITCOUNT))
#define DEM_BITARRAY_DEFINE( VARNAME, BITCOUNT )         DEM_ARRAY_DEFINE(uint32, VARNAME, DEM_BITARRAY_DATAELEMENTS(BITCOUNT))
#define DEM_BITARRAY_DEFINE_CONST( VARNAME, BITCOUNT )   DEM_ARRAY_DEFINE(const uint32, VARNAME, DEM_BITARRAY_DATAELEMENTS(BITCOUNT))

#define DEM_BITARRAY_FUNCPARAM(VARNAME)                  DEM_ARRAY_FUNCPARAM(uint32,VARNAME)
#define DEM_BITARRAY_CONSTFUNCPARAM(VARNAME)             DEM_ARRAY_CONSTFUNCPARAM(uint32,VARNAME)


/** The size of an element of a bitfield in bits. */
#define DEM_BITARRAY_ELEMENT_BITSIZE \
    (DEM_SIZEOF_TYPE(uint32) * 8u)


DEM_INLINE void Dem_BitArraySetBit(DEM_BITARRAY_FUNCPARAM(buffer), unsigned bit_position)
{
    /* Assume that bit_position is within buffer */
    const unsigned element_pos = ((unsigned)(bit_position / DEM_BITARRAY_ELEMENT_BITSIZE));
    const unsigned local_bitpos = ((unsigned)(bit_position % DEM_BITARRAY_ELEMENT_BITSIZE));
    const uint32 mask =
            ((uint32) 1) << local_bitpos;

    buffer[element_pos] |= mask;
    return;
}


DEM_INLINE void Dem_BitArrayClearBit(DEM_BITARRAY_FUNCPARAM(buffer), unsigned bit_position)
{
    /* Assume that bit_position is within buffer */
    const unsigned element_pos = ((unsigned)(bit_position / DEM_BITARRAY_ELEMENT_BITSIZE));
    const unsigned local_bitpos = ((unsigned)(bit_position % DEM_BITARRAY_ELEMENT_BITSIZE));
    const uint32 mask =
            ((uint32) 1) << local_bitpos;

    buffer[element_pos] &= (uint32) ~ mask;
    return;
}




DEM_INLINE void Dem_BitArrayOverwriteBit(DEM_BITARRAY_FUNCPARAM(buffer),
                 unsigned bit_position, Dem_boolean_least will_bit_be_set)
{
    if (will_bit_be_set) {
        Dem_BitArraySetBit(buffer, bit_position);
    } else {
        Dem_BitArrayClearBit(buffer, bit_position);
    }
    return;
}




DEM_INLINE Dem_boolean_least Dem_BitArrayIsBitSet(DEM_BITARRAY_CONSTFUNCPARAM(buffer), unsigned bit_position)
{
    /* Assume that bit_position is within buffer */
    const unsigned element_pos = ((unsigned)(bit_position / DEM_BITARRAY_ELEMENT_BITSIZE));
    const unsigned local_bitpos = ((unsigned)(bit_position % DEM_BITARRAY_ELEMENT_BITSIZE));
    const uint32 mask =
            ((uint32) 1) << local_bitpos;

    /* Comparison is necessary in case element type is unsigned and
     * local_bitpos has its maximal value: the conversion to int would
     * be implementation-defined otherwise. */
    return (buffer[element_pos] & mask) != 0u;
}





DEM_INLINE void Dem_BitArrayClearAll (DEM_BITARRAY_FUNCPARAM(buffer), unsigned number_of_bits)
{
    unsigned i;
    for (i = 0; i < DEM_BITARRAY_DATAELEMENTS(number_of_bits); i++) {
        buffer[i] = 0U;
    }
    return;
}

DEM_INLINE void Dem_BitArrayClearAll_WithInterrupt (DEM_BITARRAY_FUNCPARAM(buffer), unsigned number_of_bits)
{
   unsigned i;
   DEM_ENTERLOCK_MON_BEFORE_INIT();
   for (i = 0; i < DEM_BITARRAY_DATAELEMENTS(number_of_bits); i++)
   {
      buffer[i] = 0U;
      if ((i%16u) == 0u)
      {
         DEM_EXITLOCK_MON_BEFORE_INIT();
         DEM_ENTERLOCK_MON_BEFORE_INIT();
      }
   }
   DEM_EXITLOCK_MON_BEFORE_INIT();
   return;
}

#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 2     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 1     12.05.2015 CLH2SI
*   CSCRM00789099
* 
* AR40.10.0.0; 0     17.03.2015 TVE5COB
*   CSCRM00789300
* 
* AR40.9.0.0; 1     17.11.2014 GJ83ABT
*   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
* 
* AR40.9.0.0; 0     15.10.2014 GJ83ABT
*   CSCRM00719089, CSCRM00650337, CSCRM00625552, CSCRM00434933
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     10.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 2     21.11.2013 AMN2KOR
*   CSCRM00591723
* 
* AR40.7.0.0; 1     19.11.2013 BRM2COB
*   
* 
* AR40.7.0.0; 0     18.11.2013 BPE4COB
*   CSCRM00560880: [Dem] Provided Memmap header
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
