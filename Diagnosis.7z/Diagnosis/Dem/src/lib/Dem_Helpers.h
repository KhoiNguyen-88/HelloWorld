/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_Helpers$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_HELPERS_H
#define DEM_HELPERS_H


#define DEM_A_MAX_AB(a,b)    do { if ( (a) < (b) )\
                                  {(a) = (b);}\
                             } while (0)

#define DEM_A_MIN_AB(a,b)    do { if ( (a) > (b) )\
                                  {(a) = (b);}\
                             } while (0)

#define DEM_MIN(a, b)        ( ((a) < (b)) ? (a) : (b) )

#define DEM_MAX(a, b)        ( ((a) > (b)) ? (a) : (b) )

#define DEM_BOOLIFY(X)  ((X)!=(0))

#define DEM_BOOL2BIT(X) (((X)!=FALSE)?(1u):(0u))


#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     16.10.2015 VSA2COB
*   Checkout by vsa2cob
* 
* AR40.10.0.0; 0     10.07.2015 CLH2SI
*   CSCRM00938605
* 
* AR40.8.0.0; 1     21.03.2014 VSA2COB
*   CSCRM00619537
* 
* AR40.8.0.0; 0     10.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 0     21.10.2013 CLH2SI
*   CSCRM00585471
* 
* AR40.4.0.0; 1     27.06.2012 BRM2COB
*   GIT to eASEE 27-06
* 
* AR40.4.0.0; 0     14.02.2012 CLH2SI
*   GIT-SYNC: a0008d733d3a94fa3e0a3e39260972344e821bef
* 
* AR40.0.0.1; 1     12.12.2011 ALA2ABT
*   Git Commit:b21a116571d3e20441afe258ab336b12b1970d77
*   
* 
* AR40.0.0.1; 0     18.08.2011 CLH2SI
*   initial Rev based on Git-Rev:
*   e1ad93e3ec82d69d1a37032dd0fd856e9b21099e
*   
*   Requests:
*   CSCRM00293299
*   CSCRM00320676
*   CSCRM00320616
*   CSCRM00320579
*   CSCRM00320488
*   CSCRM00320415
*   CSCRM00318395
*   CSCRM00316439
*   CSCRM00316437
*   CSCRM00312185
*   CSCRM00312176
*   CSCRM00312173
*   CSCRM00312166
*   CSCRM00312162
*   CSCRM00312159
*   CSCRM00333624
*   
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
