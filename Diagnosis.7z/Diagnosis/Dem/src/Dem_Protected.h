/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2015. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_Protected$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_PROTECTED_H
#define DEM_PROTECTED_H

#if  (DEM_CFG_CHECKAPICONSISTENCY == FALSE)
#define DEM_HIDE_RTEAPIS
#endif
#include "Dem_NoRte.h"


#endif /* DEM_PROTECTED_H */

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     07.01.2016 TVE5COB
*   CSCRM01017790
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
