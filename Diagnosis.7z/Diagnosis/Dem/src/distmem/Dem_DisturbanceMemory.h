/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_DisturbanceMemory$
* $Variant___:AR40.10.0.0$
* $Revision__:2$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_DISTURBANCEMEMORY_H
#define DEM_DISTURBANCEMEMORY_H


#include "Dem_Types.h"
#include "Dem_Array.h"
#include "Dem_Bits8.h"
#include "Dem_Bits16.h"
#include "Dem_Cfg_DistMem.h"
#include "Dem_Cfg_EnvMain.h"


#if(DEM_CFG_DISTURBANCE_MEMORY == DEM_CFG_DISTURBANCE_MEMORY_ON)


#define DEM_DIST_MEM_BP_FLAG_TEST_CURRENT      (0u)
#define DEM_DIST_MEM_BP_FLAG_TEST_DISTURBED    (1u)
#define DEM_DIST_MEM_BP_UPDATE_EXTN_DATA       (2u)




typedef uint8 Dem_DistMemLocationStatusType;
#define DEM_DIST_MEM_ISBITSET      Dem_Bit8IsBitSet
#define DEM_DIST_MEM_OVERWRITEBIT  Dem_Bit8OverwriteBit
#define DEM_DIST_MEM_CLEARBIT      Dem_Bit8ClearBit
#define DEM_DIST_MEM_SETBIT        Dem_Bit8SetBit


/* Location 0 in Disturbance Memory is considered as Invalid location */
#define DEM_DIST_MEM_INVALID_LOC  		0u
/* After Dem_Init, Events stored back from NvM to Disturbance Memory, events get the default status 0
   Default status flag with TEST_CURRENT-0,TEST_DISTURBED-0 & UpdateExtndata Required No */
#define DEM_DIST_MEM_INIT_STATUS_BYTE	0u
/* Events stored to  Disturbance Memory first time gets the default status TEST_CURRENT-1,TEST_DISTURBED-0 & UpdateExtndata Required Yes */
#define DEM_DIST_MEM_NEW_ENTRY_STATUS_BYTE ((uint8)(1u<<DEM_DIST_MEM_BP_FLAG_TEST_CURRENT) | (uint8)(1u<<DEM_DIST_MEM_BP_UPDATE_EXTN_DATA))

#define DEM_DIST_MEM_MAX_DIST_CTR_LIMIT  255u
/*---Disturbance memory storage type ---------------------------------------------------------------------------------*/
/* Type that holds the elements of disturbance memory structure. EventId ,disturbanceCtr ,env data & debug data stored in
   This type holds the elements that are stored persistently in NvRam */

typedef struct
{
	uint8 disturbanceCtr;
#if(DEM_CFG_DIST_MEM_EXTENDED_DATA_USED == STD_ON)
	uint8 extData[DEM_CFG_DIST_MEM_EXT_DATA_SIZE];
#endif
	Dem_EventIdType eventId;
	#if (DEM_CFG_DEBUGDATA != DEM_CFG_DEBUGDATA_OFF)
	Dem_DebugDataType debug0;
	Dem_DebugDataType debug1;
	#endif
} Dem_DistMemLocationType;


/* RAM block base address - #define DEM_DIST_MEM_NVRAM_RAM_BASE_ADDRESS &Dem_DistMemLocations[1]
and size is size-of(Dem_DistMemLocationsType) * DEM_CFG_DISTURBANCE_MEMORY_SIZE */


/*---GLOBAL VARIABLES  declaration ---------------------------------------------------------------------------------*/
#define DEM_START_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"
DEM_ARRAY_DECLARE( Dem_DistMemLocationType, Dem_DistMemLocations, (DEM_CFG_DISTURBANCE_MEMORY_ARRAYLENGTH));
#define DEM_STOP_SEC_SAVED_ZONE
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"
extern uint8 Dem_DistMemNextEmptyIndex;
#define DEM_STOP_SEC_RAM_INIT
#include "Dem_Cfg_MemMap.h"

#define DEM_START_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"
DEM_ARRAY_DECLARE( Dem_DistMemLocationStatusType, Dem_DistMemLocationsStatus, (DEM_CFG_DISTURBANCE_MEMORY_ARRAYLENGTH));
extern uint8 Dem_DistMemReadIndex;
#define DEM_STOP_SEC_RAM_CLEARED
#include "Dem_Cfg_MemMap.h"




/*-- EVENT ID in DISTURBANCE MEMORY---------------------------------------------------------------------------------*/


DEM_INLINE Dem_EventIdType Dem_DistMemGetStoredEventId (uint8 DistMemIndex)
{
   return Dem_DistMemLocations[DistMemIndex].eventId;
}

DEM_INLINE void Dem_DistMemSetStoredEventId (uint8 DistMemIndex , Dem_EventIdType EventId)
{
   Dem_DistMemLocations[DistMemIndex].eventId = EventId;
}

/*-- DISTURBANCE COUNTER in DISTURBANCE MEMORY---------------------------------------------------------------------------------*/
DEM_INLINE uint8 Dem_DistMemGetStoredDisturbanceCounter (uint8 DistMemIndex)
{
   return Dem_DistMemLocations[DistMemIndex].disturbanceCtr;
}

/*-- TEST_CURRENT FLAG----------------------------------------------------------------------------------------------*/

DEM_INLINE Dem_boolean_least Dem_DistMemEvtGetTestCurrent_Flag (uint8 DistMemIndex)
{
   return DEM_DIST_MEM_ISBITSET (Dem_DistMemLocationsStatus[DistMemIndex], DEM_DIST_MEM_BP_FLAG_TEST_CURRENT);
}


DEM_INLINE void Dem_DistMemEvtWriteTestCurrent_Flag (uint8 DistMemIndex , Dem_boolean_least setBit )
{
	DEM_DIST_MEM_OVERWRITEBIT (&Dem_DistMemLocationsStatus[DistMemIndex], DEM_DIST_MEM_BP_FLAG_TEST_CURRENT , setBit);
}



/*-- TEST_DISTURBED FLAG--------------------------------------------------------------------------------------------*/

DEM_INLINE Dem_boolean_least Dem_DistMemEvtGetTestDisturbed_Flag (uint8 DistMemIndex)
{
   return DEM_DIST_MEM_ISBITSET (Dem_DistMemLocationsStatus[DistMemIndex], DEM_DIST_MEM_BP_FLAG_TEST_DISTURBED);
}

DEM_INLINE void Dem_DistMemEvtSetTestDisturbed_Flag (uint8 DistMemIndex)
{
	DEM_DIST_MEM_SETBIT (&Dem_DistMemLocationsStatus[DistMemIndex], DEM_DIST_MEM_BP_FLAG_TEST_DISTURBED);
}



/*-- UPDATE_EXTN_DATA FLAG------------------------------------------------------------------------------------------*/

DEM_INLINE Dem_boolean_least Dem_DistMemIsUpdateEvtExtDataNecessary (uint8 DistMemIndex)
{
   return DEM_DIST_MEM_ISBITSET (Dem_DistMemLocationsStatus[DistMemIndex], DEM_DIST_MEM_BP_UPDATE_EXTN_DATA);
}

DEM_INLINE void Dem_DistMemRequestUpdateEvtExtData (uint8 DistMemIndex)
{
	DEM_DIST_MEM_SETBIT (&Dem_DistMemLocationsStatus[DistMemIndex], DEM_DIST_MEM_BP_UPDATE_EXTN_DATA);
}

DEM_INLINE void Dem_DistMemClearUpdateEvtExtData (uint8 DistMemIndex)
{
	DEM_DIST_MEM_CLEARBIT (&Dem_DistMemLocationsStatus[DistMemIndex], DEM_DIST_MEM_BP_UPDATE_EXTN_DATA);
}

/*-- DISTURBANCE MEMORY EVENTS STATUS BYTE AS A WHOLE---------------------------------------------------------------*/


DEM_INLINE void Dem_DistMemSetStatusByte (uint8 DistMemIndex , uint8 newStatus)
{
	Dem_DistMemLocationsStatus[DistMemIndex] = newStatus;
}





/*-- DISTURBANCE MEMORY ENV DATA--------------------------------------------------------------------------------------*/

#if(DEM_CFG_DIST_MEM_EXTENDED_DATA_USED == STD_ON)
DEM_INLINE void Dem_DistMemGetEnvData (uint8 DistMemIndex ,uint8* dest, uint8 size)
{
	DEM_MEMCPY(dest, Dem_DistMemLocations[DistMemIndex].extData , size );
}
#endif



/*---APIs  declaration ---------------------------------------------------------------------------------------------*/

DEM_INLINE Dem_boolean_least Dem_DistMemIsFull (void)
{
	return (Dem_DistMemNextEmptyIndex == 0);
}


DEM_INLINE Dem_boolean_least Dem_DistMemIsReportFailedNecessary (Dem_EventIdType eventId, Dem_EventStatusType eventStatus)
{
   return (   ((eventStatus==DEM_EVENT_STATUS_FAILED) || (eventStatus==DEM_EVENT_STATUS_PREFAILED))
		   && (Dem_EvtIsEventStoredInDistMem(eventId) || !Dem_DistMemIsFull()));
}



#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
void Dem_DistMemReportFailed(Dem_EventIdType EventId
							 DEM_DEBUGDATA_PARAM(Dem_DebugDataType debug0, Dem_DebugDataType debug1));

void Dem_DistMemReportPassed(Dem_EventIdType EventId);

/**
 * @ingroup DEM_EXT_H
 *
 * Interface to clear events that are stored in disturbance memory.
 *  @return  E_OK: Clear disturbance memory was successful\n
 *             E_NOT_OK: Clear disturbance memory was not successful\n
 */
Std_ReturnType Dem_ClearDisturbanceMemory (void);

void Dem_DistMemInitCheckNvM(void);
void Dem_DistMemInit(void);
void Dem_DistMemMainFunction(void);

#if (DEM_CFG_TRIGGER_TO_STORE_NVM_SUPPORTED)
void Dem_DistMemTriggerStoreToNvM(void);
#endif

void Dem_DistMemShutdown(void);

/**
 * @ingroup DEM_EXT_H
 *
 * Interface to start reading the disturbance memory.
 *  @return  E_OK: Reading the disturbance memory was successful\n
 *           E_NOT_OK: Reading the disturbance memory was not successful\n
 */
Std_ReturnType Dem_ReadDisturbanceMemory (void);

/**
 * @ingroup DEM_EXT_H
 *
 * Interface to get the actual data from the disturbance memory.
 *
 * @param [out] EventId the identifier of the calling event
 * @param [out] DestBuffer Parameter contains a byte pointer that points to the buffer
 * @param [inout] BufSize When the function is called this parameter contains the maximum number of data bytes that can be written to the buffer.
 *  The function returns the actual number of written data bytes in this parameter.
 *
 *  @return  E_OK: Returned next element\n
 *           E_NOT_OK: no further element found\n
 */
Std_ReturnType Dem_GetNextDisturbanceData(Dem_EventIdType* EventId, uint8* DestBuffer, uint8* BufSize);

/**
 * @ingroup DEM_EXT_H
 *
 * Interface to lock the disturbance memory.
 * @param [in] Lock: describes whether the disturbance memory is locked or unlocked
 * @return E_OK: Accessing any of the functions is possible
 * @return E_NOT_OK: Only read and clear functions are accessible. Accessing other functions are not possible since the memory is locked for any insertion of events.
 */

Std_ReturnType Dem_LockDisturbanceMemory(boolean Lock);


#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif


#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.10.0.0; 2     14.07.2015 WUG3ABT
*   Checkout by wug3abt
* 
* AR40.10.0.0; 1     10.07.2015 CLH2SI
*   CSCRM00938605
* 
* AR40.10.0.0; 0     09.07.2015 RPV5COB
*   CSCRM00791814
* 
* AR40.9.0.0; 0     17.10.2014 BPE4COB
*   CSCRM00732499
* 
* AR40.8.0.0; 4     16.07.2014 BRM2COB
*   CSCRM00688243
* 
* AR40.8.0.0; 3     16.06.2014 BPE4COB
*   CSCRM00666829
* 
* AR40.8.0.0; 2     15.05.2014 VSA2COB
*   CSCRM00662943
* 
* AR40.8.0.0; 1     10.03.2014 VSA2COB
*   CSCRM00619537_ComassoChanges
* 
* AR40.8.0.0; 0     20.01.2014 SAL2COB
*   
* 
* AR40.7.0.0; 7     21.11.2013 GIN9COB
*   CSCRM00598921
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
