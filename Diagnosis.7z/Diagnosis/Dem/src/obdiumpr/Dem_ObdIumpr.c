/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:C$
* $Name______:Dem_ObdIumpr$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/


#include "Dem_ObdIumpr_Prv.h"
#include "Dem_ObdIumpr.h"
#include "Rte_Dem.h"
#include "Dem_Protected.h"


#if(DEM_CFG_OBD != DEM_CFG_OBD_OFF)

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

FUNC(Std_ReturnType, DEM_CODE) Dem_RepIUMPRFaultDetect (VAR(Dem_RatioIdType, AUTOMATIC) RatioID)
{
   /* CDG implementation does not support IUMPR for now */
    DEM_UNUSED_PARAM(RatioID);
    return E_NOT_OK;
}


FUNC(Std_ReturnType, DEM_CODE) Dem_RepIUMPRDenLock (VAR(Dem_RatioIdType, AUTOMATIC) RatioID)
{
   /* CDG implementation does not support IUMPR for now */
    DEM_UNUSED_PARAM(RatioID);
    return E_NOT_OK;
}


FUNC(Std_ReturnType, DEM_CODE) Dem_RepIUMPRDenRelease (VAR(Dem_RatioIdType, AUTOMATIC) RatioID)
{
   /* CDG implementation does not support IUMPR for now */
    DEM_UNUSED_PARAM(RatioID);
    return E_NOT_OK;
}

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif /* DEM_CFG_OBD != DEM_CFG_OBD_OFF */


/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     07.01.2016 TVE5COB
*   CSCRM01017790
* 
* AR40.9.0.0; 1     06.01.2015 GJ83ABT
*   CSCRM00751490
* 
* AR40.9.0.0; 0     17.11.2014 GJ83ABT
*   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
* 
* AR40.8.0.0; 0     15.04.2014 GJ83ABT
*   CSCRM00652072
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
