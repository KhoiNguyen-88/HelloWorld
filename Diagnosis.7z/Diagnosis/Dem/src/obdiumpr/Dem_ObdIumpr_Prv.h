/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************
* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_ObdIumpr_Prv$
* $Variant___:AR40.9.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_OBDIUMPR_PRV_H
#define DEM_OBDIUMPR_PRV_H


#include "Dem_Types.h"
#include "Dem_Cfg_Main.h"
#include "Dem_Cfg_ObdMain.h"
#include "Dem_Cfg_ObdIumpr.h"


#if(DEM_CFG_OBD != DEM_CFG_OBD_OFF)

#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"


DEM_INLINE void Dem_ObdIumprInit (void)
{
    /* CDG implementation does not support IUMPR for now */
}


DEM_INLINE void Dem_ObdIumprMainFunction (void)
{
    /* CDG implementation does not support IUMPR for now */
}


DEM_INLINE void Dem_ObdIumprShutdown (void)
{
    /* CDG implementation does not support IUMPR for now */
}


DEM_INLINE void Dem_ObdIumprClear (void)
{
    /* CDG implementation does not support IUMPR for now */
}


DEM_INLINE void Dem_ObdIumprStartDrivingCycle (void)
{
    /* CDG implementation does not support IUMPR for now */
}


#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"

#endif

#endif /* DEM_OBDIUMPR_PRV_H */

/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.9.0.0; 1     17.11.2014 GJ83ABT
*   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
* 
* AR40.9.0.0; 0     15.10.2014 GJ83ABT
*   CSCRM00719089, CSCRM00650337, CSCRM00625552, CSCRM00434933
* 
* MDG1_FORD_PRE_5; 0     15.10.2014 GJ83ABT
*   CSCRM00652728
* 
* $
**********************************************************************************************************************
</BASDKey>*/
