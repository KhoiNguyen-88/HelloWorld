/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************
* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_ObdIumpr$
* $Variant___:AR40.9.0.0$
* $Revision__:1$
**********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_OBDIUMPR_H
#define DEM_OBDIUMPR_H


#include "Dem_Types.h"



#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)

/* CDG implementation does not support IUMPR for now */

#endif /* DEM_CFG_OBD != DEM_CFG_OBD_OFF */

#endif /* DEM_OBDIUMPR_H */

/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.9.0.0; 1     17.11.2014 GJ83ABT
*   CSCRM00747561, CSCRM00731899, CSCRM00720274, CSCRM00625559
* 
* AR40.9.0.0; 0     15.10.2014 GJ83ABT
*   CSCRM00719089, CSCRM00650337, CSCRM00625552, CSCRM00434933
* 
* AR40.8.0.0; 0     15.04.2014 GJ83ABT
*   CSCRM00652072
* 
* $
**********************************************************************************************************************
</BASDKey>*/
