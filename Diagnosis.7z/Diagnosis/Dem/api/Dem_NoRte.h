/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2015. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_NoRte$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_NORTE_H
#define DEM_NORTE_H
#define DEM_START_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"
/**
 * \defgroup RTE_DEM_H    DEM - RTE AUTOSAR interface
 * This interface provides functionality to report errors
 * as specified by AUTOSAR. The functions are actually provided via RTE.\n
 * To use this interface include the header <b>dem.h</b>
 */
#ifndef DEM_HIDE_RTEAPIS

/** * @ingroup RTE_DEM_H
 *
 * Dem198: Gets the DTC of an event.
 * @param [in]  EventId     Identification of an event by assigned EventId.
 * @param [in]  DTCFormat   Defines the output-format of the requested DTC value.
 * @param [out]  DTCOfEvent  Receives the DTC value returned by the function.
 *                          If the return value of the function is other than E_OK
 *                          this parameter does not contain valid data.
 * @return  E_OK: get of DTC was successful\n
 *          E_NOT_OK: the call was not successful\n
 *          E_NO_DTC_AVAILABLE: there is no DTC
 */
Std_ReturnType Dem_GetDTCOfEvent(Dem_EventIdType EventId, Dem_DTCFormatType DTCFormat, uint32* DTCOfEvent);

/**
 * @ingroup RTE_DEM_H
 *
 * Dem589: Set the suppression status of a specific DTC.
 * @param [in]  DTC  Diagnostic Trouble Code.
 * @param [in]  DTCFormat  Defines the output-format of the requested DTC value.
 * @param [in]  SuppressionStatus  This parameter specifies whether the respective DTC shall be disabled (TRUE) or enabled (FALSE).
 * @return  E_OK: Operation was successful\n
 *          E_NOT_OK: Operation failed or event entry for this DTC still exists
 */
Std_ReturnType Dem_SetDTCSuppression (uint32 DTC, Dem_DTCFormatType DTCFormat, boolean SuppressionStatus);

/**
 * @ingroup RTE_DEM_H
 *
 * Dem181: Gets the fault detection counter of an event.
 * <b>Note:</b>\n
 * @param [in]  EventId  Identification of an event by assigned EventId.
 * @param [out] FaultDetectionCounter  This parameter receives the Fault Detection
 * Counter information of the requested EventId. If the return value of the function call
 * is other than E_OK this parameter does not contain valid data. -128dec...127dec PASSED... FAILED
 * according to ISO 14229-1

 * @return       E_OK = Operation was successful \n
 *           E_NOT_OK = Operation was not successful
 */
Std_ReturnType Dem_GetFaultDetectionCounter (Dem_EventIdType EventId, sint8* FaultDetectionCounter);

/**
 * @ingroup RTE_DEM_H
 *
 * Dem188: Captures the freeze frame data for a specific event.
 *
 * @param [in]  EventId          Identification of Event by ID.
 * @return  E_OK = storing of prestored freezeframe was succssful \n
 *          E_NOT_OK = storing of prestored freezeframe was not successful
 */
Std_ReturnType  Dem_PrestoreFreezeFrame( Dem_EventIdType EventId );

/**
 * @ingroup RTE_DEM_H
 *
 * Dem193: Clears a prestored freeze frame of a specific event.
 *
 * @param [in]  EventId          Identification of Event by ID.
 * @return  E_OK = Clearing of prestored freezeframe was succssful \n
 *          E_NOT_OK = Clearing of prestored freezeframe was not successful
 */
Std_ReturnType  Dem_ClearPrestoredFreezeFrame( Dem_EventIdType EventId );

/**
 * @ingroup RTE_DEM_H
 *
 * Dem183: Set the status of an event.
 * @param [in]  EventId          identifier of calling event
 * @param [in]  EventStatus      status of event to be set
 * @return  E_OK = Event Status set was successful \n
 *          E_NOT_OK = Event Status set was not successful
 */
Std_ReturnType  Dem_SetEventStatus(Dem_EventIdType     EventId,
                                   Dem_EventStatusType EventStatus);
/**
 * @ingroup RTE_DEM_H
 *
 * Dem185: Resets the event failed status.
 * @param [in]  EventId          identifier of calling event
 * @return  E_OK = reset of event status was successful \n
 *          E_NOT_OK = reset of event status failed or was not accepted.
 */
Std_ReturnType  Dem_ResetEventStatus(Dem_EventIdType     EventId);

/**
 * @ingroup RTE_DEM_H
 *
 * Dem196: Gets the event failed status of an event.
 * @param [in]   EventId          identifier of event
 * @param [out]  EventFailed      TRUE - Last Failed \n
                                 FALSE - not Last Failed
 * @return  E_OK: get of "EventFailed" was successful \n
 *          E_NOT_OK: get of "EventFailed" was not successful
 */
Std_ReturnType  Dem_GetEventFailed(Dem_EventIdType  EventId,
                                   boolean*         EventFailed);

/**
 * @ingroup RTE_DEM_H
 *
 * Dem197: The function Dem_GetEventTested shall read the negated
 * TestNotCompletedThisOperationCycle status of the requested Event.
 * @param [in]   EventId          Identification of Event by ID.
 * @param [out]  EventTested      TRUE, if event is tested in this cycle\n
 *                               FALSE, if event is not tested in this cycle
 * @return  E_OK = Get of event state "tested" was successful \n
 *          E_NOT_OK = Get of event state "tested" failed
 */
Std_ReturnType  Dem_GetEventTested(Dem_EventIdType  EventId,
                                   boolean*         EventTested);

/**
 * @ingroup RTE_DEM_H
 *
 * Dem201: Allows activation or deactivation of enableconditions.
 * This function is only available, if enable conditions are configured.
 *
 * @param [in] EnableConditionID   This parameter identifies the enable condition.
 * @param [in] ConditionFulfilled  This parameter specifies whether the enable condition assigned to the
 *                                 EnableConditionID is fulfilled (TRUE) or not fulfilled (FALSE).
 * @return  E_OK = Set of enable condition was successful \n
 *          E_NOT_OK = Set of enable condition was not successful
 */
Std_ReturnType Dem_SetEnableCondition (uint8 EnableConditionID, boolean ConditionFulfilled);

/**
 * @ingroup RTE_DEM_H
 *
 * Dem205: Gets the indicator status derived from the event status.
 *
 * @param [in]  IndicatorId         Number of indicator
 * @param [out] IndicatorStatus     Status of the indicator, like off, on, or blinking.
 * @return  E_OK = Get Indicator Status operation was successful \n
 *          E_NOT_OK = Get Indicator Status operation failed or is not supported
 */
Std_ReturnType Dem_GetIndicatorStatus(uint8 IndicatorId, Dem_IndicatorStatusType* IndicatorStatus);

/**
 * @ingroup RTE_DEM_H
 *
 * Dem556: Sets a storage condition.
 * @param [in]  StorageConditionID  This parameter identifies the storage condition.
 * @param [in]  ConditionFulfilled  This parameter specifies whether the storage condition
 *                                 assigned to the StorageConditionID is fulfilled (TRUE)
 *                                 or not fulfilled (FALSE).
 * @return  In case the storage condition could be set successfully the API call returns E_OK.
 *          If the setting of the storage condition failed the return value of the function is E_NOT_OK.
 */
Std_ReturnType Dem_SetStorageCondition (uint8 StorageConditionID, boolean ConditionFulfilled);

/**
 * @ingroup RTE_DEM_H
 *
 * Gets a storage condition.
 * @param [in]   StorageConditionID            This parameter identifies the storage condition.
 * @param [out]  ConditionFulfilled            This parameter specifies whether the storage condition
 *                                             assigned to the StorageConditionID is fulfilled (TRUE)
 *                                             or not fulfilled (FALSE).
 * @return       E_OK = return value if the DEM_CFG_STORAGECONDITION is ON \n
 *               E_NOT_OK = return value if the DEM_CFG_STORAGECONDITION is OFF
 */
Std_ReturnType Dem_GetStorageCondition (uint8 StorageConditionID, boolean* ConditionFulfilled);

/**
 * @ingroup RTE_DEM_H
 *
 * Sets an operation cycle state. This API can only be used through the RTE and therefore
 * no declaration is exported via Dem.h.
 *
 * @param OperationCycleId    Identification of operation cycle, like power cycle, driving cycle.
 * @param CycleState          New operation cycle state: (re-)start or end
 *
 * @return  E_OK: set of operation cycle was successful\n
 *          E_NOT_OK: set of operation cycle failed
 */
Std_ReturnType Dem_SetOperationCycleState (uint8 OperationCycleId, Dem_OperationCycleStateType CycleState);

/**
 * @ingroup RTE_DEM_H
 *
 * Gets the current extended event status of an event.
 *
 * @param [in] EventId Identification of an event by assigned EventId.
 * @param [in,out] EventStatusExtended UDS DTC status byte of the requested event (refer to chapter "Status bit support").
 *                            If the return value of the function call is E_NOT_OK, this parameter does not contain valid data.
 *
 * @return  E_OK = get of event status was successful \n
 *          E_NOT_OK = get of event status failed
 *
 * @see  Dem_SetEventStatus
 */
Std_ReturnType Dem_GetEventStatus(Dem_EventIdType EventId,
        Dem_EventStatusExtendedType* EventStatusExtended);

/**
 * @ingroup RTE_DEM_H
 *
 * Sets the WIR status bit via failsafe SW-Cs.
 *
 * @param [in] EventId      Event Identification of an event by assigned EventId. The Event Number is configured in the DEM.
 * @param [in] WIRStatus    Requested status of event related WIR-bit (regarding to the current status of function inhibition)
 *              WIRStatus = TRUE -> WIR-bit shall be set to "1" WIRStatus = FALSE -> WIR-bit shall be set to "0"
 *
 * @return  E_OK = The request is accepted
 *          E_NOT_OK = The request is accepted E_NOT_OK: not be accepted
 */
Std_ReturnType Dem_SetWIRStatus( Dem_EventIdType EventId, boolean WIRStatus );

/**
 * @ingroup RTE_DEM_H
 *
 * Dem266: Processes all not event based Dem internal functions.
 */

void Dem_MainFunction(void);


/* FC_VariationPoint_START */
#if (DEM_CFG_OBD != DEM_CFG_OBD_OFF)

/**
 * @ingroup RTE_DEM_H
 *
 * Dem312: Reports the event as disabled for the PID $41 computation. \n
 * \b Note: \n
 * For the computation of PID $41, the monitor has to report its event as disabled, if the test cannot be carried out
 * anymore until the end of this driving cycle.
 * @param[in]    EventId            Identification of an event by assigned EventId.
 * @return       E_OK = Setting of event to disabled was successful.\n
 *               E_NOT_OK = Setting of event to disabled failed.\n
 */
FUNC(Std_ReturnType, DEM_CODE) Dem_SetEventDisabled(VAR(Dem_EventIdType, AUTOMATIC) EventId);

/**
 * @ingroup RTE_DEM_H
 *
 * Dem313: Service for reporting that faults are possibly found because all conditions are fullfilled.
 *
 * @param[in]    RatioID Ratio Identifier reporting that a respective monitor could have found a fault - only used when interface option "API" is selected.
 * @return       E_OK = Report of IUMPR result was successfully reported\n
 *               E_NOT_OK = Report of IUMPR result was not successfully reported\n
 */
FUNC(Std_ReturnType, DEM_CODE) Dem_RepIUMPRFaultDetect (VAR(Dem_RatioIdType, AUTOMATIC) RatioID);

/**
 * @ingroup RTE_DEM_H
 *
 * Dem314: Service is used to lock a denominator of a specific monitor.
 *
 * @param[in]    RatioID Ratio Identifier reporting that specific denominator is locked (for physical reasons - e.g. temperature conditions or minimum activity)
 * @return       E_OK = report of IUMPR denominator status was successfully reported.\n
 *               E_NOT_OK = Report of IUMPR denominator status was not successfully reported.\n
 */
FUNC(Std_ReturnType, DEM_CODE) Dem_RepIUMPRDenLock (VAR(Dem_RatioIdType, AUTOMATIC) RatioID);

/**
 * @ingroup RTE_DEM_H
 *
 * Dem315: Service is used to release a denominator of a specific monitor.
 *
 * @param[in]    RatioID Ratio Identifier reporting that specific denominator is released (for physical reasons - e.g. temperature conditions or minimum activity)
 * @return       E_OK = report of IUMPR denominator status was successfully reported.\n
 *               E_NOT_OK = Report of IUMPR denominator status was not successfully reported.\n
 */
FUNC(Std_ReturnType, DEM_CODE) Dem_RepIUMPRDenRelease (VAR(Dem_RatioIdType, AUTOMATIC) RatioID);

#endif
/* FC_VariationPoint_END */

#endif

#define DEM_STOP_SEC_ROM_CODE
#include "Dem_Cfg_MemMap.h"



#endif /* DEM_NORTE_H */
/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     07.01.2016 TVE5COB
*   CSCRM01017790
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */

