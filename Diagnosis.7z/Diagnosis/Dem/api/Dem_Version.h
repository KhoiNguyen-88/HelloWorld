/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_Version$
* $Variant___:AR40.11.0.0$
* $Revision__:0$
**********************************************************************************************************************
</BASDKey>*/

#ifndef DEM_VERSION_H
#define DEM_VERSION_H

#define DEM_VENDOR_ID                          6
#define DEM_MODULE_ID                          54
#define DEM_INSTANCE_ID                        0

#define DEM_SW_MAJOR_VERSION 11
#define DEM_SW_MINOR_VERSION 0
#define DEM_SW_PATCH_VERSION 0
#define DEM_AR_RELEASE_MAJOR_VERSION 4
#define DEM_AR_RELEASE_MINOR_VERSION 0
#define DEM_AR_RELEASE_REVISION_VERSION 2

#endif
/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 0     17.09.2015 UDKOEGEL
*   CSCRM00960004
* 
* AR40.10.0.0; 0     26.01.2015 LIB8FE
*   CSCRM00737824
* 
* AR40.9.0.0; 0     18.08.2014 BPE4COB
*   CSCRM00672665
* 
* AR40.8.0.0; 1     20.03.2014 CLH2SI
*   CSCRM00632758
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.7.0.0; 0     21.10.2013 CLH2SI
*   CSCRM00585471
* 
* AR40.4.0.0; 1     27.06.2012 BRM2COB
*   GIT to eASEE 26-05 History info updated.
* 
* AR40.4.0.0; 0     14.02.2012 CLH2SI
*   GIT-SYNC: a0008d733d3a94fa3e0a3e39260972344e821bef
* 
* AR40.1.1.0; 1     12.12.2011 ALA2ABT
*   Git Commit:b21a116571d3e20441afe258ab336b12b1970d77
*   
* 
* AR40.1.1.0; 0     22.11.2011 ALA2ABT
*   Versionnumber
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
