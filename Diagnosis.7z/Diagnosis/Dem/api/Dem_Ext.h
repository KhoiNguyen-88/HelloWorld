/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem_Ext$
* $Variant___:AR40.11.0.0$
* $Revision__:2$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_EXT_H
#define DEM_EXT_H


#include "Dem_Types.h"

#include "Dem.h"
#include "Dem_EventRecheck.h"


/**
 * \defgroup DEM_EXT_H    DEM - Extension to AUTOSAR interface
 * This interface provides additional functionality which is NOT
 * specified by AUTOSAR.\n
 * To use this interface include the header <b>dem_ext.h</b>
 */


/**
 * @ingroup DEM_EXT_H
 *
 * Gets the status whether the event FDC value has reached the FDCThreshold.
 * @param [in]   EventId          identifier of event
 * @param [out]  FdcThresholdReached  TRUE - Event FDC value has reached the FDCThreshold \n
                                      FALSE - Event FDC value not reached the FDCThreshold
 * @return  E_OK: get of "FdcThresholdReached" was successful \n
 *          E_NOT_OK: get of "FdcThresholdReached" was not successful
 */
Std_ReturnType  Dem_GetEventFdcThresholdReached(Dem_EventIdType  EventId,
                                                boolean*         FdcThresholdReached);


/**
 * @ingroup DEM_EXT_H
 *
 * Interface to get the suspicious status of an event.
 * @param [in]   EventId          identifier of an event
 * @param [out]  EventSuspicious  TRUE - Event is suspicious
                                  FALSE - Event is not suspicious
 * @return  E_OK: getting "EventSuspicious" was successful
 *          E_NOT_OK: getting "EventSuspicious" was not successful
 */
Std_ReturnType Dem_GetEventSuspicious(Dem_EventIdType EventId, boolean* EventSuspicious);

/**
 * @ingroup DEM_EXT_H
 *
 * Interface to get the suspicious status of the Component(Node).
 * @param [in]   ComponentId          identifier of the component
 * @param [out]  ComponentSuspicious  TRUE - Component is suspicious
                                      FALSE - Component is not suspicious
 * @return  E_OK: getting "ComponentSuspicious" was successful
 *          E_NOT_OK: getting "ComponentSuspicious" was not successful
 */
Std_ReturnType Dem_GetComponentSuspicious (Dem_ComponentIdType ComponentId, boolean* ComponentSuspicious);

/**
 *  @ingroup DEM_EXT_H
 *
 * Interface to query, whether a Component(Node) is usable.
 * This function returns E_OK, if the Component may be used (Component is not failed & Component is not suspicious & Component is initialized & Component is available).
 * If the function returns E_NOT_OK the Component may not be used (i.e. one of the 4 criterias is not met).
 *
 * @param [in]   ComponentId          identifier of the component
 * @param [out]  ComponentUsable      TRUE - Component is usable
 *                                    FALSE - Component is not usable
 * @return  E_OK: getting "ComponentUsable" was successful
 *          E_NOT_OK: getting "ComponentUsable" was not successful
 *
 */
Std_ReturnType Dem_GetComponentUsable (Dem_ComponentIdType ComponentId, boolean* ComponentUsable);

/**
 * @ingroup DEM_EXT_H
 *
 * Interface to query, whether a Component(Node) is restricted usable.
 * The function returns true, if the Component may restrictedly be used (Component is not failed & Component is initialized & Component is available,
 * but Component may be suspicious). If the function returns false, the Component may not be used (i.e. one of the 3 criterias
 * is not met).
 *
 * @param [in]   ComponentId                  identifier of the component
 * @param [out]  ComponentRestrictedUsable    TRUE - Component may restrictedly be used
 *                                            FALSE - Component may not be used
 * @return  E_OK: getting "ComponentRestrictedUsable" was successful
 *          E_NOT_OK: getting "ComponentRestrictedUsable" was not successful
 */
Std_ReturnType Dem_GetComponentRestrictedUsable (Dem_ComponentIdType ComponentId, boolean* ComponentRestrictedUsable);


/**
 * @ingroup DEM_EXT_H
 *
 * Interface to querry whether a Component(Node) is initialized. At startup Components(Nodes) may not be initialized.
 *
 * Don't use this function to querry, whether a Component can be used. Use Dem_GetComponentUsable or Dem_GetComponentRestrictedUsable instead.
 *
 * @param [in]   ComponentId              identifier of the component
 * @param [out]  ComponentInitialized     TRUE - Component is initialized
 *                                        FALSE - Component is not initialized
 * @return  E_OK: getting "ComponentInitialized" was successful
 *          E_NOT_OK: getting "ComponentInitialized" was not successful
 */
Std_ReturnType Dem_GetComponentInitialized (Dem_ComponentIdType ComponentId, boolean* ComponentInitialized);

/**
 * @ingroup DEM_EXT_H
 *
 * Interface to querry whether a Component(Node) is failed. A Component is marked as invalid/failed by monitoring functions.
 *
 * Don't use this function to querry whether a Component can be used. Use Dem_GetComponentUsable or Dem_GetComponentRestrictedUsable instead.
 *
 * @param [in]   ComponentId            Identification of a DemComponent
 * @param [out]  ComponentFailed        TRUE - Component is failed
 *                                      FALSE - Component is not failed.
 * @return  E_OK: getting "ComponentFailed" was successful
 *          E_NOT_OK: getting "ComponentFailed" was not successful
 */
Std_ReturnType Dem_GetComponentFailed (Dem_ComponentIdType ComponentId, boolean* ComponentFailed);

/**
 * @ingroup DEM_EXT_H
 *
 * Interface to querry whether a Component(Node) is invalid/failed by itself. That means that monitoring functions at this Component did report failed.
 *
 * Don't use this function to querry whether a Component can be used. Use Dem_GetComponentUsable or Dem_GetComponentRestrictedUsable instead.
 *
 * @param [in]   ComponentId              identifier of the component
 * @param [out]  ComponentFailedItself    TRUE - The component itself is failed.
 *                                        FALSE - The component is valid. No event did report failed at the component.
 * @return  E_OK: getting "ComponentFailedItself" was successful
 *          E_NOT_OK: getting "ComponentFailedItself" was not successful
 */
Std_ReturnType Dem_GetComponentFailedItself (Dem_ComponentIdType ComponentId, boolean* ComponentFailedItself);

/**
 * @ingroup DEM_EXT_H
 *
 * Interface to querry whether a Component(Node) is suspicious itself. A Component may be marked as suspicious by monitoring functions. If a Component
 * is marked as failed, it isn't marked automatically as suspicious.
 *
 * Don't use this function to querry whether a Component can be used. Use Dem_GetComponentUsable or Dem_GetComponentRestrictedUsable instead.
 *
 * @param [in]   ComponentId                  identifier of the component
 * @param [out]  ComponentSuspiciousItself    TRUE - The component is susipicous.
 *                                            FALSE - The component is valid. No event did report susipicous at the component.
 * @return  E_OK: getting "ComponentSuspiciousItself" was successful
 *          E_NOT_OK: getting "ComponentSuspiciousItself" was not successful
 */
Std_ReturnType Dem_GetComponentSuspiciousItself (Dem_ComponentIdType ComponentId, boolean* ComponentSuspiciousItself);

/**
 * @ingroup DEM_EXT_H
 *
 * Interface to querry whether a Component(Node) is available. A Component may be unavailable due to a variant code configuration or other conditions.
 *
 * Don't use this function to querry whether a Component can be used.Use Dem_GetComponentUsable or Dem_GetComponentRestrictedUsable instead.
 *
 * @param [in]   ComponentId           identifier of the component
 * @param [out]  ComponentAvailable    TRUE - The component is available.
 *                                     FALSE - The component is not available.
 * @return  E_OK: getting "ComponentAvailable" was successful
 *          E_NOT_OK: getting "ComponentAvailable" was not successful
 */
Std_ReturnType Dem_GetComponentAvailable (Dem_ComponentIdType ComponentId, boolean* ComponentAvailable);

/**
 * @ingroup DEM_EXT_H
 *
 * Interface to querry whether Component's(Node's) ancestors(parents) are initialized. At startup Components may not be initialized.
 *
 * Don't use this function to querry whether a Component can be used.Use Dem_GetComponentUsable or Dem_GetComponentRestrictedUsable instead.
 *
 * @param [in]   ComponentId                        identifier of the component
 * @param [out]  ComponentAreAncestorsInitialized    TRUE -  All ancestor components are initialized.
 *                                                   FALSE - Any ancestor component is not initialized.
 * @return  E_OK: getting "ComponentAreAncestorsInitialized" was successful
 *          E_NOT_OK: getting "ComponentAreAncestorsInitialized" was not successful
 */
Std_ReturnType Dem_GetComponentAreAncestorsInitialized (Dem_ComponentIdType ComponentId, boolean* ComponentAreAncestorsInitialized);

#endif

/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 2     31.12.2015 VSA2COB
*   CSCRM01016285
* 
* AR40.11.0.0; 1     24.11.2015 VSA2COB
*   CSCRM01013111
* 
* AR40.11.0.0; 0     20.11.2015 SUH4COB
*   CSCRM00540538
* 
* AR40.10.0.0; 0     16.04.2015 CLH2SI
*   CSCRM00764027
* 
* AR40.8.0.0; 0     11.03.2014 VSA2COB
*   CSCRM00619537_Comassochanges
* 
* AR40.4.0.0; 0     05.07.2012 BRM2COB
*   Version updated to AR40.4.0.0
* 
* AR40.0.0.1; 5     27.06.2012 BRM2COB
*   GIT to eASEE 26-05 History info updated.
* 
* AR40.0.0.1; 4     12.12.2011 ALA2ABT
*   Git Commit:b21a116571d3e20441afe258ab336b12b1970d77
*   
* 
* AR40.0.0.1; 3     04.10.2011 ALA2ABT
*   Git Commit:7b61e894beb4a29b8ceee4f7dcffd00974fcfbe1
* 
* AR40.0.0.1; 2     16.09.2011 ALA2ABT
*   Git-Rev: e1b5f01564bf06a1a589e79796180c364307470c
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */

