/* BASDKey_start */
/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, Robert Bosch GmbH, 2012. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************/
/* BASDKey_end */
/* Administrative Information (automatically filled in)
* $Domain____:BASD$
* $Namespace_:\Comp\Dem$
* $Class_____:H$
* $Name______:Dem$
* $Variant___:AR40.11.0.0$
* $Revision__:2$
**********************************************************************************************************************
</BASDKey>*/


#ifndef DEM_H
#define DEM_H


/**
 * \file
 * \brief DEM-Interface according to AUTOSAR 4.0
 */

#include "Dem_Version.h"
#include "Dem_Types.h"
#include "Dem_EvtRelatedData.h"  /* included for Diag compilation */
#include "Dem_Cfg_EventId.h"
#include "Dem_Cfg_DtcId.h"
#include "Dem_Cfg_NodeId.h"
#include "Dem_Deb.h"

#include "Dem_Mapping.h"
#include "Dem_EvBuff.h"
#include "Dem_EventFHandling.h"
#include "Dem_Events.h"
#include "Dem_EventStatus.h"
#include "Dem_ConsisChk.h"
#include "Dem_EvMem.h"
#include "Dem_EvMemGen.h"
#include "Dem_DTCs.h"
#include "Dem_DTCStatusByte.h"
#include "Dem_DTCFilter.h"
#include "Dem_DTCGroup.h"
#include "Dem_Main.h"
#include "Dem_Clear.h"
#include "Dem_OperationCycle.h"
/* FC_VariationPoint_START */
#include "Dem_ObdMain.h"
#include "Dem_ObdRdy.h"
#include "Dem_ObdIumpr.h"
#include "Dem_Bfm.h"
#include "Dem_BfmRecord.h"
#include "Dem_BfmCounter.h"
#include "Dem_BfmEvent.h"
#include "Dem_BfmTypes.h"
/* FC_VariationPoint_END */
#include "Dem_Dependencies.h"
#include "Dem_IndicatorAttributes.h"
#include "Dem_Indicator.h"
#include "Dem_Cfg_Nodes.h"

#ifndef DEM_HIDE_RTEAPIS
#include "Dem_NoRte.h"
#endif


#ifdef DEM_CFG_EXTPROTOTYPES_H
#error "Do not include 'Dem_Cfg_ExtPrototypes.h' in header file"
#endif

/**
 * \defgroup DEM_H    DEM - AUTOSAR interface
 * This interface provides functionality to report errors
 * as specified by AUTOSAR.\n
 * To use this interface include the header <b>dem.h</b>
 */


#endif
/* FC_VariationPoint_START */
/*<BASDKey>
**********************************************************************************************************************
* $History___:
* 
* AR40.11.0.0; 2     11.01.2016 NAL2KOR
*   CSCRM01015983
* 
* AR40.11.0.0; 1     07.01.2016 TVE5COB
*   CSCRM01017790
* 
* AR40.11.0.0; 0     21.12.2015 NAL2KOR
*   CSCRM00957431
* 
* AR40.10.0.0; 2     06.07.2015 VSA2COB
*   CSCRM00830308
* 
* AR40.10.0.0; 1     17.06.2015 VSA2COB
*   CSCRM00880343
* 
* AR40.10.0.0; 0     16.04.2015 CLH2SI
*   CSCRM00764027
* 
* AR40.9.0.0; 0     15.10.2014 GJ83ABT
*   CSCRM00719089, CSCRM00650337, CSCRM00625552, CSCRM00434933
* 
* AR40.8.0.0; 9     16.07.2014 BRM2COB
*   CSCRM00688243
* 
* AR40.8.0.0; 8     19.06.2014 BRM2COB
*   CSCRM00659761
* 
* AR40.8.0.0; 7     16.06.2014 GJ83ABT
*   CSCRM00615634, CSCRM00671513
* 
* $
**********************************************************************************************************************
</BASDKey>*/
/* FC_VariationPoint_END */
