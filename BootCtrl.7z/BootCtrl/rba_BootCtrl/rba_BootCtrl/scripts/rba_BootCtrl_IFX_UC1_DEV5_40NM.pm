#<RBHead>
#************************************************************************
#                                                                       *
#                      ROBERT BOSCH GMBH                                *
#                          STUTTGART                                    *
#                                                                       *
#          Alle Rechte vorbehalten - All rights reserved                *
#                                                                       *
#************************************************************************
#
#************************************************************************
#    Administrative Information (automatically filled in by eASEE)      *
#************************************************************************
#
# $Filename__:$
#
# $Author____:$
#
# $Function__:$
#
#************************************************************************
# $Domain____:$
# $User______:$
# $Date______:$
# $Class_____:$
# $Name______:$
# $Variant___:$
# $Revision__:$
# $Type______:$
# $State_____:$
# $Generated_:$
#************************************************************************
#
# $UniqueName:$
# $Component_:$
#
#
#************************************************************************
#</RBHead>

package rba_BootCtrl_uC1_Dev;
use strict;
use warnings;

#----------------------------------------------------------------------------------------------------------------------
# Subroutine to check validity of selected CAN port and get pin configuration value (JDP: MSCR_SSS) (IFX: CAN_NPCR)
#
# Parameters:
# $_[0]: input signal (JDP: PORT_X_YY) (IFX: PORT_XX_YY)
# $_[1]: can node
# $_[2]: direction ('Rx' or 'Tx')
# Return:
# value assigned to input
#----------------------------------------------------------------------------------------------------------------------
sub GetCanPin
{
    my $Input_s     = $_[0];
    my $CanNode_s   = $_[1];
    my $Dir_s       = $_[2];
    my @Return_a;

    my %CanPortMux_h = (
        'Rx' => {
                  'CAN_03' => {
                                'PORT_20_00' => 2,
                                'PORT_20_09' => 4,
                                'PORT_32_02' => 1,
                                'PORT_01_00' => 5,
                                'PORT_11_10' => 3,
                                'PORT_00_03' => 0
                              },
                  'CAN_02' => {
                                'PORT_10_02' => 4,
                                'PORT_02_03' => 1,
                                'PORT_14_08' => 3,
                                'PORT_32_06' => 2,
                                'PORT_15_01' => 0
                              },
                  'CAN_13' => {
                                'PORT_14_07' => 0,
                                'PORT_33_05' => 1,
                                'PORT_11_13' => 3,
                                'PORT_22_05' => 2
                              },
                  'CAN_20' => {
                                'PORT_10_08' => 1,
                                'PORT_02_14' => 3,
                                'PORT_34_02' => 2,
                                'PORT_01_08' => 4,
                                'PORT_11_14' => 5,
                                'PORT_10_05' => 0
                              },
                  'CAN_21' => {
                                'PORT_20_00' => 2,
                                'PORT_32_02' => 3,
                                'PORT_13_12' => 1,
                                'PORT_22_07' => 5,
                                'PORT_01_00' => 4,
                                'PORT_00_03' => 0
                              },
                  'CAN_12' => {
                                'PORT_10_08' => 1,
                                'PORT_11_08' => 3,
                                'PORT_20_06' => 0,
                                'PORT_23_03' => 2
                              },
                  'CAN_01' => {
                                'PORT_02_10' => 4,
                                'PORT_15_03' => 0,
                                'PORT_14_01' => 1,
                                'PORT_01_04' => 2,
                                'PORT_33_10' => 3
                              },
                  'CAN_22' => {
                                'PORT_33_13' => 0,
                                'PORT_14_14' => 3,
                                'PORT_22_09' => 4,
                                'PORT_32_07' => 1,
                                'PORT_23_06' => 2
                              },
                  'CAN_10' => {
                                'PORT_14_07' => 1,
                                'PORT_00_01' => 0,
                                'PORT_13_01' => 3,
                                'PORT_23_00' => 2
                              },
                  'CAN_23' => {
                                'PORT_14_10' => 0,
                                'PORT_22_11' => 4,
                                'PORT_23_03' => 1,
                                'PORT_14_15' => 2,
                                'PORT_13_05' => 3
                              },
                  'CAN_11' => {
                                'PORT_02_04' => 0,
                                'PORT_00_05' => 1,
                                'PORT_11_07' => 3,
                                'PORT_23_07' => 2
                              },
                  'CAN_00' => {
                                'PORT_02_14' => 7,
                                'PORT_02_01' => 0,
                                'PORT_33_12' => 3,
                                'PORT_12_00' => 2,
                                'PORT_34_02' => 6,
                                'PORT_20_07' => 1,
                                'PORT_33_07' => 4,
                                'PORT_01_08' => 5
                              }
                },
        'Tx' => {
                  'CAN_03' => {
                                'PORT_11_12' => '5',
                                'PORT_20_03' => '5',
                                'PORT_20_10' => '5',
                                'PORT_00_02' => '5',
                                'PORT_32_03' => '5',
                                'PORT_01_02' => '3'
                              },
                  'CAN_02' => {
                                'PORT_32_05' => '6',
                                'PORT_14_10' => '5',
                                'PORT_15_00' => '5',
                                'PORT_10_03' => '6',
                                'PORT_02_02' => '5'
                              },
                  'CAN_13' => {
                                'PORT_22_04' => '6',
                                'PORT_33_04' => '7',
                                'PORT_14_06' => '4',
                                'PORT_11_04' => '5'
                              },
                  'CAN_20' => {
                                'PORT_34_01' => '5',
                                'PORT_01_13' => '5',
                                'PORT_10_07' => '5',
                                'PORT_10_06' => '5',
                                'PORT_11_05' => '5',
                                'PORT_02_13' => '5'
                              },
                  'CAN_21' => {
                                'PORT_22_06' => '5',
                                'PORT_20_03' => '6',
                                'PORT_00_02' => '3',
                                'PORT_32_03' => '6',
                                'PORT_01_02' => '5',
                                'PORT_13_09' => '5'
                              },
                  'CAN_12' => {
                                'PORT_10_07' => '6',
                                'PORT_23_02' => '5',
                                'PORT_20_07' => '5',
                                'PORT_11_01' => '5'
                              },
                  'CAN_01' => {
                                'PORT_15_02' => '5',
                                'PORT_01_03' => '5',
                                'PORT_02_09' => '5',
                                'PORT_14_00' => '5',
                                'PORT_33_09' => '5'
                              },
                  'CAN_22' => {
                                'PORT_14_13' => '5',
                                'PORT_22_08' => '5',
                                'PORT_23_05' => '6',
                                'PORT_33_12' => '5',
                                'PORT_32_06' => '5'
                              },
                  'CAN_10' => {
                                'PORT_23_01' => '5',
                                'PORT_00_00' => '5',
                                'PORT_14_09' => '4',
                                'PORT_13_00' => '7'
                              },
                  'CAN_23' => {
                                'PORT_14_14' => '5',
                                'PORT_14_09' => '2',
                                'PORT_13_04' => '7',
                                'PORT_23_02' => '4',
                                'PORT_22_10' => '5'
                              },
                  'CAN_11' => {
                                'PORT_11_00' => '5',
                                'PORT_02_05' => '2',
                                'PORT_00_04' => '3',
                                'PORT_23_06' => '5'
                              },
                  'CAN_00' => {
                                'PORT_33_13' => '5',
                                'PORT_34_01' => '4',
                                'PORT_01_13' => '4',
                                'PORT_12_01' => '5',
                                'PORT_33_08' => '5',
                                'PORT_02_00' => '5',
                                'PORT_20_08' => '5',
                                'PORT_02_13' => '4'
                              }
                }
    );

    if (!exists($CanPortMux_h{$Dir_s}{$CanNode_s}{$Input_s}))
    {
        # illegal port for CAN operation
        @Return_a = (0,
                        "#   Configured port $Input_s is not a $CanNode_s $Dir_s port.\n" .
                        "#   List of supported CAN $Dir_s pins for $CanNode_s are: " .
                        join(", ", sort(keys(%{$CanPortMux_h{$Dir_s}{$CanNode_s}}))) . "\n"
                    );
    }
    else
    {
        @Return_a = ($CanPortMux_h{$Dir_s}{$CanNode_s}{$Input_s}, undef);
    }
    return (@Return_a);
}



# In the past we put an anonymous function at the end of a perl modul which returned 1
# {
#   1;
# }
# but it seems that this only works if the require is in the same sub (same level) which is called by conf_process
# if the require is called from a sub inside the sub which is called by conf_process this does not work.

# Form: http://perldoc.perl.org/functions/require.html
# The file must return true as the last statement to indicate successful execution of any initialization code,
# so it's customary to end such a file with 1; unless you're sure it'll return true otherwise. But it's better just
# to put the 1; , in case you add more statements.

1;

#<RBHead>
#***********************************************************************************************************************
# $History$
#***********************************************************************************************************************
#</RBHead>
