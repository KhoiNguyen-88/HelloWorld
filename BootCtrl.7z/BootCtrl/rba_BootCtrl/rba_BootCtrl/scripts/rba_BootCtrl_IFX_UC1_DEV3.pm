#<RBHead>
#************************************************************************
#                                                                       *
#                      ROBERT BOSCH GMBH                                *
#                          STUTTGART                                    *
#                                                                       *
#          Alle Rechte vorbehalten - All rights reserved                *
#                                                                       *
#************************************************************************
#
#************************************************************************
#    Administrative Information (automatically filled in by eASEE)      *
#************************************************************************
#
# $Filename__:$
#
# $Author____:$
#
# $Function__:$
#
#************************************************************************
# $Domain____:$
# $User______:$
# $Date______:$
# $Class_____:$
# $Name______:$
# $Variant___:$
# $Revision__:$
# $Type______:$
# $State_____:$
# $Generated_:$
#************************************************************************
#
# $UniqueName:$
# $Component_:$
#
#
#************************************************************************
#</RBHead>

package rba_BootCtrl_uC1_Dev;
use strict;
use warnings;

#----------------------------------------------------------------------------------------------------------------------
# Subroutine to check validity of selected CAN port and get pin configuration value (JDP: MSCR_SSS) (IFX: CAN_NPCR)
#
# Parameters:
# $_[0]: input signal (JDP: PORT_X_YY) (IFX: PORT_XX_YY)
# $_[1]: can node
# $_[2]: direction ('Rx' or 'Tx')
# Return:
# value assigned to input
#----------------------------------------------------------------------------------------------------------------------
sub GetCanPin
{
    my $Input_s     = $_[0];
    my $CanNode_s   = $_[1];
    my $Dir_s       = $_[2];
    my @Return_a;

    my %CanPortMux_h = (
       'Tx' => {
                 'CAN_D' => {
                              'PORT_11_12' => 5,
                              'PORT_20_03' => 5,
                              'PORT_20_10' => 5,
                              'PORT_32_03' => 5,
                              'PORT_00_02' => 5
                            },
                 'CAN_A' => {
                              'PORT_34_01' => 4,
                              'PORT_12_01' => 5,
                              'PORT_33_08' => 5,
                              'PORT_02_05' => 2,
                              'PORT_02_00' => 5,
                              'PORT_20_08' => 5
                            },
                 'CAN_C' => {
                              'PORT_32_05' => 6,
                              'PORT_14_10' => 5,
                              'PORT_15_00' => 5,
                              'PORT_10_03' => 6,
                              'PORT_02_02' => 5
                            },
                 'CAN_B' => {
                              'PORT_15_02' => 5,
                              'PORT_01_03' => 5,
                              'PORT_00_00' => 5,
                              'PORT_02_09' => 5,
                              'PORT_14_00' => 5
                            }
               },
       'Rx' => {
                 'CAN_D' => {
                              'PORT_32_02' => 1,
                              'PORT_20_00' => 2,
                              'PORT_20_09' => 4,
                              'PORT_11_10' => 3,
                              'PORT_00_03' => 0
                            },
                 'CAN_A' => {
                              'PORT_02_04' => 3,
                              'PORT_02_01' => 0,
                              'PORT_12_00' => 2,
                              'PORT_34_02' => 6,
                              'PORT_20_07' => 1,
                              'PORT_33_07' => 4
                            },
                 'CAN_C' => {
                              'PORT_10_02' => 4,
                              'PORT_02_03' => 1,
                              'PORT_14_08' => 3,
                              'PORT_32_06' => 2,
                              'PORT_15_01' => 0
                            },
                 'CAN_B' => {
                              'PORT_02_10' => 4,
                              'PORT_15_03' => 0,
                              'PORT_00_01' => 3,
                              'PORT_14_01' => 1,
                              'PORT_01_04' => 2
                            }
               }
    );

    if (!exists($CanPortMux_h{$Dir_s}{$CanNode_s}{$Input_s}))
    {
        # illegal port for CAN operation
        @Return_a = (0,
                        "#   Configured port $Input_s is not a $CanNode_s $Dir_s port.\n" .
                        "#   List of supported CAN $Dir_s pins for $CanNode_s are: " .
                        join(", ", sort(keys(%{$CanPortMux_h{$Dir_s}{$CanNode_s}}))) . "\n"
                    );
    }
    else
    {
        @Return_a = ($CanPortMux_h{$Dir_s}{$CanNode_s}{$Input_s}, undef);
    }
    return (@Return_a);
}



# In the past we put an anonymous function at the end of a perl modul which returned 1
# {
#   1;
# }
# but it seems that this only works if the require is in the same sub (same level) which is called by conf_process
# if the require is called from a sub inside the sub which is called by conf_process this does not work.

# Form: http://perldoc.perl.org/functions/require.html
# The file must return true as the last statement to indicate successful execution of any initialization code,
# so it's customary to end such a file with 1; unless you're sure it'll return true otherwise. But it's better just
# to put the 1; , in case you add more statements.

1;

#<RBHead>
#***********************************************************************************************************************
# $History$
#***********************************************************************************************************************
#</RBHead>
