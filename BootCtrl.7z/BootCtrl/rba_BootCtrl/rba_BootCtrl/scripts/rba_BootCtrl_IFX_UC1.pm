#<RBHead>
#************************************************************************
#                                                                       *
#                      ROBERT BOSCH GMBH                                *
#                          STUTTGART                                    *
#                                                                       *
#          Alle Rechte vorbehalten - All rights reserved                *
#                                                                       *
#************************************************************************
#
#************************************************************************
#    Administrative Information (automatically filled in by eASEE)      *
#************************************************************************
#
# $Filename__:$
#
# $Author____:$
#
# $Function__:$
#
#************************************************************************
# $Domain____:$
# $User______:$
# $Date______:$
# $Class_____:$
# $Name______:$
# $Variant___:$
# $Revision__:$
# $Type______:$
# $State_____:$
# $Generated_:$
#************************************************************************
#
# $UniqueName:$
# $Component_:$
#
#
#************************************************************************
#</RBHead>

package rba_BootCtrl_Ifx_uC1;
use strict;
use warnings;

#----------------------------------------------------------------------------------------------------------------------
# Subroutine to create mask for a specific pin in IOCR register
#
# Parameters:
# $_[0]: Pin Number (value range: 0..15)
# Return:
# mask for given pin
#----------------------------------------------------------------------------------------------------------------------
sub CreateIocrPinMask
{
    my $pin_s  = $_[0];
    my $temp_s;
    my $mask_s;

    # get pin offset in IOCR register
    $temp_s = $pin_s % 4;
    # set pin offset to basis of 8bits
    $temp_s *= 8;
    # create mask for port IOCR
    $mask_s = 0xFF << $temp_s;

    return $mask_s;
}

#----------------------------------------------------------------------------------------------------------------------
# Subroutine to split user input port information into port and pin
#
# Parameters:
# $_[0]: User Input (PORT_XX_YY)
# Return:
# Port number, pin number
#----------------------------------------------------------------------------------------------------------------------
sub SplitPortPin
{
    my $Input_s = $_[0];
    $Input_s =~ s/PORT_//;              # remove preceded PORT_ indication
    $Input_s =~ m/(^\d{2})_(\d{2})/;    # split input into
    my $port_s = $1;                    # port and
    my $pin_s = $2;                     # pin
    return ($port_s, $pin_s);
}

#----------------------------------------------------------------------------------------------------------------------
# Subroutine to create IOCR bitfield value
#
# Parameters:
# $_[0]: pin number (value range 0..15)
# $_[1]: value for bitfield
# Return:
# IOCR bitfield corresponding to pin number
#----------------------------------------------------------------------------------------------------------------------
sub CreateIocrBitfieldForPin
{
    my $Pin_s   = $_[0];
    my $Value_s = $_[1];
    my $Bitfield_s;
    $Value_s <<= 3;             # adjust value for register definition (IOCR.Pin: Bit0, 1, 2 is reserved, 3..7 is used)
    my $temp_s = $Pin_s % 4;    # get pin offset in IOCR register
    $temp_s *= 8;               # set pin offset to basis of 8bits
    $Bitfield_s = $Value_s << $temp_s;  # shift value to desired location by pin offset

    return ($Bitfield_s);
}

#----------------------------------------------------------------------------------------------------------------------
# Subroutine to get Port base address from rba_Reg
#
# Parameters:
# $_[0]: port number (value range 0..99)
# Return:
# base address of Port
#----------------------------------------------------------------------------------------------------------------------
sub GetPortBaseAddress
{
    my $Port_s   = $_[0];
    my $baseAddr_s;

    # create PXX naming for rba_Reg lookup where XX is the port number (without prefix)
    my $temp_s = "P" . $Port_s;
    # get access to rba_Reg
    my $reg_hr = conf_process::GetInvariantInputData("rba_Reg");
    # Loop over all modules provided from rba_Reg
    foreach my $regMod_a (@{$reg_hr->{rba_Reg_Module}})
    {
        if ($regMod_a->{rba_Reg_Module__KEY}->{content} eq $temp_s)
        {
            # take base address from REG data in BDOM
            $baseAddr_s = hex($regMod_a->{rba_Reg_Module_BaseAddr}->{content});
            $baseAddr_s =~ s/0x//i;
        }
    }
    return ($baseAddr_s);
}

#----------------------------------------------------------------------------------------------------------------------
# Subroutine to get IOCR register offset
#
# Parameters:
# $_[0]: pin number (value range 0..15)
# Return:
# offset of corresponding IOCR register
#----------------------------------------------------------------------------------------------------------------------
sub GetIocrRegisterOffset
{
    my $Pin_s   = $_[0];
    my $Offset_s;

    # IOCR register has offset 0x10...0x1C to base address of port
    my $temp_s = int ($Pin_s / 4);
    $temp_s *= 4;
    $Offset_s = 0x10;
    $Offset_s += $temp_s;

    return ($Offset_s);
}

#----------------------------------------------------------------------------------------------------------------------
# Subroutine to get OMR register offset
#
# Parameters:
# none
# Return:
# offset of corresponding OMR register
#----------------------------------------------------------------------------------------------------------------------
sub GetOmrRegisterOffset
{
    my $Offset_s;

    # OMR register has offset 0x04 to base address of port
    $Offset_s = 0x04;

    return ($Offset_s);
}

#----------------------------------------------------------------------------------------------------------------------
# Subroutine to get address of IOCR register of a specific port pin
#
# Parameters:
# $PortPin_s: Port pin PORT_XX_YY
# Return:
# address of corresponding IOCR register
# error message
#----------------------------------------------------------------------------------------------------------------------
sub GetIocrAddrOfPortPin
{
    my $PortPin_s = $_[0];
    my $Port_s;
    my $Pin_s;
    my $ErrorMsg_s = undef;
    ($Port_s, $Pin_s) = SplitPortPin($PortPin_s);
    my $BaseAddr_s = GetPortBaseAddress($Port_s);
    if (!defined($BaseAddr_s))
    {
        $ErrorMsg_s = "Port $Port_s not found. Configured port $PortPin_s is not a valid IFX uC port!";
    }
    if (($Pin_s < 0) || ($Pin_s > 15))
    {
        $ErrorMsg_s = "Pin $Pin_s not found. Configured port $PortPin_s is not a valid IFX uC port!";
    }
    $BaseAddr_s += GetIocrRegisterOffset($Pin_s);
    return ($BaseAddr_s, $ErrorMsg_s);
}

#----------------------------------------------------------------------------------------------------------------------
# Subroutine to get address of OMR register of a specific port pin
#
# Parameters:
# $PortPin_s: Port pin PORT_XX_YY
# Return:
# address of corresponding OMR register
# error message
#----------------------------------------------------------------------------------------------------------------------
sub GetOmrAddrOfPortPin
{
    my $PortPin_s = $_[0];
    my $Port_s;
    my $Pin_s;
    my $ErrorMsg_s = undef;
    ($Port_s, $Pin_s) = SplitPortPin($PortPin_s);
    my $BaseAddr_s = GetPortBaseAddress($Port_s);
    if (!defined($BaseAddr_s))
    {
        $ErrorMsg_s = "Port $Port_s not found. Configured port $PortPin_s is not a valid IFX uC port!";
    }
    if (($Pin_s < 0) || ($Pin_s > 15))
    {
        $ErrorMsg_s = "Pin $Pin_s not found. Configured port $PortPin_s is not a valid IFX uC port!";
    }
    $BaseAddr_s += GetOmrRegisterOffset();
    return ($BaseAddr_s, $ErrorMsg_s);
}

#----------------------------------------------------------------------------------------------------------------------
# Subroutine for special handling of IOCR mask and value of external CAN transceiver where given space in config hex
# is not sufficient.
# Function only designed for IFX devices and external CAN transceivers. Do not use in other cases.
#
# Parameters:
# $_[0]: pin number (value range 0..15)
# Return:
# combined 32 bit value: bit position in high-word, value for output in low-word
#----------------------------------------------------------------------------------------------------------------------
sub CompressIocrMaskValueForExtCanTrcv
{
    my $Pin_s   = $_[0];
    my $RetVal_s;
    # get pin offset in IOCR register
    my $temp_s = $Pin_s % 4;
    # set pin offset to basis of 8bits
    $temp_s *= 8;
    $RetVal_s = $temp_s << 16;  # store shift value in high word
    # IOCR value for output is stored in low word
    $RetVal_s |= 0x80;

    return ($RetVal_s);
}



# In the past we put an anonymous function at the end of a perl modul which returned 1
# {
#   1;
# }
# but it seems that this only works if the require is in the same sub (same level) which is called by conf_process
# if the require is called from a sub inside the sub which is called by conf_process this does not work.

# Form: http://perldoc.perl.org/functions/require.html
# The file must return true as the last statement to indicate successful execution of any initialization code,
# so it's customary to end such a file with 1; unless you're sure it'll return true otherwise. But it's better just
# to put the 1; , in case you add more statements.

1;

#<RBHead>
#***********************************************************************************************************************
# $History$
#***********************************************************************************************************************
#</RBHead>
