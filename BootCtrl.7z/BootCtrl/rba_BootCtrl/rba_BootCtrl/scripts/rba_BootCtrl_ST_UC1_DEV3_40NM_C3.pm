#<RBHead>
#************************************************************************
#                                                                       *
#                      ROBERT BOSCH GMBH                                *
#                          STUTTGART                                    *
#                                                                       *
#          Alle Rechte vorbehalten - All rights reserved                *
#                                                                       *
#************************************************************************
#
#************************************************************************
#    Administrative Information (automatically filled in by eASEE)      *
#************************************************************************
#
# $Filename__:$
#
# $Author____:$
#
# $Function__:$
#
#************************************************************************
# $Domain____:$
# $User______:$
# $Date______:$
# $Class_____:$
# $Name______:$
# $Variant___:$
# $Revision__:$
# $Type______:$
# $State_____:$
# $Generated_:$
#************************************************************************
#
# $UniqueName:$
# $Component_:$
#
#
#************************************************************************
#</RBHead>

# The following table was extracted from the following Excel Export
# D4 - Matterhorn (MPC5777M) Rev1.0 |  I/O Signal Table | Freescale / ST Microelectronics Confidential Proprietary | 17.01.2013

package rba_BootCtrl_uC1_Dev;
use strict;
use warnings;

#----------------------------------------------------------------------------------------------------------------------
# Subroutine to check validity of selected CAN port and get pin configuration value (JDP: MSCR_SSS) (IFX: CAN_NPCR)
#
# Parameters:
# $_[0]: input signal (JDP: PORT_X_YY) (IFX: PORT_XX_YY)
# $_[1]: can node
# $_[2]: direction ('Rx' or 'Tx')
# Return:
# value assigned to input
#----------------------------------------------------------------------------------------------------------------------
sub GetCanPin
{
    my $Input_s     = $_[0];
    my $CanNode_s   = $_[1];
    my $Dir_s       = $_[2];
    my @Return_a;

    my %CanPortMux_h = (
        'Tx' => {
                  'CAN_11' => {
                                  'PORT_L_07' => 1,
                                  'PORT_A_10' => 7,
                                  'PORT_F_08' => 7,
                                  'PORT_D_03' => 7,
                                  'PORT_C_02' => 18,
                                  'PORT_L_09' => 3,
                                  'PORT_H_13' => 1,
                                  'PORT_H_08' => 14,
                                  'PORT_F_07' => 3
                                },
                  'CAN_00' => {
                                  'PORT_M_07' => 3,
                                  'PORT_L_09' => 1,
                                  'PORT_C_06' => 2,
                                  'PORT_E_05' => 1,
                                  'PORT_D_14' => 1
                                },
                  'CAN_13' => {
                                  'PORT_C_13' => 6,
                                  'PORT_C_04' => 1,
                                  'PORT_J_12' => 1,
                                  'PORT_M_00' => 1,
                                  'PORT_G_14' => 7,
                                  'PORT_H_13' => 7,
                                  'PORT_J_03' => 7,
                                  'PORT_F_03' => 1,
                                  'PORT_M_04' => 7,
                                  'PORT_F_00' => 1
                                },
                  'CAN_01' => {
                                  'PORT_A_10' => 1,
                                  'PORT_L_04' => 1,
                                  'PORT_L_01' => 1,
                                  'PORT_B_10' => 1,
                                  'PORT_A_12' => 1
                                },
                  'CAN_03' => {
                                  'PORT_C_00' => 1,
                                  'PORT_J_01' => 1,
                                  'PORT_F_15' => 1
                                },
                  'CAN_14' => {
                                  'PORT_E_10' => 18,
                                  'PORT_B_08' => 5,
                                  'PORT_J_10' => 7,
                                  'PORT_D_00' => 1,
                                  'PORT_E_00' => 1,
                                  'PORT_M_01' => 1,
                                  'PORT_H_04' => 14,
                                  'PORT_F_10' => 3,
                                  'PORT_M_06' => 14,
                                  'PORT_F_01' => 7
                                },
                  'CAN_02' => {
                                  'PORT_M_10' => 1,
                                  'PORT_J_06' => 1,
                                  'PORT_C_09' => 1,
                                  'PORT_A_02' => 1,
                                  'PORT_H_07' => 1
                                },
                  'CAN_12' => {
                                  'PORT_M_05' => 7,
                                  'PORT_E_10' => 1,
                                  'PORT_D_05' => 1,
                                  'PORT_F_13' => 7,
                                  'PORT_A_03' => 1,
                                  'PORT_E_01' => 7,
                                  'PORT_J_14' => 1,
                                  'PORT_C_06' => 7,
                                  'PORT_L_05' => 1
                                },
                },
        'Rx' => {
                  'CAN_11' => {
                                  'PORT_L_06' => 5,
                                  'PORT_C_01' => 8,
                                  'PORT_H_12' => 4,
                                  'PORT_A_11' => 1,
                                  'PORT_F_06' => 3,
                                  'PORT_L_10' => 6,
                                  'PORT_F_03' => 2,
                                  'PORT_D_02' => 11,
                                  'PORT_H_10' => 10,
                                  'PORT_J_02' => 9
                                },
                  'CAN_00' => {
                                  'PORT_G_14' => 2,
                                  'PORT_E_06' => 9,
                                  'PORT_D_15' => 1,
                                  'PORT_C_07' => 1,
                                  'PORT_C_06' => 2,
                                  'PORT_M_08' => 3,
                                  'PORT_L_10' => 5
                                },
                  'CAN_03' => {
                                  'PORT_H_09' => 8,
                                  'PORT_L_03' => 13,
                                  'PORT_A_11' => 11,
                                  'PORT_M_08' => 18,
                                  'PORT_L_10' => 20,
                                  'PORT_E_00' => 1,
                                  'PORT_D_04' => 5,
                                  'PORT_L_00' => 14,
                                  'PORT_G_14' => 17,
                                  'PORT_F_14' => 3,
                                  'PORT_C_07' => 19,
                                  'PORT_J_00' => 2,
                                  'PORT_B_09' => 15,
                                  'PORT_J_07' => 10,
                                  'PORT_E_06' => 4,
                                  'PORT_D_15' => 16,
                                  'PORT_A_01' => 7,
                                  'PORT_C_08' => 6,
                                  'PORT_A_13' => 12,
                                  'PORT_F_05' => 9
                                },
                  'CAN_14' => {
                                  'PORT_M_03' => 8,
                                  'PORT_C_00' => 4,
                                  'PORT_I_14' => 7,
                                  'PORT_A_08' => 1,
                                  'PORT_F_09' => 6,
                                  'PORT_E_11' => 9,
                                  'PORT_J_11' => 11,
                                  'PORT_D_01' => 5,
                                  'PORT_F_00' => 10,
                                  'PORT_H_10' => 12,
                                  'PORT_B_09' => 3
                                },
                  'CAN_02' => {
                                  'PORT_H_09' => 5,
                                  'PORT_J_07' => 7,
                                  'PORT_L_03' => 8,
                                  'PORT_A_11' => 2,
                                  'PORT_C_08' => 3,
                                  'PORT_A_01' => 4,
                                  'PORT_L_00' => 9,
                                  'PORT_A_13' => 1,
                                  'PORT_F_05' => 6,
                                  'PORT_B_09' => 10
                                },
                  'CAN_12' => {
                                  'PORT_D_07' => 3,
                                  'PORT_B_08' => 1,
                                  'PORT_K_15' => 11,
                                  'PORT_E_11' => 4,
                                  'PORT_J_15' => 5,
                                  'PORT_C_07' => 2,
                                  'PORT_E_02' => 9,
                                  'PORT_L_02' => 6,
                                  'PORT_E_09' => 7
                                },
                  'CAN_13' => {
                                  'PORT_C_05' => 3,
                                  'PORT_C_14' => 4,
                                  'PORT_H_12' => 13,
                                  'PORT_M_02' => 7,
                                  'PORT_F_02' => 9,
                                  'PORT_A_14' => 2,
                                  'PORT_M_01' => 12,
                                  'PORT_J_13' => 6,
                                  'PORT_F_01' => 8,
                                  'PORT_G_13' => 11,
                                  'PORT_J_04' => 10
                                },
                  'CAN_01' => {
                                  'PORT_H_09' => 8,
                                  'PORT_J_07' => 10,
                                  'PORT_L_03' => 3,
                                  'PORT_A_11' => 2,
                                  'PORT_C_08' => 6,
                                  'PORT_A_01' => 7,
                                  'PORT_L_00' => 4,
                                  'PORT_A_13' => 1,
                                  'PORT_F_05' => 9,
                                  'PORT_B_09' => 5
                                }
                }
    );

    if (!exists($CanPortMux_h{$Dir_s}{$CanNode_s}{$Input_s}))
    {
        # illegal port for CAN operation
        @Return_a = (0,
                        "#   Configured port $Input_s is not a $CanNode_s $Dir_s port.\n" .
                        "#   List of supported CAN $Dir_s pins for $CanNode_s are: " .
                        join(", ", sort(keys(%{$CanPortMux_h{$Dir_s}{$CanNode_s}}))) . "\n"
                    );
    }
    else
    {
        @Return_a = ($CanPortMux_h{$Dir_s}{$CanNode_s}{$Input_s}, undef);
    }
    return (@Return_a);
}

# In the past we put an anonymous function at the end of a perl modul which returned 1
# {
#   1;
# }
# but it seems that this only works if the reqire is in the same sub (same level) which is called by conf_process
# if the require is called from a sub insinde the sub which is called by conf_process this does not work.

# Form: http://perldoc.perl.org/functions/require.html
# The file must return true as the last statement to indicate successful execution of any initialization code,
# so it's customary to end such a file with 1; unless you're sure it'll return true otherwise. But it's better just
# to put the 1; , in case you add more statements.

1;

#<RBHead>
#***********************************************************************************************************************
# $History$
#***********************************************************************************************************************
#</RBHead>
