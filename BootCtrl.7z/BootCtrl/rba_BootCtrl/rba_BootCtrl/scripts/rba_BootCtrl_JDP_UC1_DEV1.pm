#<RBHead>
#************************************************************************
#                                                                       *
#                      ROBERT BOSCH GMBH                                *
#                          STUTTGART                                    *
#                                                                       *
#          Alle Rechte vorbehalten - All rights reserved                *
#                                                                       *
#************************************************************************
#
#************************************************************************
#    Administrative Information (automatically filled in by eASEE)      *
#************************************************************************
#
# $Filename__:$
#
# $Author____:$
#
# $Function__:$
#
#************************************************************************
# $Domain____:$
# $User______:$
# $Date______:$
# $Class_____:$
# $Name______:$
# $Variant___:$
# $Revision__:$
# $Type______:$
# $State_____:$
# $Generated_:$
#************************************************************************
#
# $UniqueName:$
# $Component_:$
#
#
#************************************************************************
#</RBHead>

# The following table was extracted from the following Excel Export
# D4 - Matterhorn (MPC5777M) Rev1.0 |  I/O Signal Table | Freescale / ST Microelectronics Confidential Proprietary | 17.01.2013

package rba_BootCtrl_uC1_Dev;
use strict;
use warnings;

#----------------------------------------------------------------------------------------------------------------------
# Subroutine to check validity of selected CAN port and get pin configuration value (JDP: MSCR_SSS) (IFX: CAN_NPCR)
#
# Parameters:
# $_[0]: input signal (JDP: PORT_X_YY) (IFX: PORT_XX_YY)
# $_[1]: can node
# $_[2]: direction ('Rx' or 'Tx')
# Return:
# value assigned to input
#----------------------------------------------------------------------------------------------------------------------
sub GetCanPin
{
    my $Input_s     = $_[0];
    my $CanNode_s   = $_[1];
    my $Dir_s       = $_[2];
    my @Return_a;

    my %CanPortMux_h = (
        'Tx' => {
                  'CAN_01'  => {
                                 'PORT_A_10' => 1,
                                 'PORT_A_12' => 1
                               },
                  'CAN_02'  => {
                                 'PORT_C_09' => 1,
                                 'PORT_A_02' => 1
                               }
                },
        'Rx' => {
                  'CAN_01'  => {
                                 'PORT_A_13' => 1,
                                 'PORT_A_11' => 2
                               },
                  'CAN_02'  => {
                                 'PORT_A_13' => 1,
                                 'PORT_A_11' => 2,
                                 'PORT_C_08' => 3,
                                 'PORT_A_01' => 4
                               }
                }
    );

    # Map old CAN node to new value to support legacy configuration in projects
    my $CanNode_ref = $CanPortMux_h{'Tx'}{'CAN_01'};
    $CanPortMux_h{'Tx'}{'M_CAN_1'} = $CanNode_ref;
    $CanNode_ref = $CanPortMux_h{'Rx'}{'CAN_01'};
    $CanPortMux_h{'Rx'}{'M_CAN_1'} = $CanNode_ref;
    # end of legacy configuration support

    if (!exists($CanPortMux_h{$Dir_s}{$CanNode_s}{$Input_s}))
    {
        # illegal port for CAN operation
        @Return_a = (0,
                        "#   Configured port $Input_s is not a $CanNode_s $Dir_s port.\n" .
                        "#   List of supported CAN $Dir_s pins for $CanNode_s are: " .
                        join(", ", sort(keys(%{$CanPortMux_h{$Dir_s}{$CanNode_s}}))) . "\n"
                    );
    }
    else
    {
        @Return_a = ($CanPortMux_h{$Dir_s}{$CanNode_s}{$Input_s}, undef);
    }
    return (@Return_a);
}

# In the past we put an anonymous function at the end of a perl modul which returned 1
# {
#   1;
# }
# but it seems that this only works if the reqire is in the same sub (same level) which is called by conf_process
# if the require is called from a sub insinde the sub which is called by conf_process this does not work.

# Form: http://perldoc.perl.org/functions/require.html
# The file must return true as the last statement to indicate successful execution of any initialization code,
# so it's customary to end such a file with 1; unless you're sure it'll return true otherwise. But it's better just
# to put the 1; , in case you add more statements.

1;

#<RBHead>
#***********************************************************************************************************************
# $History$
#***********************************************************************************************************************
#</RBHead>
