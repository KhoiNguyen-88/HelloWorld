#<RBHead>
#************************************************************************
#                                                                       *
#                      ROBERT BOSCH GMBH                                *
#                          STUTTGART                                    *
#                                                                       *
#          Alle Rechte vorbehalten - All rights reserved                *
#                                                                       *
#************************************************************************
#
#************************************************************************
#    Administrative Information (automatically filled in by eASEE)      *
#************************************************************************
#
# $Filename__:$
#
# $Author____:$
#
# $Function__:$
#
#************************************************************************
# $Domain____:$
# $User______:$
# $Date______:$
# $Class_____:$
# $Name______:$
# $Variant___:$
# $Revision__:$
# $Type______:$
# $State_____:$
# $Generated_:$
#************************************************************************
#
# $UniqueName:$
# $Component_:$
#
#
#************************************************************************
#</RBHead>

package rba_BootCtrl_Jdp_uC1;
use strict;
use warnings;

#----------------------------------------------------------------------------------------------------------------------
# Subroutine to get the index for SIUL.GPDI / SIUL.GPDO register
# The lookuptable is is valid and use for all machine types which
# do not have a dedicaded lookuptable (Dio_JDP_UC1_DEVx.pm) in the scripts folder
# This means it contains all the port pins for the biggest package.
# No no conf process abort if smaller packages does not have the
# pins -> Port script will abort.
#
# Parameters:
# $_[0]: Port Name
# $_[1]: Pin Number
#----------------------------------------------------------------------------------------------------------------------

sub GetMSCR_RegIdx
{
    my $port_s = $_[0];
    my $pin_s  = $_[1];
    my @return_a;

    ##########################################################################################################
    # If the below table is changed, also change it in Dio_GenMSCRLookupTab.pm -> CheckForLogicalConformance #
    ##########################################################################################################
    my %BaseLookUp_h = (
        A =>  0,
        B =>  1,
        C =>  2,
        D =>  3,
        E =>  4,
        F =>  5,
        G =>  6,
        H =>  7,
        I =>  8,
        J =>  9,
        K => 10,
        L => 11,
        M => 12,
        N => 13,
      # O           Not Available
      # P           Not Available
        Q => 14,
        R => 15,
        S => 16,
        T => 17,
      # U           Not Available
        V => 18,
        W => 19,
        X => 20,
        Y => 21,
    );

    # workaround for device selection: CpuType information is not passed through an argument due to bug in JDP Dev4 silicon
    # once JDP Dev4 is not supported anymore this function will not need CpuType information anymore.
    my $mcu_hr = conf_process::GetInvariantInputData("Mcu");
    my $BootCtrl_CpuType = $mcu_hr->{'McuRbCpuInformation'}{'McuRbMachineType'}{'content'};

    if ($BootCtrl_CpuType eq 'MCU_RB_JDP_UC1_DEV4_C2')
    {
        # special treatment for JDP Dev4
        @return_a = rba_BootCtrl_uC1_Dev::GetMSCR_RegIdx($port_s, $pin_s);
    }
    else
    {
        # all other JDP/ST devices
        if(exists $BaseLookUp_h{$port_s})
        {
            # Return index and no error message
            @return_a = ((($BaseLookUp_h{$port_s} * 16) + $pin_s), undef);
        }
        else
        {
            @return_a = (0,
                "# Port $port_s is invalid \n" .
                "# Valid Ports are:    " . join(",", sort(keys(%BaseLookUp_h))) . "\n"
            );
        }
    }
    return @return_a;
}

#----------------------------------------------------------------------------------------------------------------------
# Subroutine to get the port for SIUL.GPDPI / SIUL.GPDPO register
# The lookuptable is valid and use for all machine types which
# do not have a dedicaded lookuptable (Dio_JDP_UC1_DEVx.pm) in the scripts folder
# This means it contains all the port pins for the biggest package.
# No conf process abort if smaller packages does not have the
# pins -> Port script will abort.
#
# Parameters:
# $_[0]: Port Name
#----------------------------------------------------------------------------------------------------------------------
sub GetMSCR_PortIdx
{
    my $port_s = $_[0];

    my %BaseLookUp_h = (
        A =>
            {
                regIndex => 0,
                numShift => 0,
            },
        B =>
            {
                regIndex => 1,
                numShift => 0,
            },
        C =>
            {
                regIndex => 2,
                numShift => 0,
            },
        D =>
            {
                regIndex => 3,
                numShift => 0,
            },
        E =>
            {
                regIndex => 4,
                numShift => 0,
            },
        F =>
            {
                regIndex => 5,
                numShift => 0,
            },
        G =>
            {
                regIndex => 6,
                numShift => 0,
            },
        H =>
            {
                regIndex => 7,
                numShift => 0,
            },
        I =>
            {
                regIndex => 8,
                numShift => 0,
            },
        J =>
            {
                regIndex => 9,
                numShift => 0,
            },
        K =>
            {
                regIndex => 10,
                numShift => 0,
            },
        L =>
            {
                regIndex => 11,
                numShift => 0,
            },
        M =>
            {
                regIndex => 12,
                numShift => 0,
            },
        N =>
            {
                regIndex => 13,
                numShift => 0,
            },
      # O           Not Available
      # P           Not Available
        Q =>
            {
                regIndex => 14,
                numShift => 0,
            },
        R =>
            {
                regIndex => 15,
                numShift => 0,
            },
        S =>
            {
                regIndex => 16,
                numShift => 0,
            },
        T =>
            {
                regIndex => 17,
                numShift => 0,
            },
      # U           Not Available
        V =>
            {
                regIndex => 18,
                numShift => 0,
            },
        W =>
            {
                regIndex => 19,
                numShift => 0,
            },
        X =>
            {
                regIndex => 20,
                numShift => 0,
            },
        Y =>
            {
                regIndex => 21,
                numShift => 0,
            }
    );

    if(exists $BaseLookUp_h{$port_s})
    {
        # Return index and no error message
        return ($BaseLookUp_h{$port_s}{regIndex}, undef);
    }
    else
    {
        return(0,
            "# Port $port_s is invalid \n" .
            "# Valid Ports are:    " . join(",", sort(keys(%BaseLookUp_h))) . "\n"
        );
    }
}

#----------------------------------------------------------------------------------------------------------------------
# Subroutine to find SIUL_MSCR value corresponding to a given port.
#
# Parameters:
# $_[0]: Port Name using PORT_X_YY format
# Return:
# MscrValue, error text
#----------------------------------------------------------------------------------------------------------------------
sub FindSiulMscrValueForPort
{
    my $OutputMscr_s;
    my $ErrorMsg_s;
    my $port_s;
    my $pin_s;
    my $InputPort_s = $_[0];                # input: PORT_X_YY
    $InputPort_s =~ s/PORT_//;              # remove preceded port indication: X_YY remains
    $InputPort_s =~ m/^(\w{1})_(\d{2})/;    # split X_YY into
    $port_s = $1;                           # port X and
    $pin_s = $2;                            # pin YY
    # find Siul MSCR value
    ($OutputMscr_s, $ErrorMsg_s) = GetMSCR_RegIdx($port_s, $pin_s);
    # return result and error information
    return ($OutputMscr_s, $ErrorMsg_s);
}

#----------------------------------------------------------------------------------------------------------------------
# Subroutine to find base address of a peripheral from rba_Reg.
# possible extension of function: add parameter for how many low bits of base addr should be set to zero (correction).
#
# Parameters:
# $_[0]: name of peripheral
# Return:
# base address address
#----------------------------------------------------------------------------------------------------------------------
sub CalcBaseAddressForPeripheral
{
    my $Peripheral_s = $_[0];
    my $BaseAddr_s = 0x00;
    # get access to rba_Reg
#    my $reg_hr = conf_process::Pop("rba_Reg");
    my $reg_hr = conf_process::GetInvariantInputData("rba_Reg");
    # search module in rba_Reg
    foreach my $regMod_a (@{$reg_hr->{rba_Reg_Module}})
    {
        if ($regMod_a->{rba_Reg_Module__KEY}->{content} eq $Peripheral_s)
        {
            # module found
            $BaseAddr_s = hex($regMod_a->{rba_Reg_Module_BaseAddr}->{content});
            # correction of base address from rba_Reg
            my $CorrVal_s = $BaseAddr_s % 0x10;
            if ($CorrVal_s != 0)
            {
                $BaseAddr_s -= $CorrVal_s;
            }
        }
    }
    return ($BaseAddr_s);
}

#----------------------------------------------------------------------------------------------------------------------
# Subroutine to find SIUL_MSCR address corresponding to given Siul MSCR value.
# formula from SIUL manual: RegisterAddress = Siul2BaseAddress + 0x240 + (MscrValue * 4)
#
# Parameters:
# $_[0]: MSCR value
# Return:
# MSCR address
#----------------------------------------------------------------------------------------------------------------------
sub CalcSiulMscrAddressForMscrValue
{
    my $addr_s = $_[0];
    my $siul2_baseAdr_s;

    $siul2_baseAdr_s = CalcBaseAddressForPeripheral('SIUL2_PD');
    if ($siul2_baseAdr_s != 0)
    {
        # base addr was found: apply formula to add offset for mscr register
        $addr_s *= 4;                       # MSCR value * 4
        $addr_s += 576;                     # 576dez equals 0x240
        # add base address from rba_Reg
        $addr_s += $siul2_baseAdr_s;
    }
    return $addr_s;
}

#----------------------------------------------------------------------------------------------------------------------
# Subroutine to find SIUL_GPDO address corresponding to given Siul MSCR value.
# formula from SIUL manual: RegisterAddress = Siul2BaseAddress + 0x1300 + MscrValue
# twi: maybe merge function with CalcSiulMscrAddressForMscrValue as it's almost the same
#
# Parameters:
# $_[0]: MSCR value
# Return:
# GPDO address
#----------------------------------------------------------------------------------------------------------------------
sub CalcSiulGpdoAddressForMscrValue
{
    my $addr_s = $_[0];
    my $siul2_baseAdr_s;

    $siul2_baseAdr_s = CalcBaseAddressForPeripheral('SIUL2_PD');
    if ($siul2_baseAdr_s != 0)
    {
        # base addr was found: apply formula to add offset for mscr register
        $addr_s += 4864;                # 4864dez equals 0x1300
        # add base address from rba_Reg
        $addr_s += $siul2_baseAdr_s;
    }
    return $addr_s;
}

# In the past we put an anonymous function at the end of a perl modul which returned 1
# {
#   1;
# }
# but it seems that this only works if the require is in the same sub (same level) which is called by conf_process
# if the require is called from a sub inside the sub which is called by conf_process this does not work.

# Form: http://perldoc.perl.org/functions/require.html
# The file must return true as the last statement to indicate successful execution of any initialization code,
# so it's customary to end such a file with 1; unless you're sure it'll return true otherwise. But it's better just
# to put the 1; , in case you add more statements.

1;

#<RBHead>
#***********************************************************************************************************************
# $History$
#***********************************************************************************************************************
#</RBHead>
