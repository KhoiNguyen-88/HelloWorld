/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, 2010 Robert Bosch GmbH. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************
* Administrative Information (automatically filled in)
* $Domain____:$
* $Namespace_:$
* $Class_____:$
* $Name______:$
* $Variant___:$
* $Revision__:$
**********************************************************************************************************************
</BASDKey>*/   

#ifndef RBA_BOOTCTRL_MAP_H
#define RBA_BOOTCTRL_MAP_H


//---------------------------------------------------------------------------------------------------------------------
// Includes
//---------------------------------------------------------------------------------------------------------------------
#include "Std_Types.h"

#if defined(__TASKING__) || defined(__ghs__)
#  define RBA_BOOTCTRL_USE_FIXRAM(typ, var)              typ var __attribute__ ((section(".bss.bootCtrlFixRam")))
#else
#  define RBA_BOOTCTRL_USE_FIXRAM(typ, var)              typ var __attribute__ ((asection(".bootCtrlFixRam","f=aw")))
#endif
//#define BOOTCTRL_USE_SECTION(typ, var, section)    typ var __attribute__ ((asection(.section, f=aw)))

#endif

/*<BASDKey>
**********************************************************************************************************************
* $History__:$
**********************************************************************************************************************
</BASDKey>*/

/*<BASDKey>
**********************************************************************************************************************
* End of header file: $Name___:$
**********************************************************************************************************************
</BASDKey>*/
