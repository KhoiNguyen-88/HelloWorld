/*<RBHead>
 ***********************************************************************************************************************
 *                                                                                                                     *
 *                                                  ROBERT BOSCH GMBH                                                  *
 *                                                      STUTTGART                                                      *
 *                                                                                                                     *
 *                                    Alle Rechte vorbehalten - All rights reserved                                    *
 *                                                                                                                     *
 ***********************************************************************************************************************

 ***********************************************************************************************************************
 * Administrative information (automatically filled in by eASEE)
 ***********************************************************************************************************************
 *
 * $Filename__:$
 *
 * $Author____:$
 *
 * $Function__:$
 *
 ***********************************************************************************************************************
 * $Domain____:$
 * $User______:$
 * $Date______:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 * $Type______:$
 * $State_____:$
 * $Generated_:$
 ***********************************************************************************************************************
 *
 * $UniqueName:$
 * $Component_:$
 *
 ***********************************************************************************************************************
</RBHead>*/

#ifndef RBA_BOOTCTRL_TARGET_H
#define RBA_BOOTCTRL_TARGET_H


//---------------------------------------------------------------------------------------------------------------------
// Includes
//---------------------------------------------------------------------------------------------------------------------
#include "Std_Types.h"

typedef enum
{
    NO_PROZ_E,
    IFX_DEV1_E,
    IFX_DEV2_E,
    IFX_DEV3_E,
    IFX_DEV3_PRE_E,
    IFX_DEV4_E,
    JDP_DEV1_E,
    JDP_DEV2_E,
    JDP_DEV3_E,
    JDP_DEV4_E,
    IFX_DEV3_B_E
} Target_CPUType_ten;

/* structure for PLL lock time */
typedef struct
{
    uint32 tiDiffPll0_u32;              /* PLL lock time in timer ticks */
    uint32 tiDiffPll1_u32;              /* PLL lock time in timer ticks */
    uint32 frqStmMeasLockTiPll0_u32;    /* timer frequency (in kHz) used for measurement */
    uint32 frqStmMeasLockTiPll1_u32;    /* timer frequency (in kHz) used for measurement */
} Target_PLL_lock_time_tst;

/* Structure for detection of target init */
typedef struct
{
    uint32               fSysFreq_u32;                           /* System frequency in kHz            */
} Target_Info_tst;

RBA_BOOTCTRL_USE_FIXRAM(extern Target_Info_tst, Target_Info_st);
RBA_BOOTCTRL_USE_FIXRAM(extern Target_PLL_lock_time_tst, rba_BootCtrl_tiPllLock_st);

#endif

/*<RBHead>
 ***********************************************************************************************************************
 * List of changes
 *
 * $History$
 *
 ***********************************************************************************************************************
</RBHead>*/
