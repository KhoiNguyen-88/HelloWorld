/*<RBHead>
 ***********************************************************************************************************************
 *                                                                                                                     *
 *                                                  ROBERT BOSCH GMBH                                                  *
 *                                                      STUTTGART                                                      *
 *                                                                                                                     *
 *                                    Alle Rechte vorbehalten - All rights reserved                                    *
 *                                                                                                                     *
 ***********************************************************************************************************************

 ***********************************************************************************************************************
 * Administrative information (automatically filled in by eASEE)
 ***********************************************************************************************************************
 *
 * $Filename__:$
 *
 * $Author____:$
 *
 * $Function__:$
 *
 ***********************************************************************************************************************
 * $Domain____:$
 * $User______:$
 * $Date______:$
 * $Class_____:$
 * $Name______:$
 * $Variant___:$
 * $Revision__:$
 * $Type______:$
 * $State_____:$
 * $Generated_:$
 ***********************************************************************************************************************
 *
 * $UniqueName:$
 * $Component_:$
 *
 ***********************************************************************************************************************
</RBHead>*/

#ifndef RBA_BOOTCTRL_H
#define RBA_BOOTCTRL_H

/*
 *********************************************************************
 * Includes
 *********************************************************************
 */
#ifndef LINK_RUN
#   include "Std_Types.h"
#   include "Mcu.h"
#   include "rba_BootCtrl_Map.h"
#   include "rba_BootCtrl_Target.h"
#   include "rba_BootCtrl_Potest.h"
#endif


#if (MCU_RB_MACHINE_FAM == MCU_RB_JDP_UC1)
#define write_MSR(Wert) \
asm volatile(      \
        "mtmsr  %0;"   \
        : : "r"(Wert)   \
        );

#define Enable_Interrupt()        \
asm volatile(                     \
        "mfmsr   %r3;"            \
        "e_or2i  %r3, 0x8000;"    \
        "mtmsr   %r3;"            \
        );
#endif

#define RBA_BOOTCTRL_CODE_START                  RBA_MEMLAY_BOOTCTRL_START
#define RBA_BOOTCTRL_CODE_END                    RBA_MEMLAY_BOOTCTRL_END

#define RBA_BOOTCTRL_HEADER_START                (RBA_MEMLAY_BOOTCTRL_START - RBA_MEMLAY_UL(0x20))
#define RBA_BOOTCTRL_HEADER_END                  (RBA_MEMLAY_BOOTCTRL_START - RBA_MEMLAY_UL(0x1))

#if (MCU_RB_MACHINE_FAM == MCU_RB_IFX_UC1)
#   define RBA_BOOTCTRL_DMI_RAM_START               RBA_MEMLAY_RAM0_START
#   define RBA_BOOTCTRL_DMI_RAM_END                 RBA_MEMLAY_RAM0_END
#   define RBA_BOOTCTRL_PMI_RAM_START               RBA_MEMLAY_PRAM0_START
#   define RBA_BOOTCTRL_PMI_RAM_END                 RBA_MEMLAY_PRAM0_END

#   if (MCU_RB_TECHNOLOGY == MCU_RB_40NM)
#       define RBA_BOOTCTRL_HEADER2_START               RBA_MEMLAY_UL(0x80090000)
#       define RBA_BOOTCTRL_ERASE_BOOT2_START           RBA_MEMLAY_UL(0x80090000)
#       define RBA_BOOTCTRL_ERASE_BOOT2_END             RBA_MEMLAY_UL(0x8009FFFF)
#   else
#       define RBA_BOOTCTRL_HEADER2_START               RBA_MEMLAY_UL(0x80020000)
#       define RBA_BOOTCTRL_ERASE_BOOT2_START           RBA_MEMLAY_UL(0x8001C000)
#       define RBA_BOOTCTRL_ERASE_BOOT2_END             RBA_MEMLAY_UL(0x8002FFFF)
#   endif
#endif

#if (MCU_RB_MACHINE_FAM == MCU_RB_JDP_UC1)
#   define RBA_BOOTCTRL_ERASE_BOOT21_START          RBA_MEMLAY_UL(0x08FD8000)
#   define RBA_BOOTCTRL_ERASE_BOOT21_END            RBA_MEMLAY_UL(0x08FFFFFF)

#   if (MCU_RB_MACHINE_TYPE == MCU_RB_JDP_UC1_DEV1)
#       define RBA_BOOTCTRL_HEADER2_START           RBA_MEMLAY_UL(0x09040000)
#       define RBA_BOOTCTRL_ERASE_BOOT2_START       RBA_MEMLAY_UL(0x09040000)
#       define RBA_BOOTCTRL_ERASE_BOOT2_END         RBA_MEMLAY_UL(0x0907FFFF)
#       define RBA_BOOTCTRL_DMI_RAM_START           RBA_MEMLAY_RAM0_START
#       define RBA_BOOTCTRL_DMI_RAM_END             RBA_MEMLAY_RAM0_END
#		define RBA_BOOTCTRL_SECTOR_END				RBA_MEMLAY_UL(0x0903FFFF)
#   else
#       define RBA_BOOTCTRL_HEADER2_START           RBA_MEMLAY_UL(0x09000000)
#       define RBA_BOOTCTRL_ERASE_BOOT2_START       RBA_MEMLAY_UL(0x09000000)
#       define RBA_BOOTCTRL_ERASE_BOOT2_END         RBA_MEMLAY_UL(0x0903FFFF)
#       define RBA_BOOTCTRL_PMI_RAM_START           RBA_MEMLAY_PRAM0_START
#       define RBA_BOOTCTRL_PMI_RAM_END             RBA_MEMLAY_PRAM0_END
#   endif

#   if (MCU_RB_MACHINE_DEV == MCU_RB_JDP_UC1_DEV1_ALL)
#       define RBA_BOOTCTRL_ECUSECUSRV_START            RBA_MEMLAY_UL(0x9020000)
#       define RBA_BOOTCTRL_ECUSECUSRV_END              RBA_MEMLAY_UL(0x902BFFF)
#       define RBA_BOOTCTRL_ECUSECUSRV_COPY_START       RBA_MEMLAY_UL(0x9060000)
#       define RBA_BOOTCTRL_ECUSECUSRV_COPY_END         RBA_MEMLAY_UL(0x906BFFF)
#       define RBA_BOOTCTRL_ECUSECUSRV_HEADER_END       RBA_MEMLAY_UL(0x90200FF)
#       define RBA_BOOTCTRL_ECUSECUSRV_COPY_HEADER_END  RBA_MEMLAY_UL(0x90600FF)
#   endif
#endif

#define RBA_BOOTCTRL_CODE2_START                    (RBA_BOOTCTRL_HEADER2_START + RBA_MEMLAY_UL(0x20))

/* If the configuration size will be adjusted, it is necessary to change the size also in the perl script */
#if (MCU_RB_MACHINE_FAM == MCU_RB_IFX_UC1) && (MCU_RB_TECHNOLOGY == MCU_RB_40NM)
#   define RBA_BOOTCTRL_CONFIG_SIZE        RBA_MEMLAY_UL(0x280)
#else
#   define RBA_BOOTCTRL_CONFIG_SIZE        RBA_MEMLAY_UL(0x240)
#endif

#define RBA_BOOTCTRL_CONFIG_START       ( RBA_BOOTCTRL_CODE_END -                                     \
                                          (RBA_MEMLAY_EPILOG_SIZE + RBA_MEMLAY_UL(0x20) + RBA_BOOTCTRL_CONFIG_SIZE)  \
                                        + RBA_MEMLAY_UL(1) )

#endif

/*<RBHead>
 ***********************************************************************************************************************
 * List of changes
 *
 * $History$
 *
 ***********************************************************************************************************************
</RBHead>*/
