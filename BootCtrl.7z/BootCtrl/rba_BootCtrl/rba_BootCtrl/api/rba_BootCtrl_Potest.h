/*<BASDKey>
**********************************************************************************************************************
*
* COPYRIGHT RESERVED, 2010 Robert Bosch GmbH. All rights reserved.
* The reproduction, distribution and utilization of this document as well as the communication of its contents to
* others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
* All rights reserved in the event of the grant of a patent, utility model or design.
*
**********************************************************************************************************************
* Administrative Information (automatically filled in)
* $Domain____:$
* $Namespace_:$
* $Class_____:$
* $Name______:$
* $Variant___:$
* $Revision__:$
**********************************************************************************************************************
</BASDKey>*/   

#ifndef RBA_BOOTCTRL_POTEST_H
#define RBA_BOOTCTRL_POTEST_H

#include "Std_Types.h"
#include "rba_BootCtrl_Cfg.h"

/*********************************************************************
 * error types of POTest_Result_s.stResult_u8
 *********************************************************************/
enum {
    POTEST_OK_E,
    POTEST_IB_FAIL_E,
    POTEST_HW_FAIL_E
};

/* PowerOn Test results */
enum {
    /* flags of Infoblock check */
    POTEST_IB_CHECK_IB_FAIL_E = 0,
    POTEST_IB_CHECK_CSTAB_FAIL_E,
    POTEST_IB_CHECK_CSBLOCK_FAIL_E,
    POTEST_IB_CHECK_EMPTY_E,
    POTEST_IB_COMPIDFAIL_E,
    POTEST_IB_ENDPATTERN_FAIL_E,
    POTEST_IB_CB_OK_E,
    POTEST_IB_CB_END_E,
    POTEST_IB_CB_COPYPAGE_E,
    POTEST_IB_TPB_OK_E,
    POTEST_SB_COPYPAGE_E,
    POTEST_HSB_FAIL_E,
    POTEST_IB_CONFIG_FAILURE_E,
    POTEST_IB_CHAIN_INTERRUPTED_E,
    POTEST_SB_MISMATCH_CPU_E
};

typedef struct {
    uint8 dType_u8;
    uint32 stResult_u32;
    uint8 dInfo_au8[8];
} POTest_Result_tst;

#endif

/*<BASDKey>
**********************************************************************************************************************
* $History__:$
**********************************************************************************************************************
</BASDKey>*/

/*<BASDKey>
**********************************************************************************************************************
* End of header file: $Name___:$
**********************************************************************************************************************
</BASDKey>*/
