#<BASDKey>
#***********************************************************************************************************************
#
# COPYRIGHT RESERVED, Robert Bosch GmbH, 2014. All rights reserved.
# The reproduction, distribution and utilization of this document as well as the communication of its contents to
# others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
# All rights reserved in the event of the grant of a patent, utility model or design.
#
#***********************************************************************************************************************
# Administrative Information (automatically filled in)
# $Domain____:$
# $Namespace_:$
# $Class_____:$
# $Name______:$
# $Variant___:$
# $Revision__:$
#***********************************************************************************************************************
#</BASDKey>

package rba_Msc_SetCmdVal;

#-----------------------------------------------------------------------------------------------------------------------

=head1 Test specification for rba_Msc_SetCmdVal

This is the test specification as XML description

<TestConfiguration>
  <TC_Id>rba_Msc_AR40.2.0.0_Itf_SetCmdVal</TC_Id>
  <TC_BL></TC_BL>
  <TC_Spec></TC_Spec>
  <TC_EnvCond></TC_EnvCond>
  <TC_ExpRes></TC_ExpRes>
  <TestStep></TestStep>
  <TestMethod></TestMethod>
  <TestPrep></TestPrep>
  <TestType>automated</TestType>
  <Environment></Environment>
  <ResConsumption></ResConsumption>
  <CoveredReq_Id>
BSW_SWS_MCAL_Msc_RBA-2720,
BSW_SWS_MCAL_Msc_RBA-2733,
BSW_SWS_MCAL_Msc_RBA-2734
  </CoveredReq_Id>
  <CoveredReq_Doc>BSW_SWS_MCAL_Msc_RBA</CoveredReq_Doc>
</TestConfiguration>

=cut

#-----------------------------------------------------------------------------------------------------------------------

use STEPS_general;
use STEPS_NET;
use STEPS_NET_Reports;
use STEPS_BSWITF;
use STEPS_BSWITF_BSW;
use STEPS_BSWITF_ECU;
use STEPS_BSWITF_Debugger;

use strict;
use warnings;

use rba_Msc_TestLib;

# global variables
my $TestResult_s;    # test result of the test case (result of all test steps)
my $ude_s = undef;   # handle for accessing UDE functionality


#-----------------------------------------------------------------------------------------------------------------------
sub TC_set_parameters
{
  # set initial parameters for the test cases
  $TestResult_s = RESULT_PASSED;
  $ude_s        = new UdeControl();
  return (1);
}


#-----------------------------------------------------------------------------------------------------------------------
sub TC_initialization
{
  BSWITF_Init();
  return (1);
}


#-----------------------------------------------------------------------------------------------------------------------
sub TC_stimulation_and_measurement
{
  # variables containing describing text
  my $testStep_s;
  my $testStepDesc_s;
  my $testStepPrecond_s;
  my $testStepExpectedBehav_s;
  my $testStepResult_s;
  my $strTestCd_s;
  my $cntBreakPoint_s;

  # get the DET status
  my $detReportEnabled_s = getDetStatus($ude_s);

  #---------------------------------------------------------------------------------------------------------------------
  # check normal operation
  #---------------------------------------------------------------------------------------------------------------------
  $testStep_s              = "rba_Msc_SetCmdVal_NormalOperation";
  $testStepDesc_s          = "Call rba_Msc_SetCmdVal() with correct parameters";
  $testStepPrecond_s       = "MSC driver is initialized and switched to interrupt mode";
  $testStepExpectedBehav_s = "No DET entry, return value E_OK, set command value is 0x2A5A";

  printTestStepInfo($testStep_s, $testStepDesc_s, $testStepPrecond_s, $testStepExpectedBehav_s);

  # prepare test step execution
  $strTestCd_s      = "TestCd_rba_Msc_ItfSetCmdVal_e";
  $testStepResult_s = RESULT_PASSED;

  # execute test step depending on DET status
  if ($detReportEnabled_s)
  {
    # DET is enabled
    # -> execute test step and check if a DET entry is made by rba_Msc
    $cntBreakPoint_s = execTestStepEvalDetReportErrorBreakPoint($ude_s, $strTestCd_s,
                                                                RBA_MSC_MODULE_ID,
                                                                RBA_MSC_INSTANCE_ID);
  }
  else
  {
    # DET is disabled
    # -> execute test step without DET check
    execTestStep($ude_s, $strTestCd_s);
  }

  # evaluate test step result
  if ($detReportEnabled_s && ($cntBreakPoint_s != 0))
  {
    $testStepResult_s = RESULT_FAILED;
    printFailedReason("Det_ReportError was called in rba_Msc_SetCmdVal() but not expected.");
  }
  else
  {
    # check return value
    $testStepResult_s = evalRetVal($ude_s, $testStepResult_s, "stRet", E_OK);

    # check command value
    $testStepResult_s = evalRetVal($ude_s, $testStepResult_s, "xCmdVal_uo", 0x2A5A);
  }

  # result documentation
  $TestResult_s = documentTestStepResult($testStepResult_s, $TestResult_s);

  # clean up test step
  # -> nothing to do

  # if DET is enabled check all DET paths
  if ($detReportEnabled_s)
  {
    #-------------------------------------------------------------------------------------------------------------------
    # check DET RBA_MSC_E_UNINIT
    #-------------------------------------------------------------------------------------------------------------------
    $testStep_s              = "rba_Msc_SetCmdVal_Det_RBA_MSC_E_UNINIT";
    $testStepDesc_s          = "Call rba_Msc_SetCmdVal() while MSC driver is not initialized";
    $testStepPrecond_s       = "Do not initialize MSC driver (state patched by test driver)";
    $testStepExpectedBehav_s = "DET entry with error ID RBA_MSC_E_UNINIT, return value E_NO_OK";

    printTestStepInfo($testStep_s, $testStepDesc_s, $testStepPrecond_s, $testStepExpectedBehav_s);

    # prepare test step execution
    $testStepResult_s = RESULT_PASSED;
    $strTestCd_s      = "TestCd_rba_Msc_ItfSetCmdVal_UnInit_e";

    # execute test step and evaluate it
    $cntBreakPoint_s = execTestStepEvalDetReportErrorBreakPoint($ude_s, $strTestCd_s,
                                                                RBA_MSC_MODULE_ID,
                                                                RBA_MSC_INSTANCE_ID,
                                                                RBA_MSC_SERVICE_ID_SET_CMD_VAL,
                                                                RBA_MSC_E_UNINIT);

    # evaluate test step result
    $testStepResult_s = evalDet($ude_s, $testStepResult_s, $cntBreakPoint_s);
    $testStepResult_s = evalRetVal($ude_s, $testStepResult_s, "stRet", E_NOT_OK);

    # result documentation
    $TestResult_s = documentTestStepResult($testStepResult_s, $TestResult_s);

    # clean up test step
    # -> nothing to do

    #-------------------------------------------------------------------------------------------------------------------
    # check DET RBA_MSC_E_PARAM_CMD_IDX
    #-------------------------------------------------------------------------------------------------------------------
    $testStep_s              = "rba_Msc_SetCmdVal_Det_RBA_MSC_E_PARAM_CMD_IDX";
    $testStepDesc_s          = "Call rba_Msc_SetCmdVal() with invalid command index";
    $testStepPrecond_s       = "MSC driver is initialized and switched to interrupt mode";
    $testStepExpectedBehav_s = "DET entry with error ID RBA_MSC_E_PARAM_CMD_IDX, return value E_NO_OK";

    printTestStepInfo($testStep_s, $testStepDesc_s, $testStepPrecond_s, $testStepExpectedBehav_s);

    # prepare test step execution
    $testStepResult_s = RESULT_PASSED;
    $strTestCd_s      = "TestCd_rba_Msc_ItfSetCmdVal_InvldCmd_e";

    # execute test step and evaluate it
    $cntBreakPoint_s = execTestStepEvalDetReportErrorBreakPoint($ude_s, $strTestCd_s,
                                                                RBA_MSC_MODULE_ID,
                                                                RBA_MSC_INSTANCE_ID,
                                                                RBA_MSC_SERVICE_ID_SET_CMD_VAL,
                                                                RBA_MSC_E_PARAM_CMD_IDX);

    # evaluate test step result
    $testStepResult_s = evalDet($ude_s, $testStepResult_s, $cntBreakPoint_s);
    $testStepResult_s = evalRetVal($ude_s, $testStepResult_s, "stRet", E_NOT_OK);

    # result documentation
    $TestResult_s = documentTestStepResult($testStepResult_s, $TestResult_s);

    # clean up test step
    # -> nothing to do
  }

  return (1);
}


#-----------------------------------------------------------------------------------------------------------------------
sub TC_evaluation
{
  evalTestCaseResult($ude_s, $TestResult_s);
  return (1);
}


#-----------------------------------------------------------------------------------------------------------------------
sub TC_finalization
{
  # exit the test environment

  # clear the handle to enable following test cases to have access to the ude
  undef($ude_s);

  BSWITF_Exit();
  return (1);
}


#-----------------------------------------------------------------------------------------------------------------------
1;
#-----------------------------------------------------------------------------------------------------------------------

#<BASDKey>
#***********************************************************************************************************************
# $History___:$
#***********************************************************************************************************************
#</BASDKey>
